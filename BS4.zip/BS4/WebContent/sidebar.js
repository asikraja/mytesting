$(document).ready(function () {
	
	$('#demo').on('hide.bs.collapse', function () {
		$(".main").css("margin-left","0")
		$(".sidenav").css("width","0");
	})
	
	$('#demo').on('show.bs.collapse', function () {
		$(".sidenav").css("width","70px");
		$(".main").css("margin-left","70px");
	})
	
	var a=$( window ).height();
	var b=$(".navbar").height();
	var c=a-(b+b+39);

	$(".sidenav").css({"height":c+3,top:"58px"});
	$("#contentBody").css("height",c+3);
	
	$( window ).resize(function() {
		var a=$( window ).height();
		var b=$(".navbar").height();
		var c=a-(b+b+39);
		$("#contentBody").css("height",c+3);
		$(".sidenav").css({"height":c+3,top:"58px"});
		$(".sidenav").addClass("show");
		$(".sidenav").css("width","70px");
		$(".main").css("margin-left","70px");
	});
	
	$(".navbar-nav li").on("click",function(){
		$(".navbar-nav li").removeClass('active');
		$(this).addClass('active');
	});
	
});