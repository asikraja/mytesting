 
/**
 * CPF Additions & Deduction Script
 */ 

/*Datatable Initialisation*/
var cpfAccAddDedTable = $('#cpfAccAddDedTable').DataTable( {
   destroy: true,
   responsive: false,         
   ordering: false,
   searching: false,     
   scrollY:  "40vh",
   scrollX: true,
   scroller: false,
   scrollCollapse:false,
   paging:false, 
   filter:false,   
   columnDefs: [], 
   dom: '<<"top" ip>flt>',  
   columnDefs: [  { width: '20px', targets: [0,1]},
  	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10,11],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
   
		 }, 
}).draw();
	


/*Add Row Click */
$("#CpfADARow").on("click",function(){
			adctClearFlds();
			showFIPAModel('cpfAddDed_Dialog','CPF Additions & Deduction Details');   
			$('#cpfAddDed_Dialog').on('shown.bs.modal', function () {
				$("#cpfAddDed_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#cpfAddDed_Dialog").find("select[id=txtFldDlgCADApplicant]").focus();
				$("#cpfAddDed_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validateadctDetails())return;
					   	adctRdlyflds(INS_MODE);  
					   	getCADRows(null); 
						$('#cpfAddDed_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getCADRows(dataset){ 
	alert("inside getCADRows method->")

var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldCADMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="cdPkid"><input type="hidden" name="txtFldCADRefId">';

var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radadctSelect"/><label>&nbsp;</label></div>'; 
 
var cell2 ='<select name="txtFldCADApplicant" id="txtFldCADApplicant"  class="form-control editable"> </select>';

var cell3 ='<select name="selCdApplicantType" id="selCdApplicantType"  class="form-control editable"> </select>';
  
var cell4 ='<select name="selCADType" id="selCADType" class="form-control editable"> </select>';//description 
 
var cell5 ='<select name="selCADTypesOfTrans" id="selCADTypesOfTrans"  class="form-control editable"> </select>';
  
var cell6 = '<input type="hidden" name="txtCADCpfAcctype" id="txtCADCpfAcctype"  />'+
			      '<select  name="selCADCpfAcctype" id="selCADCpfAcctype" onmouseover="fipaTooltip(this);"  class="form-control editable"></select>';
  
var cell7 = '<input type="text" name="txtFldCADPerFrom" maxlength="10"  id="txtFldCADPerFrom" onmouseover="fipaTooltip(this);" class="form-control editable" maxlength="10"/>';
  
var cell8 = '<input type="text" name="txtFldCADPerTo" maxlength="10" id="txtFldCADPerTo" onmouseover="fipaTooltip(this);" class="form-control editable" maxlength="10"/>';
  
var cell9 = '<input type="text" name="txtFldCADAmt" id="txtFldCADAmt" onmouseover="fipaTooltip(this);" class="form-control editable"/>';
  
var cell10 ='<select name="selCADPayTerm" id="selCADPayTerm"  class="form-control editable"> </select>';
  
var cell11 ='<select name="selCADRetrAccAge" id="selCADRetrAccAge"  class="form-control editable"> </select>'+
'<input type="hidden" name="txtFldCADCrtdBy"/><input type="hidden" name="txtFldCADCrtdDate"/>';
 

cpfAccAddDedTable.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10,cell11] ).draw( false );

var rowCount = $('#cpfAccAddDedTable tbody tr').length;	
var $lastRow = $("#cpfAccAddDedTable tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radadct"+$lastRow.index())
.parent().find('label').attr('for',"radadct"+$lastRow.index());


var sel1 = $("#txtFldDlgCADApplicant > option").clone();
$lastRow.find("td:eq(2)").find('select:eq(0)').append(sel1);
$lastRow.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgCADApplicant").val());
$lastRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
	 changeOnCADType($(this));
	 reverseCpfSync($lastRow);
});

var seltype = $("#selDlgCADApplicantType > option").clone();
$lastRow.find("td:eq(3)").find('select:eq(0)').append(seltype);
$lastRow.find("td:eq(3)").find('select:eq(0)').val($("#selDlgCADApplicantType").val());
$lastRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
	reverseCpfSync($lastRow);	
});
 

var sel2 = $("#selDlgCADType > option").clone();
$lastRow.find("td:eq(4)").find('select:eq(0)').append(sel2);
$lastRow.find("td:eq(4)").find('select:eq(0)').val($("#selDlgCADType").val());  

var sel3 = $("#selDlgCADTypesOfTrans > option").clone();
$lastRow.find("td:eq(5)").find('select:eq(0)').append(sel3);
$lastRow.find("td:eq(5)").find('select:eq(0)').val($("#selDlgCADTypesOfTrans").val()); 


var cpfacctypes = $("#selDlgCADCpfAcctype > option").clone();
$lastRow.find("td:eq(6)").find('select:eq(0)').append(cpfacctypes);
$lastRow.find("td:eq(6)").find('input:eq(0)').val($("select#selDlgCADCpfAcctype option:selected").val());
$lastRow.find("td:eq(6)").find('select:eq(0)').val($("select#selDlgCADCpfAcctype").val());
$lastRow.find("td:eq(6)").find('select:eq(0)').on("change",function(){
	reverseCpfSync($lastRow);	
});
	
$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgCADPerFrom").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
	 checkDateFormat($(this));  
	 if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the From Date")); 
}); 

$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgCADPerTo").val());
$lastRow.find("td:eq(8)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
	 checkDateFormat($(this));  
	 if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the From Date")); 
});


$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgCADAmt").val()); 
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
	reverseCpfSync($lastRow);	
});

var sel4 = $("#selDlgCADPayTerm > option").clone();
$lastRow.find("td:eq(10)").find('select:eq(0)').append(sel4);
$lastRow.find("td:eq(10)").find('select:eq(0)').val($("#selDlgCADPayTerm").val()); 

var sel5 = $("#selDlgCADRetrAccAge > option").clone();
$lastRow.find("td:eq(11)").find('select:eq(0)').append(sel5);
$lastRow.find("td:eq(11)").find('select:eq(0)').val($("#selDlgCADRetrAccAge").val()); 



applyEventHandlers();


if(dataset != null){

	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
		case "cdPkid": 
			$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
			break;
			
		case "cdRefId": 
			$lastRow.find("td:eq(0)").find('input:eq(2)').val(col); 
			if(!isEmpty(col)){$lastRow.attr("rowref",col);}
			break;
			
		case "cdApplicant": 
			selectNullvalChk($lastRow.find("td:eq(2)"),col);
			break;
			
		case "cdApplicantType":  
			selectNullvalChk($lastRow.find("td:eq(3)"),col); 
			break;
		 
		case "cdDeductionType": 
			selectNullvalChk($lastRow.find("td:eq(4)"),col);
			break;
		 
		case "cdType": 
			selectNullvalChk($lastRow.find("td:eq(5)"),col);
			break;
			
		case "masterCpfAcctype":
			var cols;
			var value=$("#selDlgCADCpfAcctype option[value='"+col+"']").text();
			if(value=="--SELECT--"){
				cols="";
			}else{
				cols=value;
			}
			$lastRow.find("td:eq(6)").find('input:eq(1)').val(cols); 
			break;
		
		case "periodFrom": 
			$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 
			break;
		
		case "periodTo": 
			$lastRow.find("td:eq(8)").find('input:eq(0)').val(col); 
			break;
			
		case "cdDeductionAmt":
			$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
			break;
			
		case "cdPaymentTerm":
			selectNullvalChk($lastRow.find("td:eq(10)"),col);
			break;
			
		case "cdTransReference":
			selectNullvalChk($lastRow.find("td:eq(11)"),col);
			break;
				 
		case "cdCrtdBy": 
			$lastRow.find("td:eq(11)").find('input:eq(0)').val(col);
			infoDetsArr.push(col);				
			break;
			
		case "cdCrtdDate":
			$lastRow.find("td:eq(11)").find('input:eq(1)').val(col);
			infoDetsArr.push(col);
			break;
			
		case "cdModBy":
			infoDetsArr.push(col);
			break;
			
		case "cdModDate":
			infoDetsArr.push(col);
			break;	
		}			 
		 
	}
	}

adctClearFlds();

}



/*Edit Row Click */
$("#CpfADERow").on("click",function(){
	$("#CpfADVRow").click(); 
});


/*View Row Click */
$("#CpfADVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#cpfAccAddDedTable tbody tr').length;	
	var $lastRow = $("#cpfAccAddDedTable tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view");
		return;
	} 
	
	
	$("#cpfAccAddDedTable tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
	});
	
	
	
	$("#cpfAccAddDedTable tbody").find('input[name="radadctSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#cpfAccAddDedTable tbody").find('input[name="radadctSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					});  
	 
				 	adctRdlyflds($mode);
					adctfilldlgval($row);  
					showFIPAModel('cpfAddDed_Dialog','CPF Additions & Deduction Details');  
					$('#cpfAddDed_Dialog').on('shown.bs.modal', function () {
						$("#cpfAddDed_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#cpfAddDed_Dialog").find("select[id=txtFldDlgCADApplicant]").focus();
						$("#cpfAddDed_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateadctDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			adctfilldomval($RowId,$row); 
					     		}  
					     		reverseCpfSync($row);
								$('#cpfAddDed_Dialog').modal('hide'); 
								adctClearFlds();
							
						});
					});
					 
			} 
			
			isOneRowSelected++;
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#CpfADDRow").on("click",function(){ 
	datatableDeleteRow('cpfAccAddDedTable',cpfAccAddDedTable); 
	

});

/*Clear Fields */
function adctClearFlds(){
	$("#cpfAddDed_Dialog").find("input[type=text]").val("");
	$("#cpfAddDed_Dialog").find("textarea").val("");
	$("#cpfAddDed_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function adctRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#cpfAddDed_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#cpfAddDed_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateadctDetails(){
	 
	 
	if(!(validateFocusFlds('cpfAddDed_Dialog','txtFldDlgCADApplicant', CAD_APPLICANT))) return;
	if(!(validateFocusFlds('cpfAddDed_Dialog','selDlgCADTypesOfTrans', CAD_TRANSTYPE))) return;
	if(!(validateFocusFlds('cpfAddDed_Dialog','selDlgCADCpfAcctype', CAD_ACCTYPE))) return;
		 
	
	  return true; 
}


/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgCADApplicant,#selDlgCADTypesOfTrans,#selDlgCADCpfAcctype").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
 


/* Filling Model Fields*/
function adctfilldlgval($lastRow){
	  
	  $('#cpfAddDed_Dialog #txtFldDlgCADPkid').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#cpfAddDed_Dialog #txtFldDlgCADRefId').val($lastRow.find("td:eq(0)").find('input:eq(2)').val());
	  $('#cpfAddDed_Dialog #txtFldDlgCADApplicant').val($lastRow.find("td:eq(2)").find('select:eq(0)').val());
	  $('#cpfAddDed_Dialog #selDlgCADApplicantType').val($lastRow.find("td:eq(3)").find('select:eq(0)').val());
//	  $('#cpfAddDed_Dialog #selDlgCADApplicantType').val($lastRow.find("td:eq(2)").find('input:eq(1)').val());
	  $('#cpfAddDed_Dialog #selDlgCADType').val($lastRow.find("td:eq(4)").find('select:eq(0)').val()); 
	  $('#cpfAddDed_Dialog #selDlgCADTypesOfTrans').val($lastRow.find("td:eq(5)").find('select:eq(0)').val());
	  var flg=false,value;
	  $("#selDlgCADCpfAcctype").find("option").each(function(){   
		  
		  if($(this).text() == $lastRow.find("td:eq(6)").find('input:eq(1)').val()){
			  flg=true;
			  value=$(this).val();
			 
		  }
		  
	 });
	  if(flg){
	  $('#cpfAddDed_Dialog #selDlgCADCpfAcctype').val(value);  
	  }else{
		  $('#cpfAddDed_Dialog #selDlgCADCpfAcctype').val("");
	  }
	  $('#cpfAddDed_Dialog #txtFldDlgCADPerFrom').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#cpfAddDed_Dialog #txtFldDlgCADPerTo').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#cpfAddDed_Dialog #txtFldDlgCADAmt').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#cpfAddDed_Dialog #selDlgCADPayTerm').val($lastRow.find("td:eq(10)").find('select:eq(0)').val());
	  $('#cpfAddDed_Dialog #selDlgCADRetrAccAge').val($lastRow.find("td:eq(11)").find('select:eq(0)').val()); 
	  
	  $('#cpfAddDed_Dialog #txtFldDlgCADCrtdBy').val($lastRow.find("td:eq(11)").find('input:eq(0)').val());
	  $('#cpfAddDed_Dialog #txtFldDlgCADCrtdDate').val($lastRow.find("td:eq(11)").find('input:eq(1)').val());
	  
 
}

/* Filling Table Fields*/
function adctfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgCADApplicant").val()); 
	$row.find("td:eq(3)").find('select:eq(0)').val($("#selDlgCADApplicantType").val()); 
	$row.find("td:eq(4)").find('select:eq(0)').val($("#selDlgCADType").val()); 
	$row.find("td:eq(5)").find('select:eq(0)').val($("#selDlgCADTypesOfTrans").val()); 
	$row.find("td:eq(6)").find('input:eq(1)').val($("#selDlgCADCpfAcctype option[value='"+$("#selDlgCADCpfAcctype").val()+"']").text()); 
	
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgCADPerFrom").val()); 
	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgCADPerTo").val()); 
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgCADAmt").val()); 
	$row.find("td:eq(10)").find('select:eq(0)').val($("#selDlgCADPayTerm").val());
	$row.find("td:eq(11)").find('select:eq(0)').val($("#selDlgCADRetrAccAge").val());  
		
}
/*###########################################################################################################################################################*/


$("#txtFldDlgCADApplicant").on("change",function(){
	 changeOnCADType($(this));
});


function changeOnCADType(elmid){
	var $elmVal=$(elmid).val();
	if(!isEmpty($elmVal)){ 
		 var selectedIndex=$("#txtFldDlgCADApplicant option").index($("#txtFldDlgCADApplicant option:selected"));
	if(selectedIndex == 1){
		$("#cpfAddDed_Dialog #selDlgCADApplicantType").val("Self");
	}else if(selectedIndex == 2){
		$("#cpfAddDed_Dialog #selDlgCADApplicantType").val("Spouse");
	}else {
		$("#cpfAddDed_Dialog #selDlgCADApplicantType").val("");
	} 
	}else{
		$("#cpfAddDed_Dialog #selDlgCADApplicantType").val("");
	}
}

$("#txtFldDlgCADPerFrom").blur(function(){ 
	if(!chkFromToDateValidation('txtFldDlgCADPerFrom','txtFldDlgCADPerTo'),"Period To Date should greater than the Period From Date"); 
});

$("#txtFldDlgCADPerFrom").change(function(){
	 checkDateFormat($(this));
});

$("#txtFldDlgCADPerTo").blur(function(){    
	if(!chkFromToDateValidation('txtFldDlgCADPerFrom','txtFldDlgCADPerTo'),"Period To Date should greater than the Period From Date"); 
}); 

$("#txtFldDlgCADPerTo").change(function(){    
 checkDateFormat($(this));
}); 
 
$('#CADPerTopicker').blur(function(){  
   	if(!chkFromToDateValidation('txtFldDlgCADPerFrom','txtFldDlgCADPerTo'),"Period To Date should greater than the Period From Date"); 
});
  
$('#CADPerFrmpicker').blur(function(){   
   	if(!chkFromToDateValidation('txtFldDlgCADPerFrom','txtFldDlgCADPerTo'),"Period To Date should greater than the Period From Date"); 
});
   
function reverseCpfSync($row){
	//Retirement Data
	var $rowref=$row.attr("rowref");
		if(isValidObject($rowref)){ 
	
	var syncOn=$rowref.substring(0,3); 
	 var ownership=$row.find("td:eq(3)").find('select:eq(0)').val();
	 
	 var cpfacc;
	 var paymentmtd=$row.find("td:eq(6)").find('input:eq(0)').val(); 
	 if(paymentmtd == "Ordinary"){cpfacc="CPFOA";}
	 else if(paymentmtd == "Special"){cpfacc="CPFSA";}
	 else if(paymentmtd == "Medisave"){cpfacc="CPFMA";}
	 else if(paymentmtd == "Retirement"){cpfacc="CPFRA";}
	 else {cpfacc="";}
	 
	
	 var amtinv=$row.find("td:eq(9)").find('input:eq(0)').val(); 
	
	if(syncOn == "INV"){
		$("#fnaInvestmentTbl tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
			applyToastrAlert("CPF Addition and Deduction data will be reflected back to Investment Screen !"); 
			 $(this).find("td:eq(10)").find('select:eq(0)').val(cpfacc);//Payment method
			 $(this).find("td:eq(2)").find('select:eq(0)').val(ownership); //ownership
			 $(this).find("td:eq(9)").find('input:eq(0)').val(amtinv);//amount invested 
			 //Retirement table change
			 var $rowref=$(this).attr("rowref");
		 		if(isValidObject($rowref)){ 
			 			syncInvestTblEditRow($(this));
			 		
		 		}
		});
	}
	 
	
	if(syncOn == "PRO"){
		$("#fnaPropOwnTblByCPF tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
			applyToastrAlert("CPF Addition and Deduction data will be reflected back to Property Ownership Screen !");
			var exits=$(this).find("td:eq(9)").find('input:eq(0)').val();
			
			if(ownership =="Self"){
				 if(!isEmpty(exits)){
					 $(this).find("td:eq(10)").find('input:eq(0)').val(exits+amtinv);//amount invested 
					 $(this).find("td:eq(12)").find('input:eq(0)').val("");
				 }else{
					 $(this).find("td:eq(10)").find('input:eq(0)').val(amtinv);//amount invested
				 }
			}else if(ownership =="Spouse"){
				 if(!isEmpty(exits)){
					 $(this).find("td:eq(12)").find('input:eq(0)').val(exits+amtinv);//amount invested
					 $(this).find("td:eq(10)").find('input:eq(0)').val("");
				 }else{
					 $(this).find("td:eq(12)").find('input:eq(0)').val(amtinv);//amount invested
				 }
			} 
			 $(this).find("td:eq(4)").find('select:eq(0)').val(ownership); //ownership 
			 
			 //Retirement table change
			 var $rowref=$(this).attr("rowref");
			 if(isValidObject($rowref)){	
		 			syncPropTblEditRow($row);
		 		}else{
		 			syncPropTblRow();
		 		}
		});
	}
	
	
		}
		
		if(isValidObject($("#lipPremiumsrc").attr("rowref"))){
		//Life Insurance reverse sync
		var premsrcrowref=$("#lipPremiumsrc").attr("rowref").length;
		if(premsrcrowref >0){
			applyToastrAlert("CPF Addition and Deduction data will be reflected back to Life Insurance Screen !");
			$("#lipPremiumsrc").val(cpfacc);
			$("#lipSa").val(amtinv);
			$("#lipOwner").val(ownership); 
			
			 //Retirement table change
			 var $rowref=$("#sellipCoveragetype").attr("rowref").length;
			 if($rowref > 0){	
				 SyncLifeToRetEdit();
		 	 }	
		}
	 }
}

 
