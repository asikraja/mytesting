/**
 * FIPA Constant
 */

var BASE_URL;

var servletName 		= "FipaServlet";
var mastServletName 	= "MasterDataServlet";

var SESSION_EXP_JSP 	= "/sessionExpired.do";
var SESSION_EXP_TAB 	= "SESSION_EXPIRY";

var DB_EXP_JSP 			= "/dbError.do";
var DB_ERROR_TAB 		= "DB_ERROR";

var ERROR_TAB 			= "ERROR";
var ERRO_JSP 			= "/generalError.do";

var QRY_MODE = 'Q';
var INS_MODE = 'I';
var UPD_MODE = 'U';
var DEL_MODE = 'D';

var STAFFTYPE_ADVISER 	= "ADVISER";
var STAFFTYPE_STAFF 	= "STAFF";


var dobOptions = {
		 
	 	endDate: new Date(), 
        format : 'dd/mm/yyyy',
        autoclose : true, 
        clearBtn : true,
        todayBtn: true,
        todayHighlight : true,
        showClear : true,
        showClose : true,
        minView : 'month' , 
        forceParse:false,
        pickTime : false 
}; 

var dateOptions = {
	 
	 	startDate: '1901-01-01', // "today" / "2016-12-20" / 1477673788975
		endDate: "",
        format : 'dd/mm/yyyy',
        autoclose : true, 
        clearBtn : true,
        todayBtn: true,
        todayHighlight : true,
        showClear : true,
        showClose : true,
        minView : 'month' , 
        forceParse : false
        
};


var toastrOpts = {
		 "closeButton": true,
		  "debug": false,
		  "newestOnTop": true,
		  "progressBar": true,
		  "positionClass": "toast-top-right",
		  "preventDuplicates": true,
		  "preventOpenDuplicates": true,
		  "onclick": null,
		  "showDuration": "300",
		  "hideDuration": "1000",
		  "timeOut": "13000",
		  "extendedTimeOut": "13000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
}

var sucToastrOpts={
		 "closeButton": false,
		  "debug": false,
		  "newestOnTop": true,
		  "progressBar": false,
		  "positionClass": "toast-top-right",
		  "preventDuplicates": true,
		  "onclick": null,
		  "showDuration": "300",
		  "hideDuration": "1000",
		  "timeOut": "3000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
}
 
//SELF Constants 

var SELF_NAME          		= 'Key in the Name in Client\'s Particulars section ';
var SELF_NRIC          		= 'key in the NRIC in Client\'s Particulars section ';
var SELF_ADVSTF          	= 'key in the Servicing Adviser Name in Client\'s Particulars section ';
var SELF_DOB           		= 'Key in the DOB in Client\' Particulars section '; 
var SELF_NATION           	= 'Key in the Nationality  in Client\'s Particulars section ';
var SELF_HMEADDR           	= 'Key in the Registered Residential Address1 in Client\'s Particulars section ';
var SELF_HMEADDR2           = 'Key in the Registered Residential Address2 in Client\'s Particulars section ';
var SELF_RPOSTAL          	= 'Key in the Registered Residential Postal in Client\'s Particulars section ';
var SELF_RCNTRY           	= 'Key in the Registered Residential Country in Client\'s Particulars section ';
var SELF_MAILADDR           = 'Key in the Mailing Address1 in Client\'s Particulars section ';
var SELF_MAILADDR2          = 'Key in the Mailing Address2 in Client\'s Particulars section ';
var SELF_MPOSTAL           	= 'Key in the Mailing Postal in Client\'s Particulars section ';
var SELF_MCNTRY        		= 'Key in the Mailing Country in Client\'s Particulars section ';
 
//Spouse

var SPOUSE_NAME          	= 'Key in the Name in Spouse\'s Particulars section';
var SPOUSE_NRIC          	= 'Key in the NRIC in Spouse\'s Particulars section';
var SPOUSE_DOB          	= 'Key in the DOB  in Spouse\'s Particulars section';
var SPOUSE_NATION           = 'Key in the Nationality in Spouse\'s Particulars section';
var SPOUSE_HMEADDR          = 'Key in the Home Address1 in Spouse\'s Particulars section';
var SPOUSE_HMEADDR2         = 'Key in the Home Address2 in Spouse\'s Particulars section';
var SPOUSE_RPOSTAL          = 'Key in the Home Postal in Spouse\'s Particulars section';
var SPOUSE_RCNTRY           = 'Key in the Home Country in Spouse\'s Particulars section';
var SPOUSE_MAILADDR         = 'Key in the Mail Address1 in Spouse\'s Particulars section';
var SPOUSE_MAILADDR2        = 'Key in the Mail Address2 in Spouse\'s Particulars section';
var SPOUSE_MPOSTAL          = 'Key in the Mail Postal in Spouse\'s Particulars section';
var SPOUSE_MCNTRY        	= 'Key in the Mail Country in Spouse\'s Particulars section';


//CD AND AHDOC 
var SLF_MAILING_ADDR		= 'Key in the Mailing Address(Self)  ';
var SPS_MAILING_ADDR		= 'Key in the Mailing Address(Spouse)  ';

//Address
var ADDRESS_TYPE			='Please Key in Address Type ';
var ADDRESS					='Please Key in Address ';

//Depandant Details
var DEPN_NAME               ="Key in Name  ";
var DEPN_RELATION	   		="Key in Relationship  ";
var DEPN_DOB                ="Key in Date Of birth  "; 
var DEPN_AGE                ="Key in Age  "; 


//Child Particulars
var CHILD_NAME               ="Key in Child Name  ";
var CHILD_RELATION           ="Key in Relationship  ";
var CHILD_DOB              	 ="Key in Date Of Birth  ";
var CHILD_AGE                ="Key in Age  ";

//Savings / Investment Goals
var SAVEINV_PUR         ="Key in Purpose  ";
var SAVEINV_AMT		    ="Key in Amount  ";
var SAVEINV_WHEN        ="Key in When(No. of Years) ";


//Financial Goals and Concerns
var FINTYPE_GOALS		 ="Key in Type of Financial Goals ";
var FIN_GOALS            ="Key in Financial Goals and Concerns "; 


//Retirement Planning - Other Retirement
var OR_TYPE              ="Key in Type of Payment";
var OR_FREQ              ="Key in Frequency";
var OR_ANLEXP            ="Key in Annual expenditure";
var OR_ESC            	 ="Key in Escalation Rate";
var OR_AGEBSE            ="Key in Age Based On";
var OR_AGESTS            ="Key in Age payment starts";
var OR_AGEENDS           ="Key in Age payment ends";

//Retirement Planning - Income Retirement
var IR_CLSFY	        ="Key in Classification";
var IR_DESC             ="Key in Descriptions";
var IR_FRQ              ="Key in Frequency";
var IR_AMT              ="Key in Amount of income";
var IR_ESC              ="Key in Escalation Rate ";
var IR_ROI              ="Key in ROI";
var IR_AGEBASED         ="Key in Age Based On";
var IR_AGESTS           ="Key in Age payment starts";
var IR_AGEENDS          ="Key in Age payment ends";

//Retirement Planning - Income Asset Retirement
var INCASS_CLSFY	         ="Key in Classification";
var INCASS_DESC              ="Key in Descriptions";
var INCASS_FREQ              ="Key in Frequency";
var INCASS_AMT	             ="Key in Amount of income";
var INCASS_ESC               ="Key in Escalation Rate"; 
var INCASS_ROI	             ="Key in ROI";
var INCASS_AGEBSD            ="Key in Age Based On";
var INCASS_AGESTS            ="Key in Age payment starts";
var INCASS_AGEENDS           ="Key in Age payment ends";
 
//Nominees Names
var NOM_NAME                 ="Key in Nominee Name "; 


//FG Protection - Accidental & Health
var FGAHITEM       ="Key in Financial Goal Item in Accidental & Health  ";
var FGAHSLF	       ="Key in Self Priority  ";
var FGAHSPS        ="Key in Spouse Priority  ";

//FG Protection - Family & Assets
var FGFAITEM      ="Key in Financial Goal Item in Family & Assets   ";
var FGFASLF	   	  ="Key in Self Priority  ";
var FGFASPS       ="Key in Spouse Priority  ";

//FG Protection - Savings & Investment
var FGSIITEM       ="Key in Financial Goal in Family & Assets Item  ";
var FGSISLF	       ="Key in Self Priority  ";
var FGSISPS        ="Key in Spouse Priority  ";

//FG Protection - Child's  Education
var FGCEITEM       ="Key in Financial Goal Item  in Child's  Education  ";
var FGCESLF	       ="Key in Self Priority  ";
var FGCESPS        ="Key in Spouse Priority  ";

//Other Area Of Concerns
var OTHAREAOFCRN            ="Key in Other Area of Concern "; 

//Reasons For Recommendations
var RSONFRRECOM            ="Key in Reasons For Recommendations "; 

//FundFlow Details
var FDFLW_CATEG				="Key in In/Outflow  ";
var FDFLW_SRC				="Key in Source  ";
var FDFLW_WHEN				="Key in When  "; 


//Contingency Details
var CDEPN_NAME				="Key in Child Name  ";
var CDEPN_AGE				="Key in Child Age  ";
var CDEPN_YRS				="Key in Dependant Yrs  ";
 
//Life Insure
var Li_OWN				="Key in Owner / Proposed";
var Li_ASS				="Key in Life Assured";
var Li_INS				="Key in Insurance Company";
var Li_POL				="Key in Policy No.";
var Li_POLSTS			="Key in Policy Status";
var Li_DATE				="Key in Inc. Date of policy";
var Li_SA				="Key in Sum Assured";
var Li_PLAN				="Key in Name of Main Plan";
var Li_CASHVAL			="Key in Current Cash Value"; 

//Health Ins
var POLICY_TYPE			="Key in Policy Type  ";
var INSURED				="Key in Insured  ";
var BENIFIT_TYPE		="Key in Benefit Type  "; 


//Property Ownership
var PROP_DESC				="Key in Description  ";
var PROP_MARKETVAL			="Key in Market Value"; 
var PROP_OWNER				="Key in Ownership  ";




//Vehicle Ownership
var VEH_OWNER				="Key in Owner  ";
var VEH_MKTVAL				="Key in Market Value  ";
var VEH_LOANVAL				="Key in Loan Value  "; 

//Insurance
var LIINS_OWN				="Key in Owner  ";
var LIINS_ASS				="Key in Life Assured  ";
var LIINS_COM				="Key in Company  ";


//Input Investdets
var IPINVST_OWNNAME			="Key in Owner Type  ";
var IPINVST_TYPE			="Key in Types of Investment  ";
var IPINST_DATEINV			="Key in Date Invested  ";

var IPINVST_AMT			    ="Key in Amount ";
var IPINVST_FREQ			="Key in Frequency ";
var IPINST_NOOFYRS			="Key in No of yrs of reg. inv ";
var IPINST_YRSTOSTAY		="Key in Tot no. of yrs to stay ";
var IPINVST_INSNAME			="Key in Names of Institutions";
var IPINVST_FUNDCODE		="Key in Description of Investment";

//Advise Recommandations
var ADVREM_PROTYPE					="Key in Product Type  ";
var ADVREM_CMPYNAME					="Key in Company Name  ";
var ADVREM_SUM					    ="Key in Sum Assured Benefits ";
var ADVREM_PLANTERM					="Key in Plan Term  "; 


//Advise Recommandations - PLAN
var ARPLN_PROTYPE				    ="Key in Product Type  ";
var ARPLN_CMPYNAME				    ="Key in Company Name  ";
var ARPLN_SUM					    ="Key in Sum Assured Benefits  ";
var ARPLN_PLANTERM				    ="Key in Plan Term  "; 

//Advise Recommandations - FUND
var ARFD_PROTYPE				    ="Key in Product Type  ";
var ARFD_CMPYNAME				    ="Key in Company/Product Name  ";
var ARFD_FPF					    ="Key in FPF Fund Risk Rating  ";
var ARFD_SALESCHRG  				    ="Key in Sales Charges  ";
var ARFD_PURCHASE  				    ="Key in Purchase  ";

//Switching Replacements - PLAN
var SWTPLAN_PROTYPE					="Key in Product Type  ";
var SWTPLAN_CMPYNAME				="Key in Company Name  ";
var SWTPLAN_SUM					    ="Key in Sum Assured Benefits  ";
var SWTPLAN_TYPE 				    ="Key in Switch Type  "; 

//Switching Replacements - FUND
var SWTFD_PROTYPE					="Key in Product Type  ";
var SWTFD_CMPYNAME					="Key in Company Name  ";
var SWTFD_FPF		                ="Key in FPF Fund Risk Rating  ";
var SWTFD_UT		                ="Key in UT-Units/ILP-Amt  ";
var SWTFD_SALESCHRG		            ="Key in SalesCharges  ";
var SWTFD_AMT		                ="Key in Amount  ";
var SWTFD_REPL		                ="Key in Replc. Amt  ";

//CPF Monthly contribution
var CCEMPLECONTRB					="Key in Employee  ";
var CCEMPLRCONTRB					="Key in Employer  ";


//CPF Top ups Details
var CPFACCTYPE 					="Key in CPF Account Type  ";
var	CPFCTTYPE					="Key in CPF Type  ";
var	CPFCTPAY				 	="Key in CPF Payment Term ";
var	CPFCTAMT					="Key in CPF Amount ";


//CPF Top ups Details
var CPFCDACCTYPE 					="Key in CPF Account Type  ";
var	CPFCDAPP					="Key in CPF Applicant  ";
var	CPFCDTYPEDT				 	="Key in CPF Types of Deduction ";
var	CPFCDPAY					="Key in CPF Payment Term ";

//CPF Addition & Deduction
var CAD_APPLICANT				="Key in Applicant Name";
var CAD_TRANSTYPE				="Key in Types of Transaction";
var CAD_ACCTYPE					="Key in Account Types";

//PERSONAL ASSETS
var PERACCHOL					="Key in Personal Asset Account Holder ";
var PERACCTP					="Key in Type Of Personal Asset ";
var PERASTNAME					="Key in Name of Personal Asset  ";

//BUSINESS ASSETS
var BUSNACCHOL					="Key in Business Asset Account Holder ";
var BUSNACCTP					="Key in Type Of Business Asset ";
var BUSNASTNAME					="Key in Name of Business Asset ";

//CASH AT BANKS
var MAIN_HOLDER_NAME            ="Key in Main Account Holder Name ";
var BANK_NAME                   ="Key in Name of Bank ";
var BANK_NO                     ="Key in Bank Account No. ";


//LI - PLAN DETAILS
var LIPD_PLANNAME				="Key in Plan Name ";
var LIPD_PLANTYPE				="Key in Basic / Rider ";
var LIPD_PREMTERM				="Key in Premium Term ";

//LI - DEATH BENEFITS DETAILS
var LIDB_PLANNAME				="Key in Plan Name ";
var LIDB_INCDATE				="Key in Inception Date ";
var LIDB_EXPDATE				="Key in Expiry Date ";

//LI - DISABILITY DETAILS
var LIDSB_TYPE					="Key in Types of Disability ";
var LIDSB_BEGINS				="Key in Yr benefit to be payable Begins ";
var LIDSB_CEASES				="Key in Yr benefit to be payable Ceases ";


//LI - CRITICAL ILLNESS DETAILS
var LICL_LVLDD				="Key in Stages / Level of DD ";
var LICL_EXPDATE			="Key in Expiry Date ";
var LICL_BENAMT				="Key in Benefit Amount ";


//LI - HOSPITIALISATION DETAILS
var LIHSP_CLS				="Key in Class of Benefit ";
var LIHSP_COV				="Key in Term of Coverage ";
var LIHSP_DED				="Key in Deductible($) ";
var LIHSP_COI				="Key in Co-insurance(%) ";

//LI - RETIREMENT PLG
var LIRET_COMAGE				="Key in Commencement Of Age ";
var LIRET_ENDAGE				="Key in End Of Age ";
var LIRET_ESCAGE				="Key in Escalation Rate ";

//LI - EDUCATION PLG
var LIEDU_CHLDNAME				="Key in Name of child ";
var LIEDU_TEREDAGE				="Key in Tertiary education age";
var LIEDU_BANKRATE				="Key in Bank interest rate  ";
 
//ATTACHMENT
var ATTACH_CATG           ="Key in Category";
var ATTACH_TITLE          ="Key in Document Title";
var ATTACH_DOC            ="Upload the document";



//Master Cpf Details 
var CPF_ACCOUNT						="Key in Account Type ";
var CPF_INT_RATE					="Key in CPF Interest Rate  ";
var CPF_INT_MTH						="Key in CPF Interest Month  "
var INTRATE_SEARCH					="Select any search criteria in CPF Interest Rate";
	
//Master CPF Allocation Details
var	CPFALLOC_EFF					="Key in CPF Effective From  ";
var	CPFALLOC_AGEGRP					="Key in CPF Age group  ";
var	CPFALLOC_ACTYPE					="Key in CPF Account Type  ";
var	CPFALLOC_RATE					="Key in CPF Allocation Rate  ";
	
//Master CPF Contribution Details
var	CPFCONTRB_EFFFROM						="Key in Effective From ";
var	CPFCONTRB_EFFTO		      				="Key in Effective To ";
var	CPFCONTRB_AGEGRP						="Key in Employee Age Group "; 
var	CPFCONTRB_WAGEGRP						="Key in Employee Wage Group ";

//Master Quotes
var QUOTES_AUTHOR						="Key in Author Name";
var QUOTES_LOGMSG						="Key in Quotes";
var QUOTES_WEEK						    ="Key in Weekly View";
//Types of Application 
var TOAALYSFOR					="Select Any Analysis For ";
var TOAPURPO					="Select Any Purpose ";
var TOPLIFE						="Select Life & Non-Insurance Products ";
var TOPHL						="Select Accident and Health (A&H) Products ";
var TOPAYSTYPES					="Select Any Of Analysis Types ";
var TOAALYSFORSELF				="Select Any Analysis For Self";




//Profile 
var PROAPPTYPE					="Select Application Types ";
var PROREVFLG					="Select Review Flg ";


//Input Addition and Deduction into CPF a/c
var CPFADNAME					="Key in Name ";
var CPFADYEAR					="Key in Year ";
var CPFADAGE					="Key in Age ";

//Health Insurance Mandatory
var HEALTHINS_RMKS				="Key in Remarks on Replacement of Health Insurance Policy "; 

//AML Declaration
var INT_NAME				   ="Key in Interpreter Name ";
var INT_NRIC				   ="Key in Interpreter NRIC ";
var INT_CONTACT				   ="Key in Interpreter Contact ";
var INT_HOMEADDR			   ="Key in Interpreter Home Address ";
var INT_REL			   	       ="Key in Interpreter Relationship ";
var SEL_BENOWNER			   ="Select Benefical Owner "; 
var SEL_TPP				   	   ="Select Third Party Payer "; 
var SEL_PEP				       ="Select Political Exposed Person "; 
var REASONS_RECOM			   ="Key in Reasons and Recommendation ";
var SWTCH_QUEST1			   ="Select Question 1 in Switching & Replacement section ";
var SWTCH_QUEST1REMK		   ="Key in Remarks on Question 1"
var SWTCH_QUEST2			   ="Select Question 2 in Switching & Replacement section ";
var SWTCH_QUEST3			   ="Select Question 3 in Switching & Replacement section";
var SWTCH_QUEST4			   ="Select Question 4 in Switching & Replacement section";
var DECLARATION				   ="Select Declaration By Client Agree/Disagree "
var SUP_DECLARATION			   ="Select Declaration By Supervisor Agree/Disagree "
var	SUP_REASON				   ="Key in Reason(s) and Follow-up Action "
	
//New Product TOPUPS
var CHECK_PRODUCT			   ="Select any Source of income in Advice & Recommendations ";

//Datatables
var DATATABLE_ERROR			   ="------------------No Records Available------------------";


//Retirement Cash Flow Analysis - Assumption Section
var FILL_ALL_RETPLN			   ="Please Fill in Retirement planning Form ";

var RD_RETPLN_EXTAGE		   ="Please Fill value for Expected Retirement Age from Retirement Planning ";
var RD_RETPLN_ASSAGE		   ="Please Fill value for Assumed Life Expectancy Age from Retirement Planning ";

//RD Invest Cash Amount Section
var RD_INVCASHAMT_AVBLE		   	   ="Please Fill value for Amount Available";
var RD_INVCASHINT_RATE		   	   ="Please Fill value for Interest Rate";
//Retirement Cash Flow Analysis - Projection of Expenditure
var RD_CRCASH_DESC			   ="Key in Description";
var RD_CRCASH_ANLAMT		   ="Key in Annual Amount";
var RD_CRCASH_STARTAGE		   ="Key in Start Age";
var RD_CRCASH_STARTYEAR		   ="Key in Year Start from retirement";
var RD_CRCASH_NOYR		       ="Key in No of years";
var RD_CRCASH_RATEOFINC		   ="Key in Rate of Increase";

//Retirement Cash Flow Analysis - Projection of Income
var RD_INPINC_DESC			   ="Key in Description";
var RD_INPINC_CLSFY			   ="Key in Classification";
var RD_INPINC_ANLAMT		   ="Key in Annual Amount";
var RD_INPINC_STARTYEAR		   ="Key in Year Start from retirement";
var RD_INPINC_STARTAGE		   ="Key in Start Age";
var RD_INPINC_NOOFYR		   ="Key in No of Years";
var RD_INPINC_RATEOFINC		   ="Key in Rate Of Increase";
//Retirement Cash Flow Analysis - Projection of Investment 
var RD_PROJINC_DESC			   ="Key in Description";
var RD_PROJINC_CLSFY		   ="Key in Classification";
var RD_PROJINC_SRCFD		   ="Key in Source Of Funds";
var RD_PROJINC_FDADD		   ="Key in Funds Added";
var RD_PROJINC_ANLAMT		   ="Key in Income";
var RD_PROJINC_STARTYEAR	   ="Key in Year Start from retirement";
var RD_PROJINC_STARTAGE		   ="Key in Start Age";
var RD_PROJINC_NOY	   		   ="Key in No of year";
var RD_PROJINC_RATE  		   ="Key in Rate Of Increase";


//Buttons
var STR_FIPA_SAVE		='Save Profile';
var STR_FIPA_NEW		='New Profile';
var STR_FIPA_DELETE		='Delete Profile';
var STR_FIPA_HOME		='FIPA Home';
var STR_FIPA_LOGOUT		='Logout';
var STR_CLIENT_SEARCH	='Search Client';
var STR_FPMSLINK		='FIPA Policy Link To FPMS';
var STR_ADDNEWLIFE		='Add New Life Insurance';
var STR_BACKTOFDFLW		='Back To Expected Fund Flow';
var STR_BACKTOANLRENT	='Back To Annual Rental Income';
var STR_FPMSPOLICY		='Click To View FPMS Policy Details';
var STRBACKTOCOB		='Back To Cash At Bank';
var STRBACKTOINV		='Back To Investment';

//var STR_BACKTOINVST  	='Back To Annual Rental Income';
var STR_BACKTOCPFAND	='Back To CPF Addition & Deduction';
var STR_BACKTOCASHASSET	='Back To Cash Asset';
var STR_FIPAPOLICY		='Click To View FIPA Policy Details';
var STR_DELFIPAPOL		='Click To Delete FIPA Policy';
var STR_FPMSPOLICY		='Click To View FPMS Policy Details';


var STR_DOWNLOADFILE	='Click To Download File';

var STR_ADDROW			='Add Row';
var STR_EDITROW			='Edit Row';
var STR_DELROW			='Delete Row';
var STR_VIEWROW			='View Row';
var STR_SEARCHROW		='Search';
var STR_RDFVINCOME		='Click To Calculate FV Income';
var STR_INFO			='info';


var EXITLIFEDETS		='Do You Want To Clear Existing Policy Data ';
var STR_FIPA_TT 		= 'FIPA Prospect indicates no information was found in FPMS.';
var STR_FPMS_TT 		= 'FPMS: indicates existing information is available in FPMS.No need to re-key client\'s particulars.Data will be fetched over from FPMS to FIPA.';
var STR_FIPAFPMS_TT 	= 'FPMS & FIPA: indicates client\'s information exist in both systems. (Client has an existing portfolio and performed FNA before)';

var INVESTMENT_ICON		='More Info about the Investment Details by clicking this icon';
var PROPERTY_ICON		='More Info about the Property Ownership Details by clicking this icon';
var VEHICLE_ICON		='More Info about the  Vehicle Ownership Details by clicking this icon';  
var LIFE_ICON			='More Info about the  Life insurance Details by clicking this icon';
var COBFIXED_ICON		='More Info about the Cash At Banks-Fixed Account by clicking this icon';
var COBSAVING_ICON		='More Info about the Cash At Banks-Saving Account Details by clicking this icon';
var COBCURRENT_ICON		='More Info about the Cash At Banks-Current Account Details by clicking this icon';
var COBSRS_ICON			='More Info about the Cash At Banks-SRS Account Details by clicking this icon';







var RETSCREEN_INTSLFAGE		='Key in Intended retirement age (Self)'; 
var RETSCREEN_INTSPSAGE		='Key in Intended retirement age (Spouse)';
var RETSCREEN_RETAGEBASE	='Retirement age based on';
var RETSCREEN_YRSTORET		='Yrs to retirement';
var RETSCREEN_CORSLFAGE		='Coordinated retirement age(Self)';
var RETSCREEN_CORSPSAGE		='Coordinated retirement age(Spouse)';
var RETSCREEN_PROSLFAGE		='Projected life expectancy(Self Age)';
var RETSCREEN_PROSPSAGE		='Projected life expectancy(Spouse Age)';
var RETSCREEN_PROSLFLVYRRET	='Projected living yrs in retirement(Self)';
var RETSCREEN_PROSPSLVYRRET	='Projected living yrs in retirement(Spouse)';
var RETSCREEN_PROFAMLVYRRET	='Projected living yrs in retirement(Family)';
var RETSCREEN_ROISLF		='Projected ROI after retirement(Self)';
var RETSCREEN_ROISPS		='Projected ROI after retirement(Spouse)';
var RETSCREEN_ROIFAM		='Projected ROI after retirement(Family)';
	 
	  
var RETSCREEN_LVYRSLF		="Living Needs during retirement(today's cost) - Self Amount "; 
var RETSCREEN_LVYRSPS		="Living Needs during retirement(today's cost) - Spouse Amount "; 
var RETSCREEN_LVYRFAM		="Living Needs during retirement(today's cost) - Family Amount ";
	
	
	

var NRIC_KEYIN				="Key in Client NRIC";
var INTRPER_KEYIN			="Key in Interpreter Details";

var EN_INT_POL_REMARKS		="Please Key in Remarks";
var CASH_VAL_RET			="Please Key in Cash Value On Retirement";
var NOMINEE_NAME			="Please Key in Nominees Names";
var AGE_PAYMENT_STARTS		="Key in Age payment starts";



var NONAV_CALCULATED	='Cannot Fetch Bid Price/ NAV Price for Analyse by portfolio';

var REFLECTED_DATA_ERRMSG  = 'This operation performs Child Record will also be deleted';

var DEFAULT_FA_AVALLIS = "Avallis Financial Pte Ltd";
