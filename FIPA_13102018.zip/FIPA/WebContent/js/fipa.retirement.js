/**Retirement Age Validation*/

function calcRtrmntPln(plnid){
	
	var ageBasedOn = $("#retAgeBasedon").val().toUpperCase();//Age Based On 
	var intRetAgeSelf = $("#retSelfAge").val();//Ret self Age
	var intRetAgeSps = $("#retSpsAge").val();//Ret spouse Age	
	var projAgeSelf = $("#retSelfProjage").val();//projected self
	var projAgeSps = $("#retSpsProjage").val();//projected spouse
	
	var selfAge = $("#dfSelfAge").val();//self age
	var spsAge = $("#dfSpsAge").val();//spouse age
	
	
   // retirementage=if age based on is "Self" then Intended retirement age of Self otherwise Spouse
	var retirementage = (ageBasedOn == "SELF" ) ? intRetAgeSelf : intRetAgeSps;
	
	// mortalityage=if age based on is "Self" then Projected life expectancy (Age) of Self otherwise Spouse
	var mortalityage = (ageBasedOn == "SELF" ) ? projAgeSelf : projAgeSps;
	
	
	//Age different between self age - spouse age
	var diffbwslfspsage = selfAge - (isNaN(spsAge)?0:spsAge);
	
	//calculate for retirement age
	//if (Age Based on is Spouse) = then ( Intended retirement age of Spouse - Spouse age) else if  (Age Based on is Self) then (Intended retirement age of Self - Self age)
	var calcforrtdage = (ageBasedOn == "SPOUSE" ) ? (Number(intRetAgeSps) - Number(spsAge)) : (Number(intRetAgeSelf) - Number(selfAge));
	
	
	//Year to retirement  = if calculated value for retirement age is greater or equal to 0 then get value of  calculated value for retirement age otherwise 0
	var yrstoret = (calcforrtdage >= 0 ? calcforrtdage : 0);
	
	//	Projected Living years in retirement self = (if Age Based on is "Self" then Projected Age self - Intended Retirement Age self )
			//otherwise  Projected Age self  - Years to retirement - Self Age
	var livingyrsself = (ageBasedOn == "SELF" ) ? (projAgeSelf - intRetAgeSelf) : (Number(projAgeSelf) -Number(yrstoret) - Number(selfAge) );

	
	// Projected Living years in retirement spouse = (if Age Based on is "Spouse" then Projected Age spouse - Intended Retirement Age Spouse)
			//otherwise  Projected Age Spouse - Years to retirement - Spouse Age
	var livingyrssps = (ageBasedOn == "SPOUSE" ) ? (projAgeSps - intRetAgeSps) : (Number(projAgeSps) - Number(yrstoret) - Number(spsAge) );
	
	// Coordinated retirement age Self = (if Age Based on is "Self" then Intended Retirement Age os Self)
	//otherwise (Intended Retirement Age of spouse) + (Difference between self spouse age)
	var coordinateselfage = (ageBasedOn == "SELF" ) ? intRetAgeSelf : (Number(intRetAgeSps)+Number(diffbwslfspsage));
	
	// Coordinated retirement age Spouse = (if Age Based on is "Spouse" then Intended Retirement Age of Spouse)
	//otherwise (Intended Retirement Age of spouse) + (Difference between self spouse age)
	var coordinatespsage = (ageBasedOn == "SPOUSE" ) ? intRetAgeSps : (Number(intRetAgeSps)+Number(diffbwslfspsage));
	
	//Retirement Age of Self = (Years to retirement) + (Self Age)
	var retageself = Number(yrstoret)+Number(selfAge);
	
	//Retirement Age of Spouse = (Years to retirement) + (Spouse Age)
	var retagesps = Number(yrstoret)+Number(spsAge);
	
	//Retirement years of Self= (65) -  (Retirement age of Self)
	var retyrsself = Number(65)-Number(retageself);
	//Retirement years of Spouse= (65) -  (Retirement age of Spouse)
	var retyrssps = Number(65)-Number(retagesps);
	
	//Retirement years of Spouse= (65) -  (Retirement age of Spouse)
	var annlcpfdefyrsself = ((retyrsself<=0) ? 0 :retyrsself);
	
	//Retirement years of Spouse= (65) -  (Retirement age of Spouse)
	var annlcpfdeftrssps =  ((retyrssps<=0) ? 0 : retyrssps);
	
	$("#retSelfLivyrs").val((isNaN(livingyrsself)?0:livingyrsself));
	$("input[name='txtFldRDSlfProlvyrs']").val((isNaN(livingyrsself)?0:livingyrsself)); //RD CF Analysis
	
	$("#retSpsLivyrs").val((isNaN(livingyrssps)?0:livingyrssps));
	$("input[name='txtFldRDSpsProlvyrs']").val(isNaN(livingyrssps)?0:livingyrssps);  //RD CF Analysis
	
	var assumedmaxLE = Math.max(livingyrsself, livingyrssps);
	$("#retFamLivyrs").val(isNaN(assumedmaxLE)?0:assumedmaxLE);
	$("input[name='txtFldRDFamProlvyrs']").val(isNaN(assumedmaxLE)?0:assumedmaxLE); //RD CF Analysis
	
	$("#retYrstoret").val(isNaN(calcforrtdage)?0:calcforrtdage);
	$("input[name='txtFldRDYrsToRet']").val(isNaN(calcforrtdage)?0:calcforrtdage);
	$("#lfretYrstoret").val($("#retYrstoret").val());//Life insurance - yr to ret
	
	
	$("#retSelfCoordinateage").val(isNaN(coordinateselfage)?0:coordinateselfage);
	$("input[name='txtFldRDSlfCoRetAge']").val(isNaN(coordinateselfage)?0:coordinateselfage);//RD CF Analysis
	$("#retSelfretage").val($("#retSelfCoordinateage").val());//Life insurance - retirement co ret age self
	
	
	$("#retSpsCoordinateage").val(isNaN(coordinatespsage)?0:coordinatespsage);
	$("input[name='txtFldSpsRDCoRetAge']").val(isNaN(coordinatespsage)?0:coordinatespsage);//RD CF Analysis
	$("#retSpouseretage").val($("#retSpsCoordinateage").val());//Life insurance - retirement co ret age spouse
	
	$("#retSelfAnnlexpdyrs").val(isNaN( $("#retSelfLivyrs").val())?0: $("#retSelfLivyrs").val());
	$("#retSpsAnnlexpdyrs").val(isNaN( $("#retSpsLivyrs").val())?0: $("#retSpsLivyrs").val());
	$("#retFamAnnlexpdyrs").val(isNaN($("#retFamLivyrs").val())?0:$("#retFamLivyrs").val() );
	
	$("#txtFldRetSelfAnnlIncyr").val(isNaN(annlcpfdefyrsself)?0:annlcpfdefyrsself);
	$("#txtFldRetSlfAnnlPte1RetYr").val(isNaN(annlcpfdefyrsself)?0:annlcpfdefyrsself);
	$("#txtFldRetSlfAnnlPte2RetYr").val(isNaN(annlcpfdefyrsself)?0:annlcpfdefyrsself);
	$("#txtFldRetSlfAnnlPte3RetYr").val(isNaN(annlcpfdefyrsself)?0:annlcpfdefyrsself);
	
	$("#txtFldRetSpsAnnlIncyr").val(isNaN(annlcpfdeftrssps)?0:annlcpfdeftrssps);
	$("#txtFldRetSpsAnnlPte1RetYr").val(isNaN(annlcpfdeftrssps)?0:annlcpfdeftrssps);
	$("#txtFldRetSpsAnnlPte2RetYr").val(isNaN(annlcpfdeftrssps)?0:annlcpfdeftrssps);
	$("#txtFldRetSpsAnnlPte3RetYr").val(isNaN(annlcpfdeftrssps)?0:annlcpfdeftrssps);
	assEffrate();
	cordretage();
	projlvyrs();
}


$("#retSelfCoordinateage,#retSpsCoordinateage").on("change blur",function(){
	cordretage();
});


function cordretage(){
	var retagebasedon=$("#retAgeBasedon").val();
	var slfCoRetAge=(!isEmpty($("#retSelfCoordinateage").val()))?Number($("#retSelfCoordinateage").val()) : 0;
	var spsCoRetAge =(!isEmpty($("#retSpsCoordinateage").val()))?Number($("#retSpsCoordinateage").val()) : 0;
	 
	 $("#retSelfCoordretage").val(slfCoRetAge);//ret plg (Self)
	 $("#txtFldRDSlfLvCorAge").val(slfCoRetAge);//rd cf (Self)
	 
	 $("#retSpsCoordretage").val(spsCoRetAge);//ret plg (Spouse) 
	 $("#txtFldRDSpsLvCorAge").val(spsCoRetAge);//rd cf (Spouse)
	 
	 if(!isEmpty(retagebasedon)){
		 if(retagebasedon == "Self"){
			 $("#retFamCoordretage").val(slfCoRetAge);
			 $("#txtFldRDFamLvCorAge").val(slfCoRetAge);
		 }else if(retagebasedon == "Spouse"){
			 $("#retFamCoordretage").val(spsCoRetAge);
			 $("#txtFldRDFamLvCorAge").val(spsCoRetAge);
		 }
	 }
}
function projlvyrs(){ 
	var SelfLivyrs=(!isEmpty($("#retSelfLivyrs").val()))?Number($("#retSelfLivyrs").val()) : 0;
	var SpsLivyrs =(!isEmpty($("#retSpsLivyrs").val()))?Number($("#retSpsLivyrs").val()) : 0;
	var famLivyrs =(!isEmpty($("#retFamLivyrs").val()))?Number($("#retFamLivyrs").val()) : 0;
	 
	 $("#txtFldSlfLvProAge").val(SelfLivyrs);//ret plg (Self)
	 $("#txtFldRDSlfLvProAge").val(SelfLivyrs);//rp cf(Self)
	 
	 $("#txtFldSpsLvProAge").val(SpsLivyrs);//ret plg (Spouse)
	 $("#txtFldRDSpsLvProAge").val(SpsLivyrs);//rp cf(Spouse)
	 
	 $("#txtFldFamLvProAge").val(famLivyrs);//ret plg (Family)
	 $("#txtFldRDFamLvProAge").val(famLivyrs);//rp cf(Family)
	  
}

/**
 * Retirement Planning - Other payment on retirement
 */

/*Datatable Initialisation*/
var OthRetPlgtbl = $('#OthRetPlgtbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9],"orderable": false,"searchable": false}],		
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	




/*Add Row Click */
$("#AOthRet").on("click",function(){
	 if(!validationRetirementScreen())return; 
			othretClearFlds();
			showFIPAModel('OthRet_Dialog','Other Payment to be made durning Retirement');   
			$('#OthRet_Dialog').on('shown.bs.modal', function () {
				$("#OthRet_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#OthRet_Dialog").find("input[id=txtFldDlgORtyofpay]").focus();//Aravindh
				$("#OthRet_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validateothretDetails())return;
					   	othretRdlyflds(INS_MODE);  
					   	getothretRows(null); 
						$('#OthRet_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getothretRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldothretMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldORId">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radothretSelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<input type="text" name="txtFldORtyofpay" class="form-control editable"   onmouseover="fipaTooltip(this);"  maxlength="150" />'; 
var cell3 = '<select type="text" name="selORFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
var cell4 = '<input type="text" name="txtFldORAnlExp" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell5 = '<input type="text" name="txtFldOREslrate" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell6 = '<select type="text" name="selORAgeBsOn" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
var cell7 = '<input type="text" name="txtFldORAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="20"/>';
var cell8 ='<input type="text" name="txtFldORAgePayends" class="form-control editable"  onmouseover="fipaTooltip(this);" maxlength="20"/>';
var cell9 ='<input type="text" name="txtFldORRemarks" class="form-control editable"  onmouseover="fipaTooltip(this);" maxlength="300"/>'+
'<input type="hidden" name="txtFldORCrtdBy"/><input type="hidden" name="txtFldORCrtdDate"/>'; 

OthRetPlgtbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9] ).draw( false );

var rowCount = $('#OthRetPlgtbl tbody tr').length;	
var $lastRow = $("#OthRetPlgtbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radothret"+$lastRow.index())
.parent().find('label').attr('for',"radothret"+$lastRow.index());

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgORtyofpay").val());

var orfreq = $("#selDlgORFreq > option").clone();
$lastRow.find("td:eq(3)").find('select:eq(0)').append(orfreq);
$lastRow.find("td:eq(3)").find('select:eq(0)').val($("#selDlgORFreq").val());
$lastRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){ 
	if(!rdFrequencyValidation($lastRow.find("td:eq(8)").find('input:eq(0)'),$lastRow.find("td:eq(5)").find('input:eq(0)'),$(this)))return; 
});

$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgORAnlExp").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntUsd");

$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgOREslrate").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntpCent3");

var oragebsed =  $("#selDlgORAgeBsOn > option").clone();
$lastRow.find("td:eq(6)").find('select:eq(0)').append(oragebsed);
$lastRow.find("td:eq(6)").find('select:eq(0)').val($("#selDlgORAgeBsOn").val());
$lastRow.find("td:eq(6)").find('select:eq(0)').on("change",function(){ 
//	if(!rdFrequencyValidation($lastRow.find("td:eq(6)").find('select:eq(0)'),$(this)))return; 
	if(!rdStartAgeValidate($lastRow.find("td:eq(7)").find('input:eq(0)'),$(this)))return;
});

 
$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgORAgePaySts").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){ 
	if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(6)").find('select:eq(0)')))return;
});

$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgORAgePayends").val());
$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(8)").find('input:eq(0)').on("change",function(){ 
	if(!rdEndAgeValidate($lastRow.find("td:eq(7)").find('input:eq(0)'),$(this)))return;
});


$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgORRemarks").val());




applyEventHandlers();


if(dataset != null){
	RDExptbl.rows().remove().draw();
	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "opId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
				break;
				
			case "retPaytype": 
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
				
				break;
				
			case "retFrequency":
				selectNullvalChk($lastRow.find("td:eq(3)"),col);   
				break;
			 
			case "retAnnualexp": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col); 
				break;
			 
			case "retEscarate": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col); 
				break;
			 
			 
			case "retAgebasedon": 
				selectNullvalChk($lastRow.find("td:eq(6)"),col);   
				 
				break;
			 
			 
			case "retAgestart": 
				$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 
				break;
			 
			 
			case "retAgeend": 
				$lastRow.find("td:eq(8)").find('input:eq(0)').val(col); 
				break;
				
			case "retOthRemarks": 
				$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
				break;
			  
			case "retCrtdBy": 
				$lastRow.find("td:eq(9)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "retCrtdDate":
				$lastRow.find("td:eq(9)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "retModBy":
				infoDetsArr.push(col);
				break;
				
			case "retModDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}
if(!rdFrequencyValidation($lastRow.find("td:eq(8)").find('input:eq(0)'),$lastRow.find("td:eq(5)").find('input:eq(0)'),$lastRow.find("td:eq(3)").find('select:eq(0)')))return;
//getSyncExpRows(dataset);
//othretClearFlds();
 
}


 
/*Edit Row Click */
$("#EOthRet").on("click",function(){
	$("#VOthRet").click(); 
});


/*View Row Click */
$("#VOthRet").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#OthRetPlgtbl tbody tr').length;	
	var $lastRow = $("#OthRetPlgtbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#OthRetPlgtbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
		
			
	});
	
	$("#OthRetPlgtbl tbody").find('input[name="radothretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#OthRetPlgtbl tbody").find('input[name="radothretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'});
				});  
				 	othretRdlyflds($mode);
					othretfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgORAgePayends'),$("#txtFldDlgOREslrate"),$("#selDlgORFreq")))return; 
					showFIPAModel('OthRet_Dialog','Other Payment to be made durning Retirement');  
					$('#OthRet_Dialog').on('shown.bs.modal', function () {
						$("#OthRet_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#OthRet_Dialog").find("input[id=txtFldDlgORtyofpay]").focus();//Aravindh
						$("#OthRet_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateothretDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			othretfilldomval($RowId,$row); 
					     		}  
					     		if(!rdFrequencyValidation($row.find("td:eq(8)").find('input:eq(0)'),$row.find("td:eq(5)").find('input:eq(0)'),$row.find("td:eq(3)").find('select:eq(0)')))return;
//					     		getSyncExpRows(null);
								$('#OthRet_Dialog').modal('hide'); 
								othretClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#DOthRet").on("click",function(){ 
	datatableDeleteRow('OthRetPlgtbl',OthRetPlgtbl); 

});

/*Clear Fields */
function othretClearFlds(){
	$("#OthRet_Dialog").find("input[type=text]").val("");
	$("#OthRet_Dialog").find("textarea").val("");
	$("#OthRet_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function othretRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#OthRet_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#OthRet_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateothretDetails(){
	  
	if(!(validateFocusFlds('OthRet_Dialog','txtFldDlgORtyofpay',OR_TYPE))) return; 
	if(!(validateFocusFlds('OthRet_Dialog','selDlgORFreq',OR_FREQ))) return; 
//	if(!(validateFocusFlds('OthRet_Dialog','txtFldDlgORAnlExp',OR_ANLEXP))) return; 
//	if(!(validateFocusFlds('OthRet_Dialog','txtFldDlgOREslrate',OR_ESC))) return; 
	if(!(validateFocusFlds('OthRet_Dialog','selDlgORAgeBsOn',OR_AGEBSE))) return; 
	if(!(validateFocusFlds('OthRet_Dialog','txtFldDlgORAgePaySts',OR_AGESTS))) return; 
//	if(!(validateFocusFlds('OthRet_Dialog','txtFldDlgORAgePayends',OR_AGEENDS))) return;  
	if(!rdFrequencyValidation($('#txtFldDlgORAgePayends'),$("#txtFldDlgOREslrate"),$("#selDlgORFreq")))return; 
	if(!rdStartAgeValidate($('#txtFldDlgORAgePaySts'),$('#selDlgORAgeBsOn')))return;
	if(!rdEndAgeValidate($('#txtFldDlgORAgePaySts'),$("#txtFldDlgORAgePayends")))return;
	  return true; 
}



/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgORtyofpay,#selDlgORFreq," +
		"#selDlgORAgeBsOn,#txtFldDlgORAgePaySts").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  

/* Filling Model Fields*/
function othretfilldlgval($lastRow){
	  
	  $('#OthRet_Dialog #txtFldDlgORId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#OthRet_Dialog #txtFldDlgORtyofpay').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#OthRet_Dialog #selDlgORFreq').val($lastRow.find("td:eq(3)").find('select:eq(0)').val());
	  $('#OthRet_Dialog #txtFldDlgORAnlExp').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#OthRet_Dialog #txtFldDlgOREslrate').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#OthRet_Dialog #selDlgORAgeBsOn').val($lastRow.find("td:eq(6)").find('select:eq(0)').val());
	  $('#OthRet_Dialog #txtFldDlgORAgePaySts').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#OthRet_Dialog #txtFldDlgORAgePayends').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#OthRet_Dialog #txtFldDlgORRemarks').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	 
	  $('#OthRet_Dialog #txtFldDlgORCrtdBy').val($lastRow.find("td:eq(9)").find('input:eq(1)').val());
	  $('#OthRet_Dialog #txtFldDlgORCrtdDate').val($lastRow.find("td:eq(9)").find('input:eq(2)').val());
	
}

/* Filling Table Fields*/
function othretfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgORtyofpay").val()); 
	$row.find("td:eq(3)").find('select:eq(0)').val($("#selDlgORFreq").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgORAnlExp").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgOREslrate").val()); 
	$row.find("td:eq(6)").find('select:eq(0)').val($("#selDlgORAgeBsOn").val());
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgORAgePaySts").val()); 
	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgORAgePayends").val());  
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgORRemarks").val());  
		
}

 

/**
 * Retirement Planning - Income payment on retirement
 */

/*Datatable Initialisation*/
var IncRetPlgtbl = $('#IncRetPlgtbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	



/*Add Row Click */
$("#AIncRet").on("click",function(){
	 if(!validationRetirementScreen())return; 
			incretClearFlds();
			showFIPAModel('IncRet_Dialog','Income to be received during retirement');   
			$('#IncRet_Dialog').on('shown.bs.modal', function () {
				$("#IncRet_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#IncRet_Dialog").find("input[id=txtFldDlgIRClsfy]").focus();//Aravindh
				$("#IncRet_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validateincretDetails())return;
					   	incretRdlyflds(INS_MODE);  
					   	getincretRows(null); 
						$('#IncRet_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getincretRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldincretMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldIRId">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radincretSelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<input type="text" name="txtFldIRClsfy" class="form-control editable"   onmouseover="fipaTooltip(this);"  maxlength="150"/>'; 
var cell3 = '<input type="text" name="txtFldIRDesc" class="form-control editable"   onmouseover="fipaTooltip(this);"  maxlength="150"/>';
var cell4 = '<select type="text" name="selIRFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
var cell5 = '<input type="text" name="txtFldIRAmtofInc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell6 = '<input type="text" name="txtFldIREslrate" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell7 = '<input type="text" name="txtFldIRRoi" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell8 = '<select type="text" name="selIRAgeBsOn" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
var cell9 = '<input type="text" name="txtFldIRAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="20"/>';
var cell10 ='<input type="text" name="txtFldIRAgePayends" class="form-control editable"  onmouseover="fipaTooltip(this);"maxlength="20" />'+
'<input type="hidden" name="txtFldIRCrtdBy"/><input type="hidden" name="txtFldIRCrtdDate"/>'; 


IncRetPlgtbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10] ).draw( false );

var rowCount = $('#IncRetPlgtbl tbody tr').length;	
var $lastRow = $("#IncRetPlgtbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radincret"+$lastRow.index())
.parent().find('label').attr('for',"radincret"+$lastRow.index());

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgIRClsfy").val());
$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgIRDesc").val());



var irfreq = $("#selDlgIRFreq > option").clone();
$lastRow.find("td:eq(4)").find('select:eq(0)').append(irfreq);
$lastRow.find("td:eq(4)").find('select:eq(0)').val($("#selDlgIRFreq").val());
$lastRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
	if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return; 
}); 



$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgIRAmtofInc").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");

$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgIREslrate").val());
$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");

$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgIRRoi").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");


var iragebsed =  $("#selDlgIRAgeBsOn > option").clone();
$lastRow.find("td:eq(8)").find('select:eq(0)').append(iragebsed);
$lastRow.find("td:eq(8)").find('select:eq(0)').val($("#selDlgIRAgeBsOn").val());
$lastRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){
	if(!rdStartAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
}); 


 
$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgIRAgePaySts").val());
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
	if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(8)").find('select:eq(0)')))return;
}); 


$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgIRAgePayends").val());
$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
	if(!rdEndAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
}); 

applyEventHandlers();
if(dataset != null){

	RDInctbl.rows().remove().draw();
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "txtFldIRId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
				break;
				
			case "txtFldIRClsfy": 
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
				
				break;
				
				
			case "txtFldIRDesc": 
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
				
				break;
				
			case "selIRFreq": 
				selectNullvalChk($lastRow.find("td:eq(4)"),col);   
				break;
			 
			case "txtFldIRAmtofInc": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col); 
				break;
			 
			case "txtFldIREslrate": 
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 
				break;
			 
			 
			case "txtFldIRRoi": 
				$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 
				break;
			 
			 
			case "selIRAgeBsOn": 
				selectNullvalChk($lastRow.find("td:eq(8)"),col);   
				break;
			 
			 
			case "txtFldIRAgePaySts": 
				$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
				break;
				
			case "txtFldIRAgePayends": 
				$lastRow.find("td:eq(10)").find('input:eq(0)').val(col); 
				break;
			  
			  
			case "txtFldIRCrtdBy": 
				$lastRow.find("td:eq(10)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "txtFldIRCrtdDate":
				$lastRow.find("td:eq(10)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "txtFldIRModBy":
				infoDetsArr.push(col);
				break;
				
			case "txtFldIRModDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}
if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$lastRow.find("td:eq(4)").find('select:eq(0)')))return; 
//getSyncIncRows(dataset);
//incretClearFlds();
 
}


 
/*Edit Row Click */
$("#EIncRet").on("click",function(){
	$("#VIncRet").click();
//	var isOneRowSelected=false;
//	$("#IncRetPlgtbl tbody").find('input[name="radincretSelect"]').each(function(){ 
//		if($(this).is(":checked")){ 
//			var $row = $(this).parents("tr"); 
//			var $mode = $(this).parents("tr").find("td:first").find('input:eq(0)').val(); 
//			
//			 
//			if($mode == INS_MODE){ 
//				$(this).parents("tr").find("td:first").find('input:eq(0)').val($mode); 
//				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
//					$(this).attr("disabled",false); 
//					$row.removeClass('selected');  
//					$(this).parent().css({border:'1px solid green'});
//					$row.css({border:'1px solid green'});
//					$row.find("td").css({border:'1px solid green'});
//				});  
//			}
//			
//			$(this).attr("checked",false);
//			isOneRowSelected=true;
//		}
//	});	    
//	if(!isOneRowSelected){
//		showAlert("No Rows Selected");
//	}
});


/*View Row Click */
$("#VIncRet").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#IncRetPlgtbl tbody tr').length;	
	var $lastRow = $("#IncRetPlgtbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#IncRetPlgtbl tbody").find('input[name="radincretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#IncRetPlgtbl tbody").find('input[name="radincretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 
				 
				 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'});
					});  
				 
				 
				 	incretRdlyflds($mode);
					incretfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgIRAgePayends'),$("#txtFldDlgIREslrate"),$("#selDlgIRFreq")))return; 
					showFIPAModel('IncRet_Dialog','Income to be received during retirement');  
					$('#IncRet_Dialog').on('shown.bs.modal', function () {
						$("#IncRet_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#IncRet_Dialog").find("input[id=txtFldDlgIRClsfy]").focus();//Aravindh
						$("#IncRet_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateincretDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			incretfilldomval($RowId,$row); 
					     		}  
					     		if(!rdFrequencyValidation($row.find("td:eq(10)").find('input:eq(0)'),$row.find("td:eq(6)").find('input:eq(0)'),$row.find("td:eq(4)").find('select:eq(0)')))return; 
								$('#IncRet_Dialog').modal('hide'); 
								incretClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#DIncRet").on("click",function(){ 
	datatableDeleteRow('IncRetPlgtbl',IncRetPlgtbl); 
});

/*Clear Fields */
function incretClearFlds(){
	$("#IncRet_Dialog").find("input[type=text]").val("");
	$("#IncRet_Dialog").find("textarea").val("");
	$("#IncRet_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function incretRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#IncRet_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#IncRet_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateincretDetails(){
	  
	if(!(validateFocusFlds('IncRet_Dialog','txtFldDlgIRClsfy',IR_CLSFY))) return;
//	if(!(validateFocusFlds('IncRet_Dialog','txtFldDlgIRDesc',IR_DESC))) return;
    if(!(validateFocusFlds('IncRet_Dialog','selDlgIRFreq',IR_FRQ))) return;
//	if(!(validateFocusFlds('IncRet_Dialog','txtFldDlgIRAmtofInc',IR_AMT))) return;
//	if(!(validateFocusFlds('IncRet_Dialog','txtFldDlgIREslrate',IR_ESC))) return;
//    if(!(validateFocusFlds('IncRet_Dialog','txtFldDlgIRRoi',IR_ROI))) return;
	if(!(validateFocusFlds('IncRet_Dialog','selDlgIRAgeBsOn',IR_AGEBASED))) return;
	if(!(validateFocusFlds('IncRet_Dialog','txtFldDlgIRAgePaySts',IR_AGESTS))) return;
//	if(!(validateFocusFlds('IncRet_Dialog','txtFldDlgIRAgePayends',IR_AGEENDS))) return;
	if(!rdFrequencyValidation($('#txtFldDlgIRAgePayends'),$("#txtFldDlgIREslrate"),$("#selDlgIRFreq")))return; 
	if(!rdStartAgeValidate($('#txtFldDlgIRAgePaySts'),$('#selDlgIRAgeBsOn')))return;
	if(!rdEndAgeValidate($('#txtFldDlgIRAgePaySts'),$("#txtFldDlgIRAgePayends")))return;
	  return true; 
}
 
/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgIRClsfy,#selDlgIRFreq," +
		"#selDlgIRAgeBsOn," +
		"#txtFldDlgIRAgePaySts").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  

/* Filling Model Fields*/
function incretfilldlgval($lastRow){
	  
	  $('#IncRet_Dialog #txtFldDlgIRId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#IncRet_Dialog #txtFldDlgIRClsfy').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#IncRet_Dialog #txtFldDlgIRDesc').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#IncRet_Dialog #selDlgIRFreq').val($lastRow.find("td:eq(4)").find('select:eq(0)').val());
	  $('#IncRet_Dialog #txtFldDlgIRAmtofInc').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#IncRet_Dialog #txtFldDlgIREslrate').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#IncRet_Dialog #txtFldDlgIRRoi').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#IncRet_Dialog #selDlgIRAgeBsOn').val($lastRow.find("td:eq(8)").find('select:eq(0)').val());
	  $('#IncRet_Dialog #txtFldDlgIRAgePaySts').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#IncRet_Dialog #txtFldDlgIRAgePayends').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#IncRet_Dialog #txtFldDlgIRCrtdBy').val($lastRow.find("td:eq(10)").find('input:eq(1)').val());
	  $('#IncRet_Dialog #txtFldDlgIRCrtdDate').val($lastRow.find("td:eq(10)").find('input:eq(2)').val());
	
}

/* Filling Table Fields*/
function incretfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgIRClsfy").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgIRDesc").val());
	$row.find("td:eq(4)").find('select:eq(0)').val($("#selDlgIRFreq").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgIRAmtofInc").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgIREslrate").val());
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgIRRoi").val()); 
	$row.find("td:eq(8)").find('select:eq(0)').val($("#selDlgIRAgeBsOn").val());  
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgIRAgePaySts").val());  
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgIRAgePayends").val());  
		
}

 
/**
 * Retirement Planning - Income and Assert on retirement
 */

/*Datatable Initialisation*/
var IncAssRetPlgtbl = $('#IncAssRetPlgtbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#AIncAssRet").on("click",function(){
	 if(!validationRetirementScreen())return; 
			incassrtClearFlds();
			showFIPAModel('IncAssRet_Dialog','Income and assets available for retirement');   
			$('#IncAssRet_Dialog').on('shown.bs.modal', function () {
				$("#IncAssRet_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#IncAssRet_Dialog").find("input[id=txtFldDlgIncAssClsfy]").focus();//Aravindh
				$("#IncAssRet_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validateincassrtDetails())return;
					   	incassrtRdlyflds(INS_MODE);  
					   	getincassrtRows(null,"N"); 
						$('#IncAssRet_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getincassrtRows(dataset,AddSts){ 

	 var intretslfage=Number($("#txtFldRDSlfIntAge").val());
		 var basedon=$("#retAgeBasedon").val().toUpperCase();

		 var totAge=Number($("#txtFldRDSlfProjLfe").val());
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldincassrtMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldIncAssId"><input type="hidden" name="txtFldIncAssRefId">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radincassrtSelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<input type="text" name="txtFldIncAssClsfy" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="150" />'; 
var cell3 = '<input type="text" name="txtFldIncAssDesc" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="150"/>';
var cell4 = '<select type="text" name="selIncAssFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
var cell5 = '<input type="text" name="txtFldIncAssAmtofInc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell6 = '<input type="text" name="txtFldIncAssEslrate" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell7 = '<input type="text" name="txtFldIncAssRoi" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell8 = '<select type="text" name="selIncAssAgeBsOn" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
var cell9 = '<input type="text" name="txtFldIncAssAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);"  maxlength="20"/>';
var cell10 ='<input type="text" name="txtFldIncAssAgePayends" class="form-control editable"  onmouseover="fipaTooltip(this);"  maxlength="20"/>'+
'<input type="hidden" name="txtFldIncAssCrtdBy"/><input type="hidden" name="txtFldIncAssCrtdDate"/>'; 


IncAssRetPlgtbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10] ).draw( false );

var rowCount = $('#IncAssRetPlgtbl tbody tr').length;	
var $lastRow = $("#IncAssRetPlgtbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radincassrt"+$lastRow.index())
.parent().find('label').attr('for',"radincassrt"+$lastRow.index());
if((AddSts =="Y")){
	
	
	 var dte=new Date();  
		var rowRefID=$("#lipPremiumsrc").attr("rowref");
		var rowRefID1=$("#sellipCoveragetype").attr("rowref");
			if(isValidObject(rowRefID)){
				rowRefID=rowRefID;
			}else if(isValidObject(rowRefID1)){
				rowRefID=rowRefID1;
			}else{
				rowRefID="LIFE_"+$lastRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
				 dte.getSeconds()+dte.getMilliseconds();
			}

			
	$lastRow.attr("rowref",rowRefID); 
	$lastRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
	$("#sellipCoveragetype").attr("rowref",rowRefID);
	 $("#lipPremiumsrc").attr("rowref",rowRefID);
	$("#lipRefId").val(rowRefID);
	
}


$lastRow.find("td:eq(2)").find('input:eq(0)').val((AddSts!="Y")?$("#txtFldDlgIncAssClsfy").val():"Insurance");
$lastRow.find("td:eq(3)").find('input:eq(0)').val((AddSts!="Y")?$("#txtFldDlgIncAssDesc").val():$("#lipPlanname").val());
$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){
	reverseRetSync($lastRow);//Reverse Sync process	
});




var iasfreq = $("#selDlgIncAssFreq > option").clone();
$lastRow.find("td:eq(4)").find('select:eq(0)').append(iasfreq);
$lastRow.find("td:eq(4)").find('select:eq(0)').val((AddSts!="Y")?(isEmpty($("#selDlgIncAssFreq").val())? "REGULAR" :  $("#selDlgIncAssFreq").val()) : "REGULAR" );
$lastRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
	if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
}); 

$lastRow.find("td:eq(5)").find('input:eq(0)').val((AddSts!="Y")?(isEmpty($("#txtFldDlgIncAssAmtofInc").val())? Number("0") :  Number($("#txtFldDlgIncAssAmtofInc").val())) :(isEmpty($("#lipSa").val())? Number("0") :  Number($("#lipSa").val())));
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
	reverseRetSync($lastRow);//Reverse Sync process	
});


$lastRow.find("td:eq(6)").find('input:eq(0)').val((AddSts!="Y")?(isEmpty($("#txtFldDlgIncAssEslrate").val())? Number("0") :  Number($("#txtFldDlgIncAssEslrate").val())) :"");
$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");

$lastRow.find("td:eq(7)").find('input:eq(0)').val((AddSts!="Y")? (isEmpty($("#txtFldDlgIncAssRoi").val())? Number("0") :  Number($("#txtFldDlgIncAssRoi").val())) :""); 
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");

var iassagebsed =  $("#selDlgIncAssAgeBsOn > option").clone();
$lastRow.find("td:eq(8)").find('select:eq(0)').append(iassagebsed);
$lastRow.find("td:eq(8)").find('select:eq(0)').val((AddSts!="Y")?(isEmpty($("#selDlgIncAssAgeBsOn").val())? basedon :  $("#selDlgIncAssAgeBsOn").val()): (isEmpty($("#lipOwner").val())?  basedon :  $("#lipOwner").val().toUpperCase()));
$lastRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
	if(!rdStartAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
	reverseRetSync($lastRow);//Reverse Sync process
}); 


$lastRow.find("td:eq(9)").find('input:eq(0)').val((AddSts!="Y")?(isEmpty($("#txtFldDlgIncAssAgePaySts").val())? intretslfage : Number($("#txtFldDlgIncAssAgePaySts").val())):intretslfage);
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
	if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(8)").find('select:eq(0)')))return;
}); 

$lastRow.find("td:eq(10)").find('input:eq(0)').val((AddSts!="Y")?(isEmpty($("#txtFldDlgIncAssAgePayends").val())? totAge : Number($("#txtFldDlgIncAssAgePayends").val())):totAge);
$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//	if(!rdFrequencyValidation($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
	if(!rdEndAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
}); 




applyEventHandlers();

if(dataset != null){
	RDIncAsstbl.rows().remove().draw();
	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){

		
		case "txtFldIncAssId": 
			$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
			break;

		case "txtFldIncAssRefId":  
			$lastRow.find("td:eq(0)").find('input:eq(2)').val(col); 
			if(!isEmpty(col)){$lastRow.attr("rowref",col);}
			break;
			
			
		case "txtFldIncAssClsfy": 
			$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
			
			break;
			
			
		case "txtFldIncAssDesc": 
			$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
			
			break;
			
		case "selIncAssFreq": 
			var value=(isEmpty(col)? "REGULAR" : col);
			selectNullvalChk($lastRow.find("td:eq(4)"),value);   
			break;
		 
		case "txtFldIncAssAmtofInc": 
			var value=(isEmpty(col)? Number("0") : col);
			$lastRow.find("td:eq(5)").find('input:eq(0)').val(value); 
			break;
		 
		case "txtFldIncAssEslrate": 
			var value=(isEmpty(col)?  Number("0") : col);
			$lastRow.find("td:eq(6)").find('input:eq(0)').val(value); 
			break;
		 
		 
		case "txtFldIncAssRoi": 
			var value=(isEmpty(col)? Number("0")  : col);
			$lastRow.find("td:eq(7)").find('input:eq(0)').val(value); 
			break;
		 
		 
		case "selIncAssAgeBsOn": 
			var value=(isEmpty(col)? basedon : col);
			selectNullvalChk($lastRow.find("td:eq(8)"),value);   
			break;
		 
		 
		case "txtFldIncAssAgePaySts": 
			var value=(isEmpty(col)? intretslfage : col);
			$lastRow.find("td:eq(9)").find('input:eq(0)').val(value); 
			break;
			
		case "txtFldIncAssAgePayends": 
			var value=(isEmpty(col)? totAge : col);
			$lastRow.find("td:eq(10)").find('input:eq(0)').val(value); 
			break;
		  
		  
		case "txtFldIncAssCrtdBy": 
			$lastRow.find("td:eq(10)").find('input:eq(1)').val(col);
			infoDetsArr.push(col);				
			break;
			
		case "txtFldIncAssCrtdDate":
			$lastRow.find("td:eq(10)").find('input:eq(2)').val(col);
			infoDetsArr.push(col);
			break;
			
		case "txtFldIncAssModBy":
			infoDetsArr.push(col);
			break;
			
		case "txtFldIncAssModDate":
			infoDetsArr.push(col);
			break;	
		}			 
		 
	}
	}
if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$lastRow.find("td:eq(4)").find('select:eq(0)')))return;
//if((AddSts=="Y")){
//	$lastRow.addClass("lifeIns");
//	
//	var dte=new Date();
//	var rowRefID="LIFEREF-"+$lastRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
//	 dte.getSeconds()+dte.getMilliseconds();
//	
//	$lastRow.attr("rowref",rowRefID);
//	
//	getSyncIncAssRows(dataset,"Y",rowRefID);
//}else{
//	getSyncIncAssRows(dataset,"N");	
//}

//incassrtClearFlds();
 
}


 
/*Edit Row Click */
$("#EIncAssRet").on("click",function(){
	$("#VIncAssRet").click();
//	var isOneRowSelected=false;
//	$("#IncAssRetPlgtbl tbody").find('input[name="radincassrtSelect"]').each(function(){ 
//		if($(this).is(":checked")){ 
//			var $row = $(this).parents("tr"); 
//			var $mode = $(this).parents("tr").find("td:first").find('input:eq(0)').val(); 
//			
//			 
//			if($mode == INS_MODE){ 
//				$(this).parents("tr").find("td:first").find('input:eq(0)').val($mode); 
//				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
//					$(this).attr("disabled",false); 
//					$row.removeClass('selected');  
//					$(this).parent().css({border:'1px solid green'});
//					$row.css({border:'1px solid green'});
//					$row.find("td").css({border:'1px solid green'});
//				});  
//			}
//			
//			$(this).attr("checked",false);
//			isOneRowSelected=true;
//		}
//	});	    
//	if(!isOneRowSelected){
//		showAlert("No Rows Selected");
//	}
});


/*View Row Click */
$("#VIncAssRet").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#IncAssRetPlgtbl tbody tr').length;	
	var $lastRow = $("#IncAssRetPlgtbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#IncAssRetPlgtbl tbody").find('input[name="radincassrtSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#IncAssRetPlgtbl tbody").find('input[name="radincassrtSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'});
				});  
				 	incassrtRdlyflds($mode);
					incassrtfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgIncAssAgePayends'),$("#txtFldDlgIncAssEslrate"),$("#selDlgIncAssFreq")))return; 
					showFIPAModel('IncAssRet_Dialog','Income and assets available for retirement');  
					$('#IncAssRet_Dialog').on('shown.bs.modal', function () {
						$("#IncAssRet_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#IncAssRet_Dialog").find("input[id=txtFldDlgIncAssClsfy]").focus();
						$("#IncAssRet_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateincassrtDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			incassrtfilldomval($RowId,$row); 
					     		}  
					     		reverseRetSync($row);//Reverse Sync process
							 			
							 		 
					     		if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$lastRow.find("td:eq(4)").find('select:eq(0)')))return;
								$('#IncAssRet_Dialog').modal('hide'); 
								incassrtClearFlds();
							
						});
					});
					 
			}  
			
			isOneRowSelected++;
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#DIncAssRet").on("click",function(){ 
	datatableDeleteRow("IncAssRetPlgtbl",IncAssRetPlgtbl);  

});

/*Clear Fields */
function incassrtClearFlds(){
	$("#IncAssRet_Dialog").find("input[type=text]").val("");
	$("#IncAssRet_Dialog").find("textarea").val("");
	$("#IncAssRet_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function incassrtRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#IncAssRet_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#IncAssRet_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateincassrtDetails(){
	 
	if(!(validateFocusFlds('IncAssRet_Dialog','txtFldDlgIncAssClsfy',INCASS_CLSFY))) return; 
//	if(!(validateFocusFlds('IncAssRet_Dialog','txtFldDlgIncAssDesc',INCASS_DESC))) return;
	if(!(validateFocusFlds('IncAssRet_Dialog','selDlgIncAssFreq',INCASS_FREQ))) return; 
//	if(!(validateFocusFlds('IncAssRet_Dialog','txtFldDlgIncAssAmtofInc',INCASS_AMT))) return; 
//	if(!(validateFocusFlds('IncAssRet_Dialog','txtFldDlgIncAssEslrate',INCASS_ESC))) return; 
//	if(!(validateFocusFlds('IncAssRet_Dialog','txtFldDlgIncAssRoi',INCASS_ROI))) return; 
	if(!(validateFocusFlds('IncAssRet_Dialog','selDlgIncAssAgeBsOn',INCASS_AGEBSD))) return; 
	if(!(validateFocusFlds('IncAssRet_Dialog','txtFldDlgIncAssAgePaySts',INCASS_AGESTS))) return; 
//	if(!(validateFocusFlds('IncAssRet_Dialog','txtFldDlgIncAssAgePayends',INCASS_AGEENDS))) return;
	if(!rdFrequencyValidation($('#txtFldDlgIncAssAgePayends'),$("#txtFldDlgIncAssEslrate"),$("#selDlgIncAssFreq")))return; 
	if(!rdStartAgeValidate($('#txtFldDlgIncAssAgePaySts'),$('#selDlgIncAssAgeBsOn')))return;
	if(!rdEndAgeValidate($('#txtFldDlgIncAssAgePaySts'),$("#txtFldDlgIncAssAgePayends")))return;
	  return true; 
}
 
/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgIncAssClsfy,#selDlgIncAssFreq," + 
		"#selDlgIncAssAgeBsOn,#txtFldDlgIncAssAgePaySts").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function incassrtfilldlgval($lastRow){
	  $('#IncAssRet_Dialog #txtFldDlgIncAssId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssRefId').val($lastRow.find("td:eq(0)").find('input:eq(2)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssClsfy').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssDesc').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#IncAssRet_Dialog #selDlgIncAssFreq').val($lastRow.find("td:eq(4)").find('select:eq(0)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssAmtofInc').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssEslrate').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssRoi').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#IncAssRet_Dialog #selDlgIncAssAgeBsOn').val($lastRow.find("td:eq(8)").find('select:eq(0)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssAgePaySts').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssAgePayends').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssCrtdBy').val($lastRow.find("td:eq(10)").find('input:eq(1)').val());
	  $('#IncAssRet_Dialog #txtFldDlgIncAssCrtdDate').val($lastRow.find("td:eq(10)").find('input:eq(2)').val());
}

/* Filling Table Fields*/
function incassrtfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgIncAssClsfy").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgIncAssDesc").val());
	$row.find("td:eq(4)").find('select:eq(0)').val($("#selDlgIncAssFreq").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgIncAssAmtofInc").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgIncAssEslrate").val());
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgIncAssRoi").val()); 
	$row.find("td:eq(8)").find('select:eq(0)').val($("#selDlgIncAssAgeBsOn").val());  
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgIncAssAgePaySts").val());  
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgIncAssAgePayends").val());  
		
}

/*Validations*/
/*Table1*/
$("#selDlgORFreq").on("change",function(){
	if(!rdFrequencyValidation($('#txtFldDlgORAgePayends'),$("#txtFldDlgOREslrate"),$(this)))return; 
}); 

$("#txtFldDlgORAgePaySts,#selDlgORAgeBsOn").on("change",function(){
	if(!rdStartAgeValidate($('#txtFldDlgORAgePaySts'),$('#selDlgORAgeBsOn')))return;
});
$("#txtFldDlgORAgePayends").on("change",function(){
	if(!rdEndAgeValidate($('#txtFldDlgORAgePaySts'),$(this)))return;
});

/*Table2*/
$("#selDlgIRFreq").on("change",function(){
	if(!rdFrequencyValidation($('#txtFldDlgIRAgePayends'),$("#txtFldDlgIREslrate"),$(this)))return; 
}); 

$("#txtFldDlgIRAgePaySts,#selDlgIRAgeBsOn").on("change",function(){
	if(!rdStartAgeValidate($('#txtFldDlgIRAgePaySts'),$('#selDlgIRAgeBsOn')))return;
});
$("#txtFldDlgIRAgePayends").on("change",function(){
	if(!rdEndAgeValidate($('#txtFldDlgIRAgePaySts'),$(this)))return;
});
 
/*Table3*/
$("#selDlgIncAssFreq").on("change",function(){
	if(!rdFrequencyValidation($('#txtFldDlgIncAssAgePayends'),$("#txtFldDlgIncAssEslrate"),$(this)))return; 
}); 

$("#txtFldDlgIncAssAgePaySts,#selDlgIncAssAgeBsOn").on("change",function(){
	if(!rdStartAgeValidate($('#txtFldDlgIncAssAgePaySts'),$('#selDlgIncAssAgeBsOn')))return;
});
$("#txtFldDlgIncAssAgePayends").on("change",function(){
	if(!rdEndAgeValidate($('#txtFldDlgIncAssAgePaySts'),$(this)))return;
});



function reverseRetSync($row){
	//Retirement Data
	var $rowref=$row.attr("rowref");
		if(isValidObject($rowref)){ 
	
	var syncOn=$rowref.substring(0,3);
	var owner=$row.find("td:eq(8)").find('select:eq(0)').val();
	var ownership;
	if(owner == "SELF"){
		ownership="Self";
	}else if(owner == "SPOUSE"){
		ownership="Spouse";
	}else{
		ownership="";
	}
	var amountofincome=$row.find("td:eq(5)").find('input:eq(0)').val();  
	var description=$row.find("td:eq(3)").find('input:eq(0)').val();  
	
	if(syncOn == "INV"){
		$("#fnaInvestmentTbl tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
			applyToastrAlert("Retirement data will be reflected back to Investment Screen !"); 
			  $(this).find("td:eq(9)").find('input:eq(0)').val(amountofincome);
			  $(this).find("td:eq(2)").find('select:eq(0)').val(ownership); 
			  //Cpf table change 
		 			newRowInvestCpfEditTbl( $(this));
		 		
		});
	}
	
	
	if(syncOn == "CAB"){
		$("#cashOfBanksTable tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
			applyToastrAlert("Retirement data will be reflected back to Cash At Bank Screen !"); 
			  if(ownership == "Self"){	
				  $(this).find("td:eq(2)").find('option:eq(1)').prop("selected","selected");
			  }else if(ownership == "Spouse"){	
				  $(this).find("td:eq(2)").find('option:eq(2)').prop("selected","selected");
			  }else{	
				  $(this).find("td:eq(2)").find('option:eq(0)').prop("selected","selected");
			  }
			  $(this).find("td:eq(9)").find('input:eq(0)').val(amountofincome);
			  $(this).find("td:eq(5)").find('select:eq(0)').val(ownership); 
		});
	}
	
	
	
	
	if(syncOn == "PRO"){
		$("#fnaPropOwnTblByCPF tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
			applyToastrAlert("Retirement data will be reflected back to Property Ownership Screen !");  
			  $(this).find("td:eq(2)").find('input:eq(0)').val(description);
			  $(this).find("td:eq(4)").find('select:eq(0)').val(ownership); 
			  $(this).find("td:eq(16)").find('input:eq(0)').val(amountofincome);
		});
	}
	
	 
		}
		
		//Life Insurance reverse sync
		if(isValidObject($("#sellipCoveragetype").attr("rowref"))){
	    
		var covergerowref=$("#sellipCoveragetype").attr("rowref").length;
		if(covergerowref >0){
			applyToastrAlert("Retirement data will be reflected back to Life Insurance Screen !");
			$("#lipPlanname").val(description);
			$("#lipSa").val(amountofincome);
			$("#lipOwner").val(ownership);
			
			//Cpf table change
			 var $rowref=$("#lipPremiumsrc").attr("rowref").length;
			 if($rowref > 0){	
				 SyncLifeToCpfAddDed($("#lipPremiumsrc").val());
		 	 }	
		}
		}
		
		
		
}











