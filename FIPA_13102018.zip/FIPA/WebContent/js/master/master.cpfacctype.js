
var cpfacctypeform ;

var stafftype = $('#hTxtFldLoggedStfType').val();


/*Datatable Initialisation*/
var CpfAccTypeTbl = $('#CpfAccTypeTbl').DataTable( {
   destroy: true,
   responsive: false,         
   ordering: false,
   searching: false,     
   scrollY:  "30vh",
   scrollX: true,
   scroller: false,
   scrollCollapse:false,
   paging:false, 
   filter:false,   
   columnDefs: [], 
   dom: '<<"top" ip>flt>',  
   columnDefs: [  { width: '20px', targets: [0,1]},
  	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
   
		 }, 
}).draw();

function fipaInitPage(){
	
	cpfacctypeform = document.forms[0];
	
	if(stafftype == STAFFTYPE_STAFF){ //Amin
//		$('#mastercpf_li').removeClass("hidden");
		$("#btnSave").removeClass("hidden");  
	}
	if(stafftype == STAFFTYPE_ADVISER){
		$("#btnSave").addClass("hidden");  
		}

	
	 showTooltip('CpfAccAddRow','Add Row For Master CPF Account Details');
	 showTooltip('CpfAccEditRow','Edit Row For Master CPF Account Details');
	 showTooltip('CpfAccDelRow','Delete Row For Master CPF Account Details');
	 showTooltip('CpfAccViewRow','View Row For Master CPF Account Details');
	
	 
	 showTooltip('btnSearch','Search Master CPF Account Details');
	 showTooltip('btnSave','Save Master CPF Account Details');
	 
	
	   showTooltip('btnFipaHome',STR_FIPA_HOME);
	   showTooltip('btnLogout',STR_FIPA_LOGOUT);
	   
	   $('.accordHeaderDiv').css("display","none"); 
//	   $("#btnSaveProfile").removeClass("hidden");
//	   $("#btnDeleteProfile").removeClass("hidden");
	   $("#sidebar-menu ul li[id='mastercpf_li']").click(); 
	   $("#sidebar-menu ul li[id='masteracctypes']").parent().removeClass("sideMenuHighlight nv");
	   $("#sidebar-menu ul li[id='masteracctypes']").addClass("sideMenuHighlight nv");
	   
	   $('#mastercpf_li').removeClass("hidden");
		$('#mastercpf_li').css("display", "block");
		CpfAcTypeSrch();
	   hideLoader();
}

function clearAccTypDets(){
	
}


$("#btnSave").on("click",function(){
	fipaMasterSave();
});

function fipaMasterSave(){
	 

	 enableComboWhenSubmit(cpfacctypeform);
	  
	cpfacctypeform.action = "CpfAccountTypeSave.do";
	cpfacctypeform.submit();
		
}


$("#btnSearch").on("click",function(){
	CpfAcTypeSrch();
});


function CpfAcTypeSrch(){
	showLoader(); 
	CpfAccTypeTbl.clear().draw(); 
var srchCpfParams="";
srchCpfParams = "&selSrchCpfAcctype="+encodeURIComponent(escape($("#selSrchCpfAcctype").val()));

var parameter = "DBCALLFOR=CPFACCTYPE_SEARCH"+srchCpfParams;

ajaxCall(parameter,servletName,function(Data){
var retval = Data;
hideLoader()
for ( var val in retval) {
var tabdets = retval[val];

  
if (tabdets["SESSION_EXPIRY"]) {
	window.location = BASE_URL +  SESSION_EXP_JSP;
	return;
}

if (tabdets["DB_ERROR"]) {
	window.location = BASE_URL +  DB_EXP_JSP;
	return;
}

for ( var tab in tabdets) {
	

	if (tabdets.hasOwnProperty(tab)) {	
		var key = tab;
		var value = tabdets[tab];
		  
		if (key == "CPFACCTYPE_SEARCH"){ 
	       
			//("key == CPFACCTYPE_SEARCH");
			for ( var cont in value) {
				if (value.hasOwnProperty(cont)) { 
					
					var contvalue = value[cont];

					getCpfAccTypeRows(contvalue); 
					
				}
			}
			
			 				
						
		}
		
	}
}
}
});

}
/**/
/*Add Row Click */
$("#CpfAccAddRow").on("click",function(){
			cpfAccClearFlds();
			showFIPAModel('CpfAccTyp_Dialog','CPF Account Type');  
			$('#CpfAccTyp_Dialog').on('shown.bs.modal', function () {
				$("#CpfAccTyp_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#CpfAccTyp_Dialog").find("input[id=txtFldDlgAccType]").focus();
				$("#CpfAccTyp_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatecpfAccDetails())return;
						cpfAccRdlyflds(INS_MODE);  
						getCpfAccTypeRows(null); 
						$('#CpfAccTyp_Dialog').modal('hide'); 
				  });  
			});			
});
/*Populate Data */
function getCpfAccTypeRows(dataset){ 

var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldCpfAccTypMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldCpfAccTypeId">';
//var cell1 = '<input type="checkbox" name="radcpfAccTypeSelect" />'; 


var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radcpfAccTypeSelect"/><label>&nbsp;</label></div>'; 


var cell2 = '<input  type="text" name="txtFldCpfAccType" class="form-control editable"  onmouseover="fipaTooltip(this);" maxlength="20"/>';
 
var cell3 = '<input type="text" name="txtFldCpfAccCode" class="form-control editable"  onmouseover="fipaTooltip(this);" maxlength="20"/>'; 

var cell4 = '<input type="text" name="txtFldCpfAccCommenceAge" class="form-control editable"  onmouseover="fipaTooltip(this);" maxlength="3"/>';

var cell5 = '<input type="text" name="txtFldCpfAccWithdrawAge" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="3"/>'+
'<input type="hidden" name="txtFldCpfAccCrtdBy"/><input type="hidden" name="txtFldCpfAccCrtdDate"/>';

CpfAccTypeTbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5] ).draw( false );

var rowCount = $('#CpfAccTypeTbl tbody tr').length;	
var $lastRow = $("#CpfAccTypeTbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radcpfAccType"+$lastRow.index())
.parent().find('label').attr('for',"radcpfAccType"+$lastRow.index());

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgAccType").val());


$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgAccCode").val());


$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgAccCommnceAge").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntYrs");

$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgAccWitdrwAge").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntYrs");

applyEventHandlers();


if(dataset != null){

	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
		case "cpfAcId": 
			$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
			break;
			
		case "accType": 
			$lastRow.find("td:eq(2)").find('input:eq(0)').val(col);
			$lastRow.find("td:eq(2)").find('input:eq(0)').prop("disabled",true);
			break;
			
		case "accCode": 
			$lastRow.find("td:eq(3)").find('input:eq(0)').val(col);
			$lastRow.find("td:eq(3)").find('input:eq(0)').prop("disabled",true);
			break;
		 
		case "accCommAge": 
			$lastRow.find("td:eq(4)").find('input:eq(0)').val(col);
			$lastRow.find("td:eq(4)").find('input:eq(0)').prop("disabled",true);
			break;
		 
		case "accWithdrawAge": 
			$lastRow.find("td:eq(5)").find('input:eq(0)').val(col);
			$lastRow.find("td:eq(5)").find('input:eq(0)').prop("disabled",true);
			break;
		
		case "accCrtdBy": 
			$lastRow.find("td:eq(5)").find('input:eq(1)').val(col);
			infoDetsArr.push(col);
			break;
			
		case "accCrtdDate": 
			$lastRow.find("td:eq(5)").find('input:eq(2)').val(col);
			infoDetsArr.push(col);	
			break;
		}			 
		 
	}
	}

cpfAccClearFlds();

}

/*Edit Row Click */
$("#CpfAccEditRow").on("click",function(){
	$("#CpfAccViewRow").click();
});

/*View Row Click */
$("#CpfAccViewRow").on("click",function(){
	
	 
	var isOneRowSelected=0;
	var $rowCount = $('#CpfAccTypeTbl tbody tr').length;	
	var $lastRow = $("#CpfAccTypeTbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view");
		return;
	} 
	
	$("#CpfAccTypeTbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
	});
	
	
	$("#CpfAccTypeTbl tbody").find('input[name="radcpfAccTypeSelect"]').each(function(){ //Checkbox selection
	
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					});  
					
				 $curElm.prop("checked",false);
		     	 $curElm.parents("tr").removeClass('selected');
		     	 cpfAccRdlyflds($mode);
				 cpfaccfilldlgval($row); 
				 showFIPAModel('CpfAccTyp_Dialog','CPF Account Type'); 
					$('#CpfAccTyp_Dialog').on('shown.bs.modal', function () {
						$("#CpfAccTyp_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#CpfAccTyp_Dialog").find("input[id=txtFldDlgAccType]").focus();
						$("#CpfAccTyp_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatecpfAccDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			cpfaccfilldomval($RowId,$row); 
					     		} 
					     		
								$('#CpfAccTyp_Dialog').modal('hide'); 
								cpfAccClearFlds();
							
						});
					});
					 
			} 
			if(($mode == QRY_MODE) ){
				var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE); 
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					});  
				 $curElm.prop("checked",false);
		     	 $curElm.parents("tr").removeClass('selected'); 
				 cpfAccRdlyflds($mode);
				cpfaccfilldlgval($row); 
				showFIPAModel('CpfAccTyp_Dialog','CPF Account Type');
					$('#CpfAccTyp_Dialog').on('shown.bs.modal', function () {
						$("#CpfAccTyp_Dialog").find(".modal-footer").find("button:eq(0)").text("ok");
						$("#CpfAccTyp_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatecpfAccDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			cpfaccfilldomval($RowId,$row); 
					     		} 
					     		
								$('#CpfAccTyp_Dialog').modal('hide'); 
								cpfAccClearFlds();
							
						});
					});
			}
			
			
			$curElm.attr("checked",false);
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	
});


/*Delete Row Click */
$("#CpfAccDelRow").on("click",function(){ 
	
	datatableDeleteRow('CpfAccTypeTbl',CpfAccTypeTbl); 	
});


/*Clear Fields */
function cpfAccClearFlds(){
	$("#CpfAccTyp_Dialog").find("input[type=text]").val("");
	$("#CpfAccTyp_Dialog").find("textarea").val("");
	$("#CpfAccTyp_Dialog").find("select").val("");
}


/*Disabled/Readonly Fields */
function cpfAccRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#CpfAccTyp_Dialog :input").prop("disabled", false); 
			$("#CpfAccTyp_Dialog :button").prop("disabled", false); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#CpfAccTyp_Dialog :input").prop("disabled", false);
	 }
}
/*Validation */
function validatecpfAccDetails(){ 
	if(!(validateFocusFlds('CpfAccTyp_Dialog','txtFldDlgAccType', CPF_ACCOUNT))) return;
	  return true; 
}

/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgAccType").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});

/* Filling Model Fields*/
function cpfaccfilldlgval($lastRow){
	  
	  $('#CpfAccTyp_Dialog #txtFldDlgCpfAccId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#CpfAccTyp_Dialog #txtFldDlgAccType').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#CpfAccTyp_Dialog #txtFldDlgAccCode').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#CpfAccTyp_Dialog #txtFldDlgAccCommnceAge').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#CpfAccTyp_Dialog #txtFldDlgAccWitdrwAge').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#CpfAccTyp_Dialog #txtFldDlgCpfAccCreatedBy').val($lastRow.find("td:eq(5)").find('input:eq(1)').val());
	  $('#CpfAccTyp_Dialog #txtFldDlgCpfAccCreatedDate').val($lastRow.find("td:eq(5)").find('input:eq(2)').val());
}

/* Filling Table Fields*/
function cpfaccfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgAccType").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgAccCode").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgAccCommnceAge").val()); 
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgAccWitdrwAge").val()); 		
}

function validateCpfAcIsExisted(cpfAcId){ 
	//alert("validateCpfAcIsExisted"+cpfAcId.value);

	var rowCount = $('#CpfAccTypeTbl tbody tr').length;	
	var $lastRow = $("#CpfAccTypeTbl tbody tr:last");	

	
  
var respText;
var srchCpfParams="";
srchCpfParams += "&txtFldAccType="+encodeURIComponent(escape(cpfAcId.value));
 
var mode ; 
var parameter = "DBCALLFOR=CPF_ACC_SRCH_EXIST"+srchCpfParams;
var validateFlag=0;


$('#CpfAccTypeTbl tbody tr').each(function(){
	mode=$(this).find("td:eq(0)").find("input:eq(0)").val();
	var chkbox=$(this).find("td:eq(1)").find("input:first");
	var acctype=$(this).find("td:eq(2)").find("input:eq(0)").val();
	if(mode!= 'D' && (chkbox.is(":checked")== false)){
		validateFlag = 1;
	}
	
	if(validateFlag){ 
		if(!isEmpty(cpfAcId.value) && !(mode == 'D')){ 

			ajaxCall(parameter,servletName,function(Data){
			var retval = Data;
			hideLoader()
			for ( var val in retval) {
			var tabdets = retval[val];

			  
			if (tabdets["SESSION_EXPIRY"]) {
				window.location = BASE_URL +  SESSION_EXP_JSP;
				return;
			}

			if (tabdets["DB_ERROR"]) {
				window.location = BASE_URL +  DB_EXP_JSP;
				return;
			}

			for ( var tab in tabdets) {
				

				if (tabdets.hasOwnProperty(tab)) {	
					var key = tab;
					var value = tabdets[tab];
					  
					if (key == "CPF_ACC_EXISTED"){ 
				 showAlert("Already Exist",$("#txtFldDlgAccType")); 
					$("#txtFldDlgAccType").val("");
					
					$("#txtFldDlgAccType").focus();
					 return false; 		
					}else{
						return true;
					}
					
				}
			}
			}
			});
	     }
		return;
	}	
	
});

}








function acctypeChkDhtml(cpfAcId){
	//alert("acctypeChkDhtml"+cpfAcId.value);
	
var enterAccType=cpfAcId.value; 

	
   
var mode ;  
var validateFlag=0;


$('#CpfAccTypeTbl tbody tr').each(function(){
	mode=$(this).find("td:eq(0)").find("input:eq(0)").val();
	var chkbox=$(this).find("td:eq(1)").find("input:first");
	var acctype=$(this).find("td:eq(2)").find("input:eq(0)").val();
	//alert("acctype"+acctype)
	if(mode!= 'D' && (chkbox.is(":checked")== false)){
		//alert("mode!= 'D' && (chkbox.is()== false");
		validateFlag = 1;
	}
	
	if(validateFlag){ 
		//alert("if Condition ")
		
		if(!isEmpty(cpfAcId.value) && !(mode == 'D')){ 

			if (acctype == enterAccType){ 
				//alert("Condition true");
				 showAlert("Already Exist",$("#txtFldDlgAccType")); 
					$("#txtFldDlgAccType").val("");
					
					$("#txtFldDlgAccType").focus();
					 return false; 		
					}else{
						return true;
					}
					
	     }
		return;
	}	
	
});

}
