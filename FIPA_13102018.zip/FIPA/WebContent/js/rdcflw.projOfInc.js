var generatetoamendincExp;

$("a#RdAmendInc ,a#RdAmendExp").click(function(){
	amendIncomeAndExpenditure();
});

function amendIncomeAndExpenditure(){
	if(!validationOnProjOfExp())return;
	if(!validationOnProjOfInc())return;
	 getRDIncomeAndExp();
}

function getRDIncomeAndExp(){
	 
	$("#generateproRetirementtbl tbody").html("");
	
	var projOnRtddata = [];
	 $("#projInvRettbldiv").css("display","block"); 

var headlist=[];



var dataHeader=[
                {"data":"Self Age","title":"Self Age"},
                {"data":"Spouse Age","title":"Spouse Age"},
                {"data":"Current cash funds on retirement","title":"Current cash funds on retirement"},
                {"data":"Annual income","title":"Annual income"},
                {"data":"Annual Expenses","title":"Annual Expenses"},
                {"data":"Available retirement funds -(Surplus/ deficit)","title":"Available retirement funds -(Surplus/ deficit)"},
                ];
 



/*Data Set*/
 
var intretslfage=Number($("#txtFldRDSlfIntAge").val());
var intretspsage=Number($("#txtFldRDSpsIntAge").val());

var totAge=Number($("#txtFldRDSlfProjLfe").val());
 

var dataset=[];

/*Data Set*/ 
//$("#RetirementValueBasedOn").val(agebasedon); 

var count=0;
var oldval=0;
var olddata=0;
   
	d3.select("#CashFlwprojectionOnRtmnt").selectAll("svg").remove();
var ExpHeadercount=Number(rdcflwTbl.columns().header().length)-1;
var IncHeadercount=Number(rdcflwIncAssTbl.columns().header().length)-1;
var spouseage=intretspsage;
for(var i=intretslfage;i<=totAge;i++){ 
		
	var arrlist={};
			
			arrlist["Self Age"]=i+'<input type="hidden" value="'+(count+1)+'"/>'; //self age
			arrlist["Spouse Age"]=spouseage; //spouse age
			arrlist["Current cash funds on retirement"]=0;
			
			var anlInc=Number($("#generateproExptbl").find("tr:eq("+(count+1)+")").find("td:eq("+ExpHeadercount+")").get(0).innerHTML);
			arrlist["Annual income"]=RemDecimalNumber(anlInc);
				 
			var anlExp=Number($("#generateproIncometbl").find("tr:eq("+(count+1)+")").find("td:eq("+IncHeadercount+")").get(0).innerHTML);
			arrlist["Annual Expenses"]=RemDecimalNumber(anlExp);
			
			
			var total=Math.abs(anlExp-anlInc);
			   
			arrlist["Available retirement funds -(Surplus/ deficit)"]=RemDecimalNumber(total);  
			   
			
			 
			
			dataset.push(arrlist)
			
			spouseage++;
			count++;
			
			projOnRtddata.push({Date: i,Categories: [{Name: "Annual income",Value: anlInc }, { Name: "Annual Expenses",Value: anlExp}],LineCategory: [{Name: "Available retirement funds -(Surplus/ deficit)",Value: total}]});
			 
			
		}
 
genCashFlwProjChartOnRtrmnt(projOnRtddata);

if ($.fn.DataTable.isDataTable( '#generatetoamendincExp') ) {
	generatetoamendincExp.destroy();
	$('#generatetoamendincExp').html("");
}			 
 

	/*Generate Proper header*/
generatetoamendincExp=$('#generatetoamendincExp').DataTable( { 
		destroy: true,
	 	responsive: false,         
	    ordering: false,
	    searching: false,     
	    scrollY:  "40vh",
	    scrollX: true,
	    scroller: false,
	    scrollCollapse:false,
	    paging:false, 
	    filter:false,   
	    columnDefs: [], 
	    dom: '<<"top" ip>flt>', 
	    "columns": dataHeader,  
	    "createdRow": function ( row, data, index ) {
	    		
        },
        data:dataset,
       	columnDefs: [{"className": "dt-right","targets": "_all","orderable": false,"searchable": false}, ],
//       				{"className": "dt-left","targets": [1-7]},{visible:false,"targets":[8]},{visible:false,"targets":[9]},
//       				{"className": "hidden","targets":[10]}],
		fnDrawCallback: function(oSettings) {
		    		if(this.fnSettings().bSorted){
		    			reorderSino('generatetoamendincExp');
		    		}
    	}    	
	}).draw();



var len=Number($("#generatetoamendincExp thead tr").find("th").length)-1;  
$("#generatetoamendincExp_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th").css("text-align","center");
$("#generatetoamendincExp_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th:eq('"+(Number(len)-1)+"')").css("background-color","#337AB7").css("color","white");
$("#generatetoamendincExp_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th:eq('"+(Number(len)-2)+"')").css("background-color","#337AB7").css("color","white");
  

$("#generatetoamendincExp_wrapper").find(".dataTables_scrollBody").find("table tbody tr").each(function(){
	$(this).find("td:eq(0)").css("text-align","left");
	$(this).find("td:eq(1)").css("text-align","left");
});
$("#generatetoamendincExp_wrapper").find(".dataTables_scrollBody").find("table tbody tr").find("td:eq('"+(Number(len)-1)+"')").css("background-color","rgb(110, 162, 206)").css("color","#FFF").css("border","1px solid #FAFDFF").css("font-weight","bold");
$("#generatetoamendincExp_wrapper").find(".dataTables_scrollBody").find("table tbody tr").find("td:eq('"+(Number(len)-2)+"')").css("background-color","rgb(110, 162, 206)").css("color","#FFF").css("border","1px solid #FAFDFF").css("font-weight","bold");
	



}
function validationOnProjOfExp(){
	var $rdexpcount = RDExptbl.rows().count();	
	if($rdexpcount<1){
		showAlert("No Records found in Input Expenditure on retirement based on current cost !");
		$("#RDExpAddRow").focus(); 
		$("#RDExpAddRow").parent().css("border","2px solid #F25B5B");
		return false;
	}
	return true;
}
 
function validationOnProjOfInc(){
	var $rdinccount = RDInctbl.rows().count(); 
	var $rdincasscount = RDIncAsstbl.rows().count();
	
	if($rdinccount<1  && $rdincasscount<1){
		showAlert("No Records found in Income to be received durning retirement !");
		$("#RDIncAddRow").focus(); 
		$("#RDIncAddRow").parent().css("border","2px solid #F25B5B");
		return false;
	}
	return true;
}
 