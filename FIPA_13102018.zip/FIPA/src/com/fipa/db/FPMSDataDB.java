package com.fipa.db;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;

import com.fipa.dbinterface.DBInterface;
import com.fipa.util.ApplicationContextUtils;
import com.fipa.util.FipaConstant;
import com.fipa.util.FipaUtils;

public class FPMSDataDB {
	
	@SuppressWarnings("unchecked")
	public List getAllAdvStfDets() {
		
		List lstAllAdvStfList = new ArrayList();
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean"); 
			String SQL_ADVSTF_QUERY = "SELECT  ADV.ADVSTF_ID, ADV.ADVSTF_NAME,"
					+ " ADV.MANAGER_ID,MGR.ADVSTF_NAME MANAGERNAME,"
					+ "DESIG.DESIG_NAME,DESIG.DESIG_TYPE,DESIG.MGR_FLG "
					+ " FROM "
					+ FipaConstant.FPMSNL_SCHEMA+".ADVISER_STAFF ADV, "
					+ FipaConstant.FPMSNL_SCHEMA+".ADVISER_STAFF MGR, "
					+ FipaConstant.FPMSNL_SCHEMA+".MASTER_EMPLOYMENT_STATUS EMP, "
					+ FipaConstant.FPMSNL_SCHEMA+".MASTER_DESIGNATION DESIG "
					+ " where ADV.EMPSTATUS_ID = EMP.EMPSTATUS_ID "
					+ " AND ADV.DESIG_ID = DESIG.DESIG_ID "
					+ " AND ADV.MANAGER_ID = MGR.ADVSTF_ID "
					+ " AND EMP.EMPSTATUSNAME NOT IN ('RESIGNED','SUSPENDED') ORDER BY 2";
			
			lstAllAdvStfList =  dao.searchByNativeSQLQuery(SQL_ADVSTF_QUERY);

		return lstAllAdvStfList;
	}
	
	
	@SuppressWarnings("unchecked")
	public List getAllCountryList() {
		
		List lstAllCountry = new ArrayList();

			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");


			String SQL_COUNTRY_QUERY = "SELECT  COUNTRYCODE,COUNTRYNAME"
					+ " FROM "
					+ FipaConstant.FPMSNL_SCHEMA+".MASTER_COUNTRY ORDER BY 2 "
					;
			
			lstAllCountry =  dao.searchByNativeSQLQuery(SQL_COUNTRY_QUERY);

		return lstAllCountry;
	}
	
	@SuppressWarnings("unchecked")
	public List getfundMgrList() {
		
		List lstAllfundMgr = new ArrayList();

			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");


			String SQL_FUNDMGR_QUERY = "select FM_CODE,NAME from FPIS_MASTER_FUNDMANAGER"
					+ " WHERE STATUS ='AI' ORDER BY UPPER(NAME) ";
			
			lstAllfundMgr =  dao.searchByNativeSQLQuery(SQL_FUNDMGR_QUERY);

		return lstAllfundMgr;
	}
	
	
	@SuppressWarnings("unchecked")
	public List getfundNameList() {
		
		List lstAllfundName = new ArrayList();

			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");


			String SQL_FUNDNAME_QUERY = "SELECT FM_CODE,FUND_CODE,FUND_NAME FROM FPIS_MASTER_FUNDS"
					+ " WHERE STATUS ='AI' ORDER BY UPPER(FUND_NAME) "; 
			
			lstAllfundName =  dao.searchByNativeSQLQuery(SQL_FUNDNAME_QUERY);

		return lstAllfundName;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List getfpmsPrincipalList() {
		
		List lstfpmsPrinList = new ArrayList();

			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");


			String SQL_PRINLIST_QUERY = "SELECT PRIN_ID,PRIN_NAME FROM FPMS_MASTER_PRINCIPAL ORDER BY UPPER(PRIN_NAME)";
			
			lstfpmsPrinList =  dao.searchByNativeSQLQuery(SQL_PRINLIST_QUERY);

		return lstfpmsPrinList;
	}
		
	
	@SuppressWarnings("unchecked")
	public List getattchCatgList() {
		
		List lstAllAttachCatg = new ArrayList();

			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");


			String SQL_ATTACHCATG_QUERY = " SELECT ATTACH.ATTACH_CATEG_ID,ATTACH.ATTACH_CATEG_NAME,ATTACH.DOC_TITLE FROM  "
					+  FipaConstant.FPMSNL_SCHEMA+".MASTER_ATTACH_CATEG ATTACH ORDER BY UPPER(ATTACH_CATEG_NAME) ASC "; 
			 
			
			lstAllAttachCatg =  dao.searchByNativeSQLQuery(SQL_ATTACHCATG_QUERY);

		return lstAllAttachCatg;
	}
	
	
	@SuppressWarnings("unchecked")
	public List getportofolioList() {
		
		List lstAllPortofolioCatg = new ArrayList();

			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");


			String SQL_PORTOFOLIO_QUERY = "SELECT MAIN_CATEG,SUB_CATEG FROM FPIS_MASTER_PORTFOLIOCATEG where STATUS='AI' order by MAIN_CATEG ,SUB_CATEG" ;
			
			lstAllPortofolioCatg =  dao.searchByNativeSQLQuery(SQL_PORTOFOLIO_QUERY);

		return lstAllPortofolioCatg;
	}
	
	 
	
	@SuppressWarnings("unchecked")
	public List getAllRelationshipList() {
		
		List lstAllRelatioship = new ArrayList();

			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");


			String SQL_COUNTRY_QUERY = "SELECT  RELATION_ID,RELATION_NAME"
					+ " FROM "
					+ FipaConstant.FPMSNL_SCHEMA+".MASTER_RELATIONSHIP ORDER BY 2 "
					;
			
			lstAllRelatioship =  dao.searchByNativeSQLQuery(SQL_COUNTRY_QUERY);

		return lstAllRelatioship;
	}
	

	public List getFPMSLifeInsuracePolDets(DBInterface dao,String ... strParams){
		
		List lstPolicyDets = new ArrayList();
		 
		String strParamFPMS="";
		String strCustName = strParams[0];
		String strCustNric = strParams[1];
		String strCustId = strParams[2];
		String strAppId = strParams[3];
		
//		if(strParams.length == 2){
//			if(!FipaUtils.nullOrBlank(strParams[1])){			
//				strParamFPMS += " and COALESCE(CUST_DETS.NRIC,CUST_DETS.CUST_PASSPORT_NUM,CUST_DETS.CUST_FIN) ='"+strParams[1]+"'";			
//			}
//			
//			if(!FipaUtils.nullOrBlank(strParams[0])){			
//				strParamFPMS +=" and upper(CUST_DETS.CUST_NAME) like '"+strParams[0].toUpperCase()+"'";
//			}
//		}else if(strParams.length == 1){
		if(!FipaUtils.nullOrBlank(strAppId)){
			strParamFPMS +=" and upper(POLDET.APPID) = '"+strAppId+"'";	
		}
		
		if(!FipaUtils.nullOrBlank(strCustId)){		
			strParamFPMS +=" and upper(CUST_DETS.CUSTID) = '"+strCustId+"'";
		}

//		}
		

		
		String STR_POLICY_QRY = "SELECT DISTINCT   'FPMSNL' APPLICATION  ,ADVSTF.ADVSTF_NAME ADIVSER  ,CUST_DETS.CUST_NAME CUST_NAME,CUST_DETS.NRIC NRIC"
				+ "  ,POLDET.POL_PLN_NAME PLANNAME  ,POLDET.POLICYNO POLICYNO  ,PRIN.PRIN_NAME PRINCIPAL"
				+ "  ,'' PREMIUMTYPE  ,POLDET.TOTAL_PREM PREMIUMAMOUNT  ,POLDET.TOTAL_SA ASSURD"
				+ "  ,POLDET.PAYMENT_MODE PAYMENTMODE  ,POLDET.PAYMENT_METHOD PAYMENTMETHOD  ,TO_CHAR(POLDET.EFF_DATE,'DD/MM/YYYY') EFFECTIVEDATE"
				+ "  ,POLDET.RENEWAL_DATE RENEWALDATE  ,'BASIC' BASIC  ,MPS.POL_STATUS_NAME"
				+ " ,UPPER(PL.PRODUCT_LINE_MAIN)MAIN_LOB,UPPER(PL.PRODUCT_LINE_SUB) SUB_LOB ,POLDET.APPID,POLDET.PRIN_ID"
				+ " FROM  "
				+ FipaConstant.FPMSNL_SCHEMA+ ".CUSTOMER_DETAILS CUST_DETS  ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".ADVISER_STAFF ADVSTF  ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".POLICY POLDET,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_PRINCIPAL PRIN,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_PRODUCT_LINE PL  ,"				
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_POLICY_STATUS MPS"
				+ " WHERE    POLDET.ADVISER_CURRENT = ADVSTF.ADVSTF_ID "
				+ " AND  POLDET.PRIN_ID = PRIN.PRIN_ID AND  POLDET.POL_STATUS_ID = MPS.POL_STATUS_ID "
				+ " AND	POLDET.POLICY_OWNER = CUST_DETS.CUSTID AND  POLDET.PRODUCT_LINE_ID  = PL.PRODUCT_LINE_ID"
				+ " AND  MPS.POL_STATUS_NAME IN( 'INFORCE','RENEWAL') AND "
				+ "  (UPPER(PL.PRODUCT_LINE_MAIN) = ('LIFE INSURANCE') OR UPPER(PL.PRODUCT_LINE_SUB) IN ('ILP','UT'))"
				+ strParamFPMS				
				+ " ORDER BY 13,15";
		
		
//		System.out.println(STR_POLICY_QRY);
		
		
		lstPolicyDets =  dao.searchByNativeSQLQuery(STR_POLICY_QRY);
		
		return lstPolicyDets;
	}

	public List getLifeInsuracePlanDets(DBInterface dao,String ... strParams){
		
		List lstPolicyDets = new ArrayList();
		
		String strCustName = strParams[0];
		String strCustNric = strParams[1];
		String strCustId = strParams[2];
		String strAppId =  strParams[3];
		 
		String strParamFPMS="";
		
		/*if(strParams.length == 2){
			if(!FipaUtils.nullOrBlank(strParams[1])){			
				strParamFPMS += " and COALESCE(CUST_DETS.NRIC,CUST_DETS.CUST_PASSPORT_NUM,CUST_DETS.CUST_FIN) ='"+strParams[1]+"'";			
			}
			
			if(!FipaUtils.nullOrBlank(strParams[0])){			
				strParamFPMS +=" and upper(CUST_DETS.CUST_NAME) like '"+strParams[0].toUpperCase()+"'";
			}
			

			if(!FipaUtils.nullOrBlank(strParams[2])){			
				strParamFPMS +=" and upper(POLDET.APPID) like '"+strParams[2].toUpperCase()+"'";
			}
			
		}else if(strParams.length == 1){
			strParamFPMS +=" and upper(CUST_DETS.CUSTID) = '"+strParams[0]+"'";
		}*/
		
		if(!FipaUtils.nullOrBlank(strAppId)){
			strParamFPMS +=" and upper(POLDET.APPID) = '"+strAppId+"'";	
		}
		
		if(!FipaUtils.nullOrBlank(strCustId)){		
			strParamFPMS +=" and upper(CUST_DETS.CUSTID) = '"+strCustId+"'";
		}

		
		String STR_POLICY_QRY = "SELECT DISTINCT   'FPMSNL' APPLICATION  ,ADVSTF.ADVSTF_NAME ADIVSER  ,CUST_DETS.CUST_NAME CUST_NAME  ,CUST_DETS.NRIC NRIC"
				+ "  ,POLINSBAS.BAS_PLAN_NAME PLANNAME  ,POLDET.POLICYNO POLICYNO  ,PRIN.PRIN_NAME PRINCIPAL"
				+ "  ,POLINSBAS.PREM_TYPE PREMIUMTYPE  ,POLINSBAS.PREM_AMT PREMIUMAMOUNT  ,POLINSBAS.SUM_ASSURD ASSURD"
				+ "  ,POLINSBAS.BAS_PAYMENT_MODE PAYMENTMODE  ,POLDET.PAYMENT_METHOD PAYMENTMETHOD  ,TO_CHAR(POLDET.EFF_DATE,'DD/MM/YYYY') EFFECTIVEDATE"
				+ "  ,POLDET.RENEWAL_DATE RENEWALDATE  ,'B' BASIC  ,MPS.POL_STATUS_NAME"
				+ " ,UPPER(PL.PRODUCT_LINE_MAIN)MAIN_LOB,UPPER(PL.PRODUCT_LINE_SUB) SUB_LOB,POLDET.APPID,  POLINSBAS.PREM_TERM,  POLINSBAS.REMARKS"
				+ " FROM  "
				+ FipaConstant.FPMSNL_SCHEMA+ ".CUSTOMER_DETAILS CUST_DETS  ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".ADVISER_STAFF ADVSTF  ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".POLICY POLDET,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_PRINCIPAL PRIN,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_PRODUCT_LINE PL  ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".POL_INSLIFEBASIC POLINSBAS  ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_POLICY_STATUS MPS"
				+ " WHERE   POLDET.APPID= POLINSBAS.APPID (+) AND  POLDET.ADVISER_CURRENT = ADVSTF.ADVSTF_ID "
				+ " AND  POLDET.PRIN_ID = PRIN.PRIN_ID AND  POLDET.POL_STATUS_ID = MPS.POL_STATUS_ID "
				+ " AND	POLDET.POLICY_OWNER = CUST_DETS.CUSTID AND  POLDET.PRODUCT_LINE_ID  = PL.PRODUCT_LINE_ID"
				+ " AND  MPS.POL_STATUS_NAME IN( 'INFORCE','RENEWAL') AND "
				+ "  (UPPER(PL.PRODUCT_LINE_MAIN) = ('LIFE INSURANCE') OR UPPER(PL.PRODUCT_LINE_SUB) IN ('ILP','UT'))"
				+ strParamFPMS
				+ " UNION "
				+ " SELECT DISTINCT  'FPMSNL' APPLICATION ,ADVSTF.ADVSTF_NAME ADIVSER ,CUST_DETS.CUST_NAME CUST_NAME "
				+ ",CUST_DETS.NRIC NRIC ,POLINSRDR.RID_PLAN_NAME PLANNAME ,POLDET.POLICYNO POLICYNO ,PRIN.PRIN_NAME PRINCIPAL "
				+ ",POLINSRDR.PREM_TYPE PREMIUMTYPE"
				+ " ,POLINSRDR.PREM_AMT PREMIUMAMOUNT ,POLINSRDR.SUM_ASSURD SUMASSURED ,POLINSRDR.RDR_PAYMENT_MODE PAYMENTMODE"
				+ " ,POLDET.PAYMENT_METHOD PAYMENTMETHOD ,TO_CHAR(POLDET.EFF_DATE,'DD/MM/YYYY')EFFECTIVEDATE ,POLDET.RENEWAL_DATE RENEWALDATE"
				+ " ,'R' RIDER ,MPS.POL_STATUS_NAME ,UPPER(PL.PRODUCT_LINE_MAIN)MAIN_LOB,UPPER(PL.PRODUCT_LINE_SUB) SUB_LOB,POLDET.APPID,  POLINSRDR.PREM_TERM,  POLINSRDR.REMARKS" 
				+ " FROM "
				+ FipaConstant.FPMSNL_SCHEMA+ ".CUSTOMER_DETAILS CUST_DETS ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".ADVISER_STAFF ADVSTF ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".POLICY POLDET,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_PRINCIPAL PRIN ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_PRODUCT_LINE PL  ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".POL_INSLIFERIDER POLINSRDR  ,"
				+ FipaConstant.FPMSNL_SCHEMA+ ".MASTER_POLICY_STATUS MPS"
				+ " WHERE  POLDET.APPID= POLINSRDR.APPID  AND  POLDET.ADVISER_CURRENT = ADVSTF.ADVSTF_ID "
				+ " AND   POLDET.PRIN_ID = PRIN.PRIN_ID AND  POLDET.POL_STATUS_ID = MPS.POL_STATUS_ID"
				+ " AND  POLDET.POLICY_OWNER = CUST_DETS.CUSTID AND  POLDET.PRODUCT_LINE_ID  = PL.PRODUCT_LINE_ID "
				+ " AND  UPPER(PL.PRODUCT_LINE_MAIN) = ('LIFE INSURANCE') AND  "
				+ " MPS.POL_STATUS_NAME IN( 'INFORCE','RENEWAL') "
				+ strParamFPMS
				+ " ORDER BY 6,15";
		
//		System.out.println(STR_POLICY_QRY);
		
		lstPolicyDets =  dao.searchByNativeSQLQuery(STR_POLICY_QRY);
		
		return lstPolicyDets;
	}
	
public List getCustomerDetsFromFPMS(DBInterface dao,String ...strParams){
		
		List clientSrchList = new ArrayList();
		
		String strCustName = strParams[0];
		String strCustNric = strParams[1];
		String strCustId = strParams[2];
		
		String strParamFPMS ="";
		strParamFPMS += " and CUSTID ='"+strCustId+"'";
		strParamFPMS += " and upper(CUST_NAME) like '"+strCustName+"'";
		strParamFPMS += " and COALESCE(NRIC,CUST_PASSPORT_NUM,CUST_FIN) ='"+strCustNric+"'";
		
		
		
		
		
		/*String STR_CUST_QRY = "select CUSTID, CUST_NAME, AGENT_ID_CURRENT, TO_CHAR(DOB,'DD/MM/YYYY'), NATIONALITY, "
				+ "COALESCE(NRIC,CUST_PASSPORT_NUM,CUST_FIN) NRIC, SEX, MARITAL_STATUS, OCCPN_TITLE, OCCPN_DESC, COMPANY_NAME, "
				+ "RES_HAND_PHONE, RES_PH, RES_FAX, EMAIL_ID, INCOME, SMOKER_FLG, "
				+ "RES_ADDR1, RES_ADDR2, RES_ADDR3, RES_POSTALCODE, RES_CITY, RES_STATE, RES_COUNTRY, "
				+ " COR_ADDR1, COR_ADDR2, COR_ADDR3, COR_CITY, COR_STATE, COR_COUNTRY,COR_POSTALCODE "
				+ " FROM "
				+ FipaConstant.FPMSNL_SCHEMA+".CUSTOMER_DETAILS "
				+ " where COALESCE(NRIC,CUST_PASSPORT_NUM,CUST_FIN) is not null "
				+ strParamFPMS*/
		
		String STR_SELF_SPS_QRY = "SELECT   CUST.CUSTID,  CUST.CUST_CATEG,  CUST.CUST_NAME,  CUST.CUST_INITIALS, "
				+ " DECODE(CUST.CUST_CATEG,'COMPANY',CUST.ROC_NO,COALESCE(CUST.NRIC,CUST.CUST_FIN,CUST.CUST_PASSPORT_NUM))NRIC,"
				+ "  CUST.CUST_STATUS,  CUST.AGENT_ID_INITIAL,  CUST.AGENT_ID_CURRENT,  ADV.ADVSTF_NAME,  CUST.COMPANY_NAME,"
				+ "  CUST.OCCPN_TITLE,  CUST.OCCPN_DESC,  CUST.ADDRESS_PREF,  CUST.RES_ADDR1,  CUST.RES_ADDR2,  CUST.RES_ADDR3,  CUST.RES_CITY,"
				+ "  CUST.RES_STATE,  CUST.RES_COUNTRY,  CUST.RES_POSTALCODE,  CUST.RES_FAX,  CUST.RES_PH,  CUST.RES_HAND_PHONE,  CUST.OFF_ADDR1,"
				+ "  CUST.OFF_ADDR2,  CUST.OFF_ADDR3,  CUST.OFF_CITY,  CUST.OFF_STATE,  CUST.OFF_COUNTRY,  CUST.OFF_POSTALCODE,  CUST.OFF_PH,"
				+ "  CUST.OFF_HAND_PHONE,  CUST.OFF_FAX,  CUST.COR_ADDR1,  CUST.COR_ADDR2,  CUST.COR_ADDR3,  CUST.COR_CITY,  CUST.COR_STATE,"
				+ "  CUST.COR_COUNTRY,  CUST.COR_POSTALCODE,  CUST.OTH_PH,  TO_DATE(DECODE(CUST.CUST_CATEG,'COMPANY',CUST.ROC_DATE,CUST.DOB))DOB,"
				+ "  CUST.MARITAL_STATUS,  CUST.SEX,  CUST.EMAIL_ID,  CUST.WEBSITE,  CUST.SMOKER_FLG,  CUST.RACE,  CUST.NATIONALITY,  CUST.TITLE,  "
				+ "  CUST.WEIGHT,  CUST.HEIGHT,  CUST.ACADEMIC_TITLE,  CUST.INCOME,  CUST.REMARKS,  FP.CUSTID FP_CUSTID,"
				+ "  FP.NRIC SPNRIC,  FP.CUST_NAME SPCUST_NAME,  FP.CUST_INITIALS SPCUST_INITIALS,  NVL(FP.RELATIONSHIP,'NULL') SPREL,  "
				+ "  FP.AGE SPAGE,  FP.REMARKS SPREMARKS,  FP.SEX SPSEX,  FP.AGENT_ID_CURRENT SPAGENT_ID_CURRENT,  FP.DOB SPDOB,"
				+ "  FP.MARITAL_STATUS SPMARITAL_STS,  FP.INCOME SPINCOME,  ADV.EMAIL_ID ADV_EMAILID,  ADV.MANAGER_ID MGR_ID,"
				+ "  MGR.ADVSTF_NAME MGR_NAME,  MGR.EMAIL_ID MGR_EMAILID "
				+ "  ,  CUST.BUSINESS_NATR ,  CUST.CITIZENSHIP"
				+ "  FROM "+FipaConstant.FPMSNL_SCHEMA+".CUSTOMER_DETAILS CUST ,  "
				+  FipaConstant.FPMSNL_SCHEMA+".ADVISER_STAFF ADV ,"+ FipaConstant.FPMSNL_SCHEMA+".ADVISER_STAFF MGR,"
								+ " (SELECT FP.CUSTID,  FP.NRIC , FP.CUST_NAME ,  FP.CUST_INITIALS , NVL(FP.RELATIONSHIP,'NULL') RELATIONSHIP,"
								+ "    FP.AGE ,    FP.REMARKS ,   FP.SEX ,    FP.AGENT_ID_CURRENT ,    FP.DOB,    FP.MARITAL_STATUS ,"
								+ "    FP.INCOME  FROM "+FipaConstant.FPMSNL_SCHEMA+".CUSTOMER_FAMILYPARTICULARS FP "
								+ "  WHERE CUSTID                            =('"+strCustId+"')"
								+ "  AND UPPER(NVL(FP.RELATIONSHIP,'NULL')) IN ('SPOUSE','REL022','REL22','NULL')"
								+ "  )FP"
								+ " WHERE CUST.CUSTID         =('"+strCustId+"') "
								+ " AND CUST.AGENT_ID_CURRENT = ADV.ADVSTF_ID "
								+ " AND ADV.MANAGER_ID        = MGR.ADVSTF_ID "
								+ " AND CUST.CUSTID           = FP.CUSTID(+) "
								
				;
//		System.out.println("------------------------------------------>(STR_CUST_QRY);");
//		System.out.println(STR_CUST_QRY);
		clientSrchList = dao.searchByNativeSQLQuery(STR_SELF_SPS_QRY);
		
		return clientSrchList;
		
	}

}
