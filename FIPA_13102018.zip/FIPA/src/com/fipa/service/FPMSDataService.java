package com.fipa.service;

import java.util.List;

import com.fipa.db.ClientDB;
import com.fipa.db.FPMSDataDB;
import com.fipa.dbinterface.DBInterface;

public class FPMSDataService {
	
	public List getAllAdvStfDets(){
		FPMSDataDB clientDB = new FPMSDataDB();
		return clientDB.getAllAdvStfDets();
	}
	
	public List getAllCountryList(){
		FPMSDataDB clientDB = new FPMSDataDB();
		return clientDB.getAllCountryList();
	}
	
	
	public List getAllRelationshipList(){
		FPMSDataDB clientDB = new FPMSDataDB();
		return clientDB.getAllRelationshipList();
	}
	
	
	public List getFPMSLifeInsuracePolDets(DBInterface dao,String ... strParams){
		FPMSDataDB clientDB = new FPMSDataDB();
		return clientDB.getFPMSLifeInsuracePolDets(dao,strParams);
	}
	
	public List getLifeInsuracePlanDets(DBInterface dao,String ... strParams){
		FPMSDataDB clientDB = new FPMSDataDB();
		return clientDB.getLifeInsuracePlanDets(dao,strParams);
	}
	
	 public List getCustomerDetsFromFPMS(DBInterface dao,String ... strBufQryParam){
		 FPMSDataDB db = new FPMSDataDB();		 
		 return db.getCustomerDetsFromFPMS(dao, strBufQryParam);
	 }

	 
	 public List getfundMgrList(){
			FPMSDataDB clientDB = new FPMSDataDB();
			return clientDB.getfundMgrList();
	}
	 
	 
	 
	 public List getfundNameList(){
			FPMSDataDB clientDB = new FPMSDataDB();
			return clientDB.getfundNameList();
	 }
	 
	 public List getfpmsPrincipalList() {
			FPMSDataDB clientDB = new FPMSDataDB();
			return clientDB.getfpmsPrincipalList();
	 }
	  
	 public List getattchCatgList(){
			FPMSDataDB clientDB = new FPMSDataDB();
			return clientDB.getattchCatgList();
	 }
	 
	 
	 
	 
	 public List getportofolioList(){
			FPMSDataDB clientDB = new FPMSDataDB();
			return clientDB.getportofolioList();
	 }
	 
	 
	 
	 
}
