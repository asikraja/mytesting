package com.fipa.servlet;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor; 
import java.io.BufferedInputStream; 
import java.io.DataOutputStream;
import java.io.File; 
import java.io.FileInputStream;
import java.io.FileOutputStream; 
import java.io.IOException;
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.PrintWriter; 
import java.util.ArrayList;
  
import java.util.Iterator;
import java.util.List; 
import java.util.Properties;

import javax.servlet.ServletException; 
import javax.servlet.ServletOutputStream; 
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject; 

import com.fipa.dbinterface.DBInterfaceImpl; 
import com.fipa.service.ClientService;
import com.fipa.util.ApplicationContextUtils;
import com.fipa.util.FipaConstant;
import com.fipa.util.FipaUtils;  
import com.fipa.util.PropReadUtils;

import java.net.MalformedURLException;
import java.net.URL; 

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document; 
import com.itextpdf.text.Element;
import com.itextpdf.text.Font; 
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.pdf.GrayColor;
import com.itextpdf.text.html.WebColors;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase; 
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;  
/**
 * Servlet implementation class GenReportServlet
 */  
public class GenReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final Logger logger = LoggerFactory.getLogger(GenReportServlet.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenReportServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
    
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
  
		
		String strDBCallFor = FipaUtils.getParamValue(request, "strDBCallFor"); 
		String strReportName= FipaUtils.getParamValue(request, "strReportName");
		
		JSONArray retvals=new JSONArray();
		
		
		//System.out.println(strDBCallFor);

		if(!FipaUtils.isSessionExpired(request)){ 
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("SESSION_EXPIRY", "SESSION_EXPIRY");
			retvals.add(jsonObj);
			strDBCallFor = "";
			 
		} 
		
		if(strDBCallFor.equalsIgnoreCase("SRCH_REPORT") && strReportName.equalsIgnoreCase("CFA")){
			
			retvals= openCFAReport(request,response);
			   
	 }
		 
		
		
	}
 
		public JSONArray openCFAReport(HttpServletRequest request,HttpServletResponse response) {
			
//			logger.info(" ------> Inside openCFAReport method"); 
			
			JSONArray retValues = new JSONArray(); 
			JSONObject jsnExpMsgObj  = new JSONObject();
			
			try {
				
				
				String strClientId = FipaUtils.getParamValue(request,"strClientId");
				JSONObject jsnObj=new JSONObject();
				
				String strFileName = "CashFlowAnalysis_"+strClientId;
				
				String strRepTitle = "CASH FLOW ANALYSIS";
				strFileName = strFileName +".PDF";
				String strLogoFileLoc="/images/avallislogo_formerfp.jpg";
				
				
				
				
				PropReadUtils prosp = new PropReadUtils();
				String filePath = prosp.getfilepath();
				
				//System.out.println(filePath);
				 
		        File uploadDir = new File(filePath);
 
				
				if (!uploadDir.exists()) {
					 
					uploadDir.mkdirs(); 
				} 
				
				OutputStream file = new FileOutputStream(uploadDir+"/"+strFileName);
			 
			    Document document = new Document(PageSize.A4);
				PdfWriter.getInstance(document,file);
				document.open();
				   
				 
				 
				List clientTabDetsList = new ArrayList();
				List expenditureDetsList = new ArrayList();
				List srcOfincDetsList = new ArrayList();
				List getAllDetsList = new ArrayList();
				 

				ClientService serv=new ClientService(); 
				try{

						ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
						DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
						
						
						
							clientTabDetsList = serv.openClientProfile(dao,strClientId);
							srcOfincDetsList = serv.openSrcIncProfile(dao,strClientId);
							expenditureDetsList = serv.openExpProfile(dao,strClientId);
							
							getAllDetsList.addAll(srcOfincDetsList);
							getAllDetsList.addAll(clientTabDetsList);
							getAllDetsList.addAll(expenditureDetsList);
							
							try{
								if(getAllDetsList.size() > 0){
									Iterator Itr = getAllDetsList.iterator();
									 while(Itr.hasNext()){
										 
									Object  objDTO = (Object) Itr.next();					
									BeanInfo beanInfo = Introspector.getBeanInfo(objDTO.getClass());		
									
									for (PropertyDescriptor propertyDesc : beanInfo.getPropertyDescriptors()) {
										String propertyName = propertyDesc.getName();
										Object value = propertyDesc.getReadMethod().invoke(objDTO);
										
										jsnObj.put(propertyName, !FipaUtils.nullOrBlank(FipaUtils.getObjValue(value))?FipaUtils.getObjValue(value) : "0");	
									 
									}
								}
							}
							}catch(Exception ex){
								ex.printStackTrace();
							}
							
							
				URL url = getServletContext().getResource(strLogoFileLoc);
			   
			  	
		        Image logo = Image.getInstance(url);
		            logo.setAlignment(Image.RIGHT);
		            logo.scaleAbsoluteHeight(20);
		            logo.scaleAbsoluteWidth(20);
		            logo.scalePercent(30);
		            document.add(logo);
		           
		            float[] columnWidths = {5, 15};
		            PdfPTable table = new PdfPTable(columnWidths);
		            
		            table.setSpacingBefore(30f);
		            table.setSpacingAfter(30f);			            
		            table.setWidthPercentage(100);			            
		            
		            table.getDefaultCell().setUseAscender(true);
		            table.getDefaultCell().setUseDescender(true);
		            
		            table.getDefaultCell().setBackgroundColor(new GrayColor(0.75f));
		            
		            Font fGrayWhiteBold = FontFactory.getFont("Arial", 10,Font.BOLD,GrayColor.GRAYWHITE);
		            Font fGrayBlackBold = FontFactory.getFont("Arial", 10,Font.BOLD,GrayColor.BLACK);
		            Font fGrayBlackNormal = FontFactory.getFont("Arial", 10,Font.NORMAL,GrayColor.BLACK); 
		            
		            String corpColorCode = "#50907C"; 
		            String corpHClrCode="#001d4c";
		            BaseColor corpColor = WebColors.getRGBColor(corpColorCode); 
		            BaseColor corpHeader = WebColors.getRGBColor(corpHClrCode); 
	             
		            PdfPCell cell = new PdfPCell(new Phrase(strRepTitle, fGrayWhiteBold));
		            cell.setPadding(5);			            
		            cell.setBackgroundColor(corpColor);
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		            cell.setColspan(2);			            
		            table.addCell(cell);
		            
		            cell = new PdfPCell(new Paragraph(""));
		            cell.setColspan(2);	
		            table.addCell(cell);			            
		            
		            
		            
		            
		            cell = new PdfPCell(new Phrase("Client Name", fGrayBlackBold));
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		            table.addCell(cell); 
		            
		            String dfSelfName =(String) (!FipaUtils.nullObj(jsnObj.get("dfSelfName")) ? jsnObj.get("txtFldDfSlfName") : "0" );
		            cell = new PdfPCell(new Phrase(dfSelfName, fGrayBlackNormal));
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		            table.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Spouse Name", fGrayBlackBold));
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		            table.addCell(cell);
		            
		            
		            String dfSpsName =(String) (!FipaUtils.nullObj(jsnObj.get("dfSpsName")) ? jsnObj.get("txtFldDfSpsName") : "0" );
			        cell = new PdfPCell(new Phrase(jsnObj.getString("dfSpsName"), fGrayBlackNormal));
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		            table.addCell(cell);			            
		           	             
		            
					cell = new PdfPCell(new Paragraph(""));
		            cell.setColspan(6);	
		            table.addCell(cell);
		            
		            double totSOISlf=0.0;
				  	double totSOISps=0.0; 
				  	
				  	
		            float[] dataColumnWidths = {20, 20, 10,10,10};
		            PdfPTable dataTable = new PdfPTable(dataColumnWidths);
		             	             
		            dataTable.setSpacingAfter(30f);		 
		            dataTable.setWidthPercentage(100);
		            
		            dataTable.getDefaultCell().setUseAscender(true);
		            dataTable.getDefaultCell().setUseDescender(true);			            
		            dataTable.getDefaultCell().setBackgroundColor(new GrayColor(0.75f));
		            
		            cell = new PdfPCell(new Phrase("Source Of Income", fGrayWhiteBold));
		            cell.setPadding(5);			            
		            cell.setBackgroundColor(corpHeader);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setColspan(6);			            
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	 
		            cell.setColspan(2);
		            cell.setRowspan(2);
		            dataTable.addCell(cell);
		             
		            
		            cell = new PdfPCell(new Phrase("Self", fGrayWhiteBold));			            		            
		            cell.setBackgroundColor(corpColor);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            cell.setRowspan(2);
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Spouse", fGrayWhiteBold));			            		            
		            cell.setBackgroundColor(corpColor);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            cell.setRowspan(2);
		            dataTable.addCell(cell);     
		            
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setBackgroundColor(corpColor);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            cell.setRowspan(2);
		            dataTable.addCell(cell);  
		            
		             
		            cell = new PdfPCell(new Phrase("Employment", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setRowspan(2);
		            dataTable.addCell(cell);
				     
					
		            cell = new PdfPCell(new Phrase("Monthly Income", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            dataTable.addCell(cell);   
		             
		           	totSOISlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSelfEmpMonthly")) ? Double.parseDouble((jsnObj.get("incsrcSelfEmpMonthly")).toString())*12 : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSelfEmpMonthly")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSelfEmpMonthly").toString()) : " " ), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            totSOISps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSpsEmpMonthly")) ? jsnObj.get("incsrcSpsEmpMonthly") : "0" ).toString())*12;
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSpsEmpMonthly")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSpsEmpMonthly").toString()) : " " ), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Annual Profits/Bonuses", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            dataTable.addCell(cell);
		            
		            
		            totSOISlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSelfEmpAddlwage")) ? jsnObj.get("incsrcSelfEmpAddlwage") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSelfEmpAddlwage")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSelfEmpAddlwage").toString()) : " " ), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            totSOISps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSpsEmpAddlwage")) ? jsnObj.get("incsrcSpsEmpAddlwage") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSpsEmpAddlwage")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSpsEmpAddlwage").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Non Employment Income", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setRowspan(4);
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Monthly Income", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            dataTable.addCell(cell);
		            
		             
		            
		            totSOISlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSelfNempMonthly")) ? jsnObj.get("incsrcSelfNempMonthly") : "0" ).toString())*12;
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSelfNempMonthly")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSelfNempMonthly").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            totSOISps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSpsNempMonthly")) ? jsnObj.get("incsrcSpsNempMonthly") : "0" ).toString())*12;
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSpsNempMonthly")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSpsNempMonthly").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Annual Int., dividends, gains", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            dataTable.addCell(cell);
		            
		            
		            
		            totSOISlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSelfNempDivdamt")) ? jsnObj.get("incsrcSelfNempDivdamt") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSelfNempDivdamt")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSelfNempDivdamt").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            totSOISps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSpsNempDivdamt")) ? jsnObj.get("incsrcSpsNempDivdamt") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSpsNempDivdamt")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSpsNempDivdamt").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Annual rental income", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            dataTable.addCell(cell);
		            
		            totSOISlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSelfNempRentamt")) ? jsnObj.get("incsrcSelfNempRentamt") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSelfNempRentamt")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSelfNempRentamt").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            
		            totSOISps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("incsrcSpsNempRentamt")) ? jsnObj.get("incsrcSpsNempRentamt") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("incsrcSpsNempRentamt")) ? FipaUtils.DigitFormat(jsnObj.get("incsrcSpsNempRentamt").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Others (annual)", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            dataTable.addCell(cell);
		            
		             
		            
		            totSOISlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("txtFldIncSrcSlfNempOthAmt")) ? jsnObj.get("txtFldIncSrcSlfNempOthAmt") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("txtFldIncSrcSlfNempOthAmt")) ? FipaUtils.DigitFormat(jsnObj.get("txtFldIncSrcSlfNempOthAmt").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            totSOISps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("txtFldIncSrcSpsNempOthAmt")) ? jsnObj.get("txtFldIncSrcSpsNempOthAmt") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("txtFldIncSrcSpsNempOthAmt")) ? FipaUtils.DigitFormat(jsnObj.get("txtFldIncSrcSpsNempOthAmt").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            dataTable.addCell(cell);
		            
		             
		            cell = new PdfPCell(new Phrase("Total Annual Income", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            dataTable.addCell(cell);
		            
		            
		            
		            cell = new PdfPCell(new Phrase((!(String.valueOf(totSOISlf).equals("0.0"))  ?   FipaUtils.DigitFormat(String.valueOf(totSOISlf)): " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase((!(String.valueOf(totSOISps).equals("0.0"))  ?   FipaUtils.DigitFormat(String.valueOf(totSOISps)): " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            dataTable.addCell(cell);
		            
		            
		            
		            cell = new PdfPCell(new Phrase("Less CPF contributions", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		            cell.setColspan(2);
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            
		            cell = new PdfPCell(new Phrase("New Annual Inflow", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            dataTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            dataTable.addCell(cell);
		            
		            
		            double totExpSlf=0.0;
				  	double totExpSps=0.0;
				  	double totExpFam=0.0;
				  	
		            
		            float[] anlExpWidths = {20, 20, 10,10,10};
		            PdfPTable AnlExpTable = new PdfPTable(dataColumnWidths);
		             		            
		            AnlExpTable.setSpacingAfter(40f);
		            AnlExpTable.setWidthPercentage(100);
		            
		            AnlExpTable.getDefaultCell().setUseAscender(true);
		            AnlExpTable.getDefaultCell().setUseDescender(true);			            
		            AnlExpTable.getDefaultCell().setBackgroundColor(new GrayColor(0.75f));
		            
		            
		            
		            
		            cell = new PdfPCell(new Phrase("Annual Expenditure", fGrayWhiteBold));
		            cell.setPadding(5);			            
		            cell.setBackgroundColor(corpHeader);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setColspan(6);			            
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	 
		            cell.setColspan(2);
		            cell.setRowspan(2);
		            AnlExpTable.addCell(cell);
		             
		            
		            cell = new PdfPCell(new Phrase("Self", fGrayWhiteBold));			            		            
		            cell.setBackgroundColor(corpColor);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            cell.setRowspan(2);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Spouse", fGrayWhiteBold));			            		            
		            cell.setBackgroundColor(corpColor);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            cell.setRowspan(2);
		            AnlExpTable.addCell(cell);     
		            
		            
		            cell = new PdfPCell(new Phrase("Family", fGrayWhiteBold));			            		            
		            cell.setBackgroundColor(corpColor);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            cell.setRowspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            cell = new PdfPCell(new Phrase("Rental for lodgings", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfRent")) ? jsnObj.get("expdSelfRent") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfRent")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfRent").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsRent")) ? jsnObj.get("expdSpsRent") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsRent")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsRent").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyRent")) ? jsnObj.get("expdFamilyRent") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyRent")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyRent").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		             
		            
		            cell = new PdfPCell(new Phrase("Utilities & communication", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfUtil")) ? jsnObj.get("expdSelfUtil") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfUtil")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfUtil").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsUtil")) ? jsnObj.get("expdSpsUtil") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsUtil")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsUtil").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyUtil")) ? jsnObj.get("expdFamilyUtil") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyUtil")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyUtil").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		             
		            
		            cell = new PdfPCell(new Phrase("Grocery & hoursehold needs", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfGrocery")) ? jsnObj.get("expdSelfGrocery") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfGrocery")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfGrocery").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsGrocery")) ? jsnObj.get("expdSpsGrocery") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsGrocery")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsGrocery").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyGrocery")) ? jsnObj.get("expdFamilyGrocery") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyGrocery")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyGrocery").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		             
		            cell = new PdfPCell(new Phrase("Eating out", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfEatingout")) ? jsnObj.get("expdSelfEatingout") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfEatingout")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfEatingout").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsEatingout")) ? jsnObj.get("expdSpsEatingout") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsEatingout")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsEatingout").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyEatingout")) ? jsnObj.get("expdFamilyEatingout") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyEatingout")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyEatingout").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Clothing & apparel", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfClothing")) ? jsnObj.get("expdSelfClothing") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfClothing")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfClothing").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsClothing")) ? jsnObj.get("expdSpsClothing") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsClothing")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsClothing").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyClothing")) ? jsnObj.get("expdFamilyClothing") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyClothing")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyClothing").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            cell = new PdfPCell(new Phrase("Transportation", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfTransport")) ? jsnObj.get("expdSelfTransport") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfTransport")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfTransport").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsTransport")) ? jsnObj.get("expdSpsTransport") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsTransport")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsTransport").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyTransport")) ? jsnObj.get("expdFamilyTransport") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyTransport")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyTransport").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Medical & personal care", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfMedical")) ? jsnObj.get("expdSelfMedical") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfMedical")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfMedical").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsMedical")) ? jsnObj.get("expdSpsMedical") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsMedical")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsMedical").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyMedical")) ? jsnObj.get("expdFamilyMedical") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyMedical")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyMedical").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Personal expenses", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfPersonal")) ? jsnObj.get("expdSelfPersonal") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfPersonal")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfPersonal").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsPersonal")) ? jsnObj.get("expdSpsPersonal") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsPersonal")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsPersonal").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyPersonal")) ? jsnObj.get("expdFamilyPersonal") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyPersonal")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyPersonal").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            cell = new PdfPCell(new Phrase("Household maintenance & conservancy", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		             
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyHousehold")) ? jsnObj.get("expdFamilyHousehold") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyHousehold")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyHousehold").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Domestic Help", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		             
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyDomestic")) ? jsnObj.get("expdFamilyDomestic") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyDomestic")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyDomestic").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Children care, education & enhancement program", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		             
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyEnhance")) ? jsnObj.get("expdFamilyEnhance") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyEnhance")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyEnhance").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Dependant contributions", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfDepntcontr")) ? jsnObj.get("expdSelfDepntcontr") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfDepntcontr")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfDepntcontr").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsDepntcontr")) ? jsnObj.get("expdSpsDepntcontr") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsDepntcontr")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsDepntcontr").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Taxes", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfTaxes")) ? jsnObj.get("expdSelfTaxes") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfTaxes")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfTaxes").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsTaxes")) ? jsnObj.get("expdSpsTaxes") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsTaxes")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsTaxes").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyTaxes")) ? jsnObj.get("expdFamilyTaxes") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyTaxes")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyTaxes").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            cell = new PdfPCell(new Phrase("Entertainment", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfEntertain")) ? jsnObj.get("expdSelfEntertain") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfEntertain")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfEntertain").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsEntertain")) ? jsnObj.get("expdSpsEntertain") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsEntertain")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsEntertain").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyEntertain")) ? jsnObj.get("expdFamilyEntertain") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyEntertain")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyEntertain").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Festive Spending", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfFestiv")) ? jsnObj.get("expdSelfFestiv") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfFestiv")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfFestiv").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsFestiv")) ? jsnObj.get("expdSpsFestiv") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsFestiv")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsFestiv").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		             
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyFestiv")) ? jsnObj.get("expdFamilyFestiv") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyFestiv")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyFestiv").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Vacations", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfVacations")) ? jsnObj.get("expdSelfVacations") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfVacations")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfVacations").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsVacations")) ? jsnObj.get("expdSpsVacations") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsVacations")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsVacations").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyVacations")) ? jsnObj.get("expdFamilyVacations") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyVacations")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyVacations").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Charity", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfCharity")) ? jsnObj.get("expdSelfCharity") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfCharity")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfCharity").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsCharity")) ? jsnObj.get("expdSpsCharity") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsCharity")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsCharity").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyCharity")) ? jsnObj.get("expdFamilyCharity") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyCharity")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyCharity").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Property loan repayment", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfProploan")) ? jsnObj.get("expdSelfProploan") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfProploan")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfProploan").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsProploan")) ? jsnObj.get("expdSpsProploan") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsProploan")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsProploan").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyProploan")) ? jsnObj.get("expdFamilyProploan") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyProploan")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyProploan").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Vehicle loan repayment", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfVehiloan")) ? jsnObj.get("expdSelfVehiloan") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfVehiloan")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfVehiloan").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsVehiloan")) ? jsnObj.get("expdSpsVehiloan") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsVehiloan")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsVehiloan").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("txtFldExpdFmlyVehln")) ? jsnObj.get("txtFldExpdFmlyVehln") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("txtFldExpdFmlyVehln")) ? FipaUtils.DigitFormat(jsnObj.get("txtFldExpdFmlyVehln").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Insurance premiums", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfInsurance")) ? jsnObj.get("expdSelfInsurance") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfInsurance")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfInsurance").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsInsurance")) ? jsnObj.get("expdSpsInsurance") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsInsurance")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsInsurance").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyInsurance")) ? jsnObj.get("expdFamilyInsurance") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyInsurance")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyInsurance").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Others", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSlf+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSelfOthers")) ? jsnObj.get("expdSelfOthers") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSelfOthers")) ? FipaUtils.DigitFormat(jsnObj.get("expdSelfOthers").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpSps+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdSpsOthers")) ? jsnObj.get("expdSpsOthers") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdSpsOthers")) ? FipaUtils.DigitFormat(jsnObj.get("expdSpsOthers").toString()) : " ") , fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            
		            totExpFam+=Double.parseDouble((!FipaUtils.nullObj(jsnObj.get("expdFamilyOthers")) ? jsnObj.get("expdFamilyOthers") : "0" ).toString());
		            cell = new PdfPCell(new Phrase((!FipaUtils.nullObj(jsnObj.get("expdFamilyOthers")) ? FipaUtils.DigitFormat(jsnObj.get("expdFamilyOthers").toString()) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		             
		            cell = new PdfPCell(new Phrase("Annual Expenses", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            

		            //System.out.println();
		            cell = new PdfPCell(new Phrase((!(String.valueOf(totExpSlf).equals("0.0"))  ?  FipaUtils.DigitFormat(String.valueOf(totExpSlf)) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase((!(String.valueOf(totExpSps).equals("0.0"))  ?  FipaUtils.DigitFormat(String.valueOf(totExpSps)) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase((!(String.valueOf(totExpFam).equals("0.0"))  ? FipaUtils.DigitFormat(String.valueOf(totExpFam)) : " "), fGrayBlackNormal));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            AnlExpTable.addCell(cell);
		             
		            cell = new PdfPCell(new Phrase(" ", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	 
		            cell.setColspan(5);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("Net surplus/ deficit", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setBackgroundColor(corpHeader);
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            cell.setBackgroundColor(corpHeader);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setBackgroundColor(corpHeader);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	
		            cell.setBackgroundColor(corpHeader);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	 
		            cell.setColspan(5);
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("Total Net surplus/ deficit", fGrayBlackBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);	
		            cell.setColspan(2);
		            AnlExpTable.addCell(cell);
		            
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	 
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setBackgroundColor(corpHeader);
		            AnlExpTable.addCell(cell);
		            
		            cell = new PdfPCell(new Phrase("", fGrayWhiteBold));			            		            
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);	 
		            AnlExpTable.addCell(cell);
		            
		            Paragraph desHeader = new Paragraph("Important Notes -",fGrayBlackBold);
		            desHeader.setSpacingAfter(5f);
		            Paragraph desContent1 = new Paragraph("Your cash flow analysis is an important component of "
		            		+ "your entire financial plan. It reveals your spending pattern and behaviour, "
		            		+ "hence providing you with a better understanding of your financial situation. "
		            		+ "It identifies your core expenditure and allows you to make feasible adjustments"
		            		+ " according to your personal and family situation. Ultimately, it determines your "
		            		+ "ability to set aside regular funds for future accumulations.",fGrayBlackNormal);
		             
		            desContent1.setSpacingAfter(5f);
		            Paragraph desContent2 = new Paragraph("We advise that you review your cash "
		            		+ "flow analysis regularly to ensure that you are able to accomplish the "
		            		+ "financial goals you set.",fGrayBlackNormal);
		            
		            
		            desContent2.setSpacingAfter(5f);
		            
		            document.add(table);
		            document.add(dataTable);
		            document.add(AnlExpTable);
		            document.add(desHeader);
		            document.add(desContent1);
		            document.add(desContent2);
		             
		            jsnExpMsgObj.put("SUCCESS_MESSAGE","Downloaded Successfully !!!"); 
		    	  	retValues.add(jsnExpMsgObj);
		    	  	document.close(); 
		            file.close();
		            
		            
		            //System.out.println("File write over!!!!");
		            
		            //System.out.println("File write over!!!!");
		            
		            logger.info(" ------> File write over!!!!");
		            logger.info(" ------> File reading!!!!"); 
		            
		            downloadPDF(request,response,filePath,strFileName);
		            
		            
 
				}catch(Exception ex){
					ex.printStackTrace();
					 
				}

			}catch (Exception e) {
				
				
				jsnExpMsgObj.put("EXCEPTION_MESSAGE", e.getMessage()); 
	    	  	retValues.add(jsnExpMsgObj);
	    	  	logger.info("Exception messages"+e.getMessage());
	    		
	    		e.printStackTrace();

	    		
	          	 
			}
			
			
		return retValues;
	}
 

		public void downloadPDF(HttpServletRequest request, HttpServletResponse response, String fileURL, String strFileName)
			    throws IOException{
			
			    response.setContentType("application/pdf");
			    response.setHeader("Content-Disposition", "attachments; filename=\"" + strFileName + "\"");
			    try { 
			        File fileReport = new File(fileURL+strFileName);
			        FileInputStream finput = new FileInputStream(fileReport);
			        DataOutputStream foutput = new DataOutputStream(response.getOutputStream());
			        response.setHeader("Content-Length",String.valueOf(fileReport.length()));
			        byte[] buffer = new byte[1024];
			        int len = 0;
			        while ((len = finput.read(buffer)) >= 0) {
			        	foutput.write(buffer, 0, len);
			        }
			        foutput.close();
			        finput.close();
			       
			    } catch (Exception e) {
			        e.printStackTrace();
			        logger.info("Error while downloading file!!!!");
			    }
		}
	
	 
	 
}