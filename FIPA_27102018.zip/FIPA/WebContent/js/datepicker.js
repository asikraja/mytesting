 
// * Date picker
 var dobid="";
 var ageid="";
 var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;  
 
 var stafftype = $('#hTxtFldLoggedStfType').val();

 function getdob(dateid,ageeid,flg){
	  
	 var findId=$(dateid).attr("id");/*RP CF*/
	 var birth =  $(dateid).val(); 
	  
 	if (!(birth == undefined || birth == "" || birth == null)){
    if(birth.match(dateformat)) {
 		
 		var date = birth.substring(0, 2);
   		var month = birth.substring(3, 5);
   		var year = birth.substring(6, 10);
   		
   		
   	 if(birth.length<10){  
		 arr = birth.split('/');
		 if(arr[0].length == 1){
			 date=arr[0].replace(arr[0],"0"+arr[0]);
		 }else{
			 date=arr[0];
		 }
		 
		 if(arr[1].length == 1){
			 month=arr[1].replace(arr[1],"0"+arr[1]);
		 }else{
			 month=arr[1];
		 }
		 
		 year=arr[2];
		 $(dateid).val(date+"/"+month+"/"+year);
	 }
   	 
   	 
   		var d=new Date(); 
   		var cmonth = d.getMonth()+1;
   		var day = d.getDate();

   		var output =((''+day).length<2 ? '0' : '') + day + '/' +
   		    ((''+month).length<2 ? '0' : '') + month + '/' +
   		 d.getFullYear(); 
   		var y=d.getFullYear();
   		var age; 
   		
   		
   			if(month > cmonth){
   				age=y-year-1;
   			}else if(month < cmonth){
   				age=y-year;
   			}else if(month == cmonth){
   				if(Number(date) > day){
   					age=y-year-1;
   				}else{
   					age=y-year;
   				}
   			}
   			if(age == 0){
   				ageeid.val(age);		
   			}
   		
   			$("span[id='txtFldRDClientAge']").text("");
   			$("span[id='txtFldRDSpouseAge']").text("");
   		
   		if(!(age <= 0)){
   			ageeid.val(age);
   			/*RP CF*/
   		
   			if(findId == 'dfSelfDob'){$("span[id='txtFldRDClientAge']").text(age);}else 
   				if(findId == 'dfSpsDob'){$("span[id='txtFldRDSpouseAge']").text(age);}
   		}else if(age < 0){
   			if(flg){
   			showAlert("DOB Cannot be Greater than Current Date",$(dateid));
   			}
   			$(dateid).val(""); 
   			ageeid.val(0);
   			/*RP CF*/
   			if(findId == 'dfSelfDob'){$("span[id='txtFldRDClientAge']").text(0);}
   			else if(findId == 'dfSpsDob'){$("span[id='txtFldRDSpouseAge']").text(0);}
   		}
   	  }else{
   		if(flg){
   		showAlert("Invalid Date Format",$(dateid));
   		}
   		$(dateid).val(""); 
   		ageeid.val(0);
   		/*RP CF*/
   		if(findId == 'dfSelfDob'){$("span[id='txtFldRDClientAge']").val(0);}
   		else if(findId == 'dfSpsDob'){$("span[id='txtFldRDSpouseAge']").val(0);}
       }
 	 }
 	
 	else if( birth == undefined || birth == "" || birth == null){ 
 		ageeid.val(0);
 		/*RP CF*/
 		if(findId == 'dfSelfDob'){$("input[id='txtFldRDClientAge']").val(0);}else 
				if(findId == 'dfSpsDob'){$("span[id='txtFldRDSpouseAge']").val(0);}
	    
 	}
	
 }
  
 
 
 $(function (){  
	    //DOB  Picker
	 if(stafftype == STAFFTYPE_ADVISER){  
		  
		 
		//Date Of Birth - Datepicker Initialisation and Format validation
		 $("#dobSlfpicker,#dobSpspicker,#DateChildDatepicker,#DateDeptDatePpicker").datetimepicker(dobOptions).on("change",function(){
				 checkDateFormat($(this));  
			 });	 
		//Date Of Birth - Field initialise date format validation
		 $("#dfSelfDob,#dfSpsDob,#txtFldDlgChildDob,#txtFldDlgDepnDob").on("change",function(){
			 checkDateFormat($(this)); 
		 }); 
		 
		 
		 //Normal date - Datepicker Initialisation and Format validation
		 $('#txtFldRDDatepicker,#COBPerFrmpicker,#COBPerTopicker,#InvDateInvstDatepicker,#InvDateInvstDatepicker,'
				 +'#LIIncptDatepicker,#LIMaturityDatepicker,#DfIncepDatepicker,#DfExpiryDatepicker,#CrtlnsExpDatepicker,'
				 +'#HIExpirypicker, #SrchCpfAllocEffFrompicker,#dlgCpfAllocEffFrompicker,#SrchCpfIntMthpicker,#dlgCpfIntMthpicker,#dlgMsCpfContEffFrmpickr,#dlgMsCpfContEffTopickr')
				 .datetimepicker(dateOptions).on("change",function(){
			 checkDateFormat($(this));  
		 });
		  
		 
		 
		
		 $("#dobSlfpicker").datetimepicker(dobOptions).on("change",function(){
			 calSelfCpfMastMthContr();
		 });
		 $("#dobSpspicker").datetimepicker(dobOptions).on("change",function(){
			 calSpsCpfMastMthContr();
		 });
		 $("#dfSelfDob").on("change",function(){
			 calSelfCpfMastMthContr();
		 });
		 
		 $("#dfSpsDob").on("change",function(){
			 calSpsCpfMastMthContr();
		 });
		 
		//Normal date - Field initialise date format validation
		 $("#dfSelfDob,#dfSpsDob,#txtFldDlgChildDob,#txtFldDlgDepnDob,#txtFldDlgInvDateInvst," +
		 		"#txtFldDlgCOBPerFrom,#txtFldDlgCOBPerTo," +
		 		"#txtFldDlgInvDateInvs,#lipIncepdate," +
		 		"#lipMaturityDate,#txtFldDlgDfIncepDate,#txtFldDlgDfExpiryDate," +
		 		"#txtFldDlgCrtlnsExpDate,#txtFldDlgHIExpiry,#txtFldSrchCpfAllocEffFrom," +
		 		"#txtFldDlgCPFAllocEffFrom,#txtFldSrchCpfIntMth,#txtFldDlgCpfIntMonth,#dlgmscpfconeffFrom,#dlgmscpfconeffTo").on("change",function(){
			 checkDateFormat($(this)); 
		 }); 
		 
		 
		 
		 	/*Cash At Banks*/
		 $('#COBPerTopicker').datetimepicker(dateOptions).on("change",function(){  
		    	if(!chkFromToDateValidation('txtFldDlgCOBPerFrom','txtFldDlgCOBPerTo',"Period To Date should greater than the Period From Date"));
		 });
		 $('#COBPerFrmpicker').datetimepicker(dateOptions).on("change",function(){
		       	if(!chkFromToDateValidation('txtFldDlgCOBPerFrom','txtFldDlgCOBPerTo',"Period To Date should greater than the Period From Date")); 		       	
		 });
		 
		 	/*Death benefit*/
		 $('#DfIncepDatepicker').datetimepicker(dateOptions).on("change",function(){  
		    	if(!chkFromToDateValidation('txtFldDlgDfIncepDate','txtFldDlgDfExpiryDate',"Expiry Date should greater than the Inception Date"));
		 });
		 $('#DfExpiryDatepicker').datetimepicker(dateOptions).on("change",function(){
		       	if(!chkFromToDateValidation('txtFldDlgDfIncepDate','txtFldDlgDfExpiryDate',"Expiry Date should greater than the Inception Date")); 		       	
		 });
		 
		 /*Central provident fund*/
		 $('#CADPerFrmpicker').datetimepicker(dateOptions).on("change",function(){  
		    	if(!chkFromToDateValidation('CADPerFrmpicker','CADPerTopicker',"Period To Date should greater than the Period From Date"));
		 });
		 $('#CADPerTopicker').datetimepicker(dateOptions).on("change",function(){
		       	if(!chkFromToDateValidation('CADPerFrmpicker','CADPerTopicker',"Period To Date should greater than the Period From Date")); 		       	
		 });


		 $("#dfSelfDob").on("change",function(){
		 	getdob(this,$('#dfSelfAge'),true);  
		 });


		 $("#dfSpsDob").on("change",function(){
		 	getdob(this,$('#dfSpsAge'),true);  
		 });
 
		 
	 }  
	   
	    
	    
 });


  


function checkDateFormat(date){
	 var txtVal=date.val();
	 var day,month,year;
	 var arr=[]; 
	 if(txtVal.match(dateformat)) {
	 if(txtVal.length<10){  
		 arr = txtVal.split('/');
		 if(arr[0].length == 1){
			 day=arr[0].replace(arr[0],"0"+arr[0]);
		 }else{
			 day=arr[0];
		 }
		 
		 if(arr[1].length == 1){
			 month=arr[1].replace(arr[1],"0"+arr[1]);
		 }else{
			 month=arr[1];
		 }
		 
		 year=arr[2];
		 date.val(day+"/"+month+"/"+year);
	 }
	 }
		if(!isEmpty(txtVal) && !isDate(txtVal)){
		
			showAlert('Invalid Date');
			date.val("");
	}
}

 
