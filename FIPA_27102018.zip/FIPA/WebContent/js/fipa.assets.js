/**
 * Personal Assets
 */  

/*Datatable Initialisation*/
var personalAssetTbl = $('#personalAssetTbl').DataTable( {
   destroy: true,
   responsive: false,         
   ordering: false,
   searching: false,     
   scrollY:  "40vh",
   scrollX: true,
   scroller: false,
   scrollCollapse:false,
   paging:false, 
   filter:false,   
   columnDefs: [], 
   dom: '<<"top" ip>flt>',  
   columnDefs: [  { width: '20px', targets: [0,1]},
  	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10,11,12],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
   
		 }, 
}).draw();
	


/*Add Row Click */
$("#PersARow").on("click",function(){
	if(!valperastTbl())return; 
			perastClearFlds();
			showFIPAModel('perAssets_Dialog','Personal Assets Details');   
			$('#perAssets_Dialog').on('shown.bs.modal', function () {
				$("#perAssets_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#perAssets_Dialog").find("select[id=txtFldDlgPerAcctHolder]").focus(); 
				$("#perAssets_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validateperastDetails())return;
					   	perastRdlyflds(INS_MODE);  
					   	getPerAssetRows(null); 
						$('#perAssets_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getPerAssetRows(dataset){ 

var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldperastMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldPerBusiPersId">';

var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radperastSelect"/><label>&nbsp;</label></div>'; 


var cell2 = '<select name="txtFldPerAcctHolder" class="form-control editable"></select>';
 
var cell3 = '<input type="text" name="txtFldPerTypeOfAsset" class="form-control editable"  maxlength="60" onmouseover="fipaTooltip(this);" maxlength="300"/>'; 

var cell4 = '<input type="text" name="txtFldPerNameOfAsset" class="form-control editable"  maxlength="60"  onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell5 = '<input type="text" name="txtFldPerPurInvValue" class="form-control editable"  onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell6 = '<input type="text" name="txtFldPerCurrValue" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell7 = '<input type="text" name="txtFldPerOsValue" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell8 = '<input type="text" name="txtFldPerEstApprValue" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell9 = '<input type="text" name="txtFldPerYrs2keep" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell10 = '<input type="text" name="txtFldPerChildEdnPrcnt" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell11 = '<input type="text" name="txtFldPerRetPlanPrcnt" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell12 = '<input type="text" name="txtFldPerRemarks" class="form-control editable"   maxlength="300"  onmouseover="fipaTooltip(this);" maxlength="300"/>'+
'<input type="hidden" name="txtFldPerCrtdBy"/><input type="hidden" name="txtFldPerCrtdDate"/>';

personalAssetTbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10,cell11,cell12] ).draw( false );

var rowCount = $('#personalAssetTbl tbody tr').length;	
var $lastRow = $("#personalAssetTbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radperast"+$lastRow.index())
.parent().find('label').attr('for',"radperast"+$lastRow.index());


var accholder = $("#txtFldDlgPerAcctHolder > option").clone();
$lastRow.find("td:eq(2)").find('select:eq(0)').append(accholder);
$lastRow.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgPerAcctHolder").val());


$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgPerTypeOfAsset").val());

$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgPerNameOfAsset").val());

$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgPerPurInvValue").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");


$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgPerCurrValue").val());
$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntUsd");


$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgPerOsValue").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntUsd");


$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgPerEstApprValue").val());
$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntUsd");


$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgPerYrs2keep").val());
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntYrs");



$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgPerChildEdnPrcnt").val());
$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntpCent"); 


 
$lastRow.find("td:eq(11)").find('input:eq(0)').val($("#txtFldDlgPerRetPlanPrcnt").val());
$lastRow.find("td:eq(11)").find('input:eq(0)').addClass("applyEvntpCent"); 


$lastRow.find("td:eq(12)").find('input:eq(0)').val($("#txtFldDlgPerRemarks").val());


applyEventHandlers();


if(dataset != null){

	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
		case "txtFldPerBusiPersId": 
			$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
			break;
			
		case "txtFldPerAcctHolder": 
			selectNullvalChk($lastRow.find("td:eq(2)"),col);
			break;
			
		case "txtFldPerTypeOfAsset": 
			$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
			break;
		 
		case "txtFldPerNameOfAsset": 
			$lastRow.find("td:eq(4)").find('input:eq(0)').val(col); 
			break;
		 
		case "txtFldPerPurInvValue": 
			$lastRow.find("td:eq(5)").find('input:eq(0)').val(col); 
			break;
			
		case "txtFldPerCurrValue": 
			$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 			
			break;
		
		case "txtFldPerOsValue": 
			$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 
			break;
		
		case "txtFldPerEstApprValue": 
			$lastRow.find("td:eq(8)").find('input:eq(0)').val(col); 
			break;
			
		case "txtFldPerYrs2keep":
			$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
			break;
			
		case "txtFldPerChildEdnPrcnt":
			$lastRow.find("td:eq(10)").find('input:eq(0)').val(col); 
			break;
			
		case "txtFldPerRetPlanPrcnt":
			$lastRow.find("td:eq(11)").find('input:eq(0)').val(col); 
			break;
				
		case "txtFldPerRemarks":
			$lastRow.find("td:eq(12)").find('input:eq(0)').val(col); 
			break;
		
		
		case "txtFldPerCrtdBy": 
			$lastRow.find("td:eq(16)").find('input:eq(1)').val(col);
			infoDetsArr.push(col);				
			break;
			
		case "txtFldPerCrtdDate":
			$lastRow.find("td:eq(16)").find('input:eq(2)').val(col);
			infoDetsArr.push(col);
			break;
			
		case "txtFldPerModBy":
			infoDetsArr.push(col);
			break;
			
		case "txtFldPerModDate":
			infoDetsArr.push(col);
			break;	
		}			 
		 
	}
	}

perastClearFlds();

}



/*Edit Row Click */
$("#PersERow").on("click",function(){
	$("#PersVRow").click(); 
});


/*View Row Click */
$("#PersVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#personalAssetTbl tbody tr').length;	
	var $lastRow = $("#personalAssetTbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view");
		return;
	} 
	
	
	$("#personalAssetTbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
	});
	
	
	
	$("#personalAssetTbl tbody").find('input[name="radperastSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	
	$("#personalAssetTbl tbody").find('input[name="radperastSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode); 
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					});  
	 
				 	perastRdlyflds($mode);
					perastfilldlgval($row); 
					showFIPAModel('perAssets_Dialog','Personal Assets Details');  
					$('#perAssets_Dialog').on('shown.bs.modal', function () {
						$("#perAssets_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#perAssets_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateperastDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			perastfilldomval($RowId,$row); 
					     		}  
					     		
								$('#perAssets_Dialog').modal('hide'); 
								perastClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#PersDRow").on("click",function(){ 
	datatableDeleteRow('personalAssetTbl',personalAssetTbl); 
	

});

/*Clear Fields */
function perastClearFlds(){
	$("#perAssets_Dialog").find("input[type=text]").val("");
	$("#perAssets_Dialog").find("textarea").val("");
	$("#perAssets_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function perastRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#perAssets_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#perAssets_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateperastDetails(){
	 
	 
	if(!(validateFocusFlds('perAssets_Dialog','txtFldDlgPerAcctHolder', PERACCHOL))) return;
	if(!(validateFocusFlds('perAssets_Dialog','txtFldDlgPerTypeOfAsset', PERACCTP))) return;
	if(!(validateFocusFlds('perAssets_Dialog','txtFldDlgPerNameOfAsset', PERASTNAME))) return;
	
		
	
	  return true; 
}

function valperastTbl(){ 
	var $lastRow = $("#personalAssetTbl tbody tr:last");	
	var $RowCount = personalAssetTbl.rows().count();

	var valid=true;
	if($RowCount > 0 ){ 
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(2)").find('select:eq(0)'), PERACCHOL))) return; 
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(3)").find('input:eq(0)'), PERACCTP))) return; 
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(4)").find('input:eq(0)'), PERASTNAME))) return; 
	}  
  return true; 
}

/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgPerAcctHolder,#txtFldDlgPerNameOfAsset,#txtFldDlgPerTypeOfAsset").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
 


/* Filling Model Fields*/
function perastfilldlgval($lastRow){
	  
	  $('#perAssets_Dialog #txtFldDlgPerBusiPersId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#perAssets_Dialog #txtFldDlgPerAcctHolder').val($lastRow.find("td:eq(2)").find('select:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerTypeOfAsset').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerNameOfAsset').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerPurInvValue').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerCurrValue').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerOsValue').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerEstApprValue').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerYrs2keep').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerChildEdnPrcnt').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerRetPlanPrcnt').val($lastRow.find("td:eq(11)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerRemarks').val($lastRow.find("td:eq(12)").find('input:eq(0)').val());
	  $('#perAssets_Dialog #txtFldDlgPerCrtdBy').val($lastRow.find("td:eq(12)").find('input:eq(1)').val());
	  $('#perAssets_Dialog #txtFldDlgPerCrtdDate').val($lastRow.find("td:eq(12)").find('input:eq(2)').val());
}

/* Filling Table Fields*/
function perastfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgPerAcctHolder").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgPerTypeOfAsset").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgPerNameOfAsset").val()); 
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgPerPurInvValue").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgPerCurrValue").val()); 
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgPerOsValue").val()); 
	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgPerEstApprValue").val()); 
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgPerYrs2keep").val()); 
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgPerChildEdnPrcnt").val()); 
	$row.find("td:eq(11)").find('input:eq(0)').val($("#txtFldDlgPerRetPlanPrcnt").val());
	$row.find("td:eq(12)").find('input:eq(0)').val($("#txtFldDlgPerRemarks").val());  
		
}
/*###########################################################################################################################################################*/


/**
 * Business Assets
 */ 

/*Datatable Initialisation*/
var businessAssetTbl = $('#businessAssetTbl').DataTable( {
   destroy: true,
   responsive: false,         
   ordering: false,
   searching: false,     
   scrollY:  "40vh",
   scrollX: true,
   scroller: false,
   scrollCollapse:false,
   paging:false, 
   filter:false,   
   columnDefs: [], 
   dom: '<<"top" ip>flt>',  
   columnDefs: [  { width: '20px', targets: [0,1]},
  	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10,11,12],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
   
		 }, 
}).draw();



/*Add Row Click */
$("#BusiARow").on("click",function(){
	if(!valbusnastTbl())return; 
			busnastClearFlds();
			showFIPAModel('busnAssets_Dialog','Business Assets Details');   
			$('#busnAssets_Dialog').on('shown.bs.modal', function () {
				$("#busnAssets_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#busnAssets_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatebusnastDetails())return;
					   	busnastRdlyflds(INS_MODE);  
					   	getBuisAsstRows(null); 
						$('#busnAssets_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getBuisAsstRows(dataset){ 

var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldbusnastMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldPerBusiPersId">';

var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radbusnastSelect"/><label>&nbsp;</label></div>'; 


var cell2 = '<select type="text" name="txtFldBuisAcctHolder" class="form-control editable" ></select>';
 
var cell3 = '<input type="text" name="txtFldBuisTypeOfAsset" class="form-control editable" maxlength="60" onmouseover="fipaTooltip(this);" maxlength="300"/>'; 

var cell4 = '<input type="text" name="txtFldBuisNameOfAsset" class="form-control editable"   maxlength="60" onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell5 = '<input type="text" name="txtFldBuisPurInvValue" class="form-control editable" onmouseover="fipaTooltip(this);" maxlength="300"/>'; 

var cell6 = '<input type="text" name="txtFldBuisCurrValue"" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell7 = '<input type="text" name="txtFldBuisOsValue" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell8 = '<input type="text" name="txtFldBuisEstApprValue" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell9 = '<input type="text" name="txtFldBuisYrs2keep" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell10 = '<input type="text" name="txtFldBuisChildEdnPrcnt" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell11 = '<input type="text" name="txtFldBuisRetPlanPrcnt" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell12 = '<input type="text" name="txtFldBuisRemarks" class="form-control editable" maxlength="500"  onmouseover="fipaTooltip(this);" maxlength="300"/>'+
'<input type="hidden" name="txtFldBuisCrtdBy"/><input type="hidden" name="txtFldBuisCrtdDate"/>';

businessAssetTbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10,cell11,cell12] ).draw( false );

var rowCount = $('#businessAssetTbl tbody tr').length;	
var $lastRow = $("#businessAssetTbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radbusnast"+$lastRow.index())
.parent().find('label').attr('for',"radbusnast"+$lastRow.index());


var accholder = $("#txtFldDlgBusnAcctHolder > option").clone();
$lastRow.find("td:eq(2)").find('select:eq(0)').append(accholder);
$lastRow.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgBusnAcctHolder").val());


$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgBusnTypeOfAsset").val());

$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgBusnNameOfAsset").val());

$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgBusnPurInvValue").val()); 
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");

$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgBusnCurrValue").val());
$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntUsd");

$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgBusnOsValue").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntUsd");

$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgBusnEstApprValue").val());
$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntUsd");


$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgBusnYrs2keep").val());
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntYrs");


$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgBusnChildEdnPrcnt").val());
$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntpCent");

 
$lastRow.find("td:eq(11)").find('input:eq(0)').val($("#txtFldDlgBusnRetPlanPrcnt").val());
$lastRow.find("td:eq(11)").find('input:eq(0)').addClass("applyEvntpCent");


$lastRow.find("td:eq(12)").find('input:eq(0)').val($("#txtFldDlgBuisRemarks").val());


applyEventHandlers();


if(dataset != null){

	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
		case "txtFldBuisBusiPersId": 
			$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
			break;
			
		case "txtFldBuisAcctHolder": 
			selectNullvalChk($lastRow.find("td:eq(2)"),col);
			break;
			
		case "txtFldBuisTypeOfAsset": 
			$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
			break;
		 
		case "txtFldBuisNameOfAsset": 
			$lastRow.find("td:eq(4)").find('input:eq(0)').val(col); 
			break;
		 
		case "txtFldBuisPurInvValue": 
			$lastRow.find("td:eq(5)").find('input:eq(0)').val(col); 
			break;
			
		case "txtFldBuisCurrValue": 
			$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 			
			break;
		
		case "txtFldBuisOsValue": 
			$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 
			break;
		
		case "txtFldBuisEstApprValue": 
			$lastRow.find("td:eq(8)").find('input:eq(0)').val(col); 
			break;
			
		case "txtFldBuisYrs2keep":
			$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
			break;
			
		case "txtFldBuisChildEdnPrcnt":
			$lastRow.find("td:eq(10)").find('input:eq(0)').val(col); 
			break;
			
		case "txtFldBuisRetPlanPrcnt":
			$lastRow.find("td:eq(11)").find('input:eq(0)').val(col); 
			break;
				
		case "txtFldBuisRemarks":
			$lastRow.find("td:eq(12)").find('input:eq(0)').val(col); 
			break;
		
		
		case "txtFldBuisCrtdBy": 
			$lastRow.find("td:eq(16)").find('input:eq(1)').val(col);
			infoDetsArr.push(col);				
			break;
			
		case "txtFldBuisCrtdDate":
			$lastRow.find("td:eq(16)").find('input:eq(2)').val(col);
			infoDetsArr.push(col);
			break;
			
		case "txtFldBuisModBy":
			infoDetsArr.push(col);
			break;
			
		case "txtFldBuisModDate":
			infoDetsArr.push(col);
			break;	
		}			 
		 
	}
	}

busnastClearFlds();

}



/*Edit Row Click */
$("#BusiERow").on("click",function(){
	$("#BusiVRow").click(); 
});


/*View Row Click */
$("#BusiVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#businessAssetTbl tbody tr').length;	
	var $lastRow = $("#businessAssetTbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	
	$("#businessAssetTbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
	});
	
	
	$("#businessAssetTbl tbody").find('input[name="radbusnastSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#businessAssetTbl tbody").find('input[name="radbusnastSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);   
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'}); 
				});
				 	busnastRdlyflds($mode);
					busnastfilldlgval($row); 
					showFIPAModel('busnAssets_Dialog','Business Assets Details');  
					$('#busnAssets_Dialog').on('shown.bs.modal', function () {
						$("#busnAssets_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#busnAssets_Dialog").find("select[id=txtFldDlgBusnAcctHolder]").focus(); 
						$("#busnAssets_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatebusnastDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			busnastfilldomval($RowId,$row); 
					     		}  
					     		
								$('#busnAssets_Dialog').modal('hide'); 
								busnastClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#BusiDRow").on("click",function(){ 
	datatableDeleteRow('businessAssetTbl',businessAssetTbl); 
	

});

/*Clear Fields */
function busnastClearFlds(){
	$("#busnAssets_Dialog").find("input[type=text]").val("");
	$("#busnAssets_Dialog").find("textarea").val("");
	$("#busnAssets_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function busnastRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#busnAssets_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#busnAssets_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatebusnastDetails(){
	 
	 
	if(!(validateFocusFlds('busnAssets_Dialog','txtFldDlgBusnAcctHolder', PERACCHOL))) return;
	if(!(validateFocusFlds('busnAssets_Dialog','txtFldDlgBusnTypeOfAsset', PERACCTP))) return; 
	if(!(validateFocusFlds('busnAssets_Dialog','txtFldDlgBusnNameOfAsset', PERASTNAME))) return;

	  return true; 
}

function valbusnastTbl(){ 
	var $lastRow = $("#businessAssetTbl tbody tr:last");	
	var $RowCount = businessAssetTbl.rows().count();

	var valid=true;
	if($RowCount > 0 ){ 
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(2)").find('select:eq(0)'), PERACCHOL))) return; 
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(3)").find('input:eq(0)'), PERACCTP))) return; 
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(4)").find('input:eq(0)'), PERASTNAME))) return; 
	}  
  return true; 
}


/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgBusnAcctHolder,#txtFldDlgBusnNameOfAsset,#txtFldDlgBusnTypeOfAsset").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
 


/* Filling Model Fields*/
function busnastfilldlgval($lastRow){
	  
	  $('#busnAssets_Dialog #txtFldDlgBusnBusiPersId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnAcctHolder').val($lastRow.find("td:eq(2)").find('select:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnTypeOfAsset').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnNameOfAsset').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnPurInvValue').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnCurrValue').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnOsValue').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnEstApprValue').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnYrs2keep').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnChildEdnPrcnt').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnRetPlanPrcnt').val($lastRow.find("td:eq(11)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBuisRemarks').val($lastRow.find("td:eq(12)").find('input:eq(0)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnCrtdBy').val($lastRow.find("td:eq(12)").find('input:eq(1)').val());
	  $('#busnAssets_Dialog #txtFldDlgBusnCrtdDate').val($lastRow.find("td:eq(12)").find('input:eq(2)').val());
}

/* Filling Table Fields*/
function busnastfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgBusnAcctHolder").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgBusnTypeOfAsset").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgBusnNameOfAsset").val()); 
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgBusnPurInvValue").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgBusnCurrValue").val()); 
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgBusnOsValue").val()); 
	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgBusnEstApprValue").val()); 
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgBusnYrs2keep").val()); 
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgBusnChildEdnPrcnt").val()); 
	$row.find("td:eq(11)").find('input:eq(0)').val($("#txtFldDlgPerRetPlanPrcnt").val());
	$row.find("td:eq(12)").find('input:eq(0)').val($("#txtFldDlgBuisRemarks").val()); 
		
}
/*###########################################################################################################################################################*/
