
var fipaForm;
var master;
var newProfile = "";
var FIPAFnaId = "";
var FIPAMenu = "";
var FundListNames = new Array();
var dataTableFlg=false;
var stafftype = $('#hTxtFldLoggedStfType').val();
var advstfId = $('#hTxtFldLoggedAdvStfId').val();
var strMgrFlg = $('#hTxtFldLoggedUserMgrFlg').val();

var searchtbl = $("#ClientSearchTable").DataTable(
		{
			scrollCollapse : true,
			scrollX : true,
			scrollY : "36vh",
			sorting : false,
			ordering : false,
			bLengthChange : false,
			filter : false,
			paging : false,
			dom : '<<"top" ip>flt>',
			 columnDefs: [  { width: '20px', targets: [0,1]},
			   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8]}],		 
			fnDrawCallback : function(oSettings) {
				if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) {
					$(oSettings.nTableWrapper).find('.dataTables_paginate')
							.hide();
					$(oSettings.nTableWrapper).find('.dataTables_scrollBody')
							.css("height", "36vh");

				}

			}
		});
var profileTbl = $('#ProfileSearchTable').DataTable(
		{
			destroy : true,
			responsive : false,
			ordering : false,
			searching : false,
			scrollY : "63vh",
			scrollX : true,
			scroller : false,
			scrollCollapse : true,
			paging : false,
			filter : false,
			columnDefs : [ {
				width : '20px',
				targets : [ 0, 1 ]
			}, {
				"className" : "dt-head-center text-center",
				targets : [ 0, 1, 2, 3, 4, 5, 6, 7, 8 ],
				"orderable" : false,
				"searchable" : false
			} ],
			dom : '<<"top" ip>flt>',
			fnDrawCallback : function(oSettings) {
				if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) {
					$(oSettings.nTableWrapper).find('.dataTables_scrollBody')
							.css("max-height", "63vh").css("min-height",
									"400px");
				}
			}
		}).draw();

var utlipPolicyTbl = $('#existPolicyUtlip').DataTable(
		{
			destroy : true,
			responsive : false,
			ordering : false,
			searching : false,
			scrollY : 200,
			scrollX : true,
			scroller : false,
			scrollCollapse : true,
			paging : false,
			filter : false,
			dom : '<<"top" ip>flt>',
			columnDefs : [ {
				width : '20px',
				targets : [ 0, 1 ]
			}, {
				"orderable" : false,
				"searchable" : false
			} ],

			fnDrawCallback : function(oSettings) {
				if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) {
					$(oSettings.nTableWrapper).find('.dataTables_scrollBody')
							.css("max-height", "40vh").css("min-height",
									"250px");
				}
			}

		});

var existPolicyLHIns = $('#existPolicyLHIns').DataTable(
		{
			destroy : true,
			responsive : false,
			ordering : false,
			searching : false,
			scrollY : 200,
			scrollX : true,
			scroller : false,
			scrollCollapse : true,
			paging : false,
			filter : false,
			dom : '<<"top" ip>flt>',
			columnDefs : [ {
				width : '20px',
				targets : [ 0, 1 ]
			}, {
				"orderable" : false,
				"searchable" : false
			} ],

			fnDrawCallback : function(oSettings) {

				if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) {
					$(oSettings.nTableWrapper).find('.dataTables_scrollBody')
							.css("max-height", "45vh").css("min-height",
									"250px");
				}

			}

		});

function fipaInitPage() {

	fipaForm = document.forms[0];

	 

	if (!isEmpty(newProfile) && newProfile === "TRUE") {

		openClientSection();
		$("#btnSaveProfile").removeClass("hidden");
		$("#advstfId").val(advstfId);
		setAdvMgrId(document.getElementById("advstfId"));
		$("select#advstfId").prop("disabled", true);

		$("input:checkbox[name=txtFldAnalyisFor]").prop("checked", true);
		$("input:checkbox[name=txtFldAnalyisFor]:eq(0)").prop("disabled", true);
		$("input:checkbox[name=txtFldAnalyisFor]").val("Y");
		$("#appAnalysisFor").val('{"ANALYS_SLF":"Y","ANALYS_SPS":"N","ANALYS_FAM":"Y"}');
		$("input:checkbox[name=txtFldClientChoice]:eq(1)").click();  
		$("input:checkbox[name=txtFldClientChoice]:eq(3)").click();
		$("input:checkbox[name=txtFldClientChoice]:eq(5)").click();
		$("#appClientChoice").val('{"LF":"Y","AF":"Y","IF":"Y"}');
	}

	if (stafftype == STAFFTYPE_ADVISER) {// Salim

		$("#advstfId").val(advstfId);
		setAdvMgrId(document.getElementById("advstfId"));
		$("select#advstfId").prop("disabled", true);

		var selectedText = $("#advstfId option:selected").text();
		$("input[name='txtFldAdviserName']").val(selectedText);
 

		// Toolbar icons
		$("#btnNewProfile").removeClass("hidden");
		$("#btnSaveProfile").removeClass("hidden");

	}

	if (stafftype == STAFFTYPE_STAFF) { // Amin
 
		$('#lblSrchNric').css('color', 'maroon');

		$("#profileDialog #fnaType").attr("disabled", false);
		clearAllDetails('disable'); // commented by thulasy 03.11.2017
		$(".funcToDisable").css("display", "none"); // Dhtml table buttons 
		// Toolbar icons
		$("#btnNewProfile").addClass("hidden");
		$("#btnSaveProfile").addClass("hidden");
	}
	if (!(stafftype == STAFFTYPE_STAFF)) {

		if (isEmpty(newProfile) && newProfile != "TRUE") {
			$("#sidebar-menu").find("li[id='search_li']").addClass("active");
    		chkClientMenu();show('searchpage');navlink($("#search_li"),'null');  
		}

	}

	if (strMgrFlg == "Y") {
		$('#sidebar-menu #supervisor_li').css("display", "block");
	}
	
//	alert(FIPAFnaId)

	loadAllSymbols();
	applyEventHandlers();
	tooltipHandlers();

	if (!isEmpty(FIPAMenu)) {
		openCurrentScreen(FIPAMenu);
	}

	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);

	hideLoader();

}
function tooltipHandlers() {
	
	
	
	

	showTooltip('imgFIPAProspect', STR_FIPA_TT);
	showTooltip('imgFPMSClient', STR_FPMS_TT);
	showTooltip('imgBoth1', STR_FIPAFPMS_TT);
	showTooltip('imgBoth2', STR_FIPAFPMS_TT);
	showTooltip('btnSaveProfile', STR_FIPA_SAVE);
	showTooltip('btnNewProfile', STR_FIPA_NEW);
	showTooltip('btnDeleteProfile', STR_FIPA_DELETE);
	showTooltip('btnFipaHome', STR_FIPA_HOME);
	showTooltip('btnLogout', STR_FIPA_LOGOUT);
	showTooltip('btnSrchProfile', STR_CLIENT_SEARCH);
	showTooltip('FipaLinkToFpms', STR_FPMSLINK);
	
	
	

	showTooltip('exportfipapolicy', STR_FIPAPOLICY);
	showTooltip('fipadelpolicy', STR_DELFIPAPOL);
	showTooltip('exportfpmspolicy', STR_FPMSPOLICY);

	showTooltip('finglsprop', 'Add New');
	showTooltip('propAddbtn', 'Add');
	showTooltip('propdelbtn', 'Delete');

	
	
	
	showTooltip('backNavInvCash', STRBACKTOCOB);
	showTooltip('backNavCashInv', STRBACKTOINV);
	
	showTooltip('exportfpmspolicy', STR_FPMSPOLICY);
	
	showTooltip('attcfiledownload', STR_DOWNLOADFILE);
	
	 

	showTooltipCls('searchRow-icon', STR_SEARCHROW);

	
	
	showTooltipCls('pdf-icon', 'Generate PDF');
	showTooltipCls('reset-icon', 'Reset All');
	showTooltipCls('genNavicon', 'Fetch NAV');
	
	showTooltipCls('rdcalFVIncome', STR_RDFVINCOME);
	showTooltipCls('canvas_info', STR_INFO);
	showTooltipCls('info', 'Additional Information');
	showTooltipCls('addnewlife', STR_ADDNEWLIFE);
	showTooltipCls('addInflwOutflw', INVESTMENT_ICON);
	showTooltipCls('addpropertyicon', PROPERTY_ICON);
	showTooltipCls('addvehcileicon', VEHICLE_ICON);
	showTooltipCls('addlifeicon', LIFE_ICON);
	showTooltipCls('backToFdFlow', STR_BACKTOFDFLW);
	showTooltipCls('backToAnlRnt', STR_BACKTOANLRENT); 
	showTooltipCls('backToCpfAD', STR_BACKTOCPFAND); 
	
	
	
	showTooltipCls('backToCashAsset', STR_BACKTOCASHASSET);
	showTooltipCls('addnaviCobFixed', COBFIXED_ICON);
	showTooltipCls('addnaviCobSaving', COBSAVING_ICON);
	showTooltipCls('addnaviCobCashEq', COBCURRENT_ICON);
	showTooltipCls('addnaviCobSRS', COBSRS_ICON);
	
	/* Children Particulars */
	showTooltip('AChldPt', 'Add Row For Childrens Particulars Details');
	showTooltip('EChldPt', 'Edit Row For Childrens Particulars Details');
	showTooltip('DChldPt', 'Delete Row For Childrens Particulars Details');
	showTooltip('VChldPt', 'View Row For Childrens Particulars Details');

	/* Financial Goals */
	showTooltip('AfinGls', 'Add Row For Financial Goals/Concern Details');
	showTooltip('EfinGls', 'Edit Row For Financial Goals/Concern Details');
	showTooltip('DfinGls', 'Delete Row For Financial Goals/Concern Details');
	showTooltip('VfinGls', 'View Row For Financial Goals/Concern Details');

	/* Wealth Accumulation */
	showTooltip('WAcARow', 'Add Row For Wealth Accumulation Goals Details');
	showTooltip('WAcERow', 'Edit Row For Wealth Accumulation Goals Details');
	showTooltip('WAcDRow', 'Delete Row For Wealth Accumulation Goals Details');
	showTooltip('WAcVRow', 'View Row For Wealth Accumulation Goals Details');

	/* Dependant Particulars */
	showTooltip('DeptARow',
			'Add Row For Other than family members(Dependant Particulars)');
	showTooltip('DeptERow',
			'Edit Row For Other than family members(Dependant Particulars)');
	showTooltip('DeptDRow',
			'Delete Row For Other than family members(Dependant Particulars)');
	showTooltip('DeptVRow',
			'View Row For Other than family members(Dependant Particulars)');

	/* Life Insurance - Nominees */
	showTooltip('NomARow', 'Add Row For Life Insurance - Nominees Details');
	showTooltip('NomERow', 'Edit Row For Life Insurance - Nominees Details');
	showTooltip('NomDRow', 'Delete Row For Life Insurance - Nominees Details');
	showTooltip('NomVRow', 'View Row For Life Insurance - Nominees Details');

	/* Life Insurance - Plan Details */
	showTooltip('lfplnARow', 'Add Row For Life Insurance - Plan Details');
	showTooltip('lfplnERow', 'Edit Row For Life Insurance - Plan Details');
	showTooltip('lfplnDRow', 'Delete Row For Life Insurance - Plan Details');
	showTooltip('lfplnVRow', 'View Row For Life Insurance - Plan Details');

	/* Life Insurance - Health Insurance Details */
	showTooltip('HlthARow',
			'Add Row For Life Insurance - Health Insurance Details');
	showTooltip('HlthERow',
			'Edit Row For Life Insurance - Health Insurance Details');
	showTooltip('HlthDRow',
			'Delete Row For Life Insurance - Health Insurance Details');
	showTooltip('HlthVRow',
			'View Row For Life Insurance - Health Insurance Details');

	/* Life Insurance - Death Benefits Details */
	showTooltip('DthARow',
			'Add Row For Life Insurance - Death Benefits Details');
	showTooltip('DthERow',
			'Edit Row For Life Insurance - Death Benefits Details');
	showTooltip('DthDRow',
			'Delete Row For Life Insurance - Death Benefits Details');
	showTooltip('DthVRow',
			'View Row For Life Insurance - Death Benefits Details');

	/* Life Insurance - Disability Details */
	showTooltip('DsbltyARow', 'Add Row For Life Insurance - Disability Details');
	showTooltip('DsbltyERow',
			'Edit Row For Life Insurance - Disability Details');
	showTooltip('DsbltyDRow',
			'Delete Row For Life Insurance - Disability Details');
	showTooltip('DsbltyVRow',
			'View Row For Life Insurance - Disability Details');

	/* Life Insurance - Critical Illness Details */
	showTooltip('CrtlARow',
			'Add Row For Life Insurance - Critical Illness Details');
	showTooltip('CrtlERow',
			'Edit Row For Life Insurance - Critical Illness Details');
	showTooltip('CrtlDRow',
			'Delete Row For Life Insurance - Critical Illness Details');
	showTooltip('CrtlVRow',
			'View Row For Life Insurance - Critical Illness Details');

	/* Life Insurance - Hospitality Details */
	showTooltip('HospARow', 'Add Row For Life Insurance - Hospitality Details');
	showTooltip('HospERow', 'Edit Row For Life Insurance - Hospitality Details');
	showTooltip('HospDRow',
			'Delete Row For Life Insurance - Hospitality Details');
	showTooltip('HospVRow', 'View Row For Life Insurance - Hospitality Details');

	/* Life Insurance - Retirement Planning Details */
	showTooltip('lfRetPlgARow',
			'Add Row For Life Insurance - Retirement Planning Details');
	showTooltip('lfRetPlgERow',
			'Edit Row For Life Insurance - Retirement Planning Details');
	showTooltip('lfRetPlgDRow',
			'Delete Row For Life Insurance - Retirement Planning Details');
	showTooltip('lfRetPlgVRow',
			'View Row For Life Insurance - Retirement Planning Details');

	/* Life Insurance - Education Planning Details */
	showTooltip('lfEduPlgARow',
			'Add Row For Life Insurance - Education Planning Details');
	showTooltip('lfEduPlgERow',
			'Edit Row For Life Insurance - Education Planning Details');
	showTooltip('lfEduPlgDRow',
			'Delete Row For Life Insurance - Education Planning Details');
	showTooltip('lfEduPlgVRow',
			'View Row For Life Insurance - Education Planning Details');

	/* Investment Details */
	showTooltip('InvestARow', 'Add Row For Investment Details');
	showTooltip('InvestERow', 'Edit Row For Investment Details');
	showTooltip('InvestDRow', 'Delete Row For Investment Details');
	showTooltip('InvestVRow', 'View Row For Investment Details');

	/* Property Ownership Details */
	showTooltip('powncpfARow', 'Add Row For Property Ownership  Details');
	showTooltip('powncpfERow', 'Edit Row For Property Ownership  Details');
	showTooltip('powncpfDRow', 'Delete Row For Property Ownership  Details');
	showTooltip('powncpfVRow', 'View Row For Property Ownership  Details');

	/* Cash At Banks Details */
	showTooltip('CobARow', 'Add Row For Cash At Banks Details');
	showTooltip('CobERow', 'Edit Row For Cash At Banks Details');
	showTooltip('CobDRow', 'Delete Row For Cash At Banks Details');
	showTooltip('CobVRow', 'View Row For Cash At Banks Details');

	/* Asset - Personal Assets Details */
	showTooltip('PersARow', 'Add Row For Personal Assets Details');
	showTooltip('PersERow', 'Edit Row For Personal Assets Details');
	showTooltip('PersDRow', 'Delete Row For Personal Assets Details');
	showTooltip('PersVRow', 'View Row For Personal Assets Details');

	/* Asset - Business Assets Details */
	showTooltip('BusiARow', 'Add Row For Business Assets Details');
	showTooltip('BusiERow', 'Edit Row For Business Assets Details');
	showTooltip('BusiDRow', 'Delete Row For Business Assets Details');
	showTooltip('BusiVRow', 'View Row For Business Assets Details');

	/* Vehicle Ownership Details */
	showTooltip('VehARow', 'Add Row For Vehicle Ownership Details');
	showTooltip('VehERow', 'Edit Row For Vehicle Ownership Details');
	showTooltip('VehDRow', 'Delete Row For Vehicle Ownership Details');
	showTooltip('VehVRow', 'View Row For Vehicle Ownership Details');

	/* CPF Addition & Deduction Details */
	showTooltip('CpfADARow', 'Add Row For CPF Addition & Deduction Details');
	showTooltip('CpfADERow', 'Edit Row For CPF Addition & Deduction Details');
	showTooltip('CpfADDRow', 'Delete Row For CPF Addition & Deduction Details');
	showTooltip('CpfADVRow', 'View Row For CPF Addition & Deduction Details');

	/* Other Area & Concern Details */
	showTooltip('ArCARow', 'Add Row For Other Area and Concern Details');
	showTooltip('ArCERow', 'Edit Row For Other Area and Concern Details');
	showTooltip('ArCDRow', 'Delete Row For Other Area and Concern Details');
	showTooltip('ArCVRow', 'View Row For Other Area and Concern Details');

	/* Adviser and Recommendations - LIFE & HEALTH INS Plan Dets */
	showTooltip(
			'ArtuPlanARow',
			'Add Row For Adviser and Recommendations - Life & Health Insurance (Plan Details)');
	showTooltip(
			'ArtuPlanERow',
			'Edit Row For Adviser and Recommendations - Life & Health Insurance (Plan Details)');
	showTooltip(
			'ArtuPlanDRow',
			'Delete Row For Adviser and Recommendations - Life & Health Insurance (Plan Details)');
	showTooltip(
			'ArtuPlanVRow',
			'View Row For Adviser and Recommendations - Life & Health Insurance (Plan Details)');

	/* Adviser and Recommendations - UT and ILP (Fund Details) */
	showTooltip('ArtuFundARow',
			'Add Row For Adviser and Recommendations - UT and ILP (Fund Details)');
	showTooltip('ArtuFundERow',
			'Edit Row For Adviser and Recommendations - UT and ILP (Fund Details)');
	showTooltip('ArtuFundDRow',
			'Delete Row For Adviser and Recommendations - UT and ILP (Fund Details)');
	showTooltip('ArtuFundVRow',
			'View Row For Adviser and Recommendations - UT and ILP (Fund Details)');

	/* Switching and Replace - LIFE & HEALTH INS Plan Dets */
	showTooltip('SwrepPlanARow',
			'Add Row For Switching and Replace - Life & Health Insurance (Plan Details)');
	showTooltip('SwrepPlanERow',
			'Edit Row For Switching and Replace - Life & Health Insurance (Plan Details)');
	showTooltip('SwrepPlanDRow',
			'Delete Row Switching and Replace - Life & Health Insurance (Plan Details)');
	showTooltip('SwrepPlanVRow',
			'View Row For Switching and Replace - Life & Health Insurance (Plan Details)');

	/* Switching and Replace - UT and ILP (Fund Details) */
	showTooltip('SwrepFundARow',
			'Add Row For Switching and Replace - UT and ILP (Fund Details)');
	showTooltip('SwrepFundERow',
			'Edit Row For Switching and Replace - UT and ILP (Fund Details)');
	showTooltip('SwrepFundDRow',
			'Delete Row For Switching and Replace - UT and ILP (Fund Details)');
	showTooltip('SwrepFundVRow',
			'View Row For Switching and Replace - UT and ILP (Fund Details)');

	/* Basis & Rationale of Recommendations */
	showTooltip('rsnARow', 'Add Row For Basis & Rationale of Recommendations');
	showTooltip('rsnERow', 'Edit Row For Basis & Rationale of Recommendations');
	showTooltip('rsnDRow',
			'Delete Row For Basis & Rationale of Recommendations');
	showTooltip('rsnVRow', 'View Row For Basis & Rationale of Recommendations');

	/* Retirement Plg - Other Payment on Retirement */
	showTooltip('AOthRet',
			'Add Row For Other Payment to be made during Retirement Details');
	showTooltip('EOthRet',
			'Edit Row For Other Payment to be made during Retirement Details');
	showTooltip('DOthRet',
			'Delete Row For Other Payment to be made during Retirement Details');
	showTooltip('VOthRet',
			'View Row For Other Payment to be made during Retirement Details');

	/* Retirement Plg - Income to be received during retirement */
	showTooltip('AIncRet',
			'Add Row For Income to be received during retirement Details');
	showTooltip('EIncRet',
			'Edit Row For Income to be received during retirement Details');
	showTooltip('DIncRet',
			'Delete Row For Income to be received during retirement Details');
	showTooltip('VIncRet',
			'View Row For Income to be received during retirement Details');

	/* Retirement Plg - Income and assets available for retirement */
	showTooltip('AIncAssRet',
			'Add Row For Income and assets available for retirement Details');
	showTooltip('EIncAssRet',
			'Edit Row For Income and assets available for retirement Details');
	showTooltip('DIncAssRet',
			'Delete Row For Income and assets available for retirement Details');
	showTooltip('VIncAssRet',
			'View Row For Income and assets available for retirement Details');

	/* Retirement Expenditure */
	showTooltip('RDExpAddRow',
			'Add Row For Other payment to be made during retirement Details');
	showTooltip('RDExpEditRow',
			'Edit Row For Other payment to be made during retirement Details');
	showTooltip('RDExpDelRow',
			'Delete Row For Other payment to be made during retirement Details');
	showTooltip('RDExpViewRow',
			'View Row For Other payment to be made during retirement Details');
	
	
	
	/*Attachments */
	showTooltip('DcAttchARow',
			'Add Row For Attachments Details');
	showTooltip('DcAttchERow',
			'Edit Row For Attachments Details');
	showTooltip('DcAttchDRow',
			'Delete Row For Attachments Details');
	showTooltip('DcAttchVRow',
			'View Row For Attachments Details');
	
	
	

}

function reloadProfile() {
	$("#btnSaveProfile").removeClass("hidden");

	$("#hTxtFldFnaReviewFlag").val("I");
	$(".fipaMode").val("I");
//	alert("--->"+FIPAFnaId)
	populateProfileDetails(null, FIPAFnaId);
	$("#analysisTypesdiv").find("input[type='checkbox']:checked").attr(
			"checked", false);

}
function openCurrentScreen(MenuName) {
	showLoader();
	reloadProfile();
	$("#sidebar-menu").find("ul li a").each(function() {
		var elmtxt = $(this).text();
		if (elmtxt == MenuName) {
			$(this).click();
		}
	});

}

function fipaSearch() {

	$('#ClientSearchTable').dataTable().fnClearTable();
	removeTblRows('ClientSearchTable');
	$("#ClientSearchTable").dataTable().fnDestroy();
	var srchFldsArrExclAll = [ "txtFldSrchCustName", "txtFldSrchCustNric" ];

	var isAnyAdvSelected = false;
	var isAnyStfSelected = false;

	if (stafftype == STAFFTYPE_ADVISER) {
		$.each(srchFldsArrExclAll, function(index, value) {
			if (!isEmpty($("#" + srchFldsArrExclAll[index]).val())) {
				isAnyAdvSelected = true;

			}
		});

		if (!isAnyAdvSelected) {
			showAlert("Select any search criteria!");
			clearDataTable('ClientSearchTable');
			return false;
		}

	} else if (stafftype == STAFFTYPE_STAFF) {
		if (!isEmpty($("#txtFldSrchCustNric").val())) {
			isAnyStfSelected = true;

		}

		if (!isAnyStfSelected) {
			showAlert(NRIC_KEYIN, txtFldSrchCustNric);// S1262752A
			clearDataTable('ClientSearchTable');
			return false;
		}
	}

	showLoader();
	var srchParams = "";

	srchParams += "&strSrchClntName="
			+ encodeURIComponent(escape($("#txtFldSrchCustName").val()
					.toUpperCase()));
	srchParams += "&strSrchClntNric="
			+ encodeURIComponent(escape($("#txtFldSrchCustNric").val()
					.toUpperCase()));

	var parameter = "DBCALLFOR=CLIENT_SEARCH" + srchParams;

	var tblId = document.getElementById("ClientSearchTable");
	var tbody = tblId.tBodies[0]; 
	ajaxCall(
			parameter,
			servletName,
			function(Data) {

				var retval = Data;

				for ( var val in retval) {

					var tabdets = retval[val];

					if (tabdets["SESSION_EXPIRY"]) {
						window.location = BASE_URL + SESSION_EXP_JSP;
						return;
					}

					if (tabdets["DB_ERROR"]) {
						window.location = BASE_URL + DB_EXP_JSP;
						return;
					}

					for ( var tab in tabdets) {

						if (tabdets.hasOwnProperty(tab)) {

							var key = tab;
							var value = tabdets[tab];

							if (key == "CLIENT_SEARCH_NOREC") {
								showAlert("No Record Found");
								clearDataTable('ClientSearchTable');
								hideLoader();
								return false;
							}

							if (key == "CLIENT_SEARCH") {
								for ( var cont in value) {
									if (value.hasOwnProperty(cont)) {

										var contvalue = value[cont];
										var rc = Number(cont);
										var crow = tbody.insertRow(cont);

										var cell0 = crow.insertCell(0);
										cell0.innerHTML =  (rc + 1);
										cell0.style.textAlign = "center";

										var setuniqid="radSrch"+(rc + 1);
										var cell1 = crow.insertCell(1); 
										cell1.innerHTML='<div class="radio radio-primary text-center"><input type="radio" name="radSrchSelectedId" id="'+setuniqid+'" onclick="populateProfileDetails(this,null)"/><label for="'+setuniqid+'">&nbsp;</label></div>';
										cell1.style.textAlign = "center"; 
//										cell1.find("input:first").attr('id',"radplnDet"+$lastRow.index())
//										.parent().find('label').attr('for',"radplnDet"+$lastRow.index());
										
										
										var cell2 = crow.insertCell(2);
										cell2.innerHTML ='<div class="dhtmlTableText wraptext">'+contvalue["dfSelfName"]+'</div>';
										cell2.style.textAlign = "left";
//										cell2.childNodes[0].value = contvalue["dfSelfName"];

										var cell3 = crow.insertCell(3);
										cell3.innerHTML = '<input type="text" readOnly="true" class="dhtmlTableText ptrcursor" style="width:73px" onmouseover="fipaTooltip(this);" /><input type="hidden"/><input type="hidden"/>';
										cell3.childNodes[0].value = contvalue["dfSelfNric"];
										cell3.childNodes[1].value = contvalue["fnaId"];
										cell3.childNodes[2].value = contvalue["strFpmsCustId"];

										var strMailId = isEmpty(contvalue["dfSelfPersemail"]) ? ""
												: contvalue["dfSelfPersemail"];
										
//										cell4.innerHTML = '<input type="text" readOnly="true" class="dhtmlTableText ptrcursor" onmouseover="fipaTooltip(this);" value="'
//												+ strMailId + '" />';
										var cell4 = crow.insertCell(4);
										cell4.innerHTML ='<div class="dhtmlTableText wraptext">'+strMailId+'</div>';
										cell4.style.textAlign = "left";
										
										var cell5 = crow.insertCell(5);
										cell5.innerHTML = '<div class="dhtmlTableText wraptext">'+contvalue["dfSelfMobile"]+'</div>';
										cell4.style.textAlign = "left";
											
//											'<input type="text" readOnly="true" class="dhtmlTableText ptrcursor" value="'
//												+ contvalue["dfSelfMobile"]
//												+ '"  />';

										var flagFPMS = contvalue["strFpmsExists"];
										var flagFIPA = contvalue["strFipaExists"];
										var ticksymbol = "&#9745;";

										var cell6 = crow.insertCell(6);
										cell6.style.textAlign = "center";
										cell6.innerHTML = (flagFIPA == "Y"
												&& flagFPMS == "Y" ? ""
												: (flagFIPA == "Y" ? ticksymbol
														: ""));

										var cell7 = crow.insertCell(7);
										cell7.style.textAlign = "center";
										cell7.innerHTML = (flagFIPA == "Y"
												&& flagFPMS == "Y" ? ""
												: (flagFPMS == "Y" ? ticksymbol
														: ""));

										var cell8 = crow.insertCell(8);
										cell8.style.textAlign = "center";
										cell8.innerHTML = (flagFIPA == "Y"
												&& flagFPMS == "Y" ? ticksymbol
												: "");

									}
								}
								tblRowHover("ClientSearchTable");

							}

						}
					}
				}

				hideLoader();

				$("#ClientSearchTable").DataTable(
						{
							destroy : true,
							scrollX : true,
							scrollY : "36vh",
							scrollCollapse : true,
							sorting : false,
							ordering : false,
							filter : false,
							paging : true,
							bLengthChange : false,
							pagingType : "full_numbers",
							dom : '<<"top" ip>flt>',
							 columnDefs: [  { width: '20px', targets: [0,1]},
							   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8]}],		 
								
							fnDrawCallback : function(oSettings) {
								if (oSettings._iDisplayLength > oSettings
										.fnRecordsDisplay()) {
									$(oSettings.nTableWrapper).find(
											'.dataTables_paginate').hide();
									$(oSettings.nTableWrapper).find(
											'.dataTables_scrollBody').css(
											"height", "38vh");

								}

							}
						// data: data
						});
			});

}

function clearClntSrchRows() {
//	searchtbl.clear().draw(); 
	$("#ClientSearchTable").dataTable().fnClearTable();
}

// $("#txtFldSrchCustName,#txtFldSrchCustNric").on("change,blur",function(){
// searchtbl.clear().draw();
// });

function clearAllDetails(option) {

	var txtFldInputsAll = [ 'clientsection', 'spousesection', 'childsection',
			'typesofappsec', 'goalssection', 'policysection',
			'dependantsection', 'sourceincomediv', 'hlinsurncesecion',
			'lifeinscsecion', 'contingencysection', 'estateplansection',
			'providentdiv', 'liabilitydiv', 'assumptiondiv', 'retireplandiv',
			'investdiv', 'cashassetdiv', 'cobdiv', 'areaofconcerndiv',
			'lifeinscsecion', 'clntreportdiv', 'clientsdeclrdiv',
			'attachmntdiv', 'adrecomprodiv', 'adrecomswtcdiv', 'Invstobjdiv',
			'Adandreadiv', 'brofrecomdiv', 'summarydiv', 'decbyclidiv',
			'suprvsrdiv', 'lifeinscsecion', 'retirecashflowdiv' ];

	switch (option) {
	case "clear": {

		$.each(txtFldInputsAll, function(index, value) {
			$("#" + value).find("input[type=text]").val("");
			$("#" + value).find("select").val("");
			$("#dfSpsIdtype").val("NRIC");
			$("#dfSelfIdtype").val("NRIC");
			$("#" + value).find("input[type=checkbox]").attr("checked", false);
			$("#" + value).find("input[type=radio]").attr("checked", false);
		});

		clearDHTMLTables();
		resetMultiSelectOpts();
		break;

	}
	case "disable": {

		$.each(txtFldInputsAll, function(index, value) {
			$("#" + value).find("input[type=text]").val("").attr("disabled",
					true);
			$("#" + value).find("select").val("").attr("disabled", true);
			$("#dfSpsIdtype").val("NRIC");
			$("#dfSelfIdtype").val("NRIC");
			$("#" + value).find("input[type=checkbox]").attr("checked", false)
					.attr("disabled", true);
			$("#" + value).find("input[type=radio]").attr("checked", false)
					.attr("disabled", true);
		});

		// alert("inside")
		clearDHTMLTables();
		$("#dfSelfNationality").val("Singaporean");
		$("#dfSpsNationality").val("Singaporean");
		$("#dfSpsMartsts").val("Married");

		$('#sellipIsnurObject').multiselect('disable');
		$('#sellipCoveragetype').multiselect('disable');
		$('#selmulCriticalLevelofDD').multiselect('disable');
		break;

	}

	default: {
		// alert("inside")
		clearDHTMLTables();
		$("#selDfSlfNationality").val("Singaporean");
		$("#dfSpsNationality").val("Singaporean");
		$("#dfSpsMartsts").val("Married");

	}

	}

}

function resetMultiSelectOpts() {
	resetMultiSel('selamlLanguageUse');
	resetMultiSel('sellipIsnurObject');
	resetMultiSel('sellipCoveragetype');
	resetMultiSel('selmulCriticalLevelofDD');
	$("#dfSelfNationality").val("Singaporean");
	$("#dfSpsNationality").val("Singaporean");
	$("#dfSpsMartsts").val("Married");
	typeOfCoverage('All', 'none');
	ObjOfInsurance('All', 'none');
	$('#liTypesOfCovBenefdiv').css("display", "none");
	CriticalLevelofDD('All', 'none', '', '');
	$('#lifeInsNavTabsDets a[href="#existPolicyDetstab"]').click();
	$("#lifeInsdetstab #NomineesTblDiv").css("display", "none");
}

function clearDHTMLTables() {

	var dataTableIdsAll = [ 'childParticularsTable', 'OthRetPlgtbl','fnaAttachments',
			'IncRetPlgtbl', 'IncAssRetPlgtbl', 'RDExptbl', 'RDInctbl',
			'RDIncAsstbl', 'finGoalsTable', 'wealthAccmltTable',
			'existPolicyLHIns', 'existPolicyUtlip', 'deptParticularsTable',
			'cpfAccTpupTable', 'cpfAccDeductTable', 'fnaPropOwnTblByCPF',
			'fnaVehiOwnTbl', 'fnadepntfinanceTbl', 'personalAssetTbl',
			'businessAssetTbl', 'othareaofconTbl', 'fnahlthinsTbl',
			'clntReasnsTable', 'fnaadvrecTbl', 'fnaartuplanTbl',
			'fnaartufundTbl', 'fnaswrepplanTbl', 'cashOfBanksTable',
			'cpfAccAddDedTable', 'fnaSwrepFundTbl', 'CpfSearchDetail',
			'CpfContrbRateSearch', 'fnaLINomineesTbl', 'fnaInvestmentTbl',
			'cpfAccAddDedTable', 'liRetirementPlgtbl' ];

	$.each(dataTableIdsAll, function(index, value) {
		$("#" + value).dataTable().fnClearTable();
		$("#" + value).find("tfoot").css("display", "none");
		showInfoError(value);
	});

	var totalTabls = [ "fnaVehiOwnTblfooter", "fnaPropOwnTblfooter" ];

	$.each(totalTabls, function(index, value) {
		$("#" + value).css("display", "none");
	});

}

function fipaNewProfile() {

	fipaForm.action = "NewProfile.do";
	fipaForm.submit();

}

function fipaSave() {

	// if($("#btnSaveProfile").hasClass("disabled"))return false;

	var strCustId = $("#fipaForm input[name=fnaId]").val();
	var strLipId = $("#fipaForm input[name=lipId]").val();

	if (!validateDetails())
		return;

	$("#btnSaveProfile").css("display", "none");
	$("#btnDeleteProfile").css("display", "none");

	showLoader();

	enableComboWhenSubmit(fipaForm);

	// Based on review confirmation , whether need to insert or update!!
	if ($("#hTxtFldFnaReviewFlag").val() == "I") {

		strCustId = "";
		$("input[name=txtFldAppTypeIds]").val('');

	}

	if (isEmpty(strCustId)) { 
		fipaForm.action = "SaveProfile.do";
		fipaForm.submit();

	} else if (!isEmpty(strCustId)) { 
		fipaForm.action = "UpdateProfile.do";
		fipaForm.submit();

	}
	 

}

function fipaDelete() {
 
	showLoader();

	alert("work in progress...");

	/*
	 * if(window.confirm("Do you want to delete all client's details?")){
	 *  // var tbl = document.getElementById('deptParticularsTable'), // tblBody =
	 * tbl.tBodies[0], // len = tblBody.rows.length; // // for(var rl=0;rl<len;rl++){ //
	 * tblBody.rows[rl].cells[1].childNodes[0].value=GLBL_MODE_DELETE; // } //
	 * 
	 * 
	 * makeTblDeleteMode(['childParticularsTable',
	 * 'finGoalsTable','wealthAccmltTable',
	 * 'existPolicyLHIns','existPolicyUtlip', 'deptParticularsTable',
	 * 'cpfAccTpupTable','cpfAccDeductTable',
	 * 'fnaPropOwnTblByCPF','fnaPropOwnTbl','fnaVehiOwnTbl',
	 * 'fnaFlowDetTbl','fnadepntfinanceTbl','personalAssetTbl',
	 * 'businessAssetTbl','othareaofconTbl', 'fnahlthinsTbl','clntReasnsTable',
	 * 'fnaLIPlanTbl','fnaInvsetPlanTbl', 'fnaadvrecTbl','fnaartuplanTbl',
	 * 'fnaartufundTbl','fnaswrepplanTbl','cashOfBanksTable',
	 * 'fnaSwrepFundTbl','CpfSearchDetail','CpfContrbRateSearch',
	 * 'CpfAllocRateSearch','cpfADuctTable',
	 * 'fnaInputLifeInsuranceTbl','liTPDBeneftbl','liRetirementPlgtbl',
	 * 'liEducationPlgtbl','fnaLINomineesTbl']);
	 * 
	 * 
	 * enableComboWhenSubmit(fipaForm);
	 * 
	 * fipaForm.action = "DeleteProfile.do"; fipaForm.submit();
	 * 
	 * 
	 *  }
	 */

	hideLoader();
}

function validateDetails() {

	var fipaForm = document.forms[0];

	if (!(validateMandatoryOfTypesOfApplication(fipaForm)))
		return;

	if (!(validateMandatoryOfPersonalParticulars(fipaForm)))
		return;

	if ($("input:checkbox[name='txtFldAnalyisFor']:eq(1)").is(":checked")  &&  ($("#dfSelfMartsts").val() != "Single")  ) {

		$("#dfSelfMartsts").val('Married');
		$("#dfSelfMartsts").prop("disabled", true);
		if (!(validateMandatoryOfSpouseParticulars(fipaForm)))
			return;
	}

	if (!(validateMandatoryOfHealthInsuranceNeeds(fipaForm)))
		return;

	if (!(validateMandatoryOfAMLDeclaration(fipaForm)))
		return;
	if (!(validateMandatoryOfLifeInsurance()))
		return;
	if(!validateAttchDetails())return; 
	/*
	 * Need to re-visit. Based on condition it will validate.
	 * 
	 * if(!(validateMandatoryOfNewProductTopUps(fipaForm))) return;
	 * 
	 * if(!(validateMandatoryOfSwitchingRepl(fipaForm))) return;
	 * 
	 * if(!(validateMandatoryOfReasonsRecom(fipaForm))) return;
	 * 
	 * if(strMgrFlg == "Y"){
	 * if(!(validateMandatoryOfSuperviorDeclaration(fipaForm))) return; }
	 * 
	 * if(!(validateMandatoryOfDeclarationByClient(fipaForm))) return;
	 */
	
	/*table Validation entries*/
	if(!valarcTbl())return;  
	if(!valadctTbl())return; 
//	if(!valadRcPlnTbl())return; 
//	if(!valadRcFdTbl())return; 
//	if(!valswRplPlnTbl())return; 
//	if(!valswRplFdTbl())return; 
	if(!valperastTbl())return; 
	if(!valbusnastTbl())return; 
	if(!valCobTbl())return; 
	if(!valchildTbl())return; 
	if(!valdeptTbl())return;
	if(!valfinGlsTbl())return; 
	if(!valhlthGlsTbl())return; 
	if(!valpropTbl())return; 
	if(!valreasnTbl())return; 
	if(!valothretTbl())return;  
	if(!valincretTbl())return; 
	if(!valincassrtTbl())return; 
	if(!valwlthaccTbl())return; 
	if(!valvehTbl())return;
	/*table Validation entries*/
	return true;

}

function validateMandatoryOfLifeInsurance() {
	var lifeOwner = $("#lipOwner").val();

	if (!isEmpty(lifeOwner)) {

		
		if (!(validateFocusFlds('lifeInsdetstab', 'lipAssured', Li_ASS)))
			return;
		if (!(validateFocusFlds('lifeInsdetstab', 'lipCompany', Li_INS)))
			return;
		if (!(validateFocusFlds('lifeInsdetstab', 'lipPolicyno', Li_POL)))
			return;
		if (!(validateFocusFlds('lifeInsdetstab', 'policyStatus', Li_POLSTS)))
			return;
		if (!(validateFocusFlds('lifeInsdetstab', 'lipIncepdate', Li_DATE)))
			return;
		if (!(validateFocusFlds('lifeInsdetstab', 'lipSa', Li_SA)))
			return;
		if (!(validateFocusFlds('lifeInsdetstab', 'lipPlanname', Li_PLAN)))
			return;
		if (!(validateFocusFlds('lifeInsdetstab', 'lipCurrCashVal', Li_CASHVAL)))
			return;

	}
	return true;
}

/* Mandatory Fields Tooltip */
$(
		"#lipAssured,#lipCompany,#lipPolicyno,#policyStatus,#lipIncepdate,#lipSa,#lipPlan,#lipCurrCashVal")
		.on("change", function() {
			if (!isEmpty($(this).val())) {
				$(this).removeClass("mandatoryFillFlds");
				$(this).qtip('disable');
				$(this).qtip('destroy', true);
			}
		});

function validateMandatoryOfPersonalParticulars(fipaForm) {

	/*
	 * if(!$("input:checkbox[name=txtFldAnalyisFor]").is(":checked")){
	 * showAlert(TOAALYSFORSELF);
	 * $("input:checkbox[name=txtFldAnalyisFor]:eq(0)").focus(); return; }
	 */

	/*
	 * if(!(fipaForm.txtFldAnalyisFor.checked)){
	 * showAlert(TOAALYSFORSELF,txtFldAnalyisFor); return false; }
	 */

	if (!(validateMandatoryFlds(fipaForm.dfSelfName, SELF_NAME)))
		return;
	if (!(validateMandatoryFlds(fipaForm.advstfId, SELF_ADVSTF)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfDob, SELF_DOB)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfNationality, SELF_NATION)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfNric, SELF_NRIC)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfHomeaddr, SELF_HMEADDR)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfHomepostal, SELF_RPOSTAL)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfHomecntry, SELF_RCNTRY)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfMailaddr, SELF_MAILADDR)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfMailpostal, SELF_MPOSTAL)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSelfMailcntry, SELF_MCNTRY)))
		return;

	return true;
}
function validateMandatoryOfSpouseParticulars(fipaForm) {

	// if(fipaForm.dfSelfMartsts.value == 'Married'){
	// if(isEmpty(fipaForm.dfSpsName.value)){
	if (!(validateMandatoryFlds(fipaForm.dfSpsName, SPOUSE_NAME)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsDob, SPOUSE_DOB)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsNationality, SPOUSE_NATION)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsNric, SPOUSE_NRIC)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsHomeaddr, SPOUSE_HMEADDR)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsHomepostalcode, SPOUSE_RPOSTAL)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsHomecntry, SPOUSE_RCNTRY)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsMailaddr, SPOUSE_MAILADDR)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsMailpostal, SPOUSE_MPOSTAL)))
		return;
	if (!(validateMandatoryFlds(fipaForm.dfSpsMailcntry, SPOUSE_MCNTRY)))
		return;
	// }
	// }

	return true;

}
function validateMandatoryOfTypesOfApplication(fipaForm) {

	/*
	 * if(!(fipaForm.txtFldAnalyForSelf.checked ||
	 * fipaForm.txtFldAnalyForSpouse.checked ||
	 * fipaForm.txtFldAnalyForFamily.checked)){
	 * showAlert(TOAALYSFOR,txtFldAnalyForSelf); return false; }
	 */
	/*
	 * commented by thulasy 03.11.2017
	 * if(!(fipaForm.txtFldAnalyPurReport.checked ||
	 * fipaForm.txtFldAnalyPurAdvisory.checked)){
	 * showAlert(TOAPURPO,txtFldAnalyPurReport); return false; }
	 */

	/*
	 * commented by thulasy 03.11.2017 var totlifeniFlds =
	 * document.getElementsByName("chkAdvFullAnaLifeniPrdt").length; for(var
	 * i=0;i<totlifeniFlds;i++){
	 * if(!(document.getElementsByName("chkAdvFullAnaLifeniPrdt")[0].checked ||
	 * document.getElementsByName("chkAdvFullAnaLifeniPrdt")[1].checked)){
	 * showAlert(TOPLIFE,document.getElementsByName("chkAdvFullAnaLifeniPrdt")[0]);
	 * return false;
	 *  } }
	 * 
	 * var totnonlifeniFlds =
	 * document.getElementsByName("chkAdvFullAnaAhniPrdt").length; for(var i=0;i<totnonlifeniFlds;i++){
	 * if(!(document.getElementsByName("chkAdvFullAnaAhniPrdt")[0].checked ||
	 * document.getElementsByName("chkAdvFullAnaAhniPrdt")[1].checked)){
	 * showAlert(TOPHL,document.getElementsByName("chkAdvFullAnaAhniPrdt")[0]);
	 * return false;
	 *  } }
	 */

	var anyunchk = 0;
	$(".analysischkbox").each(function() {
		if ($(this).prop("checked")) {
			anyunchk++;
		}
	});

	if (anyunchk == 0) {
		showAlert(TOAALYSFORSELF, "");
		$("#divAnalysisFor").addClass("panel-danger").removeClass(
				"panel-default");
		return false;
	}

	var anyunchkType = 0;
	$(".analyTypeChkbox").each(function() {
		if ($(this).prop("checked")) {
			anyunchkType++;
		}
	});

	if (anyunchkType == 0) {
		showAlert(TOPAYSTYPES);
		$("#divAnalysisTypes").addClass("panel-danger").removeClass(
				"panel-default");
		return false;
	}

	/*
	 * if(!(document.getElementsByName("analysis")[0].checked ||
	 * document.getElementsByName("analysis")[1].checked ||
	 * document.getElementsByName("analysis")[2].checked ||
	 * document.getElementsByName("analysis")[3].checked ||
	 * document.getElementsByName("analysis")[4].checked ||
	 * document.getElementsByName("analysis")[5].checked ||
	 * document.getElementsByName("analysis")[6].checked ||
	 * document.getElementsByName("analysis")[7].checked||
	 * document.getElementsByName("analysis")[8].checked )){
	 * showAlert(TOPAYSTYPES); return false; }
	 */
	return true;
}

function validateMandatoryOfHealthInsuranceNeeds(fipaForm) {

	if (fipaForm.ppInspolicyflg.value == 'Y') {
		if (isEmpty($("#ppInspolicydets").val())) {
			showAlert(HEALTHINS_RMKS, ppInspolicydets);
			return false;
		}
	}
	return true;
}

function validateMandatoryOfAMLDeclaration(fipaForm) {

	if (fipaForm.amlIntprtExist.value == 'Y') {
		if (!(validateMandatoryFlds(fipaForm.amlIntprtName, INT_NAME)))
			return;
		if (!(validateMandatoryFlds(fipaForm.amlIntprtNric, INT_NRIC)))
			return;
		if (!(validateMandatoryFlds(fipaForm.amlIntprtMobile, INT_CONTACT)))
			return;
		// if(!(validateMandatoryFlds(fipaForm.amlIntprtHome, INT_HOMEADDR)))
		// return;
		if (!(validateMandatoryFlds(fipaForm.amlIntprtRelat, INT_REL)))
			return;
	}

	return true;
}

function validateMandatoryOfNewProductTopUps(fipaForm) {
	//	 
	// if(!(fipaForm.chkAdvrecFamIncProt.checked ||
	// fipaForm.chkAdvRecMedDisIncProt.checked
	// ||fipaForm.chkAdvRecSvForedn.checked
	// || fipaForm.chkAdvRecInvestment.checked
	// ||fipaForm.chkAdvRecRetirement.checked ||fipaForm.chkAdvRecOth.checked
	// )){
	// showAlert(CHECK_PRODUCT,chkAdvrecFamIncProt);
	// return false;
	// }
	return true;
}

function validateMandatoryOfSwitchingRepl(fipaForm) {

	if (!(fipaForm.srQ1Flg.checked)) {
		showAlert(SWTCH_QUEST1, srQ1Flg);
		return false;
	}

	if (fipaForm.srQ1Flg.checked) {

		document.getElementById('spanAdvRecomSwRepConf').style.display = "inline";
		document.getElementById('srQ1Dets').readOnly = false;

		if (isEmpty(fipaForm.srQ1Dets.value)) {
			showAlert(SWTCH_QUEST1REMK, srQ1Dets);
			return false;
		}

	}

	var totradSwRepAdvbyFlg = document.getElementsByName("srQ2Flg").length;
	for (var i = 0; i < totradSwRepAdvbyFlg; i++) {
		if (!(document.getElementsByName("srQ2Flg")[0].checked || document
				.getElementsByName("srQ2Flg")[1].checked)) {
			showAlert(SWTCH_QUEST2, document.getElementsByName("srQ2Flg")[0]);
			return false;
		}
	}

	var totradSwrepDisadvgFlg = document.getElementsByName("srQ3Flg").length;
	for (var i = 0; i < totradSwrepDisadvgFlg; i++) {
		if (!(document.getElementsByName("srQ3Flg")[0].checked || document
				.getElementsByName("srQ3Flg")[1].checked)) {
			showAlert(SWTCH_QUEST3, document.getElementsByName("srQ3Flg")[0]);
			return false;
		}
	}

	var totradSwrepProceedFlg = document.getElementsByName("srQ4Flg").length;
	for (var i = 0; i < totradSwrepProceedFlg; i++) {
		if (!(document.getElementsByName("srQ4Flg")[0].checked || document
				.getElementsByName("srQ4Flg")[1].checked)) {
			showAlert(SWTCH_QUEST4, document.getElementsByName("srQ4Flg")[0]);
			return false;
		}
	}
	return true;
}

function validateMandatoryOfReasonsRecom(fipaForm) {
	$("#clntReasnsTable tbody").find('tr.odd').each(function() {
		$(this).remove();
	});
	var index = $("#clntReasnsTable tbody").find("td").length;
	if (!(index > 0)) {
		showAlert(REASONS_RECOM);
		return false;
	}
	return true;
}

function validateMandatoryOfDeclarationByClient(fipaForm) {
	var totchkCdAgrFlg = document.getElementsByName("cdAgreeFlg").length;
	for (var i = 0; i < totchkCdAgrFlg; i++) {
		if (!(document.getElementsByName("cdAgreeFlg")[0].checked || document
				.getElementsByName("cdAgreeFlg")[1].checked)) {
			showAlert(DECLARATION, document.getElementsByName("cdAgreeFlg")[0]);
			return false;
		}
	}
	return true;

}

function validateMandatoryOfSuperviorDeclaration(fipaForm) {

	var totchkCdMgrAgrFlg = document.getElementsByName("mgrAgreeFlag").length;
	for (var i = 0; i < totchkCdMgrAgrFlg; i++) {
		if (!(document.getElementsByName("mgrAgreeFlag")[0].checked || document
				.getElementsByName("mgrAgreeFlag")[1].checked)) {
			showAlert(SUP_DECLARATION, document
					.getElementsByName("mgrAgreeFlag")[0]);
			return false;
		}
	}

	if (fipaForm.mgrAgreeFlag.value == 'DISAGREE') {
		if (isEmpty(fipaForm.mgrFollowupRemarks.value)) {
			showAlert(SUP_REASON, mgrFollowupRemarks);
			return false;
		}
	}

	return true;
}

function jsonDataPopulate(jsnData, tab) {


	for ( var cont in jsnData) {

		/*
		 * if(tab == "CPF_BALANCE_DETS"){
		 * $("input[name='"+cont+"']").val(jsnData[cont]); }
		 */

		if (jsnData.hasOwnProperty(cont)) {

			var contvalue = jsnData[cont];
			var elemObj = eval('fipaForm.' + cont);


			/*
			 * if(cont == "selFipaAdviserByAdvstfId"){ alert("sssssss")
			 * 
			 * var totAdvId =
			 * document.getElementsByName("txtFldAdviserName").length; var
			 * totAdvSign = document.getElementsByName("lblRepSign").length;
			 * 
			 * $("#advstfId").val(contvalue);
			 * setAdvMgrId(document.getElementById("advstfId"));
			 * 
			 * 
			 * for(var i=0;i<totAdvId;i++){ var selectedText =$("#advstfId
			 * option:selected").text();
			 * document.getElementsByName("txtFldAdviserName")[i].value=selectedText;
			 *  }
			 * 
			 * for(var i=0;i<totAdvSign;i++){ // var selectedText =
			 * $('#selAdvstfId:selected').text();; var selectedText
			 * =$("#advstfId option:selected").text();
			 * document.getElementsByName("lblRepSign")[i].value=selectedText;
			 *  } }
			 */

			if (elemObj) {

				elemObj.value = contvalue;

				if (elemObj.type == "checkbox") {
					if (contvalue == 'Y') {
						elemObj.checked = true;
						$(elemObj).prop("checked", true);
					}
				}

				if (elemObj.type == "radio") {
					if (contvalue == "Y" || elemObj.value == contvalue) {
						elemObj.checked = true;
						$(elemObj).prop("checked", true);
					}
				}

				if (elemObj.type == "select") {
					$("#" + cont).value = contvalue;
				}

				if (tab == "OPEN_CUST_DETS") {
					
					
					if (cont == "dfSelfRegmailaddrSame") {
						if (contvalue == 'Y') {
							$("#dfSelfRegmailaddrSame").prop("checked", false);
							if (!$("#dfSelfRegmailaddrSame").is(":checked")) {
								$("#dfSelfRegmailaddrSame").prop("checked",
										true);
								// $("#dfSelfRegmailaddrSame").click();
							}
						}
					}

					if (cont == "dfSpsRegmailaddrSame") {
						if (contvalue == 'Y') {
							$("#dfSpsRegmailaddrSame").prop("checked", false);
							if (!$("#dfSpsRegmailaddrSame").is(":checked")) {
								$("#dfSpsRegmailaddrSame")
										.prop("checked", true);
							}
						}
					}

					if (cont == "dfSpsMailaddrAsSelf") {
						if (contvalue == 'Y') {
							if (!$("#dfSpsMailaddrAsSelf").is(":checked")) {
								$("#dfSpsMailaddrAsSelf").prop("checked", true);
								// $("#dfSpsMailaddrAsSelf").click();
							}
						}
					}

					if ($("#dfSpsRegmailaddrSame").val() == 'Y') {

						$("#dfSpsHomecntry").prop("disabled", true);

					} else {

						if (($("input:checkbox[name=txtFldAnalyisFor]:eq(1)")
								.val() == 'Y')) {
							$("#dfSpsHomecntry").prop("disabled", false);
						} else {
							$("#dfSpsHomecntry").prop("disabled", true);
						}
					}

					if ($("#dfSpsMailaddrAsSelf").val() == 'Y') {
						$("#dfSpsMailaddrAsSelf").prop("checked", true);
					} else {
						$("#dfSpsMailaddrAsSelf").prop("checked", false);
					}

					if ($("#dfSelfRegmailaddrSame").val() == 'Y') {

						$('#dfSelfMailaddr').prop('readonly', false);
						$('#dfSelfMailaddr').removeClass("readOlyCursor");

						$('#dfSelfMailaddr2').prop('readonly', false);
						$('#dfSelfMailaddr2').removeClass("readOlyCursor");

						$('#dfSelfMailpostal').prop('readonly', false);
						$('#dfSelfMailpostal').removeClass("readOlyCursor");

						$('#dfSelfMailcntry').prop('disabled', false);
						$('#dfSelfMailcntry').removeClass("disabledCursor");

						$('#dfSelfAddrreason').prop('disabled', false);
						$('#dfSelfAddrreason').removeClass("disabledCursor");

					} else {

						$('#dfSelfMailaddr').prop('readonly', true);
						$('#dfSelfMailaddr').addClass("readOlyCursor");

						$('#dfSelfMailaddr2').prop('readonly', true);
						$('#dfSelfMailaddr2').addClass("readOlyCursor");

						$('#dfSelfMailpostal').prop('readonly', true);
						$('#dfSelfMailpostal').addClass("readOlyCursor");

						$('#dfSelfMailcntry').prop('disabled', true);
						$('#dfSelfMailcntry').addClass("disabledCursor");

						$('#dfSelfAddrreason').prop('disabled', true);
						$('#dfSelfAddrreason').addClass("disabledCursor");
					}

					if (cont == "dfSpsRegmailaddrSame") {
						if (contvalue == 'Y') {
							if ($("#dfSpsMailaddrAsSelf").is(":not(:checked)")
									&& $("#dfSpsRegmailaddrSame").is(
											":not(:checked)")) {
								$("#dfSpsMailaddrAsSelf").prop("checked", true)
										.val("Y");
							}

						}
					}

					if (cont == "dfSelfName") {

						var totSlfFlds = document
								.getElementsByName("txtFldClientName").length;
						for (var i = 0; i < totSlfFlds; i++) {
							document.getElementsByName("txtFldClientName")[i].value = contvalue;
						}

					}

					if (cont == "dfSelfNric") {
						var totNricFlds = document
								.getElementsByName("txtFldDfClientNric").length;
						for (var i = 0; i < totNricFlds; i++) {
							document.getElementsByName("txtFldDfClientNric")[i].value = contvalue;
						}
					}

					if (cont == "dfSpsName") {
						var totSpsFlds = document
								.getElementsByName("txtFldSpouseName").length;
						for (var i = 0; i < totSpsFlds; i++) {
							document.getElementsByName("txtFldSpouseName")[i].value = contvalue;
						}
					}
				 
					
					loadSlfSpsName();
					

				}

				if (tab == "ADVDCL_DETS") {
					
					

					if (cont == "appPurpose") {
						var resp = JSON.stringify(contvalue);
						$("#" + cont).val(resp);
						if (contvalue.FIN_PLN_RPT == "Y") {
							if (!$("input:checkbox[name=txtFldPurpose]:eq(0)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldPurpose]:eq(0)")
//										.click();
								$("input:checkbox[name=txtFldPurpose]:eq(0)").prop("checked", true);
							}
						} else {
							if ($("input:checkbox[name=txtFldPurpose]:eq(0)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldPurpose]:eq(0)")
//										.click();
								$("input:checkbox[name=txtFldPurpose]:eq(0)").prop("checked", false);
							}
						}

						if (contvalue.FIN_ADVSRY == "Y") {
							if (!$("input:checkbox[name=txtFldPurpose]:eq(1)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldPurpose]:eq(1)")
//										.click();
								$("input:checkbox[name=txtFldPurpose]:eq(1)").prop("checked", true);
							}
						} else {
							if ($("input:checkbox[name=txtFldPurpose]:eq(1)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldPurpose]:eq(1)")
//										.click();
								$("input:checkbox[name=txtFldPurpose]:eq(1)").prop("checked", false);
							}
						}
					}

					if (cont == "arNewRecomm") {

						var resp = JSON.stringify(contvalue);
						$("#" + cont).val(resp);
						if (contvalue.FAMINCPRO == "Y") {
							if (!$("input:checkbox[name=chkArNewRecom]:eq(0)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(0)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(0)").prop("checked", true);
							}
						} else {
							$("#" + cont).val("");
							if ($("input:checkbox[name=chkArNewRecom]:eq(0)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(1)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(0)").prop("checked", false);
							}
						}

						if (contvalue.MEDDISINC == "Y") {
							if (!$("input:checkbox[name=chkArNewRecom]:eq(1)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(1)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(1)").prop("checked", true);
							}
						} else {
							if ($("input:checkbox[name=chkArNewRecom]:eq(1)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(1)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(1)").prop("checked", false);
							}

						}

						if (contvalue.RECSVEDU == "Y") {
							if (!$("input:checkbox[name=chkArNewRecom]:eq(2)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(2)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(2)").prop("checked", true);
							}
						} else {
							if ($("input:checkbox[name=chkArNewRecom]:eq(2)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(2)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(2)").prop("checked", false);
							}

						}

						if (contvalue.RECINVST == "Y") {
							if (!$("input:checkbox[name=chkArNewRecom]:eq(3)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(3)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(3)").prop("checked", true);
							}
						} else {
							if ($("input:checkbox[name=chkArNewRecom]:eq(3)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(3)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(3)").prop("checked", false);
							}

						}

						if (contvalue.RECRETRMT == "Y") {
							if (!$("input:checkbox[name=chkArNewRecom]:eq(4)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(4)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(4)").prop("checked", true);
							}
						} else {
							if ($("input:checkbox[name=chkArNewRecom]:eq(4)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(4)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(4)").prop("checked", false);
							}

						}

						if (contvalue.RECOTHRS == "Y") {
							if (!$("input:checkbox[name=chkArNewRecom]:eq(5)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(5)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(5)").prop("checked", true);
							}
						} else {
							if ($("input:checkbox[name=chkArNewRecom]:eq(5)")
									.is(":checked")) {
//								$("input:checkbox[name=chkArNewRecom]:eq(5)")
//										.click();
								$("input:checkbox[name=chkArNewRecom]:eq(5)").prop("checked", false);
							}

						}
					}

					if (cont == "appClientChoice") {
						$("#appClientChoice").val(contvalue);
						var resp = JSON.stringify(contvalue);
						$("#" + cont).val(resp);
						if (contvalue.LS == "Y") {
							if (!$(
									"input:checkbox[name=txtFldClientChoice]:eq(0)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(0)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(0)")
										.prop("checked", true);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(0)")
										.val("Y");
							}
						} else {
							if ($(
									"input:checkbox[name=txtFldClientChoice]:eq(0)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(0)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(0)")
										.prop("checked", false);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(0)")
										.val("N");
							}
						}

						if (contvalue.LF == "Y") {
							if (!$(
									"input:checkbox[name=txtFldClientChoice]:eq(1)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(1)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(1)")
										.prop("checked", true);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(1)")
										.val("Y");
							}
						} else {
							if ($(
									"input:checkbox[name=txtFldClientChoice]:eq(1)")
									.is(":checked")) {
								// $("input:checkbox[name=txtFldClientChoice]:eq(1)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(1)")
										.prop("checked", false);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(1)")
										.val("N");
							}

						}

						if (contvalue.AS == "Y") {
							if (!$(
									"input:checkbox[name=txtFldClientChoice]:eq(2)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(2)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(2)")
										.prop("checked", true);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(2)")
										.val("Y");
							}
						} else {
							if ($(
									"input:checkbox[name=txtFldClientChoice]:eq(2)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(2)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(2)")
										.prop("checked", false);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(2)")
										.val("N");
							}

						}

						if (contvalue.AF == "Y") {
							if (!$(
									"input:checkbox[name=txtFldClientChoice]:eq(3)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(3)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(3)")
										.prop("checked", true);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(3)")
										.val("Y");
							}
						} else {
							if ($(
									"input:checkbox[name=txtFldClientChoice]:eq(3)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(3)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(3)")
										.prop("checked", false);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(3)")
										.val("N");
							}

						}
						
						
						
						if (contvalue.IS == "Y") {
							if (!$(
									"input:checkbox[name=txtFldClientChoice]:eq(5)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(3)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(5)")
										.prop("checked", true);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(5)")
										.val("Y");
							}
						} else {
							if ($(
									"input:checkbox[name=txtFldClientChoice]:eq(5)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(3)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(5)")
										.prop("checked", false);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(5)")
										.val("N");
							}

						}

						
						if (contvalue.IF == "Y") {
							if (!$(
									"input:checkbox[name=txtFldClientChoice]:eq(6)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(3)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(6)")
										.prop("checked", true);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(6)")
										.val("Y");
							}
						} else {
							if ($(
									"input:checkbox[name=txtFldClientChoice]:eq(6)")
									.is(":checked")) {
								// {$("input:checkbox[name=txtFldClientChoice]:eq(3)").click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(6)")
										.prop("checked", false);
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(6)")
										.val("N");
							}

						}
					}

					if (cont == "mgrAgreeFlag") {
						if (contvalue == "Y") {
							$("#mgrFollowupRemarks").prop("readonly", false);
							$('#mgrFollowupRemarks').removeClass(
									"readOlyCursor");
							$("#mgrFollowupRemarks").focus();
						} else {
							$("#mgrFollowupRemarks").prop("readonly", true);
							$('#mgrFollowupRemarks').addClass("readOlyCursor");
						}
					}

					if (cont == "mgrAgreeFlag") {
						if (contvalue == 'DISAGREE') {
							$("#mgrFollowupRemarks").prop('readonly', false);
							$("#mgrFollowupRemarks").focus();
						}
						if (contvalue == 'AGREE') {
							$("#mgrFollowupRemarks").prop('readonly', true);
						}
					}

					if (cont == "mgrAgreeFlag") {

						if (contvalue == 'DISAGREE') {
							$("#mgrFollowupRemarks").prop('readonly', false);
							$('#mgrFollowupRemarks').removeClass(
									"readOlyCursor");
						}
					}

					if (cont == "cdAgreeFlg") {
						if (contvalue == "Y") {
							$("#cdCcRemarks").prop("readonly", false);
							$('#cdCcRemarks').removeClass("readOlyCursor");
							$("#cdCcRemarks").focus();
						} else {
							$("#cdCcRemarks").prop("readonly", true);
							$('#cdCcRemarks').addClass("readOlyCursor");
						}
					}

					if (cont == "appAnalysisFor") {
						var resp = JSON.stringify(contvalue);
						$("#" + cont).val(resp);
						if (contvalue.ANALYS_SLF == "Y") {
							$("input:checkbox[name=txtFldAnalyisFor]:eq(0)")
							.click();
							
							$(".clsfipaClient").prop("disabled", false);
							$('#dobSlfpicker').datetimepicker(dobOptions);
							if (!$(
									"input:checkbox[name=txtFldAnalyisFor]:eq(0)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldAnalyisFor]:eq(0)")
//										.click();
								$("input:checkbox[name=txtFldAnalyisFor]:eq(0)").prop("checked", true);
							}
						} else {

							if ($("input:checkbox[name=txtFldAnalyisFor]:eq(0)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldAnalyisFor]:eq(0)")
//										.click();
								$("input:checkbox[name=txtFldAnalyisFor]:eq(0)").prop("checked", false);
							}
							$(".clsfipaClient").prop("disabled", true);
							$('#dobSlfpicker').datetimepicker('remove');
							$("#dfSelfRegmailaddrSame").attr("disabled", true);
						}

						if (contvalue.ANALYS_SPS == "Y") {
							$("input:checkbox[name=txtFldAnalyisFor]:eq(1)").prop("checked",true);
							if(!($("#dfSelfMartsts").val() == "Single")){
							$(".clsfipaSpouse").prop("disabled", false);
							$('#dobSpspicker').datetimepicker(dobOptions);
							$("#dfSpsRegmailaddrSame").attr("disabled", false);
							$("#dfSpsRegmailaddrSame").attr("disabled", false);
							$("#dfSpsMailaddrAsSelf").attr("disabled", false);
							if (!$(
									"input:checkbox[name=txtFldAnalyisFor]:eq(1)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldAnalyisFor]:eq(1)")
//										.click();
								$("input:checkbox[name=txtFldAnalyisFor]:eq(1)").prop("checked", true);
								
							}
						
							} 
							clientMartSts($("#dfSelfMartsts").val(),false);
						} else {

							if ($("input:checkbox[name=txtFldAnalyisFor]:eq(1)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldAnalyisFor]:eq(1)")
//										.click();
								$("input:checkbox[name=txtFldAnalyisFor]:eq(1)").prop("checked", false);
							}
							if(!($("#dfSelfMartsts").val() == "Married")){
		  			    		chkOwnership('Spouse',true);
		  			    	}
							
							$(".clsfipaSpouse").prop("disabled", true);
							$('#dobSpspicker').datetimepicker('remove');
							$("#dfSpsRegmailaddrSame").attr("disabled", true);
							$("#dfSpsRegmailaddrSame").attr("disabled", true);
							$("#dfSpsMailaddrAsSelf").attr("disabled", true);
						}

						if (contvalue.ANALYS_FAM == "Y") {
							$(".clsfipaFamily").prop("disabled", false);
							if (!$(
									"input:checkbox[name=txtFldAnalyisFor]:eq(2)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldAnalyisFor]:eq(2)")
//										.click();
								$("input:checkbox[name=txtFldAnalyisFor]:eq(2)").prop("checked", true);
							}
						} else {

							if ($("input:checkbox[name=txtFldAnalyisFor]:eq(2)")
									.is(":checked")) {
//								$("input:checkbox[name=txtFldAnalyisFor]:eq(2)")
//										.click();
								$("input:checkbox[name=txtFldAnalyisFor]:eq(2)").prop("checked", false);
							}
							
		  			    		chkOwnership('Family',false);
		  			    	
							
							$(".clsfipaFamily").prop("disabled", true);
							
							
						}
						$("input:checkbox[name=txtFldAnalyisFor]:eq(0)").prop("disabled", true);
					}

					if (cont == "srQ1Flg") {
						if (contvalue == "Y") {
							$("#spanAdvRecomSwRepConf")
									.css("display", "inline");
							$("#srQ1Dets").prop("readonly", false);
						} else {
							$("#spanAdvRecomSwRepConf").css("display", "none");
							$("#srQ1Dets").prop("readonly", true);
							$("#srQ1Dets").val("");
						}
					}

					if (cont == "amlIntprtBenfflg") {
						if (contvalue == 'Y') {
							$("#beneficialOwnerDiv :input").prop('disabled',
									false);
						} else if (contvalue == 'N' || contvalue == '') {
							$("#beneficialOwnerDiv :input").prop('disabled',
									true);
						}
					}

					if (cont == "advDecCrtdDate") {
						if (!(isEmpty(contvalue))) {
							$("input[name='updlstdateChldDecl']").val(
									"Last updated on " + contvalue + "");
							$("input[name='updlstdateChldDecl']").css(
									"display", "");
						}
					}

					if (cont == "advDecModDate") {
						if (!(isEmpty(contvalue))) {
							$("input[name='updlstdateChldDecl']").val(
									"Last updated on " + contvalue + "");
							$("input[name='updlstdateChldDecl']").css(
									"display", "");
						}
					}

					if (cont == "amlLanguageUse") {
						var arrselamlLanguageUse = contvalue.split(',');
						$('#selamlLanguageUse').multiselect('select',
								arrselamlLanguageUse);
					}

					if (cont == "amlIntprtTppflg") {
						if (contvalue == 'Y') {
							$("#ThirdPartyPayerDiv :input").prop('disabled',
									false);
						} else if (contvalue == 'N' || contvalue == '') {
							$("#ThirdPartyPayerDiv :input").prop('disabled',
									true);
						}

					}

					if (cont == "amlIntprtPepflg") {
						if (contvalue == 'Y') {
							$("#PolExpPersDiv :input").prop('disabled', false);
						} else if (contvalue == 'N' || contvalue == '') {
							$("#PolExpPersDiv :input").prop('disabled', true);
						}
					}

					if (cont == "appReplacePrdt") {
						var resp = JSON.stringify(contvalue);
						$("#" + cont).val(resp);
						if (contvalue.LS == "Y" || contvalue.LF == "Y") {
							$("#lifeInsurancePlanDets").css('display', 'block');
							$("#SwrepLifeInsPlanDets").css('display', 'block');

						} else if (contvalue.AS == "Y" || contvalue.AF == "Y") {
							$("#UtIlpFundDets").css('display', 'block');
							$("#SwrepUtIlpFundDets").css('display', 'block');
						}

					}

					if (cont == "amlIntprtExist") {

						if (contvalue == 'Y') {
							InterpreterKeyin();
						} else if (contvalue == 'N' || contvalue == '') {
							InterpreterKeyout();
						}

					}

				}
				
				if(tab == "RETP_DETS"){
					
					retirement_cashflow(cont, contvalue);
				}

				populateElmObjValues(cont, contvalue);
				

			}
		}
	}
}

function populateElmObjValues(cont, contvalue) {

	analysisCheckEvent(this, 'All'); // No need of this method call-Need to select selectAll checked when all values are  checked
//	retirement_cashflow(cont, contvalue);

	// $("select#mgrId").prop("disabled",true);
	// $("select#advstfId").prop("disabled",true);

	if (!(stafftype == 'STAFF')) {
	}

//	loadSlfSpsName();

	if (cont == "txtFldChldName") {
		addChildNameDyn($("#txtFldChldName").val());
	}

	 
	 //Cpf Contribution - Fetch From Master
	if(isEmpty($("input[name=ccEmpleContrb]:eq(0)").val()  ||  $("input[name=ccEmplrContrb]:eq(0)").val() )){
		calSelfCpfMastMthContr();
	} 
	if(isEmpty($("input[name=ccEmpleContrb]:eq(1)").val()  || $("input[name=ccEmplrContrb]:eq(1)").val())){
		calSpsCpfMastMthContr();
	} 
	

	// if(cont == "dfSpsRegmailaddrSame"){
	// if(contvalue == 'Y'){
	// $("#dfSpsMailaddrAsSelf").prop("checked",false);
	// $("#dfSpsMailaddrAsSelf").val("N");
	// $("#dfSpsRegmailaddrSame").click();
	// }else if(contvalue == 'N' || contvalue == ''){
	// $("#dfSpsRegmailaddrSame").click();
	// $("#dfSpsRegmailaddrSame").click();
	//			 
	// }
	// }

}

function jsonTableDataPopulate(jsnData, tab, changetoIModeFlag) {

	for ( var cont in jsnData) {

		var contvalue = jsnData[cont];

		if (tab == "DEPENDANT_DETS") {
			getdeptRows(contvalue);

		}

		if (tab == "CHILD_DETS") {

			getChildRows(contvalue);

		}

		if (tab == "FINGOALS_DETS") {

			getFinGoalsRows(contvalue);

		}

		if (tab == "SAVINV_DETS") {

			getwlthaccRows(contvalue);

		}

//		if (tab == "CPFMTHCTRB_DETS") {
//
//			if (contvalue != null) {
//				for ( var data in contvalue) {
//					$("input[name='" + data + "']").eq(cont).val(
//							contvalue[data]);
//				}
//			}
//
//		}

		if (tab == "CPFTP_DETS") {

			getCpfTpupRows(contvalue);

		}

		if (tab == "CPFDT_DETS") {

			getCpfDedtRows(contvalue);

		}

		if (tab == "FUNDFLW_DETS") {

			getFundFlwRows(contvalue);
		}
		if (tab == "CONTGDEPN_DETS") {

			getContgDepnRows(contvalue);
		}

		// if(tab == "PROPOWN_DETS"){
		// getPropOwnRows(contvalue);
		// }

		if (tab == "RDOTHER_PAY") {

			getothretRows(contvalue); 
		}

		if (tab == "RDINCOME_DETS") {

			getincretRows(contvalue); 
		}

		if (tab == "RDINCASS_DETS") {

			getincassrtRows(contvalue); 
		}

		if (tab == "CPF_ADD_DED_DETS") {

			getCADRows(contvalue);
		}

		if (tab == "BUSASSET_DETS") {

			getBuisAsstRows(contvalue);
		}

		if (tab == "PERASSET_DETS") {

			getPerAssetRows(contvalue);
		}

		if (tab == "FGACCHLT_DETS") {

			getproAHRows(contvalue);
		}

		if (tab == "FGFAMAST_DETS") {

			getproFARows(contvalue);
		}
		if (tab == "FGSAVINV_DETS") {

			getproSIRows(contvalue);
		}
		if (tab == "FGCHDEDU_DETS") {

			getproCERows(contvalue);
		}

		if (tab == "OTHAREA_DETS") {

			getAreaConRows(contvalue);
		}

		if (tab == "RCMRSN") {

			getReasonsRows(contvalue);
		}

		if (tab == "PROPOWNCPF_DETS") {

			getPropOwnCpfRows(contvalue);
		}

		if (tab == "VEHOWN_DETS") {

			getVehOwnRows(contvalue);
		}

		if (tab == "ATTACHMENT_DETS") { 
			getAttchRows(contvalue);
		}

		
		if (tab == "RCMPRO_DETS") {

			getRcmPlnRows(contvalue);
		}

		// if(tab == "RCMPLAN_DETS"){
		// getRcmPlnRows(contvalue);
		// }

		if (tab == "RCMFUND_DETS") {
			getFdPlnRows(contvalue);
		}

		if (tab == "SWTHPLAN_DETS") {
			getSwrepPlanRows(contvalue);
		}

		if (tab == "SWTHFUND_DETS") {
			getSwrepFundRows(contvalue);
		}

		if (tab == "CASHATBANKS_DETS") {
			getCobRows(contvalue);

		}

		if (tab == "HEALTHINS_DETS") {
			getHealthInscRows(contvalue);
		}
		if (tab == "CLIENT_DEATHBENF_SRCH") {
			getliDthBenfRows(contvalue);
		}
		if (tab == "CLIENT_CRITICAL_SRCH") {
			getlicrtlnsRows(contvalue);
		}
		if (tab == "CLIENT_HOSP_SRCH") {
			getlihospRows(contvalue);
		}
		if (tab == "CLIENT_PLANPRO_SRCH" || tab == "FPMS_POLICYPLAN_DETS") {
			getliPlndetRows(contvalue, tab);
		}

		if (tab == "CLIENT_BENEFDATA_SRCH") {
			getDsbltyRows(contvalue);
		}
		if (tab == "CLIENT_CHLDEDUDATA_SRCH") {
			getlieduplgRows(contvalue);
		}

		if (tab == "CLIENT_MVDATA_SRCH") {
			getRetPlgRows(contvalue);
		}
		//			
		if (tab == "CLIENT_NOMDATA_SRCH") {
			getNomNameRows(contvalue);
		}

		if (tab == "INPUTINVESTMENT_DETS") {
			getInptInvstRows(contvalue);

		}

	}
}

function populateProfileDetails(selobj, custId) {

	showLoader();
	clearAllDetails('clear');
	removeTblRows('ProfileSearchTable');

	var fnaId = "";
	var clientName = "";
	var clientNRIC = "";
	var custId = "";

	if ($(selobj)) {
		fnaId = $(selobj).closest("tr").find("td").eq(2).find("input").eq(1)
				.val();
		clientName = $(selobj).closest("tr").find("td").eq(2).find("div").eq(0).text();
		clientNRIC = $(selobj).closest("tr").find("td").eq(3).find("input").eq(
				0).val();
		custId = $(selobj).closest("tr").find("td").eq(3).find("input").eq(2)
				.val();

	} else {
		fnaId = selobj.parentNode.parentNode.childNodes[2].childNodes[1].value;
		clientName = selobj.parentNode.parentNode.childNodes[2].childNodes[0].innerHTML;
		clientNRIC = selobj.parentNode.parentNode.childNodes[3].childNodes[0].value;
		custId = selobj.parentNode.parentNode.childNodes[3].childNodes[2].value;
	}

	var parameter;

	if (FIPAFnaId != null && FIPAFnaId != '' && FIPAFnaId != 'null') {

		var clientlist = [];
		clientlist = makeArrSplit(FIPAFnaId, ',');

		parameter = "DBCALLFOR=OPEN_CLIENT_PROFILELIST&strCustId=&strClientName="
				+ clientlist[1].trim()
				+ "&strClientNRIC="
				+ clientlist[2].trim() + "&strFNAId=" + clientlist[0].trim();
	} else {
		parameter = "DBCALLFOR=OPEN_CLIENT_PROFILELIST&strCustId=" + custId
				+ "&strClientName=" + clientName + "&strClientNRIC="
				+ clientNRIC + "&strFNAId=" + fnaId;
	}

	/*
	 * if(!( custId== null )){
	 * 
	 * }else{
	 * 
	 *  }
	 */

	ajaxCall(
			parameter,
			servletName,
			function(Data) {

				hideLoader();
				var retval = Data;

				for ( var val in retval) {

					var tabdets = retval[val];

					if (tabdets["SESSION_EXPIRY"]) {
						window.location = BASE_URL + SESSION_EXP_JSP;
						return;
					}
					if (tabdets["DB_ERROR"]) {
						window.location = BASE_URL + DB_EXP_JSP;
						return;
					}

					for ( var tab in tabdets) {

						if (tabdets.hasOwnProperty(tab)) {
							var key = tab;
							var value = tabdets[tab];

							if (key == "NO_CLIENT_PROFILE_LIST") {
								clearAllWhnNoProfileCrtdFipa();

								$(".analysischkbox").each(
										function() {
											$(this).prop("checked", true);
											chkedJSONCollection($(this),
													'appAnalysisFor');
											var cssclass = $(this).attr(
													"data-class");
											$("." + cssclass).prop("disabled",
													false);
										});

								$(
										"input:checkbox[name=txtFldClientChoice]:eq(1)")
										.click();
								$(
										"input:checkbox[name=txtFldClientChoice]:eq(3)")
										.click();

								$('#dobSlfpicker').datetimepicker(dobOptions);
								$('#dobSpspicker').datetimepicker(dobOptions);

								getClientDetailsFromFPMS(clientName,clientNRIC, custId);

							}
							if (key == "CLIENT_PROFILE_LIST") {

								profileTbl.clear().draw();

								var jsnData = value;

								for ( var cont in jsnData) {
									if (jsnData.hasOwnProperty(cont)) {

										var contvalue = jsnData[cont];

										var cell0 = '<input type="text"  readOnly="true" class="sinoFieldDHTML ptrcursor" style="width:35px;"/>';

//										var cell1 = '<input type="radio" name="radSrchSelectedId" id="radSrchSelectedId" onclick="chkLatestProfDets(this,'+ (Number(cont) + 1) + ')"/>';
										
										var cell1 = '<div class="radio radio-primary text-center"><input type="radio" name="radSrchSelectedId" onclick="chkLatestProfDets(this,'+ (Number(cont) + 1) + ')"/><label>&nbsp;</label></div>';
										
										var cell2 = '<input type="text" readOnly="true" class="dhtmlTableText ptrcursor"  style="text-align:left;"/>'
												+ '<input type="hidden"/><input type="hidden"/><input type="hidden"/>';

										var listval = contvalue["strFnaAnalysisList"];
										var texttoshow = "";
										var arr = listval.split("<li>");
										var cnt = (listval.match(/<li>/g) || []).length;
										for ( var l in arr) {
											texttoshow = arr[l];
										}

										if (cnt > 1) {
											texttoshow = "<div style='display:inline'> ..."
													+ texttoshow
													+ "<img data-image='Show' align='right' onmouseover='profileTooltip(this);' src='images/menuicons/icoDown.png'  ><div>";

										} else {
											texttoshow = contvalue["strFnaAnalysisList"];
										}

										var cell3 = "<div data-image='Show'><span data-originaltext='"
												+ contvalue["strFnaAnalysisList"]
												+ "'><ol>"
												+ texttoshow
												+ "</ol></span></div>";

										var cell4 = contvalue["strFnaType"];
										var cell5 = contvalue["strFnaApplicants"];
										var cell6 = contvalue["strFnaAnaReplace"];
										var cell7 = "";
										if (contvalue["strFnaProfRemarks"] == "Y") { 
											cell7 = '<img src="images/menuicons/blue-f.png" width="20px" style="margin-right: -10px" />&nbsp;<img src="images/menuicons/green-f.png" width="20px" />';
										} else {
											cell7 = '<img src="images/menuicons/blue-f.png" width="20px" style="margin-right: -10px" />';
										}

										var cell8 = "-";
										var cell9 = "-";
										profileTbl.row.add(
												[ cell0, cell1, cell2, cell3,
														cell4, cell5, cell7,
														cell8, cell9 ]).draw(
												false);

										var rowCount = $('#ProfileSearchTable tbody tr').length;
										var $lastRow = $("#ProfileSearchTable tbody tr:last");

										$lastRow.find("td:eq(0)").find(
												'input:eq(0)').val(rowCount);

										$lastRow.find("td:eq(1)").find("input:first").attr('id',"radSrch"+$lastRow.index())
										.parent().find('label').attr('for',"radSrch"+$lastRow.index());
										
										
										$lastRow.find("td:eq(2)").find(
												'input:eq(0)').val(
												contvalue["strFnaCrtdDate"]);
										$lastRow.find("td:eq(2)").find(
												'input:eq(1)').val(
												contvalue["strFnaId"]);
										$lastRow.find("td:eq(2)").find(
												'input:eq(2)').val(
												contvalue["strFnaCustId"]);
										$lastRow.find("td:eq(2)").find(
												'input:eq(3)').val(
												contvalue["strFnaType"]);

										$("input[name='txtFldClientName']")
												.val(
														contvalue["strFnaCustName"]);
										$("input[name='txtFldClientNric']")
												.val(
														contvalue["strFnaCustNRIC"]);

									}

								}

								var def = $("#hTxtMenuName").val();

								// if(FIPAMenu == "" ){
								if (def == "Profile Search" || def == "Default") {
									$(".menu_section>ul.hidden").removeClass(
											"hidden");
									openDivForClient('profilepage',
											'profilesection', 'profile_li',
											'Profile Summary');
								}
								// }

								if ((custId == null)) {
									$("#ProfileSearchTable tr:eq(1)").find(
											"td:eq(1)").find(
											"input[type='radio']").click();
								}

							}
						}
					}
				}

				profileTbl.draw();
			});

}

function chkLatestProfDets(selobj, chklatestid) {

	clearAllDetails('clear');

	if (chklatestid == 1) {
		dataTableFlg=false;
		populateSearchDetails(selobj, chklatestid);

		if (!(stafftype == STAFFTYPE_STAFF)) {

			$("#fipaForm :input").attr("readonly", false);
			$("#fipaForm :input").attr("disabled", false); 
			
			$(".readOlyCursor").attr("readonly", true);
			$(".disabledCursor").attr("disabled", true);

			callDatePickers(chklatestid);

			$('#dfSelfAddrreason').prop('disabled', true);
			$('#dfSpsAddrreason').prop('disabled', true);
			$(".txtlastupdated").attr("readonly", true);
			$(".funcToDisable").css("display", "block");

		} else {

			$("#allpages").find("div").find("input").attr("disabled", true);
			$("#allpages").find("div").find("select").attr("disabled", true);

			// $(".readOlyCursor").attr("readonly", true);
			// $(".disabledCursor").attr("disabled", true);

			$("#searchpage").find("div").find("input").prop("disabled", false);
			$("#profilepage").find("div").find("input").prop("disabled", false);
			$('.accordHeaderDiv').css("display", "none");

		}
	} else if (chklatestid > 1) {
		populateSearchDetails(selobj, chklatestid);
		dataTableFlg=true;
		$("#fipaForm :input").attr("readonly", true);
		$("#fipaForm :input").attr("disabled", true);
		
		
		$(".readOlyCursor").attr("readonly", true);
		$(".disabledCursor").attr("disabled", true);

		if (!(stafftype == STAFFTYPE_STAFF)) {
			callDatePickers(chklatestid);
		}

		$(".funcToDisable").css("display", "none");

		$('.footdiv').css("display", "none");
	

	}

}

function populateSearchDetails(selobj, chklatestid) {

	var strFNAId = "", strCustId = "", strFnaType = "";
	var dateCreated = "";
	var strClientNRIC = $("input[name='txtFldClientNric']").val();
	if ($(selobj)) {
		dateCreated = $(selobj).closest("tr").find("td").eq(2).find("input")
				.eq(0).val();
		strFNAId = $(selobj).closest("tr").find("td").eq(2).find("input").eq(1)
				.val();
		strCustId = $(selobj).closest("tr").find("td").eq(2).find("input")
				.eq(2).val();
		strFnaType = $(selobj).closest("tr").find("td").eq(2).find("input").eq(
				3).val();
	} else {
		dateCreated = selobj.parentNode.parentNode.childNodes[2].childNodes[0].value;
		strFNAId = selobj.parentNode.parentNode.childNodes[2].childNodes[1].value;
		strCustId = selobj.parentNode.parentNode.childNodes[2].childNodes[2].value;
		strFnaType = selobj.parentNode.parentNode.childNodes[2].childNodes[3].value;
	}

	var tblIds = [ 'childParticularsTable', 'OthRetPlgtbl', 'IncRetPlgtbl',
			'IncAssRetPlgtbl', 'deptParticularsTable', 'RDExptbl', 'RDInctbl',
			'RDIncAsstbl', 'finGoalsTable', 'wealthAccmltTable',
			'existPolicyLHIns', 'existPolicyUtlip', 'cpfMontlyContbTable',
			'cpfAccDeductTable', 'fnaPropOwnTblByCPF', 'fnaVehiOwnTbl',
			'personalAssetTbl', 'businessAssetTbl', 'othareaofconTbl',
			'fnaAttachments', 'fnaartuplanTbl', 'fnaartufundTbl',
			'fnaswrepplanTbl', 'fnaSwrepFundTbl', 'clntReasnsTable',
			'fnaLINomineesTbl', 'liRetirementPlgtbl', 'cashOfBanksTable' ];

	for ( var tbl in tblIds) {
		removeTblRows(tblIds[tbl]);
	}

	utlipPolicyTbl.clear().draw();
	existPolicyLHIns.clear().draw();

	if (chklatestid == 1) {

		$("#hTxtFldFnaReviewFlag").val("I");

		$("#spanReviewConfirm").html("");

		$("input[name='fnaType'][value='SIMPLIFIED']").attr("disabled", true);
		$("input[name='fnaType'][value='FULLFACT']").attr("checked", true);

		$("#profileDialog #radAppDataReview").attr("disabled", true);

		if (!profileValidateDets())
			return;

		showLoader();
		loadCustFNADetails(strFNAId, strCustId, strClientNRIC, advstfId,strFnaType);

		$(".fipaMode").val("I");
		if (!(stafftype == STAFFTYPE_STAFF)) {
		$("#btnSaveProfile").removeClass("hidden");
		}else{
			$("#btnSaveProfile").addClass("hidden");
		}

	} else if (chklatestid > 1) {

		$("#CantCreateNewProfDialog").dialog(
				{
					create : function(event, ui) {
						var dialog = $(this).closest(".ui-dialog");
						dialog.find(".ui-dialog-titlebar").remove();
					},
					resizable : false,
					height : "auto",
					width : "auto",
					modal : true,
					buttons : {
						" OK " : function() {
							showLoader();
							loadCustFNADetails(strFNAId, strCustId,
									strClientNRIC, advstfId, strFnaType); 
							$(this).dialog("close");
						},
						" Cancel " : function() {
							$("#fipaForm #profilepage :input").prop("disabled",
									false); 
							$(this).dialog("close");
						}
					}
				});// end dialog

		/*
		 * $("#btnDeleteProfile").prop("disabled",true);
		 * $("#btnSaveProfile").prop("disabled",true);
		 * $("#btnNewProfile").prop("disabled",true);
		 */

		$("#btnSaveProfile").addClass("hidden");
		
		// $("#btnDeleteProfile").addClass("hidden");

	}
	
	

	
	
	
	
}

function loadCustFNADetails(strFNAId, strCustId, strClientNRIC, advstfId,
		strFnaType) {

	

	
	
	var parameter = "DBCALLFOR=OPEN_CLIENT_PROFILE&strFNAId=" + strFNAId
			+ "&strCustId=" + strCustId + "&strClientNRIC=" + strClientNRIC
			+ "&strAdvId=" + advstfId;

	ajaxCall(
			parameter,
			servletName,
			function(Data) {

				var retval = Data;

				for ( var val in retval) {
					

					var tabdets = retval[val];
					
				

					if (tabdets["SESSION_EXPIRY"]) {
						window.location = BASE_URL + SESSION_EXP_JSP;
						return;
					}
					if (tabdets["DB_ERROR"]) {
						window.location = BASE_URL + DB_EXP_JSP;
						return;
					}

					for ( var tab in tabdets) {

						if (tabdets.hasOwnProperty(tab)) {

							var key = tab;
							var value = tabdets[tab];

							// alert(key)

							if (key == "OPEN_CUST_DETS") {
								jsonDataPopulate(value, tab);

							}

							if (key == "APPTYPES_DETS") {

								var jsnData = value;
								$("input[type=checkbox][name='analysis']")
										.prop("checked", false);
								var cnt = 0;
								for ( var cont in jsnData) {
									if (jsnData.hasOwnProperty(cont)) {

										var contvalue = jsnData[cont];

										for ( var data in contvalue) {

											var col = contvalue[data];

											if (data == "appTypeid") {
												$("input[name='txtFldAppTypeIds']").each(function(i) {
													if (cnt == i) {
														document.getElementsByName("txtFldAppTypeIds")[cnt].value = col;
													}
												});
											}

											if (data == "masterAnalysisTypes") {
												$("input[type=checkbox][value='"+ col + "']").prop("checked", true);
												$("#analysisTypesdiv").find("input[type='checkbox']:checked").attr("checked", false);
											}

											$("#typesofappsec input[name='txtFldClientChoice'][data-attr='LS']").attr("disabled", true);
											$("#typesofappsec input[name='txtFldClientChoice'][data-attr='AS']").attr("disabled", true);
											$("#typesofappsec input[name='txtFldClientChoice'][data-attr='IS']").attr("disabled", true);

										}
									}
									cnt++;
								}
								$("#analysisTypesdiv").find("input[type='checkbox']:checked").attr("checked", false);
							}

							if (key == "ADVDCL_DETS") {
								jsonDataPopulate(value, tab);

								if (strFnaType == "FULLFACT") {
									if (!$("#typesofappsec input[name='txtFldClientChoice'][data-attr='LF']").is(":checked")) {
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='LF']").prop("checked", true);
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='LF']").val("Y");
									}

									if (!$("#typesofappsec input[name='txtFldClientChoice'][data-attr='AF']").is(":checked")) {
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='AF']").prop("checked", true);
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='AF']").val("Y");
									}

									if (!$("#typesofappsec input[name='txtFldClientChoice'][data-attr='IF']").is(":checked")) {
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='IF']").prop("checked", true);
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='IF']").val("Y");
									}

								} else if (strFnaType == "SIMPLIFIED") {
									if (!$("#typesofappsec input[name='txtFldClientChoice'][data-attr='LS']").is(":checked")) {
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='LS']").prop("checked", true);
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='LS']").val("Y");
									}

									if (!$("#typesofappsec input[name='txtFldClientChoice'][data-attr='AS']").is(":checked")) {
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='AS']").prop("checked", true);
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='AS']").val("Y");
									}
									
									if (!$("#typesofappsec input[name='txtFldClientChoice'][data-attr='IS']").is(":checked")) {
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='IS']").prop("checked", true);
										$("#typesofappsec input[name='txtFldClientChoice'][data-attr='IS']").val("Y");
									}

								}
							}


							if (key == "CHILD_DETS") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getChildRows(contvalue);
								});

							}

							if (key == "FINGOALS_DETS") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getFinGoalsRows(contvalue);
								});
							}

							if (tab == "SAVINV_DETS") {
								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getwlthaccRows(contvalue);
								});

							}

							if (key == "DEPENDANT_DETS") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getdeptRows(contvalue);
								});
							}
							
							
							if (key == "ATTACHMENT_DETS") {  
								$.each(value, function(contkey, contvalue) {
									getAttchRows(contvalue);
								});
							}
 
							
							if (key == "SOI_DETS") {
								jsonDataPopulate(value, tab);

							}

							if (key == "EXPD_DETS") {
								jsonDataPopulate(value, tab);
								// calcSum(null,
								// Ann_Exp.SUMOF_ANNEXP_SELF);//need to check
								// strval is undefined error
								// calcSum(null, Ann_Exp.SUMOF_ANNEXP_SPS);
								// calcSum(null, Ann_Exp.SUMOF_ANNEXP_FAM);
							}

							if (key == "CONTG_DETS") {
								jsonDataPopulate(value, tab);

							}

							if (key == "FPMS_POLICY_DETS") {

								existPolicyLHIns.clear().draw();
								utlipPolicyTbl.clear().draw();

								removeTblRows('existPolicyLHIns');
								removeTblRows('existPolicyUtlip');
								$("#existPolicyLHIns_info").css("display","none");
								$("#existPolicyUtlip_info").css("display","none");

								var poltbl = document.getElementById("existPolicyLHIns");
								var poltbody = poltbl.tBodies[0];

								var ilppoltbl = document.getElementById("existPolicyUtlip");
								var ilppoltbody = ilppoltbl.tBodies[0];

								var jsnData = value;

								for ( var cont in jsnData) {

									var contvalue = jsnData[cont];

									var sublob = contvalue["strFPMSPolLOBSub"];

									var lifInsId;

									if (contvalue["strFipaLifeInsId"] != ""
											|| contvalue["strFipaLifeInsId"] != undefined) {
										lifInsId = contvalue["strFipaLifeInsId"];

									} else {
										lifInsId = "";
									}
									var AppName = contvalue["strFPMSPolApplnName"];
									var fipaSymbol = '<a class="btn btn-default exportfipapolicy" id="exportfipapolicy" onmouseover="dhtmltooltip(this,&quot;On click fetch FIPA Policy details&quot;);" ></a><a class="btn btn-default fipadelpolicy" id="fipadelpolicy" onmouseover="dhtmltooltip(this,&quot;On click Delete FIPA Policy details&quot;);"></a>';
									var fpmsSymbol = '<a class="btn btn-default exportfpmspolicy" id="exportfpmspolicy" onmouseover="dhtmltooltip(this,&quot;On click fetch FPMS Policy details&quot;);"></a>';
									// showTooltipCls('exportfipapolicy',STR_FIPAPOLICY);
									// showTooltipCls('fipadelpolicy',STR_DELFIPAPOL);
									// showTooltipCls('exportfpmspolicy',STR_FPMSPOLICY);

									if (sublob == "ILP" || sublob == "UT") {

										var ilppoltbllen = ilppoltbody.rows.length;

										var arow = ilppoltbody
												.insertRow(ilppoltbllen);

										var cell0 = '<span></span>';

										var emptycell = "";

										var cell1 = '<input type="text" readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor" style="display:inline;width:80px"/><input type="hidden" name="strFipaLifeInsId"/><input type="hidden" name="strFnaId"/><input type="hidden" name="strFPMSAppId"/><input type="hidden" name="strFIPARefId"/>'
												+ ((AppName == "FIPA") ? fipaSymbol
														: fpmsSymbol);
										var cell2 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell3 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell4 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/><input type="hidden"/>';
										var cell5 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell6 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell7 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell8 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell9 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';

										utlipPolicyTbl.row.add(
												[ cell0, cell1, cell2, cell3,
														cell4, cell5, cell6,
														cell7, cell8, cell9,
														emptycell ])
												.draw(false);

										var rowCount = $('#existPolicyUtlip tbody tr').length;
										var $lastRow = $("#existPolicyUtlip tbody tr:last");

										$lastRow.find("td:first").find('span')
												.text(rowCount);
										
										
										$lastRow
												.find("td:eq(1)")
												.find('input:eq(0)')
												.val(
														contvalue["strFPMSPolApplnName"]);

										$lastRow
												.find("td:eq(1)")
												.find("a:eq(0)")
												.on(
														"click",
														function() {
															callFipaInsuranceDets($(this))
														});

										$lastRow
												.find("td:eq(1)")
												.find("a[id='fipadelpolicy']")
												.on(
														"click",
														function() {
															callDeletePolicy(
																	$(this),
																	utlipPolicyTbl,
																	'existPolicyUtlip');
														});

										$lastRow.find("td:eq(1)").find(
												'input:eq(1)').val(
												contvalue["strFipaLifeInsId"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(2)').val(
												contvalue["strFnaId"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(3)').val(
												contvalue["strFPMSPolAppId"]);
										$lastRow.find("td:eq(1)").find(
										'input:eq(4)').val(
										contvalue["strFIPARefId"]);

										var prin;

										if(AppName == "FIPA"){
												if(!isEmpty(contvalue["strFPMSPolPrincipalName"])){
													prin=$("#lipCompany").find('option[value="' + contvalue["strFPMSPolPrincipal"] + '"]').text();
												} 
										}else{
											prin=contvalue["strFPMSPolPrincipalName"];
										}
										$lastRow
												.find("td:eq(2)")
												.find('input:eq(0)')
												.val(
														prin);

										$lastRow.find("td:eq(3)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolPolNo"]);

										$lastRow
												.find("td:eq(4)")
												.find('input:eq(0)')
												.val(
														contvalue["strFPMSPolPlanName"]);
										$lastRow
												.find("td:eq(4)")
												.find('input:eq(1)')
												.val(
														contvalue["strFPMSPolCustName"]);

										$lastRow.find("td:eq(5)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolEffDate"]);
										$lastRow.find("td:eq(6)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolStatus"]);
										$lastRow.find("td:eq(7)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolSA"]);
										$lastRow.find("td:eq(7)").find('input:eq(0)').css("text-align","right");
										$lastRow.find("td:eq(8)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolPremium"]);
										$lastRow.find("td:eq(8)").find('input:eq(0)').css("text-align","right");
										$lastRow.find("td:eq(9)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolLOBMain"]
														+ "/" + sublob);
										$lastRow.find("td:eq(10)").addClass(
												"hidden")

									} else {

										var poltbllen = poltbody.rows.length;

										var crow = poltbody
												.insertRow(poltbllen);

										var cell0 = '<span></span>';
										var emptycell = "";
										var cell1 = '<input type="text" readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor" style="display:inline;width:80px"/><input type="hidden" name="strFipaLifeInsId"/><input type="hidden" name="strFnaId"/><input type="hidden" name="strFPMSAppId"/><input type="hidden" name="strFIPARefId"/>'
												+ ((AppName == "FIPA") ? fipaSymbol
														: fpmsSymbol);
										var cell2 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell3 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/><input type="hidden"/>';
										var cell4 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell5 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell6 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell7 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell8 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										var cell9 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										existPolicyLHIns.row.add(
												[ cell0, cell1, cell2, cell3,
														cell4, cell5, cell6,
														cell7, cell8, cell9,
														emptycell ])
												.draw(false);

										var rowCount = $('#existPolicyLHIns tbody tr').length;
										var $lastRow = $("#existPolicyLHIns tbody tr:last");

										$lastRow.find("td:first").find('span')
												.text(rowCount);

										$lastRow
												.find("td:eq(1)")
												.find('input:eq(0)')
												.val(
														contvalue["strFPMSPolApplnName"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(1)').val(
												contvalue["strFipaLifeInsId"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(2)').val(
												contvalue["strFnaId"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(3)').val(
												contvalue["strFPMSPolAppId"]);
										$lastRow.find("td:eq(1)").find(
										'input:eq(4)').val(
										contvalue["strFIPARefId"]);

										$lastRow
												.find("td:eq(1)")
												.find("a:eq(0)")
												.on(
														"click",
														function() {
															callFipaInsuranceDets($(this))
														});

										$lastRow
												.find("td:eq(1)")
												.find("a[id='fipadelpolicy']")
												.on(
														"click",
														function() {
															callDeletePolicy(
																	$(this),
																	existPolicyLHIns,
																	'existPolicyLHIns');
														});

										var prin;

										if(AppName == "FIPA"){
												if(!isEmpty(contvalue["strFPMSPolPrincipalName"])){
													prin=$("#lipCompany").find('option[value="' + contvalue["strFPMSPolPrincipal"] + '"]').text();
												} 
										}else{
											prin=contvalue["strFPMSPolPrincipalName"];
										}
										$lastRow
										.find("td:eq(2)")
										.find('input:eq(0)')
										.val(
												prin);

										$lastRow.find("td:eq(3)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolPolNo"]);
										$lastRow
												.find("td:eq(3)")
												.find('input:eq(1)')
												.val(
														contvalue["strFPMSPolCustName"]);

										$lastRow
												.find("td:eq(4)")
												.find('input:eq(0)')
												.val(
														contvalue["strFPMSPolPlanName"]);
										$lastRow.find("td:eq(5)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolEffDate"]);
										$lastRow.find("td:eq(6)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolStatus"]);
										$lastRow.find("td:eq(7)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolSA"]);
										$lastRow.find("td:eq(7)").find('input:eq(0)').css("text-align","right");
										$lastRow.find("td:eq(8)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolPremium"]);
										$lastRow.find("td:eq(8)").find('input:eq(0)').css("text-align","right");
										$lastRow.find("td:eq(9)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolLOBMain"]
														+ "/" + sublob);
										$lastRow.find("td:eq(10)").addClass(
												"hidden");

									}

								}

							}

							if (tab == "HEALTHINS_DETS") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getHealthInscRows(contvalue);
								});
							}

							if (key == "PERP_DETS") {
								jsonDataPopulate(value, tab);
							}

							if (tab == "INPUTINVESTMENT_DETS") {

								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getInptInvstRows(contvalue);
								});
							}

							if (key == "INV_DETS") {
								jsonDataPopulate(value, tab);
								$("#divforInvestmentSummary").find("input")
										.attr("data-attr", "0");
							}

							if (key == "PROPOWNCPF_DETS") {
								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getPropOwnCpfRows(contvalue);
								});
							}

							if (tab == "CASHATBANKS_DETS") {

								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getCobRows(contvalue);
								});
							}

							if (key == "CAS_DETS") {
								jsonDataPopulate(value, tab);

								//	  						
							}

							if (key == "OTH_DETS") {
								jsonDataPopulate(value, tab);

							}

							if (tab == "PERASSET_DETS") {

								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getPerAssetRows(contvalue);
								});
							}

							if (tab == "BUSASSET_DETS") {

								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getBuisAsstRows(contvalue);
								});
							}

							if (key == "VEHOWN_DETS") {
								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getVehOwnRows(contvalue);
								});
							}

							if (key == "ESTPLAN_DETS") {
								for ( var val in value) {
									jsonDataPopulate(value[val], tab);
								}
							}

							if (key == "CPF_BALANCE_DETS") {
								// jsonDataPopulate(value, tab);

								for ( var cont in value) {

									if (tab == "CPF_BALANCE_DETS") {
										$("input[name='" + cont + "']").val(
												value[cont]);
									}
								}
							}

							if (key == "CPFMTHCTRB_DETS") {
								// jsonTableDataPopulate(value, tab, false);
								/*var count=0;
								for ( var cont in value) { 
									if (tab == "CPFMTHCTRB_DETS") {
										for ( var data in value) { 
											$("input[name='" + value + "']")
													.eq(count).val(value[data]);
											count++;
										}
									}
								} */
								$.each(value,function(i,objSet){
									$.each(objSet,function(keySet,val){
										$("input[name='"+keySet+"']:eq("+i+")").val(val);
									});
									
								});
								
								
							}
							

							if (tab == "CPF_ADD_DED_DETS") {
								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getCADRows(contvalue);
								});
							}

							if (key == "FLB_DETS") {
								jsonDataPopulate(value, tab);

							}

							if (key == "CURASS_DETS") {
								jsonDataPopulate(value, tab);
								changeAvgRoiToProjRoi(); 
							}

							if (key == "RETP_DETS") {
								jsonDataPopulate(value, tab);
							}

							if (tab == "RDOTHER_PAY") {
								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getothretRows(contvalue);
//									getRDothretRows(contvalue);
								});
							}

							if (tab == "RDINCOME_DETS") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getincretRows(contvalue);
//									getRDincretRows(contvalue);
								});
							}

							if (tab == "RDINCASS_DETS") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getincassrtRows(contvalue);
//									getRDincAssretRows(contvalue);
								});
							}

							if (tab == "OTHAREA_DETS") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getAreaConRows(contvalue);
								});
							}
							if (tab == "RCMRSN") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getReasonsRows(contvalue);
								});
							}

							if (tab == "RCMPRO_DETS") {
								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getRcmPlnRows(contvalue);
								});
							}

							/*
							 * if(tab == "RCMPLAN_DETS"){
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							if (tab == "RCMFUND_DETS") {
								// jsonTableDataPopulate(value, tab, false);

								$.each(value, function(contkey, contvalue) {
									getFdPlnRows(contvalue);
								});
							}

							if (tab == "SWTHPLAN_DETS") {
								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getSwrepPlanRows(contvalue);
								});
							}

							if (tab == "SWTHFUND_DETS") {
								// jsonTableDataPopulate(value, tab, false);
								$.each(value, function(contkey, contvalue) {
									getSwrepFundRows(contvalue);
								});
							}

							if (key == "RSKPREF_DETS") {
								jsonDataPopulate(value, tab);
							}

							if (key == "SUMANAL_DETS") {
								jsonDataPopulate(value, tab);
							}

							/*
							 * if(key == "NORECORDS_FPMS_POLICY_DETS"){
							 * $("#existPolicyLHIns_info").css("display","block");
							 * $("#existPolicyUtlip_info").css("display","block");
							 * 
							 * 
							 * existPolicyLHIns.clear().draw();
							 * utlipPolicyTbl.clear().draw();
							 *  }
							 */

							/*
							 * if(key == "BENFTPPPEP_DETS"){ for ( var val in
							 * value) { jsonDataPopulate(value[val], tab); } }
							 */

							/*
							 * if(key == "CPFTP_DETS"){
							 * jsonTableDataPopulate(value, tab, false);
							 *  }
							 */

							/*
							 * if(key == "CPFDT_DETS"){
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(key == "FUNDFLW_DETS"){
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(key == "PROPOWN_DETS"){
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(tab == "FGACCHLT_DETS"){
							 * 
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(tab == "FGFAMAST_DETS"){
							 * 
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(tab == "FGSAVINV_DETS"){
							 * 
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(tab == "FGCHDEDU_DETS"){
							 * 
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(tab == "LIRETPLG_DETS"){
							 * jsonTableDataPopulate(value, tab, false); }
							 */
							/*
							 * if(tab == "LIEDUPLG_DETS"){
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(tab == "LIBENEFITS_DETS"){
							 * jsonTableDataPopulate(value, tab, false); }
							 */

							/*
							 * if(tab == "LINOMNAME_DETS"){
							 * jsonTableDataPopulate(value, tab, false); }
							 */

						}
					}
				}

				// /
				openClientSection();
				setTimeout(function() {

					
					DpdcalculateRow();
					// totInsuranceCalcRow();
					// propowncalculateRow();
					// calpropLnCashRepayment();
					vehowncalculateRow();
//					calcVehLnRepayment();
					addLateUpdtDate();

					getdob($("#dfSelfDob"), $('#dfSelfAge'),false);
					getdob($("#dfSpsDob"), $('#dfSpsAge'),false);

					calcSum(null, FNA_LIA.SUMOF_FINLIAB_SELF);
					calcSum(null, FNA_LIA.SUMOF_FINLIAB_SPS);

					callSumOfCpfMth();

					calcSum(null, CASH_ASS.SUMOF_CASHASST_SELF);
					calcSum(null, CASH_ASS.SUMOF_CASHASST_SPS);
					calcSum(null, CASH_ASS.SUMOF_CASHASST_JOIN);

					calcSum(null, OTH_ASS.SUMOF_OTHASST_SELF);
					calcSum(null, OTH_ASS.SUMOF_OTHASST_SPS);
					calcSum(null, OTH_ASS.SUMOF_OTHASST_JOIN);
					calcSum(null, OTH_ASS.SUMOF_OTHASST_LOAN);

					$("select#mgrId").prop("disabled", true);
					$("select#advstfId").prop("disabled", true);
					
					
					
					/*var clientmartstst = $("#dfSelfMartsts").val();
					clientmartstst = isEmpty(clientmartstst) ? "" : clientmartstst.toUpperCase();
					if(clientmartstst != "MARRIED"){
						$(".clsfipaSpouse").prop("disabled",true);
					}else{
						$(".clsfipaSpouse").prop("disabled",false);
					}*/
					
					chkClientSingleOrNot();
					chkTableDataLatestOrNot();//only latest profile in table will be disabled otherwise enabled
					

					hideLoader();

				}, 1500);

			});

}

function profileValidateDets() {

	var totapplntypesFlds = $('#profileDialog  #fnaType').length;
	for (var i = 0; i < totapplntypesFlds; i++) {
		if (!(document.getElementsByName("fnaType")[0].checked || document
				.getElementsByName("fnaType")[1].checked)) {
			showAlert(PROAPPTYPE, document.getElementsByName("fnaType")[0]);
			return false;

		}
	}

	var totrevflgFlds = $('#profileDialog  #radAppDataReview').length;
	for (var i = 0; i < totrevflgFlds; i++) {
		if (!(document.getElementsByName("radAppDataReview")[0].checked || document
				.getElementsByName("radAppDataReview")[1].checked)) {
			showAlert(PROREVFLG,
					document.getElementsByName("radAppDataReview")[0]);
			return false;

		}
	}

	return true;

}

function validateNRIC(NRIC_id, NRIC_type, focusId) {

	if (!(isEmpty(NRIC_id.value) && isEmpty(NRIC_type.value))) {
		showLoader();
		var parameter = "DBCALLFOR=CHK_EXIST_NRIC&strSrchClntNric="
				+ NRIC_id.value + "&strSrchClntNricType=" + NRIC_type.value;

		ajaxCall(
				parameter,
				servletName,
				function(Data) {
					var retval = Data;

					hideLoader();

					for ( var val in retval) {

						var tabdets = retval[val];

						if (tabdets["SESSION_EXPIRY"]) {
							window.location = BASE_URL + SESSION_EXP_JSP;
							return;
						}

						if (tabdets["DB_ERROR"]) {
							window.location = BASE_URL + DB_EXP_JSP;
							return;
						}

						for ( var tab in tabdets) {

							if (tabdets.hasOwnProperty(tab)) {

								var key = tab;
								var value = tabdets[tab];

								if (key == "CLIENT_NRIC_SRCH_NOREC") {
									return true;
								}

								if (key == "CLIENT_NRIC_SRCH") {

									var existclient = "";

									var jsnData = value;

									for ( var cont in jsnData) {
										var contvalue = jsnData[cont];
										for ( var data in contvalue) {
											existclient = (contvalue["dfSelfNricName"]);
										}
									}

									showAlert(
											NRIC_type.value
													+ " : "
													+ NRIC_id.value
													+ " is already exists for the client "
													+ existclient, focusId);
									focusId.value = "";
									focusId.focus();
									return true;

								}
							}
						}

					}
				});
	}
}

function resetForm() {

	for (var i = 0; i < fipaForm.elements.length; i++) {

		var e = fipaForm.elements[i];

		if (e.type == "text") {
			e.value = "";
		}
		if (e.type == "checkbox" || e.type == "radio") {
			e.checked = false;
		}
		if (e.type == "textArea") {
			e.value = "";
		}

	}
}

function hideRegMailAddr() {
	document.getElementById("spanClntDeclReasMailAddr").style.display = "none";
}

function setChkBoxValue(obj) {
	if ($(obj).is(":checked")) {
		$(obj).val('Y');
	} else {
		$(obj).val('N');
	}
}

function getClientDetailsFromFPMS(clientName, clientNRIC, custId) {

	var parameter = "DBCALLFOR=GET_CUSTDETS_FROMFPMS&strClientName="
			+ clientName + "&strClientNRIC=" + clientNRIC + "&strCustId="
			+ custId;

	ajaxCall(
			parameter,
			servletName,
			function(Data) {

				var retval = Data;

				for ( var val in retval) {

					var tabdets = retval[val];

					if (tabdets["SESSION_EXPIRY"]) {
						window.location = BASE_URL + SESSION_EXP_JSP;
						return;
					}
					if (tabdets["DB_ERROR"]) {
						window.location = BASE_URL + DB_EXP_JSP;
						return;
					}

					for ( var tab in tabdets) {

						if (tabdets.hasOwnProperty(tab)) {
							var key = tab;
							var value = tabdets[tab];

							if (key == "FPMS_CUSTOMER_DETAILS") {

								var jsnData = value;

								for ( var cont in jsnData) {

									var contvalue = jsnData[cont];

									for ( var data in contvalue) {

										$('input[name=' + data + ']').val(
												contvalue[data]);
										$('select[name=' + data + ']').val(
												contvalue[data]);

										if (data == "dfSelfName") {
											$("input[name='txtFldClientName']")
													.val(contvalue[data]);

										}

										if (data == "dfSelfNric") {
											$("input[name='txtFldClientNric']")
													.val(contvalue[data]);
										}

										getdob($("#dfSelfDob"), $('#dfSelfAge'),false);
										getdob($("#dfSpsDob"), $('#dfSpsAge'),false);
										analysisCheckEvent(this, 'All');
										setAdvMgrId(document
												.getElementById("advstfId"));
										loadSlfSpsName();

										if (data == "dfSelfRegmailaddrSame") {

											if (contvalue[data] == 'Y') {
												$("#dfSelfRegmailaddrSame")
														.prop("checked", false);
											} else {
												$("#dfSelfRegmailaddrSame")
														.prop("checked", true);
											}
											setSelfAddr($("#dfSelfRegmailaddrSame"));
											setChkBoxValue(fipaForm.dfSelfRegmailaddrSame);
										}
									}
								}

								$("#btnSaveProfile").removeClass("hidden");
							}

							if (key == "FPMS_POLICY_DETS") {

								utlipPolicyTbl.clear().draw();
								existPolicyLHIns.clear().draw();

								removeTblRows('existPolicyLHIns');
								removeTblRows('existPolicyUtlip');

								$("#existPolicyLHIns_info").css("display",
										"none");
								$("#existPolicyUtlip_info").css("display",
										"none");

								var poltbl = document
										.getElementById("existPolicyLHIns");
								var poltbody = poltbl.tBodies[0];

								var ilppoltbl = document
										.getElementById("existPolicyUtlip");
								var ilppoltbody = ilppoltbl.tBodies[0];

								var jsnData = value;

								for ( var cont in jsnData) {

									var contvalue = jsnData[cont];

									var sublob = contvalue["strFPMSPolLOBSub"];

									var lifInsId;

									if (contvalue["strFipaLifeInsId"] != ""
											|| contvalue["strFipaLifeInsId"] != undefined) {
										lifInsId = contvalue["strFipaLifeInsId"];

									} else {
										lifInsId = "";
									}
									//							 
									var AppName = contvalue["strFPMSPolApplnName"];
									var fipaSymbol = '<a class="btn btn-default exportfipapolicy" id="exportfipapolicy"  onmouseover="dhtmltooltip(this,&quot;On click fetch FIPA Policy details&quot;);" ></a><a class="btn btn-default fipadelpolicy" id="fipadelpolicy" onmouseover="dhtmltooltip(this,&quot;On click Delete FIPA Policy details&quot;);"></a>';
									var fpmsSymbol = '<a class="btn btn-default exportfpmspolicy" id="exportfpmspolicy"  onmouseover="dhtmltooltip(this,&quot;On click fetch FPMS Policy details&quot;);"></a>';
									// showTooltipCls('exportfipapolicy',STR_FIPAPOLICY);
									// showTooltipCls('fipadelpolicy',STR_DELFIPAPOL);
									// showTooltipCls('exportfpmspolicy',STR_FPMSPOLICY);
									if (sublob == "ILP" || sublob == "UT") {

										var ilppoltbllen = ilppoltbody.rows.length;

										var arow = ilppoltbody
												.insertRow(ilppoltbllen);
 
										var cell0 = '<span></span>'; 

										var emptycell = "";
 
										var cell1 = '<input type="text" readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor" style="display:inline;width:80px"/><input type="hidden" name="strFipaLifeInsId"/><input type="hidden" name="strFnaId"/><input type="hidden" name="strFPMSAppId"/><input type="hidden" name="strFIPARefId"/>'
												+ ((AppName == "FIPA") ? fipaSymbol
														: fpmsSymbol);
										 
										var cell2 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';

										var cell3 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';



										var cell4 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/><input type="hidden"/>';

										var cell5 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										var cell6 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										var cell7 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										var cell8 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										var cell9 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										
										utlipPolicyTbl.row.add(
												[ cell0, cell1, cell2, cell3,
														cell4, cell5, cell6,
														cell7, cell8, cell9,
														emptycell ])
												.draw(false);

										var rowCount = $('#existPolicyUtlip tbody tr').length;
										var $lastRow = $("#existPolicyUtlip tbody tr:last");

										$lastRow.find("td:first").find('span')
												.text(rowCount);

										$lastRow
												.find("td:eq(1)")
												.find('input:eq(0)')
												.val(
														contvalue["strFPMSPolApplnName"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(1)').val(
												contvalue["strFipaLifeInsId"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(2)').val(
												contvalue["strFnaId"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(3)').val(
												contvalue["strFPMSPolAppId"]);
										$lastRow.find("td:eq(1)").find(
										'input:eq(4)').val(
										contvalue["strFIPARefId"]);
										$lastRow
												.find("td:eq(1)")
												.find("a:eq(0)")
												.on(
														"click",
														function() {
															callFipaInsuranceDets($(this))
														});

										$lastRow
												.find("td:eq(1)")
												.find("a[id='fipadelpolicy']")
												.on(
														"click",
														function() {
															callDeletePolicy(
																	$(this),
																	utlipPolicyTbl,
																	'existPolicyUtlip');
														});

										var prin;

										if(AppName == "FIPA"){
												if(!isEmpty(contvalue["strFPMSPolPrincipalName"])){
													prin=$("#lipCompany").find('option[value="' + contvalue["strFPMSPolPrincipal"] + '"]').text();
												} 
										}else{
											prin=contvalue["strFPMSPolPrincipal"];
										}
										$lastRow
												.find("td:eq(2)")
												.find('input:eq(0)')
												.val(
														prin);

										$lastRow.find("td:eq(3)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolPolNo"]);

										$lastRow
												.find("td:eq(4)")
												.find('input:eq(0)')
												.val(
														contvalue["strFPMSPolPlanName"]);
										$lastRow
												.find("td:eq(4)")
												.find('input:eq(1)')
												.val(
														contvalue["strFPMSPolCustName"]);

										$lastRow.find("td:eq(5)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolEffDate"]);
										$lastRow.find("td:eq(6)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolStatus"]);
										$lastRow.find("td:eq(7)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolSA"]);
										$lastRow.find("td:eq(7)").find('input:eq(0)').css("text-align","right");
										
										$lastRow.find("td:eq(8)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolPremium"]);
										$lastRow.find("td:eq(8)").find('input:eq(0)').css("text-align","right");

										$lastRow.find("td:eq(9)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolLOBMain"]
														+ "/" + sublob);
										$lastRow.find("td:eq(10)").addClass(
												"hidden")

									} else {

										var poltbllen = poltbody.rows.length;

										var crow = poltbody
												.insertRow(poltbllen);

										var cell0 = '<span></span>';
										var emptycell = "";
										var cell1 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor" style="display:inline;width:80px"/><input type="hidden" name="strFipaLifeInsId"/><input type="hidden" name="strFnaId"/><input type="hidden" name="strFPMSAppId"/><input type="hidden" name="strFIPARefId"/>'
												+ ((AppName == "FIPA") ? fipaSymbol
														: fpmsSymbol);

										var cell2 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										var cell3 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/><input type="hidden"/>';
										
										var cell4 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										var cell5 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										var cell6 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';

										var cell7 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										var cell8 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';

										var cell9 = '<input type="text"  readOnly="true" onmouseover="fipaTooltip(this);" class="dhtmlTableText ptrcursor"/>';
										
										existPolicyLHIns.row.add(
												[ cell0, cell1, cell2, cell3,
														cell4, cell5, cell6,
														cell7, cell8, cell9,
														emptycell ])
												.draw(false);

										var rowCount = $('#existPolicyLHIns tbody tr').length;
										var $lastRow = $("#existPolicyLHIns tbody tr:last");

										$lastRow.find("td:first").find('span')
												.text(rowCount);

										$lastRow
												.find("td:eq(1)")
												.find('input:eq(0)')
												.val(
														contvalue["strFPMSPolApplnName"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(1)').val(
												contvalue["strFipaLifeInsId"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(2)').val(
												contvalue["strFnaId"]);
										$lastRow.find("td:eq(1)").find(
												'input:eq(3)').val(
												contvalue["strFPMSPolAppId"]);
										$lastRow.find("td:eq(1)").find(
										'input:eq(4)').val(
										contvalue["strFIPARefId"]);
										$lastRow
												.find("td:eq(1)")
												.find("a:eq(0)")
												.on(
														"click",
														function() {
															callFipaInsuranceDets($(this))
														});
										$lastRow
												.find("td:eq(1)")
												.find("a[id='fipadelpolicy']")
												.on(
														"click",
														function() {
															callDeletePolicy(
																	$(this),
																	existPolicyLHIns,
																	'existPolicyLHIns');
														});

										var prin;

										if(AppName == "FIPA"){
												if(!isEmpty(contvalue["strFPMSPolPrincipalName"])){
													prin=$("#lipCompany").find('option[value="' + contvalue["strFPMSPolPrincipal"] + '"]').text();
												} 
										}else{
											prin=contvalue["strFPMSPolPrincipal"];
										}
										$lastRow
												.find("td:eq(2)")
												.find('input:eq(0)')
												.val(
														prin);

										$lastRow.find("td:eq(3)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolPolNo"]);
										$lastRow
												.find("td:eq(3)")
												.find('input:eq(1)')
												.val(
														contvalue["strFPMSPolCustName"]);

										$lastRow
												.find("td:eq(4)")
												.find('input:eq(0)')
												.val(
														contvalue["strFPMSPolPlanName"]);
										$lastRow.find("td:eq(5)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolEffDate"]);
										$lastRow.find("td:eq(6)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolStatus"]);
										$lastRow.find("td:eq(7)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolSA"]);
										$lastRow.find("td:eq(7)").find('input:eq(0)').css("text-align","right");
										
										$lastRow.find("td:eq(8)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolPremium"]);
										$lastRow.find("td:eq(8)").find('input:eq(0)').css("text-align","right");

										$lastRow.find("td:eq(9)").find(
												'input:eq(0)').val(
												contvalue["strFPMSPolLOBMain"]
														+ "/" + sublob);
										$lastRow.find("td:eq(10)").addClass(
												"hidden")

									}

								}
							}
						}
					}

				}

				
			});

	openClientSection();

}

function toggleDiv(id, hid) {

	$("#" + id).show();
	var srchFldsArrCpfAll = [ hid ];
	$.each(srchFldsArrCpfAll, function(index, value) {
		$("#" + srchFldsArrCpfAll[0]).hide();
	});
}

function openClientSection() {
	$(".menu_section>ul.hidden").removeClass("hidden");
	var def = $("#hTxtMenuName").val();
	if (FIPAMenu == "" || def == "Profile Search" || def == "Default"
			|| def == "Profile") {
		openDivForClient('typesofappln', 'typesofappsec', 'typesofAppln_li',
				'Types of Application');
		hideLoader();
	}
}

function openProfileSection() {

	show('profilepage');
	showchild('profilesection');
	openDivForClient('profilepage', 'profilesection', 'profile_li',
			'Profile Search');
	hideLoader();
}

function setFNAType(thisobj, value) {
	$("input[name='fnaType'][value='" + value + "']").attr("checked", true);
}

function disableSlfSpseFamFields() {
	$(".clsfipaClient").prop("disabled", true);
	$(".clsfipaSpouse").prop("disabled", true);
	$(".clsfipaFamily").prop("disabled", true);
	$('#dobSlfpicker').datetimepicker('remove');
	$('#dobSpspicker').datetimepicker('remove');
	$("#dfSelfRegmailaddrSame").attr("disabled", true);
	$("#dfSpsRegmailaddrSame").attr("disabled", true);
	$("#dfSpsRegmailaddrSame").attr("disabled", true);
	$("#dfSpsMailaddrAsSelf").attr("disabled", true);
}

function validateClientDets() {
	if (!(stafftype == 'STAFF')) {
		// if(!(validateMandatoryOfTypesOfApplication(fipaForm))) return;
		// if(!(validateMandatoryOfPersonalParticulars(fipaForm))) return;
	}
	return true;
}

function callDatePickers(chklatestid) {
	if (chklatestid == 1) {
		$('#dobSlfpicker,#dobSpspicker').datetimepicker(dobOptions);
		$(
				'#COBPerFrmpicker,#COBPerTopicker,#CADPerFrmpicker,#CADPerTopicker,'
						+ '#InvDateInvstDatepicker,#InvDateInvstDatepicker,'
						+ '#LIIncptDatepicker,#LIMaturityDatepicker,#DfIncepDatepicker,'
						+ '#DfExpiryDatepicker,#CrtlnsExpDatepicker,'
						+ '#HIExpirypicker, #SrchCpfAllocEffFrompicker,#dlgCpfAllocEffFrompicker,'
						+ '#SrchCpfIntMthpicker,#dlgCpfIntMthpicker')
				.datetimepicker(dateOptions);

	} else if (chklatestid > 1) {
		$('#dobSlfpicker,#dobSpspicker').datetimepicker("remove");
		$(
				'#COBPerFrmpicker,#COBPerTopicker,#CADPerFrmpicker,#CADPerTopicker,'
						+ '#InvDateInvstDatepicker,#InvDateInvstDatepicker,'
						+ '#LIIncptDatepicker,#LIMaturityDatepicker,#DfIncepDatepicker,'
						+ '#DfExpiryDatepicker,#CrtlnsExpDatepicker,'
						+ '#HIExpirypicker, #SrchCpfAllocEffFrompicker,#dlgCpfAllocEffFrompicker,'
						+ '#SrchCpfIntMthpicker,#dlgCpfIntMthpicker')
				.datetimepicker("remove");
	}
}

$("input:checkbox[name=txtFldAnalyisFor]").on("click", function() {
	chkedJSONCollection(this, 'appAnalysisFor');
});

$("input:checkbox[name=txtFldPurpose]").on("click", function() {
	chkedJSONCollection(this, 'appPurpose');
});

$("input:checkbox[name=txtFldClientChoice]").on("click", function() {
	chkedJSONCollection(this, 'appClientChoice');
});
$("input:checkbox[name=chkArNewRecom]").on("click", function() {
	chkedJSONCollection(this, 'arNewRecomm');
});
function chkedJSONCollection(chkbox, hiddenObj) {

	var hiddenObjval = $("#" + hiddenObj);
	var jsonVal = JSON.parse(isEmpty(hiddenObjval.val()) ? "{}" : hiddenObjval
			.val());
	var ischecked = $(chkbox).is(":checked");
	var checkedVal = $(chkbox).attr("data-attr");

	var resObj = jsonVal;
	resObj[checkedVal] = (ischecked == true ? "Y" : "N");
	hiddenObjval.val(JSON.stringify(resObj));

}

// Address Section Scenarios

function setSelfAddr(object) {
	{
		if (object.is(":checked")) {
			$('#dfSelfMailaddr').prop('readonly', false).removeClass(
					"readOlyCursor");
			$('#dfSelfMailaddr2').prop('readonly', false).removeClass(
					"readOlyCursor");
			$('#dfSelfMailpostal').prop('readonly', false).removeClass(
					"readOlyCursor");
			$('#dfSelfMailcntry').prop('disabled', false).removeClass(
					"disabledCursor");
			$('#dfSelfAddrreason').prop('disabled', false).removeClass(
					"disabledCursor");
		} else {
			$('#dfSelfMailaddr').val($("#dfSelfHomeaddr").val()).prop(
					'readonly', true).addClass("readOlyCursor");
			$('#dfSelfMailaddr2').val($("#dfSelfHomeaddr2").val()).prop(
					'readonly', true).addClass("readOlyCursor");
			$('#dfSelfMailpostal').val($("#dfSelfHomepostal").val()).prop(
					'readonly', true).addClass("readOlyCursor");
			$('#dfSelfMailcntry').val($("#dfSelfHomecntry").val()).prop(
					'disabled', true).addClass("disabledCursor");
			$('#dfSelfAddrreason').val("").prop('disabled', true).addClass(
					"disabledCursor");
		}

	}
}

$("input:checkbox[name=dfSelfRegmailaddrSame]").on(
		"click",
		function() {
			if ($(this).is(":checked")) {
				$('#dfSelfMailaddr').val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$('#dfSelfMailaddr2').val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$('#dfSelfMailpostal').val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$('#dfSelfMailcntry').val("").prop('disabled', false)
						.removeClass("disabledCursor");
				$('#dfSelfAddrreason').val("").prop('disabled', false)
						.removeClass("disabledCursor");
			} else {
				$('#dfSelfMailaddr').val($("#dfSelfHomeaddr").val()).prop(
						'readonly', true).addClass("readOlyCursor");
				$('#dfSelfMailaddr2').val($("#dfSelfHomeaddr2").val()).prop(
						'readonly', true).addClass("readOlyCursor");
				$('#dfSelfMailpostal').val($("#dfSelfHomepostal").val()).prop(
						'readonly', true).addClass("readOlyCursor");
				$('#dfSelfMailcntry').val($("#dfSelfHomecntry").val()).prop(
						'disabled', true).addClass("disabledCursor");
				$('#dfSelfAddrreason').val("").prop('disabled', true).addClass(
						"disabledCursor");
			}

		});

$("input:checkbox[name=dfSpsRegmailaddrSame]").on(
		"click",
		function() {

			if ($(this).is(":checked")) {
				if ($("input:checkbox[name=dfSpsMailaddrAsSelf]")
						.is(":checked")) {
					$("input:checkbox[name=dfSpsMailaddrAsSelf]").prop(
							"checked", false).val("N");
				}
				$('#dfSpsMailaddr').val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$('#dfSpsMailaddr2').val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$('#dfSpsMailpostal').val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$('#dfSpsMailcntry').val("").prop('disabled', false)
						.removeClass("disabledCursor");
				$('#dfSpsAddrreason').val("").prop('disabled', false)
						.removeClass("disabledCursor");
			}
		});

$("input:checkbox[name=dfSpsRegaddrAsSelf]").on(
		"click",
		function() {

			if ($(this).is(":checked")) {

				$("input:checkbox[name=dfSpsMailaddrAsSelf]").prop('checked',
						true).val("Y");

				$("#dfSpsHomeaddr").val($("#dfSelfHomeaddr").val()).prop(
						'readonly', true).addClass("readOlyCursor");
				$("#dfSpsHomeaddr2").val($("#dfSelfHomeaddr2").val()).prop(
						'readonly', true).addClass("readOlyCursor");
				$("#dfSpsHomepostalcode").val($("#dfSelfHomepostal").val())
						.prop('readonly', true).addClass("readOlyCursor");
				$("#dfSpsHomecntry").val($("#dfSelfHomecntry").val()).prop(
						'disabled', true).addClass("disabledCursor");

				if (!$("input:checkbox[name=dfSpsRegmailaddrSame]").is(
						":checked")) {

					$('#dfSpsMailaddr').val($("#dfSelfHomeaddr").val()).prop(
							'readonly', true).addClass("readOlyCursor");
					$('#dfSpsMailaddr2').val($("#dfSelfHomeaddr2").val()).prop(
							'readonly', true).addClass("readOlyCursor");
					$('#dfSpsMailpostal').val($("#dfSelfHomepostal").val())
							.prop('readonly', true).addClass("readOlyCursor");
					$('#dfSpsMailcntry').val($("#dfSelfHomecntry").val()).prop(
							'disabled', true).addClass("disabledCursor");
					$('#dfSpsAddrreason').val("").prop('disabled', true)
							.addClass("disabledCursor");
				} else {
					$("input:checkbox[name=dfSpsMailaddrAsSelf]").prop(
							'checked', false).val("N");
					$('#dfSpsMailaddr').val("").prop('readonly', false)
							.removeClass("readOlyCursor");
					$('#dfSpsMailaddr2').val("").prop('readonly', false)
							.removeClass("readOlyCursor");
					$('#dfSpsMailpostal').val("").prop('readonly', false)
							.removeClass("readOlyCursor");
					$('#dfSpsMailcntry').val("").prop('disabled', false)
							.removeClass("disabledCursor");
					$('#dfSpsAddrreason').val("").prop('disabled', false)
							.removeClass("disabledCursor");
					$('#dfSpsAddrreason').val("").prop('disabled', false)
							.removeClass("disabledCursor");
				}

			} else {

				$("input:checkbox[name=dfSpsMailaddrAsSelf]").prop('checked',
						false).val("N");

				$("#dfSpsHomeaddr").val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$("#dfSpsHomeaddr2").val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$("#dfSpsHomepostalcode").val("").prop('readonly', false)
						.removeClass("readOlyCursor");
				$("#dfSpsHomecntry").val("").prop('disabled', false)
						.removeClass("disabledCursor");

				if (!$("input:checkbox[name=dfSpsRegmailaddrSame]").is(
						":checked")) {
					$('#dfSpsMailaddr').val("").prop('readonly', true)
							.addClass("readOlyCursor");
					$('#dfSpsMailaddr2').val("").prop('readonly', true)
							.addClass("readOlyCursor");
					$('#dfSpsMailpostal').val("").prop('readonly', true)
							.addClass("readOlyCursor");
					$('#dfSpsMailcntry').val("").prop('disabled', true)
							.addClass("disabledCursor");
					$('#dfSpsAddrreason').val("").prop('disabled', true)
							.addClass("disabledCursor");
				}
			}
		});

$("input:checkbox[name=dfSpsMailaddrAsSelf]").on(
		"click",
		function() {
			if ($(this).is(":checked")) {

				if ($("input:checkbox[name=dfSpsRegmailaddrSame]").is(
						":checked")) {
					if ($("input:checkbox[name=dfSpsRegmailaddrSame]").is(
							":checked")) {
						$("input:checkbox[name=dfSpsRegmailaddrSame]").prop(
								"checked", false).val("N");
					}
				}

				$('#dfSpsMailaddr').val($("#dfSelfHomeaddr").val()).prop(
						'readonly', true).addClass("readOlyCursor");
				$('#dfSpsMailaddr2').val($("#dfSelfHomeaddr2").val()).prop(
						'readonly', true).addClass("readOlyCursor");
				$('#dfSpsMailpostal').val($("#dfSelfHomepostal").val()).prop(
						'readonly', true).addClass("readOlyCursor");
				$('#dfSpsMailcntry').val($("#dfSelfHomecntry").val()).prop(
						'disabled', true).addClass("disabledCursor");
				$('#dfSpsAddrreason').val("").prop('disabled', true).addClass(
						"disabledCursor");
			} else {
				$('#dfSpsMailaddr').val("").prop('readonly', true).addClass(
						"readOlyCursor");
				$('#dfSpsMailaddr2').val("").prop('readonly', true).addClass(
						"readOlyCursor");
				$('#dfSpsMailpostal').val("").prop('readonly', true).addClass(
						"readOlyCursor");
				$('#dfSpsMailcntry').val("").prop('disabled', true).addClass(
						"disabledCursor");
				$('#dfSpsAddrreason').val("").prop('disabled', true).addClass(
						"disabledCursor");
			}

		});

// Types of Application -Analysis For Section Scenarios
$("input:checkbox[name='txtFldAnalyisFor'][data-attr='ANALYS_SLF']").on(
		"click", function() {
			if ($(this).is(":checked")) {
				$(".clsfipaClient").prop("disabled", false);
				$('#dobSlfpicker').datetimepicker(dobOptions);
				$("#dfSelfRegmailaddrSame").prop("disabled", false);
				mailAddress('Slf', false, 'rmv');
				regAddress('Slf', false, 'rmv');
				$("#dfSelfMailcntry").prop("disabled", true);
				$("#dfSelfAddrreason").prop("disabled", true);

			} else {
				$(".clsfipaClient").prop("disabled", true);
				$('#dobSlfpicker').datetimepicker('remove');
				clearAllSlfSpsFields('Self');
				$("#dfSelfRegmailaddrSame").prop("disabled", true);
				$("#dfSelfMailcntry").prop("disabled", true);
				$("#dfSelfAddrreason").prop("disabled", true);
			}
		});

$("input:checkbox[name='txtFldAnalyisFor'][data-attr='ANALYS_SPS']").on(
		"click", function() {
			if ($(this).is(":checked")) {
				$(".clsfipaSpouse").prop("disabled", false);
				$('#dobSpspicker').datetimepicker(dobOptions);
				$("#dfSpsRegaddrAsSelf").prop("disabled", false);
				$("#dfSpsRegmailaddrSame").prop("disabled", false);
				$("#dfSpsMailaddrAsSelf").prop("disabled", false);
				$("#dfSpsHomecntry").prop("disabled", false);
				$("input[name=txtFldDepnProvSps]").each(function() {  
					 
							 $(this).prop("disabled",false); 
							 DpdcalculateRow(); 
			     });
				 $("input[name=txtFldPropCpfLoanBySpsCpf]").each(function() {  
			    	 
							 $(this).prop("disabled",false); 
					 
			     });
				 $("input[name=txtFldPropCpfLoanBySpsCash]").each(function() {  
			    	 
							 $(this).prop("disabled",false);  
			      }); 
				 chkOwnership('Spouse',false);

			} else {
				$(".clsfipaSpouse").prop("disabled", true);
				$('#dobSpspicker').datetimepicker('remove');
				clearAllSlfSpsFields('Spouse');
				$("#dfSpsRegaddrAsSelf").prop("disabled", true);
				$("#dfSpsRegaddrAsSelf").prop("checked", false);
				$("#dfSpsRegmailaddrSame").prop("disabled", true);
				$("#dfSpsRegmailaddrSame").prop("checked", false);
				$("#dfSpsMailaddrAsSelf").prop("disabled", true);
				$("#dfSpsMailaddrAsSelf").prop("checked", false);
				$("#dfSpsHomecntry").prop("disabled", true);

			}
		});

$("input:checkbox[name='txtFldAnalyisFor'][data-attr='ANALYS_FAM']").on(
		"click", function() {
			if ($(this).is(":checked")) {
				$(".clsfipaFamily").prop("disabled", false);
				chkOwnership('Family',false);
			} else {
				clearAllSlfSpsFields('Family');
				$(".clsfipaFamily").prop("disabled", true);

			}
		});

//Martial Status Validation 
$("#dfSelfMartsts").on("change",function(){ 
	clientMartSts($(this).val(),true);
	chkClientSingleOrNot()
	;
});

function clientMartSts(status,flg){
	if(status == "Single"){
		$(".clsfipaSpouse").prop("disabled", true);
		$('#dobSpspicker').datetimepicker('remove');
		if(flg){
		clearAllSlfSpsFields('Spouse');
		}else{
			 $('#dfSpsDob').val('');
		    	 $('.clsfipaSpouse').each(function() {  
		    		$(this).val('');
		    	 });
		    	 $('.clearfipaSpouse').each(function() {  
			    		$(this).val('');
			    		$(this).prop("readonly",true);
			    	 });
		  	 
				 $("input[name=txtFldDepnProvSps]").each(function() {  
						 
							 $(this).prop("disabled",true);
							 $(this).val("");
							DpdcalculateRow(); 
			    		 
			    	 });
			    	 $("input[name=txtFldPropCpfLoanBySpsCpf]").each(function() {  
			    		 
							 $(this).prop("disabled",true);
							 $(this).val("");
						  
			    	 });
			    	 $("input[name=txtFldPropCpfLoanBySpsCash]").each(function() {  
			    		 
							 $(this).prop("disabled",true);
							 $(this).val("");
						  
			    	 }); 
		    	$("#dfSpsRegmailaddrSame").prop("checked",false); 
		    	$("#dfSpsRegmailaddrSame").prop("checked",false); 
		    	$("#dfSpsMailaddrAsSelf").prop("checked",false); 
		    	$("#dfSpsHomecntry").val(''); 
		    		chkOwnership('Spouse',true); 
		}
		$("#dfSpsRegaddrAsSelf").prop("disabled", true);
		$("#dfSpsRegaddrAsSelf").prop("checked", false);
		$("#dfSpsRegmailaddrSame").prop("disabled", true);
		$("#dfSpsRegmailaddrSame").prop("checked", false);
		$("#dfSpsMailaddrAsSelf").prop("disabled", true);
		$("#dfSpsMailaddrAsSelf").prop("checked", false);
		$("#dfSpsHomecntry").prop("disabled", true);
	}else{
		
		$(".clsfipaSpouse").prop("disabled", false);
		$('#dobSpspicker').datetimepicker(dobOptions);
		$("#dfSpsRegaddrAsSelf").prop("disabled", false);
		$("#dfSpsRegmailaddrSame").prop("disabled", false);
		$("#dfSpsMailaddrAsSelf").prop("disabled", false);
		$("#dfSpsHomecntry").prop("disabled", false);
		
		$("input[name=txtFldDepnProvSps]").each(function() {  
			 
					 $(this).prop("disabled",false); 
			 
	     });
		 $("input[name=txtFldPropCpfLoanBySpsCpf]").each(function() {  
	    	 
					 $(this).prop("disabled",false); 
			 
	     });
		 $("input[name=txtFldPropCpfLoanBySpsCash]").each(function() {  
	    	 
					 $(this).prop("disabled",false);  
	      }); 
		 
		 chkOwnership('Spouse',false);
	}
}
$("input:radio[id=mgrAgreeFlagYes]").on("click", function() {
	if (!validateDetails())
		return;
	// if(!(stafftype == STAFFTYPE_STAFF)){
	$("#mgrFollowupRemarks").prop("readonly", false);
	$('#mgrFollowupRemarks').removeClass("readOlyCursor");
	$("#mgrFollowupRemarks").focus();
	// }
});

$("input:radio[id=mgrAgreeFlagNo]").on("click", function() {
	if (!validateDetails())
		return;
	// if(!(stafftype == STAFFTYPE_STAFF)){
	$("#mgrFollowupRemarks").prop("readonly", true);
	$('#mgrFollowupRemarks').addClass("readOlyCursor");
	// }
});

$("input:radio[id=cdAgreeFlgYes]").on("click", function() {
	if (!validateDetails())
		return;
	// if(!(stafftype == STAFFTYPE_STAFF)){
	$("#cdCcRemarks").prop("readonly", false);
	$('#cdCcRemarks').removeClass("readOlyCursor");
	$("#cdCcRemarks").focus();
	// }
});

$("input:radio[id=cdAgreeFlgNo]").on("click", function() {
	if (!validateDetails())
		return;
	// if(!(stafftype == STAFFTYPE_STAFF)){
	$("#cdCcRemarks").prop("readonly", true);
	$('#cdCcRemarks').addClass("readOlyCursor");
	// }
});

$(".side-menu").find("li[id=search_li]").on("click",function() { 
	$(".menu_section>ul:not(:first-child)").addClass("hidden");
	
});




$("#caSelfRoi,#caSpsRoi,#caFamRoi,#caProjSelfRoi,#caProjSpsRoi,#caProjFamRoi").on("change",function(){
	changeAvgRoiToProjRoi(); 
	AsspProRoiToRetRoi(); 
});

$("#caProjSelfRoi,#caProjSpsRoi,#caProjFamRoi").on("change",function(){
	AsspProRoiToRetRoi(); 
});

$("#retSelfProjroi,#retSpsProjroi,#retFamProjroi").on("change",function(){
	RetRoiToAsspProRoi(); 
});

function changeAvgRoiToProjRoi(){
	
	var avgSelfroi=isEmpty($("#caProjSelfRoi").val())?$("#caSelfRoi").val(): $("#caProjSelfRoi").val(); 
	var avgSpsroi=isEmpty($("#caProjSpsRoi").val())?$("#caSpsRoi").val(): $("#caProjSpsRoi").val();   
	var avgFamroi=isEmpty($("#caProjFamRoi").val())?$("#caFamRoi").val(): $("#caProjFamRoi").val();  
	
	$("#caProjSelfRoi").val(avgSelfroi);
	$("#caProjSpsRoi").val(avgSpsroi);
	$("#caProjFamRoi").val(avgFamroi);
	
	

	return;
}
 
function AsspProRoiToRetRoi(){
	
	applyToastrAlert("The Keyed in data will be reflected to Retirement Planning Section");
	
	var retSelfroi=$("#caProjSelfRoi").val(); 
	var retSpsroi=$("#caProjSpsRoi").val();   
	var retFamroi=$("#caProjFamRoi").val();  
	
	$("#retSelfProjroi").val(retSelfroi);
	$("#retSpsProjroi").val(retSpsroi);
	$("#retFamProjroi").val(retFamroi);
	
	return;
}


function RetRoiToAsspProRoi(){
	
	applyToastrAlert("The Keyed in data will be reflected to Current Assumption Section");
	
	var retSelfroi=$("#retSelfProjroi").val(); 
	var retSpsroi=$("#retSpsProjroi").val();   
	var retFamroi=$("#retFamProjroi").val();  
	
	$("#caProjSelfRoi").val(retSelfroi);
	$("#caProjSpsRoi").val(retSpsroi);
	$("#caProjFamRoi").val(retFamroi); 
	return;
}


$("#incsrcSelfEmpMonthly,#incsrcSelfEmpAddlwage").on("change",function(){
	 calSelfCpfMastMthContr();
});

$("#incsrcSpsEmpMonthly,#incsrcSpsEmpAddlwage").on("change",function(){
	 calSpsCpfMastMthContr();
});

$("#sidebar-menu").find("li[id=search_li]>a").on("click",function(){
	chkClientMenu();show('searchpage');navlink(this,'null');
});

