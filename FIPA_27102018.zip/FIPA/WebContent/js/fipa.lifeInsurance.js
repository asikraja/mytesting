 /**
 * Life Insurance Dialog  - Plan Details
 */

	 
	var liPlanDetailstbl = $('#liPlanDetailstbl').DataTable( {
		destroy: true,
	 	responsive: false,        
	    ordering: false,
	    searching: false,
		scrollY:  "40vh",   
		scrollX: true,
	    scroller: false,
	    scrollCollapse:false,
	    paging:false, 
	    filter:false,  
	    dom: '<<"top" ip>flt>',
	    columnDefs: [  { width: '20px', targets: [0,1]},
	       	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			    if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
			    } 
		 }
	}).draw();
	
	
	/*Add Row Click */
	$("#lfplnARow").on("click",function(){
		liplndetsclearFlds();
				showFIPAModel('liPlandets_Dialog','Life Insurance - Plan Details');   
				$('#liPlandets_Dialog').on('shown.bs.modal', function () {
					$("#liPlandets_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
					$("#liPlandets_Dialog").find("input[id=txtFldDlgliplnName]").focus();
					$("#liPlandets_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
					 
						  if(!validateLiPlanDetails())return;
						  LiPlandetsRdlyflds(INS_MODE);  
						  getliPlndetRows(null); 
							$('#liPlandets_Dialog').modal('hide'); 
					  });  
				}); 
	});


	/*Populate Data */
	function getliPlndetRows(dataset,tab){ 
	 
	var cell0 = '<span></span>'+
	'<input type="hidden" name="txtFldplnDetMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldliplnId">';
	 
	var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radplnDetSelect"/><label>&nbsp;</label></div>'; 

	var cell2 = '<input type="text" name="txtFldliplnName" class="form-control editable"  maxlength="150"  onmouseover="fipaTooltip(this);" />';

	var cell3 = '<select  name="selliplntype" class="form-control editable" ></select>';

	var cell4 = '<input type="text" name="txtFldliplnPremTerm" class="form-control editable"  maxlength="20"  onmouseover="fipaTooltip(this);" />';

	var cell5 = '<input type="text" name="txtFldliplnSA" class="form-control editable" onmouseover="fipaTooltip(this);" />'; 

	var cell6 = '<input type="text" name="txtFldliplnPremAmt" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

	var cell7 = '<select  name="selliplnPayMode" class="form-control editable" maxlength="30" ></select>';

	var cell8 = '<select  name="selliplnPayMtd" class="form-control editable" ></select>';

	var cell9 = '<input type="text" name="txtFldliplnCoverages"  maxlength="300" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

	var cell10 = '<input type="text" name="txtFldliplnRemarks" class="form-control editable"   maxlength="300"   onmouseover="fipaTooltip(this);" />'+
	'<input type="hidden" name="txtFldliplnCrtdBy"/><input type="hidden" name="txtFldliplnCrtdDate"/>';


	 

	liPlanDetailstbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10] ).draw( false );

	var rowCount = $('#liPlanDetailstbl tbody tr').length;	
	var $lastRow = $("#liPlanDetailstbl tbody tr:last");	

	$lastRow.find("td:first").find('span').text(rowCount); 
	$lastRow.find("td:eq(1)").find("input:first").click(function(){
		selectSingleRow(this);
	})
	
	$lastRow.find("td:eq(1)").find("input:first").attr('id',"radplnDet"+$lastRow.index())
	.parent().find('label').attr('for',"radplnDet"+$lastRow.index());
	
	$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgliplnName").val());
	$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){
		dhtmlModChange($lastRow);
	});
	
	var plntype = $("#selDlgliplntype > option").clone();
	$lastRow.find("td:eq(3)").find('select:eq(0)').append(plntype);
	$lastRow.find("td:eq(3)").find('select:eq(0)').val($("#selDlgliplntype").val());
	$lastRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
		dhtmlModChange($lastRow);
	});
	
	
	
	
	$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgliplnPremTerm").val());
	$lastRow.find("td:eq(4)").find('input:eq(0)').on("change",function(){
		dhtmlModChange($lastRow);
	});
	
	
	$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgliplnSA").val());
	$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
		dhtmlModChange($lastRow);
	});
	

	$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgliplnPremAmt").val());
	$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntUsd");
	$lastRow.find("td:eq(6)").find('input:eq(0)').on("change",function(){
		calcTotalPlandetails();	
		dhtmlModChange($lastRow);
	});
	
	
	
	

	var paymode = $("#selDlgliplnPayMode > option").clone();
	$lastRow.find("td:eq(7)").find('select:eq(0)').append(paymode);
	$lastRow.find("td:eq(7)").find('select:eq(0)').val($("#selDlgliplnPayMode").val());
	$lastRow.find("td:eq(7)").find('select:eq(0)').on("change",function(){
		calcTotalPlandetails();
		dhtmlModChange($lastRow);
	});

	var paymtd = $("#selDlgliplnPayMtd > option").clone();
	$lastRow.find("td:eq(8)").find('select:eq(0)').append(paymtd);
	$lastRow.find("td:eq(8)").find('select:eq(0)').val($("#selDlgliplnPayMtd").val());
	$lastRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){
		dhtmlModChange($lastRow);
	});
	 
	$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgliplnCoverages").val());
	$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
		dhtmlModChange($lastRow);
	});
	
	$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgliplnRemarks").val());
	$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
		dhtmlModChange($lastRow);
	});
	
	applyEventHandlers();

	
	
	
	if(dataset != null){
 
		
		if(tab == "FPMS_POLICYPLAN_DETS"){
			$lastRow.find("td:eq(0)").find('input:eq(0)').val("I");
		}else{
			$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
		}
		
		
				
		var infoDetsArr = new Array();
		
		for(var data in dataset){
			var col = dataset[data];
			
			switch(data){
			
				case "riderId": 
					$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 					
					break;
					
				case "planName": 
				case "strFPMSPolPlanName":
					$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
					
					break;
					
				case "basorrid": 
				case "strFPMSPolPrdtType":
					selectNullvalChk($lastRow.find("td:eq(3)"),col); 
					break;
					
				case "premTerm": 
				case "strFPMSPolPremTerm":
					$lastRow.find("td:eq(4)").find('input:eq(0)').val(col); 
					break;
				 
				case "sumAssured": 
				case "strFPMSPolSA":
					$lastRow.find("td:eq(5)").find('input:eq(0)').val(col); 
					break;
				 
				case "premAmount":
				case "strFPMSPolPremium":
					$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 
					
					break;
					
				case "paymentMode":
				case "strFPMSPolPaymentMode":
					var mode;
					if(col == "SEMI-ANNUAL" || col=="HALF-YEARLY"){
						mode="HALF YEARLY";
					}else{
						mode=col;
					} 
					selectNullvalChk($lastRow.find("td:eq(7)"),mode);   
					break;
				
				case "paymentMethod": 
				case "strFPMSPolPaymentMeth":
					selectNullvalChk($lastRow.find("td:eq(8)"),col); 
					
					break;
				
				case "coverageTypes": 
					$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
					
					break;
					
				case "planRemarks":
				case "strFPMSPolRemarks":
					$lastRow.find("td:eq(10)").find('input:eq(0)').val(col);  
					break;
					
				case "planCrtdBy": 
					$lastRow.find("td:eq(10)").find('input:eq(1)').val(col);
					infoDetsArr.push(col);				
					break;
					
				case "planCrtdDate":
					$lastRow.find("td:eq(10)").find('input:eq(2)').val(col);
					infoDetsArr.push(col);
					break;
					
				case "planModBy":
					infoDetsArr.push(col);
					break;
					
				case "planModDate":
					infoDetsArr.push(col);
					break;	
					
					
			}			 
			 
		}
		}
	if(dataset == null){
	calcTotalPlandetails();
	}
	liplndetsclearFlds(); 	
	}

	/*Edit Row Click */
	$("#lfplnERow").on("click",function(){
		$("#lfplnVRow").click(); 
	});



	/*View Row Click */
		$("#lfplnVRow").on("click",function(){
			var isOneRowSelected=0;
			var $rowCount = $('#liPlanDetailstbl tbody tr').length;	
			var $lastRow = $("#liPlanDetailstbl tbody tr:last");	
			
			if($rowCount<1){
				showAlert("Insert rows before edit/view!");
				return;
			} 
			
			$("#liPlanDetailstbl tbody tr").each(function(){
				var $row = $(this);   
				$row.removeClass('selected');  
				$(this).removeAttr("style"); 
				$row.find("td").removeAttr("style");
				
					
			});
			
			$("#liPlanDetailstbl tbody").find('input[name="radadRcPlnSelect"]').each(function(){ //Checkbox selection
				var $curElm=$(this);
				if($curElm.is(":checked")){ 
					isOneRowSelected++;
				}
			});
			
			
			if(isOneRowSelected > 1){ 
				showAlert("More than one rows selected.Select one row only");
				return;
			}
			
			
			$("#liPlanDetailstbl tbody").find('input[name="radplnDetSelect"]').each(function(){ //Checkbox selection
				var $curElm=$(this);
				if($curElm.is(":checked")){ 
					var $row = $curElm.parents("tr");                                    
					var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
					$curElm.prop("checked",false);
			     	 $curElm.parents("tr").removeClass('selected');
			     	 
					if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
						 var $RowId=$row.index();
						 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
						 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
								$(this).attr("disabled",false); 
								$row.removeClass('selected');  
								$(this).parent().css({border:'1px solid green'});
								$row.css({border:'1px solid green'});
								$row.find("td").css({border:'1px solid green'}); 
							});  
			 
						 LiPlandetsRdlyflds($mode);
						 liplandlgval($row); 
							showFIPAModel('liPlandets_Dialog','Life Insurance - Plan Details');  
							$('#liPlandets_Dialog').on('shown.bs.modal', function () {
								$("#liPlandets_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
								$("#liPlandets_Dialog").find("input[id=txtFldDlgliplnName]").focus();//Aravindh
								$("#liPlandets_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
									 if(!validateLiPlanDetails())return; 
							     		if(!isEmpty($RowId) && !($RowId==undefined)){  
							     			liplandetsdomval($RowId,$row); 
							     		}  
										$('#liPlandets_Dialog').modal('hide'); 
										liplndetsclearFlds();
									
								});
							});
							 
					}  
					
					if(($mode == QRY_MODE) ){
						 var $RowId=$row.index();
						 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE);
						 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
								$(this).attr("disabled",false); 
								$row.removeClass('selected');  
								$(this).parent().css({border:'1px solid green'});
								$row.css({border:'1px solid green'});
								$row.find("td").css({border:'1px solid green'}); 
							});  
			 
						 LiPlandetsRdlyflds($mode);
						 liplandlgval($row); 
							showFIPAModel('liPlandets_Dialog','Life Insurance - Plan Details');  
							$('#liPlandets_Dialog').on('shown.bs.modal', function () {
								$("#liPlandets_Dialog").find(".modal-footer").find("button:eq(0)").text("OK");
								$("#liPlandets_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
									 if(!validateLiPlanDetails())return; 
							     		if(!isEmpty($RowId) && !($RowId==undefined)){  
							     			liplandetsdomval($RowId,$row); 
							     		}  
							     		calcTotalPlandetails();
										$('#liPlandets_Dialog').modal('hide'); 
										liplndetsclearFlds();
									
								});
							});
							 
					}  
					isOneRowSelected++;
				} 
			});
			
			 
			if(isOneRowSelected==0){
				showAlert("No Rows Selected");
				return;
			} 
			
			
		});
		

/*Delete Row Click */
$("#lfplnDRow").on("click",function(){ 
	datatableDeleteRow('liPlanDetailstbl',liPlanDetailstbl); 
	calcTotalPlandetails();
});




function liplndetsclearFlds(){
	$("#liPlandets_Dialog").find("input[type=text]").val("");
	$("#liPlandets_Dialog").find("textarea").val("");
	$("#liPlandets_Dialog").find("select").val("");   
}
		

/*Disabled/Readonly Fields */
function LiPlandetsRdlyflds(mode){ 
	//alert("mode");
	 if(mode == QRY_MODE ){
		 	$("#liPlandets_Dialog :input").prop("disabled", false);
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#liPlandets_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateLiPlanDetails(){
	 
	if(!(validateFocusFlds('liPlandets_Dialog','txtFldDlgliplnName',LIPD_PLANNAME))) return; 
	if(!(validateFocusFlds('liPlandets_Dialog','selDlgliplntype',LIPD_PLANTYPE))) return; 
	if(!(validateFocusFlds('liPlandets_Dialog','txtFldDlgliplnPremTerm',LIPD_PREMTERM))) return; 
	  return true; 
}	
/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgliplnName,#txtFldDlgliplnPremTerm,#selDlgliplntype").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});

/* Filling Model Fields*/
	function liplandlgval($lastRow){
		 // alert($lastRow.find("td:eq(2)").find('input:eq(0)').val())
		  $('#liPlandets_Dialog #txtFldDlgliplnId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
		  $('#liPlandets_Dialog #txtFldDlgliplnName').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
		  $('#liPlandets_Dialog #selDlgliplntype').val($lastRow.find("td:eq(3)").find('select:eq(0)').val());
		  $('#liPlandets_Dialog #txtFldDlgliplnPremTerm').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
		  $('#liPlandets_Dialog #txtFldDlgliplnSA').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
		  $('#liPlandets_Dialog #txtFldDlgliplnPremAmt').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
		  $('#liPlandets_Dialog #selDlgliplnPayMode').val($lastRow.find("td:eq(7)").find('select:eq(0)').val());
		  $('#liPlandets_Dialog #selDlgliplnPayMtd').val($lastRow.find("td:eq(8)").find('select:eq(0)').val());
		  $('#liPlandets_Dialog #txtFldDlgliplnCoverages').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
		  $('#liPlandets_Dialog #txtFldDlgliplnRemarks').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
		  $('#liPlandets_Dialog #txtFldDlgliplnCrtdBy').val($lastRow.find("td:eq(2)").find('input:eq(1)').val());
		  $('#liPlandets_Dialog #txtFldDlgliplnCrtdDate').val($lastRow.find("td:eq(2)").find('input:eq(2)').val());
	}
	
/* Filling Table Fields*/
	function liplandetsdomval($RowId,$row){
		
		$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgliplnName").val()); 
		$row.find("td:eq(3)").find('select:eq(0)').val($("#selDlgliplntype").val());
		$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgliplnPremTerm").val());
		$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgliplnSA").val()); 
		$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgliplnPremAmt").val()); 
		$row.find("td:eq(7)").find('select:eq(0)').val($("#selDlgliplnPayMode").val()); 
		$row.find("td:eq(8)").find('select:eq(0)').val($("#selDlgliplnPayMtd").val()); 
		$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgliplnCoverages").val()); 
		$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgliplnRemarks").val()); 
		
	}

	
	
function calcTotalPlandetails(){
	 var sumSlf=0,sumSps=0,sumFam=0; 
	 var totsumassure=0,totpremium=0;
	 var $liPlanDetailstblcount = liPlanDetailstbl.rows().count();
//	 alert("$liPlanDetailstblcount  -->"+$liPlanDetailstblcount )
		 
		 var ownship=$("#lipOwner").val();
		 if($liPlanDetailstblcount >0){
			 
				 $("#liPlanDetailstbl tbody tr").each(function(i,row){ 
					 var planpremiumamt=$(this).find("td:eq(6)").find("input:eq(0)").val(); 
					 var sumassuredamt=$(this).find("td:eq(5)").find("input:eq(0)").val();
					 var paymode=$(this).find("td:eq(7)").find("select:eq(0)").val(); 
					 var TopUpAmt=0;
						 if(paymode == 'ANNUALLY'){
								TopUpAmt=1;
							}else if(paymode == 'HALF YEARLY'){
								TopUpAmt=2;
							}else if(paymode == 'QUARTERLY'){
								TopUpAmt=4;
							}else if(paymode == 'MONTHLY'){
								TopUpAmt=12;
							}else if(paymode == 'SINGLE'){
								TopUpAmt=1;
							}
						 
						 var sumamt=planpremiumamt*TopUpAmt;
						 totpremium +=Number(sumamt); 
					 
					 if((!isEmpty(sumamt)) && ownship == "Self"){
						 sumSlf +=Number(sumamt); 
					 }
					 if((!isEmpty(sumamt)) && ownship == "Spouse"){
						 sumSps +=Number(sumamt); 
					 } 
					 if((!isEmpty(sumamt)) && ownship == "Joint"){
						 sumFam +=Number(sumamt); 
					 } 
					 				 
					 
//					 if((!isEmpty(sumamt))){
//						 totpremium +=Number(sumamt); 
//					 } 
					  
					 if((!isEmpty(sumassuredamt))){
						 totsumassure +=Number(sumassuredamt); 
					 } 
					 
					 
			 });
			 
			 
			 
		 }
		 
		 
		 
		 
		 if(!(sumSlf == 0 && sumSps == 0 && sumFam == 0)){
			 applyToastrAlert("Life Insurance Premium is calculated and Reflected to Expected fund Inflow and Outflow Screen");
//			 $("#expdSelfInsurance").val(remPriceAfDec(sumSlf)); 
//		     $("#expdSpsInsurance").val(remPriceAfDec(sumSps));
//		     $("#expdFamilyInsurance").val(remPriceAfDec(sumFam)); 
		 } 
		 
		 $("#expdSelfInsurance").val(remPriceAfDec(sumSlf)); 
	     $("#expdSpsInsurance").val(remPriceAfDec(sumSps));
	     $("#expdFamilyInsurance").val(remPriceAfDec(sumFam)); 
		 
//		 if(!(totpremium == 0 && totsumassure == 0)){
			 $("#retTotalSa").val(remPriceAfDec(totsumassure)); 
		     $("#retTotalPrem").val(remPriceAfDec(totpremium));  
//		 } 
		 
		 
		 
//		 if(sumSlf==0){$("#expdSelfInsurance").val("0");}
//		 if(sumSps==0){$("#expdSpsInsurance").val("0");}
//		 if(sumFam==0){$("#expdFamilyInsurance").val("0");}
//		 if(totpremium==0){$("#retTotalSa").val("0");}//???????
//		 if(totsumassure==0){$("#retTotalPrem").val("0");}//????
	
		 
		 calcSum(this,'SUMOF_ANNEXP_SELF');
		 calcSum(this,'SUMOF_ANNEXP_SPS');
		 calcSum(this,'SUMOF_ANNEXP_FAM');
		 
		 
		 return true;
}	


/*###########################################################################################################################################################*/
/**
 * Retirement Planning - Other payment on retirement
 */

/*Datatable Initialisation*/
var liDeathBenefittbl = $('#liDeathBenefittbl').DataTable( {
	destroy: true,
 	responsive: false,              
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#DthARow").on("click",function(){
			dthbfClearFlds();
			showFIPAModel('liDeathBenf_Dialog','Life Insurance - Death Benefit Details');   
			$('#liDeathBenf_Dialog').on('shown.bs.modal', function () {
				$("#liDeathBenf_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#liDeathBenf_Dialog").find("input[id=txtFldDlgliDfPlnName]").focus();//Aravindh
				$("#liDeathBenf_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatedthbfDetails())return;
					   	dthbfRdlyflds(INS_MODE);  
					   	getliDthBenfRows(null); 
						$('#liDeathBenf_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getliDthBenfRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFlddthbfMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldDfId"><input type="hidden" name="ScrCoverageTypes" value="DEATH BENEFIT">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="raddthbfSelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<input type="text" name="txtFldliDfPlnName"  maxlength="150" onmouseover="fipaTooltip(this);" class="form-control editable"  />'; 
var cell3 = '<input type="text" name="txtFldDfIncepDate"  maxlength="10" onmouseover="fipaTooltip(this);" class="form-control editable"  />';
var cell4 = '<input type="text" name="txtFldDfExpiryDate"  maxlength="10" onmouseover="fipaTooltip(this);" class="form-control editable"  />';
var cell5 = '<input type="text" name="txtFldDfTermOfCov"  maxlength="20"  onmouseover="fipaTooltip(this);" class="form-control editable" />'; 
var cell6 ='<input type="text" name="txtFldDfDeathBenefit"  onmouseover="fipaTooltip(this);" class="form-control editable"  />'+
'<input type="hidden" name="txtFldDfCrtdBy"/><input type="hidden" name="txtFldDfCrtdDate"/>'; 

liDeathBenefittbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6] ).draw( false );

var rowCount = $('#liDeathBenefittbl tbody tr').length;	
var $lastRow = $("#liDeathBenefittbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"raddthbf"+$lastRow.index())
.parent().find('label').attr('for',"raddthbf"+$lastRow.index());

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgliDfPlnName").val());
$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});

$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgDfIncepDate").val());
$lastRow.find("td:eq(3)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
	 
	 checkDateFormat($(this)); 
	 if(!dhtmlChkDateValidation($lastRow.find("td:eq(3)").find('input:eq(0)'),$lastRow.find("td:eq(4)").find('input:eq(0)'),"Expiry Date should greater than the Inception Date"));  
	 dhtmlModChange($lastRow);
});

$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgDfExpiryDate").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
	 checkDateFormat($(this));   
	 if(!dhtmlChkDateValidation($lastRow.find("td:eq(3)").find('input:eq(0)'),$lastRow.find("td:eq(4)").find('input:eq(0)'),"Expiry Date should greater than the Inception Date"));  
	 
	 dhtmlModChange($lastRow);
});


$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgDfTermOfCov").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});


$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgDfDeathBenefit").val());
$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(6)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});

applyEventHandlers();


if(dataset != null){
 
	$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "coverId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col);
				$lastRow.find("td:eq(0)").find('input:eq(2)').val('DEATH BENEFIT');  
				break;
				
			case "coverPlanname": 
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col);   
				break;
				
		 
			case "effDate": 
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col);  
				break;
			 
			case "expiryDate": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col);  
				break;
			 
			case "coverageTerm": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col);  
				break;
			 
			case "coverSumAssured": 
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(col);  
				break;
				
			case "coverCreatedBy": 
				$lastRow.find("td:eq(6)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "coverCreatedDate":
				$lastRow.find("td:eq(6)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "coverModifiedBy":
				infoDetsArr.push(col);
				break;
				
			case "coverModifiedDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}

dthbfClearFlds(); 
}


 
/*Edit Row Click */
$("#DthERow").on("click",function(){
	$("#DthVRow").click(); 
});


/*View Row Click */
$("#DthVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#liDeathBenefittbl tbody tr').length;	
	var $lastRow = $("#liDeathBenefittbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	
	$("#liDeathBenefittbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
	});
	
	
	
	$("#liDeathBenefittbl tbody").find('input[name="raddthbfSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#liDeathBenefittbl tbody").find('input[name="raddthbfSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					});  
	 
				 	dthbfRdlyflds($mode);
					dthbffilldlgval($row); 
					showFIPAModel('liDeathBenf_Dialog','Life Insurance - Death Benefit Details');  
					$('#liDeathBenf_Dialog').on('shown.bs.modal', function () {
						$("#liDeathBenf_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#liDeathBenf_Dialog").find("input[id=txtFldDlgliDfPlnName]").focus();//Aravindh
						$("#liDeathBenf_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatedthbfDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			dthbffilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liDeathBenf_Dialog').modal('hide'); 
								dthbfClearFlds();
							
						});
					});
					 
			}  
		
			
			if($mode == QRY_MODE){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE);  
				 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					});  
	 
				 	dthbfRdlyflds($mode);
					dthbffilldlgval($row); 
					showFIPAModel('liDeathBenf_Dialog','Life Insurance - Death Benefit Details');  
					$('#liDeathBenf_Dialog').on('shown.bs.modal', function () {
						$("#liDeathBenf_Dialog").find(".modal-footer").find("button:eq(0)").text("Ok");
						$("#liDeathBenf_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatedthbfDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			dthbffilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liDeathBenf_Dialog').modal('hide'); 
								dthbfClearFlds();
							
						});
					});
					 
			}  
			
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#DthDRow").on("click",function(){ 
	datatableDeleteRow('liDeathBenefittbl',liDeathBenefittbl); 

});

/*Clear Fields */
function dthbfClearFlds(){
	$("#liDeathBenf_Dialog").find("input[type=text]").val("");
	$("#liDeathBenf_Dialog").find("textarea").val("");
	$("#liDeathBenf_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function dthbfRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#liDeathBenf_Dialog :input").prop("disabled", false); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#liDeathBenf_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatedthbfDetails(){
	 
	if(!(validateFocusFlds('liDeathBenf_Dialog','txtFldDlgliDfPlnName',LIDB_PLANNAME))) return; 
	if(!(validateFocusFlds('liDeathBenf_Dialog','txtFldDlgDfIncepDate',LIDB_INCDATE))) return;
	if(!(validateFocusFlds('liDeathBenf_Dialog','txtFldDlgDfExpiryDate',LIDB_EXPDATE))) return;
	
	  return true; 
}
 

/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgliDfPlnName,#txtFldDlgDfIncepDate,#txtFldDlgDfExpiryDate").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function dthbffilldlgval($lastRow){
	  
	  $('#liDeathBenf_Dialog #txtFldDlgDfId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#liDeathBenf_Dialog #txtFldDlgliDfPlnName').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#liDeathBenf_Dialog #txtFldDlgDfIncepDate').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#liDeathBenf_Dialog #txtFldDlgDfExpiryDate').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#liDeathBenf_Dialog #txtFldDlgDfTermOfCov').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#liDeathBenf_Dialog #txtFldDlgDfDeathBenefit').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#liDeathBenf_Dialog #txtFldDlgDfCrtdBy').val($lastRow.find("td:eq(6)").find('input:eq(1)').val());
	  $('#liDeathBenf_Dialog #txtFldDlgDfCrtdDate').val($lastRow.find("td:eq(6)").find('input:eq(2)').val()); 
	  
	
}

/* Filling Table Fields*/
function dthbffilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgliDfPlnName").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgDfIncepDate").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgDfExpiryDate").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgDfTermOfCov").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgDfDeathBenefit").val()); 
		
}

 /*###########################################################################################################################################################*/
 
 /**
 * Retirement Planning -Disability
 */

/*Datatable Initialisation*/
var liDisabilitytbl = $('#liDisabilitytbl').DataTable( {
	destroy: true,
 	responsive: false,              
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#DsbltyARow").on("click",function(){
			dsbltyClearFlds();
			showFIPAModel('liDisabilty_Dialog','Life Insurance - Disability Details');   
			$('#liDisabilty_Dialog').on('shown.bs.modal', function () {
				$("#liDisabilty_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#liDisabilty_Dialog").find("select[id=selDlgliDsbltyTypes]").focus();//Aravindh
				$("#liDisabilty_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatedsbltyDetails())return;
					   	dsbltyRdlyflds(INS_MODE);  
					   	getDsbltyRows(null); 
						$('#liDisabilty_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getDsbltyRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFlddsbltyMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldliDsbltyId"><input type="hidden" name="ScrCoverageTypes" value="DISABILITY">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="raddsbltySelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<select  name="selliDsbltyTypes"  onmouseover="fipaTooltip(this);" class="form-control editable" ></select>'; 
var cell3 = '<input type="text" name="txtFldliDsbltyYrBegins" maxlength="20" onmouseover="fipaTooltip(this);" class="form-control editable"  />';
var cell4 = '<input type="text" name="txtFldliDsbltyYrCeases" maxlength="20" onmouseover="fipaTooltip(this);" class="form-control editable"  />';
var cell5 = '<input type="text" name="txtFldliDsbltyBenf"  onmouseover="fipaTooltip(this);"class="form-control editable"  />'; 
var cell6 ='<input type="text" name="txtFldliDsbltyIncBenf"  onmouseover="fipaTooltip(this);" class="form-control editable" />'+
'<input type="hidden" name="txtFldliDsbltyCrtdBy"/><input type="hidden" name="txtFldliDsbltyCrtdDate"/>'; 

liDisabilitytbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6] ).draw( false );

var rowCount = $('#liDisabilitytbl tbody tr').length;	
var $lastRow = $("#liDisabilitytbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"raddsblty"+$lastRow.index())
.parent().find('label').attr('for',"raddsblty"+$lastRow.index());



var sel1 = $("#selDlgliDsbltyTypes > option").clone();
$lastRow.find("td:eq(2)").find('select:eq(0)').append(sel1);
$lastRow.find("td:eq(2)").find('select:eq(0)').val($("#selDlgliDsbltyTypes").val()); 
$lastRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});

$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgliDsbltyYrBegins").val()); 
$lastRow.find("td:eq(3)").find('input:eq(0)').on("change", function(){
	disablityYrBegin($(this),$lastRow.find("td:eq(4)").find('input:eq(0)'));
	dhtmlModChange($lastRow);
});


$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgliDsbltyYrCeases").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').on("change", function(){
		disablityYrCeases($(this),$lastRow.find("td:eq(3)").find('input:eq(0)'));
		dhtmlModChange($lastRow);
});


$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgliDsbltyBenf").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});

$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgliDsbltyIncBenf").val());
$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent");
$lastRow.find("td:eq(6)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);	
});

applyEventHandlers();


if(dataset != null){

	
//			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
//					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
//			}
	$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "benfId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col);
				$lastRow.find("td:eq(0)").find('input:eq(2)').val('DISABILITY');  
				break;
				
			case "befType":
				selectNullvalChk($lastRow.find("td:eq(2)"),col);  
				break;
				
		 
			case "startYr": 
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col);  
				break;
			 
			case "endYr": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col);  
				break;
			 
			case "benfValue": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col);  
				break;
			 
			case "bnefIncr": 
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(col);  
				break;
				
			case "benfCrtdBy": 
				$lastRow.find("td:eq(6)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "benfCrtdDate":
				$lastRow.find("td:eq(6)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "benfModBy":
				infoDetsArr.push(col);
				break;
				
			case "benfModDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}

dsbltyClearFlds(); 
}


 
/*Edit Row Click */
$("#DsbltyERow").on("click",function(){
	$("#DsbltyVRow").click();
	
//	var isOneRowSelected=false;
//	$("#liDisabilitytbl tbody").find('input[name="raddsbltySelect"]').each(function(){ 
//		if($(this).is(":checked")){ 
//			var $row = $(this).parents("tr"); 
//			var $mode = $(this).parents("tr").find("td:first").find('input:eq(0)').val(); 
//			
//			 
//			if($mode == INS_MODE){ 
//				$(this).parents("tr").find("td:first").find('input:eq(0)').val($mode); 
//				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
//					$(this).attr("disabled",false); 
//					$row.removeClass('selected');  
//					$(this).parent().css({border:'1px solid green'});
//					$row.css({border:'1px solid green'});
//					$row.find("td").css({border:'1px solid green'});
//				});  
//			}
//
//			if($mode == QRY_MODE){
//				
//				$(this).parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE); 
//				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
//					$(this).attr("disabled",false); 
//					$row.removeClass('selected');  
//					$(this).parent().css({border:'1px solid green'});
//					$row.css({border:'1px solid green'});
//					$row.find("td").css({border:'1px solid green'});
//				});
//				 
//			
//			}
//			$(this).attr("checked",false);
//			isOneRowSelected=true;
//		}
//	});	    
//	if(!isOneRowSelected){
//		showAlert("No Rows Selected");
//	}
});


/*View Row Click */
$("#DsbltyVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#liDisabilitytbl tbody tr').length;	
	var $lastRow = $("#liDisabilitytbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	
	$("#liDisabilitytbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
		
			
	});
	
	
	
	$("#liDisabilitytbl tbody").find('input[name="raddsbltySelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#liDisabilitytbl tbody").find('input[name="raddsbltySelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);
				 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					}); 
				 	dsbltyRdlyflds($mode);
					dsbltyfilldlgval($row); 
					showFIPAModel('liDisabilty_Dialog','Life Insurance - Disability Details');  
					$('#liDisabilty_Dialog').on('shown.bs.modal', function () {
						$("#liDisabilty_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#liDisabilty_Dialog").find("select[id=selDlgliDsbltyTypes]").focus();//Aravindh
						$("#liDisabilty_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatedsbltyDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			dsbltyfilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liDisabilty_Dialog').modal('hide'); 
								dsbltyClearFlds();
							
						});
					});
					 
			}  
			if($mode == QRY_MODE){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE);  
				 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					}); 
				 	dsbltyRdlyflds($mode);
					dsbltyfilldlgval($row); 
					showFIPAModel('liDisabilty_Dialog','Life Insurance - Disability Details');  
					$('#liDisabilty_Dialog').on('shown.bs.modal', function () {
						$("#liDisabilty_Dialog").find(".modal-footer").find("button:eq(0)").text("Ok");
						$("#liDisabilty_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatedsbltyDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			dsbltyfilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liDisabilty_Dialog').modal('hide'); 
								dsbltyClearFlds();
							
						});
					});
					 
			}
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#DsbltyDRow").on("click",function(){ 
	datatableDeleteRow('liDisabilitytbl',liDisabilitytbl); 

});

/*Clear Fields */
function dsbltyClearFlds(){
	$("#liDisabilty_Dialog").find("input[type=text]").val("");
	$("#liDisabilty_Dialog").find("textarea").val("");
	$("#liDisabilty_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function dsbltyRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#liDisabilty_Dialog :input").prop("disabled", false); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#liDisabilty_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatedsbltyDetails(){
	 
	if(!(validateFocusFlds('liDisabilty_Dialog','selDlgliDsbltyTypes',LIDSB_TYPE))) return; 
	if(!(validateFocusFlds('liDisabilty_Dialog','txtFldDlgliDsbltyYrBegins',LIDSB_BEGINS))) return;
	if(!(validateFocusFlds('liDisabilty_Dialog','txtFldDlgliDsbltyYrCeases',LIDSB_CEASES))) return;
	
	  return true; 
}
 

/*Mandatory Fields Tooltip*/ 
$("#selDlgliDsbltyTypes,#txtFldDlgliDsbltyYrBegins,#txtFldDlgliDsbltyYrCeases").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function dsbltyfilldlgval($lastRow){
	  
	  $('#liDisabilty_Dialog #txtFldDlgliDsbltyId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#liDisabilty_Dialog #selDlgliDsbltyTypes').val($lastRow.find("td:eq(2)").find('select:eq(0)').val());
	  $('#liDisabilty_Dialog #txtFldDlgliDsbltyYrBegins').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#liDisabilty_Dialog #txtFldDlgliDsbltyYrCeases').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#liDisabilty_Dialog #txtFldDlgliDsbltyBenf').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#liDisabilty_Dialog #txtFldDlgliDsbltyIncBenf').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#liDisabilty_Dialog #txtFldDlgliDsbltyCrtdBy').val($lastRow.find("td:eq(6)").find('input:eq(1)').val());
	  $('#liDisabilty_Dialog #txtFldDlgliDsbltyCrtdDate').val($lastRow.find("td:eq(6)").find('input:eq(2)').val()); 
	  
	
}

/* Filling Table Fields*/
function dsbltyfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('select:eq(0)').val($("#selDlgliDsbltyTypes").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgliDsbltyYrBegins").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgliDsbltyYrCeases").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgliDsbltyBenf").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgliDsbltyIncBenf").val()); 
	                                                  
}

 
 /*###########################################################################################################################################################*/
 /**
 * Retirement Planning -Critical Illness
 * 
 */

/*Datatable Initialisation*/
var liCriticalIllnesstbl = $('#liCriticalIllnesstbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#CrtlARow").on("click",function(){
			crtlnsClearFlds();
			showFIPAModel('liCrtclIllns_Dialog','Life Insurance - Critical Illness Details');   
			$('#liCrtclIllns_Dialog').on('shown.bs.modal', function () {
				$("#liCrtclIllns_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#liCrtclIllns_Dialog").find("select[id=selDlgCrtlnsLvlDD]").focus();//Aravindh
				$("#liCrtclIllns_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatecrtlnsDetails())return;
					   	crtlnsRdlyflds(INS_MODE);  
					   	getlicrtlnsRows(null); 
						$('#liCrtclIllns_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getlicrtlnsRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldcrtlnsMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldCrtlnsId"><input type="hidden" name="ScrCoverageTypes" value="CRITICAL ILLNESS">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radcrtlnsSelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<select  name="selCrtlnsLvlDD"  onmouseover="fipaTooltip(this);" class="form-control editable" ></select>'; 
var cell3 = '<input type="text" name="txtFldCrtlnsExpDate"  maxlength="10" onmouseover="fipaTooltip(this);" class="form-control editable"   />';
var cell4 = '<input type="text" name="txtFldCrtlnsBenfAmt"  onmouseover="fipaTooltip(this);" class="form-control editable"   />';
var cell5 = '<input type="text" name="txtFldCrtlnsTermofBenf"  onmouseover="fipaTooltip(this);" class="form-control editable"  />'; 
var cell6 ='<input type="text" name="txtFldCrtlnsRemarks"  maxlength="300" onmouseover="fipaTooltip(this);" class="form-control editable"   />'+
'<input type="hidden" name="txtFldCrtlnsCrtdBy"/><input type="hidden" name="txtFldCrtlnsCrtdDate"/>'; 

liCriticalIllnesstbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6] ).draw( false );

var rowCount = $('#liCriticalIllnesstbl tbody tr').length;	
var $lastRow = $("#liCriticalIllnesstbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radcrtlns"+$lastRow.index())
.parent().find('label').attr('for',"radcrtlns"+$lastRow.index());



var sel1 = $("#selDlgCrtlnsLvlDD > option").clone();
$lastRow.find("td:eq(2)").find('select:eq(0)').append(sel1);
$lastRow.find("td:eq(2)").find('select:eq(0)').val($("#selDlgCrtlnsLvlDD").val()); 
$lastRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);	
});

$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgCrtlnsExpDate").val()); 
$lastRow.find("td:eq(3)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
	 checkDateFormat($(this));   
	 dhtmlModChange($lastRow);
});


$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgCrtlnsBenfAmt").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(4)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});

$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgCrtlnsTermofBenf").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});


$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgCrtlnsRemarks").val());
$lastRow.find("td:eq(6)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});

applyEventHandlers();


if(dataset != null){
 
	$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "coverId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col);
				$lastRow.find("td:eq(0)").find('input:eq(2)').val('CRITICAL ILLNESS');  
				break;
				
			case "coverLevelortype":
				selectNullvalChk($lastRow.find("td:eq(2)"),col);  
				break;
				
		 
			case "expiryDate": 
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col);  
				break;
			 
			case "coverSumAssured": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col);  
				break;
			 
			case "coverageTerm": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col);  
				break;
			 
			case "coverRemarks": 
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(col);  
				break;
				
			case "coverCreatedBy": 
				$lastRow.find("td:eq(6)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "coverCreatedDate":
				$lastRow.find("td:eq(6)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "coverModifiedBy":
				infoDetsArr.push(col);
				break;
				
			case "coverModifiedDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}

crtlnsClearFlds(); 
}


 
/*Edit Row Click */
$("#CrtlERow").on("click",function(){
	$("#CrtlVRow").click(); 
});


/*View Row Click */
$("#CrtlVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#liCriticalIllnesstbl tbody tr').length;	
	var $lastRow = $("#liCriticalIllnesstbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	
	
	$("#liCriticalIllnesstbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
		
			
	});
	
	
	
	$("#liCriticalIllnesstbl tbody").find('input[name="radcrtlnsSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#liCriticalIllnesstbl tbody").find('input[name="radcrtlnsSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 	crtlnsRdlyflds($mode);
					crtlnsfilldlgval($row); 
					showFIPAModel('liCrtclIllns_Dialog','Life Insurance - Critical Illness Details');  
					$('#liCrtclIllns_Dialog').on('shown.bs.modal', function () {
						$("#liCrtclIllns_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#liCrtclIllns_Dialog").find("select[id=selDlgCrtlnsLvlDD]").focus();//Aravindh
						$("#liCrtclIllns_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatecrtlnsDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			crtlnsfilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liCrtclIllns_Dialog').modal('hide'); 
								crtlnsClearFlds();
							
						});
					});
					 
			}  
			if(($mode ==QRY_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE);  
				 	crtlnsRdlyflds($mode);
					crtlnsfilldlgval($row); 
					showFIPAModel('liCrtclIllns_Dialog','Life Insurance - Critical Illness Details');  
					$('#liCrtclIllns_Dialog').on('shown.bs.modal', function () {
						$("#liCrtclIllns_Dialog").find(".modal-footer").find("button:eq(0)").text("Ok");
						$("#liCrtclIllns_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatecrtlnsDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			crtlnsfilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liCrtclIllns_Dialog').modal('hide'); 
								crtlnsClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#CrtlDRow").on("click",function(){ 
	datatableDeleteRow('liCriticalIllnesstbl',liCriticalIllnesstbl); 

});

/*Clear Fields */
function crtlnsClearFlds(){
	$("#liCrtclIllns_Dialog").find("input[type=text]").val("");
	$("#liCrtclIllns_Dialog").find("textarea").val("");
	$("#liCrtclIllns_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function crtlnsRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#liCrtclIllns_Dialog :input").prop("disabled", false); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#liCrtclIllns_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatecrtlnsDetails(){
	 
	if(!(validateFocusFlds('liCrtclIllns_Dialog','selDlgCrtlnsLvlDD',LICL_LVLDD))) return; 
	if(!(validateFocusFlds('liCrtclIllns_Dialog','txtFldDlgCrtlnsExpDate',LICL_EXPDATE))) return;
	if(!(validateFocusFlds('liCrtclIllns_Dialog','txtFldDlgCrtlnsBenfAmt',LICL_BENAMT))) return;
	
	  return true; 
}
 

/*Mandatory Fields Tooltip*/ 
$("#selDlgCrtlnsLvlDD,#txtFldDlgCrtlnsExpDate,#txtFldDlgCrtlnsBenfAmt").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function crtlnsfilldlgval($lastRow){
	  
	  $('#liCrtclIllns_Dialog #txtFldDlgCrtlnsId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#liCrtclIllns_Dialog #selDlgCrtlnsLvlDD').val($lastRow.find("td:eq(2)").find('select:eq(0)').val());
	  $('#liCrtclIllns_Dialog #txtFldDlgCrtlnsExpDate').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#liCrtclIllns_Dialog #txtFldDlgCrtlnsBenfAmt').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#liCrtclIllns_Dialog #txtFldDlgCrtlnsTermofBenf').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#liCrtclIllns_Dialog #txtFldDlgCrtlnsRemarks').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#liCrtclIllns_Dialog #txtFldDlgCrtlnsCrtdBy').val($lastRow.find("td:eq(6)").find('input:eq(1)').val());
	  $('#liCrtclIllns_Dialog #txtFldDlgCrtlnsCrtdDate').val($lastRow.find("td:eq(6)").find('input:eq(2)').val()); 
	  
	
}

/* Filling Table Fields*/
function crtlnsfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('select:eq(0)').val($("#selDlgCrtlnsLvlDD").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgCrtlnsExpDate").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgCrtlnsBenfAmt").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgCrtlnsTermofBenf").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgCrtlnsRemarks").val()); 
		
}

 
 
 /*###########################################################################################################################################################*/
 /**
 * Retirement Planning -Hospitalisation
 * 
 */

/*Datatable Initialisation*/
var liHospitilisationtbl = $('#liHospitilisationtbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#HospARow").on("click",function(){
			hospClearFlds();
			showFIPAModel('liHospitalisation_Dialog','Life Insurance - Hospitalisation Details');   
			$('#liHospitalisation_Dialog').on('shown.bs.modal', function () {
				$("#liHospitalisation_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#liHospitalisation_Dialog").find("input[id=txtFldDlgHospClsOfBenf]").focus();//Aravindh
				$("#liHospitalisation_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatehospDetails())return;
					   	hospRdlyflds(INS_MODE);  
					   	getlihospRows(null); 
						$('#liHospitalisation_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getlihospRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldhospMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldHospId"><input type="hidden" name="ScrCoverageTypes" value="HOSPITALITY">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radhospSelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<input type="text" name="txtFldHospClsOfBenf"  maxlength="10" onmouseover="fipaTooltip(this);" class="form-control editable" />'; 
var cell3 = '<input type="text" name="txtFldHospTermOfCov"  onmouseover="fipaTooltip(this);" class="form-control editable" />';
var cell4 = '<input type="text" name="txtFldHospDedctble"  onmouseover="fipaTooltip(this);" class="form-control editable"  />'; 
var cell5 ='<input type="text" name="txtFldHospCoIns"  onmouseover="fipaTooltip(this);" class="form-control editable"  />'+
'<input type="hidden" name="txtFldHospCrtdBy"/><input type="hidden" name="txtFldHospCrtdDate"/>'; 

liHospitilisationtbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5] ).draw( false );

var rowCount = $('#liHospitilisationtbl tbody tr').length;	
var $lastRow = $("#liHospitilisationtbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radhosp"+$lastRow.index())
.parent().find('label').attr('for',"radhosp"+$lastRow.index());

 
$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgHospClsOfBenf").val()); 
$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
});

$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgHospTermOfCov").val());
$lastRow.find("td:eq(3)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 	
});



$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgHospDedctble").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(4)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
	 
});



$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgHospCoIns").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntpCent");
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
	 	
});



applyEventHandlers();


if(dataset != null){
 
	$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "coverId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col);
				$lastRow.find("td:eq(0)").find('input:eq(2)').val('HOSPITALITY');  
				break;
				
			case "coverBasorrid":
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col);  
				break;
				
		 
			case "coverageTerm": 
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
				break;
			 
			case "coverDeductable": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col);  
				break;
			 
			case "coInsurance": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col);  
				break;
			  
			case "coverCreatedBy": 
				$lastRow.find("td:eq(5)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "coverCreatedDate":
				$lastRow.find("td:eq(5)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "coverModifiedBy":
				infoDetsArr.push(col);
				break;
				
			case "coverModifiedDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}

hospClearFlds(); 
}


 
/*Edit Row Click */
$("#HospERow").on("click",function(){
	$("#HospVRow").click(); 
});


/*View Row Click */
$("#HospVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#liHospitilisationtbl tbody tr').length;	
	var $lastRow = $("#liHospitilisationtbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#liHospitilisationtbl tbody").find('input[name="radhospSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#liHospitilisationtbl tbody").find('input[name="radhospSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'});
				});  
				 	hospRdlyflds($mode);
					hospfilldlgval($row); 
					showFIPAModel('liHospitalisation_Dialog','Life Insurance - Hospitalisation Details');  
					$('#liHospitalisation_Dialog').on('shown.bs.modal', function () {
						$("#liHospitalisation_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#liHospitalisation_Dialog").find("input[id=txtFldDlgHospClsOfBenf]").focus();//Aravindh
						$("#liHospitalisation_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatehospDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			hospfilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liHospitalisation_Dialog').modal('hide'); 
								hospClearFlds();
							
						});
					});
					 
			}  
			
			 
			if(($mode == QRY_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE);  
				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'});
				});  
				 	hospRdlyflds($mode);
					hospfilldlgval($row); 
					showFIPAModel('liHospitalisation_Dialog','Life Insurance - Hospitalisation Details');  
					$('#liHospitalisation_Dialog').on('shown.bs.modal', function () {
						$("#liHospitalisation_Dialog").find(".modal-footer").find("button:eq(0)").text("Ok");
						$("#liHospitalisation_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatehospDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			hospfilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liHospitalisation_Dialog').modal('hide'); 
								hospClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#HospDRow").on("click",function(){ 
	datatableDeleteRow('liHospitilisationtbl',liHospitilisationtbl); 

});

/*Clear Fields */
function hospClearFlds(){
	$("#liHospitalisation_Dialog").find("input[type=text]").val("");
	$("#liHospitalisation_Dialog").find("textarea").val("");
	$("#liHospitalisation_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function hospRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#liHospitalisation_Dialog :input").prop("disabled", false); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#liHospitalisation_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatehospDetails(){
	 
	if(!(validateFocusFlds('liHospitalisation_Dialog','txtFldDlgHospClsOfBenf',LIHSP_CLS))) return; 
	if(!(validateFocusFlds('liHospitalisation_Dialog','txtFldDlgHospTermOfCov',LIHSP_COV))) return;
	if(!(validateFocusFlds('liHospitalisation_Dialog','txtFldDlgHospDedctble',LIHSP_DED))) return;
	
	  return true; 
}
 

/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgHospClsOfBenf,#txtFldDlgHospTermOfCov,#txtFldDlgHospDedctble").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function hospfilldlgval($lastRow){
	  
	  $('#liHospitalisation_Dialog #txtFldDlgHospId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#liHospitalisation_Dialog #txtFldDlgHospClsOfBenf').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#liHospitalisation_Dialog #txtFldDlgHospTermOfCov').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#liHospitalisation_Dialog #txtFldDlgHospDedctble').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#liHospitalisation_Dialog #txtFldDlgHospCoIns').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#liHospitalisation_Dialog #txtFldDlgHospCrtdBy').val($lastRow.find("td:eq(5)").find('input:eq(1)').val()); 
	  $('#liHospitalisation_Dialog #txtFldDlgHospCrtdDate').val($lastRow.find("td:eq(5)").find('input:eq(2)').val()); 
	  
	
}

/* Filling Table Fields*/
function hospfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgHospClsOfBenf").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgHospTermOfCov").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgHospDedctble").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgHospCoIns").val());  
		
}

 
 
 /*###########################################################################################################################################################*/
 /**
 * Retirement Planning -Education
 * 
 */

/*Datatable Initialisation*/
var liEducationtbl = $('#liEducationtbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#lfEduPlgARow").on("click",function(){
			eduplgClearFlds();
			showFIPAModel('liEducationPlg_Dialog','Life Insurance - Education Planning Details');   
			$('#liEducationPlg_Dialog').on('shown.bs.modal', function () {
				$("#liEducationPlg_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#liEducationPlg_Dialog").find("select[id=selDlgEdPlgChldName]").focus();//Aravindh
				$("#liEducationPlg_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validateeduplgDetails())return;
					   	eduplgRdlyflds(INS_MODE);  
					   	getlieduplgRows(null); 
						$('#liEducationPlg_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getlieduplgRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldeduplgMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldEduPlgId">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radeduplgSelect"/><label>&nbsp;</label></div>'; 
var cell2 ='<select  name="selEdPlgChldName"  onmouseover="fipaTooltip(this);" class="form-control editable" ></select>';	 
var cell3 ='<input type="text" name="txtFldEdPlgTerEdcAge" maxlength="20" onmouseover="fipaTooltip(this);" class="form-control editable" />';	
var cell4 ='<input type="text" name="txtFldEdPlgBankIntRate"  onmouseover="fipaTooltip(this);" class="form-control editable"/>';	
var cell5='<input type="text" name="txtFldEdPlgInfRate"  onmouseover="fipaTooltip(this);" class="form-control editable"/>';	
var cell6='<input type="text" name="txtFldEduPlgChlBegAge" maxlength="20" onmouseover="fipaTooltip(this);" class="form-control editable" />';	
var cell7='<input type="text" name="txtFldEduPlgTotProPaid"  onmouseover="fipaTooltip(this);" class="form-control editable" />';	
var cell8='<input type="text" name="txtFldEduPlgChldTerAge"  onmouseover="fipaTooltip(this);" class="form-control editable" />'+
'<input type="hidden" name="txtFldEduPlgCrtdBy"/><input type="hidden" name="txtFldEduPlgCrtdDate"/>';


liEducationtbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8] ).draw( false );

var rowCount = $('#liEducationtbl tbody tr').length;	
var $lastRow = $("#liEducationtbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radeduplg"+$lastRow.index())
.parent().find('label').attr('for',"radeduplg"+$lastRow.index());

 
var sel1 = $("#selDlgEdPlgChldName > option").clone();
$lastRow.find("td:eq(2)").find('select:eq(0)').append(sel1);
$lastRow.find("td:eq(2)").find('select:eq(0)').val($("#selDlgEdPlgChldName").val()); 
$lastRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 
});


$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgEdPlgTerEdcAge").val()); 
$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 
});


$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgEdPlgBankIntRate").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntpCent26");
$lastRow.find("td:eq(4)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 
});


$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgEdPlgInfRate").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntpCent26");
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 
});


$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgEduPlgChlBegAge").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgEduPlgTotProPaid").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 
});

$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgEduPlgChldTerAge").val());
$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(8)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 
});

applyEventHandlers();


if(dataset != null){

	 
	$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "chliId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col);  
				break;
				
				

			case "childName":
				selectNullvalChk($lastRow.find("td:eq(2)"),col);  
				break;
				
	
			case "terEdcAge":
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col);  
				break;
				
		 
			case "bankIntRate": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col);  
				break;
			 
			case "inflationRate": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col);  
				break;
			 
			case "startAge": 
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(col);  
				break;
				
			case "paidByPolicy": 
				$lastRow.find("td:eq(7)").find('input:eq(0)').val(col);  
				break;  
				
			case "convertVal": 
				$lastRow.find("td:eq(8)").find('input:eq(0)').val(col);  
				break; 
				
				
			case "chliCrtdBy": 
				$lastRow.find("td:eq(8)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "chliCrtdDate":
				$lastRow.find("td:eq(8)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "chliModBy":
				infoDetsArr.push(col);
				break;
				
			case "chliModDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}

eduplgClearFlds(); 
}


 
/*Edit Row Click */
$("#lfEduPlgERow").on("click",function(){
	$("#lfEduPlgVRow").click(); 
});


/*View Row Click */
$("#lfEduPlgVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#liEducationtbl tbody tr').length;	
	var $lastRow = $("#liEducationtbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#liEducationtbl tbody").find('input[name="radeduplgSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#liEducationtbl tbody").find('input[name="radeduplgSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 	eduplgRdlyflds($mode);
					eduplgfilldlgval($row); 
					showFIPAModel('liEducationPlg_Dialog','Life Insurance - Education Planning Details');  
					$('#liEducationPlg_Dialog').on('shown.bs.modal', function () {
						$("#liEducationPlg_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#liEducationPlg_Dialog").find("select[id=selDlgEdPlgChldName]").focus();//Aravindh
						$("#liEducationPlg_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateeduplgDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			eduplgfilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liEducationPlg_Dialog').modal('hide'); 
								eduplgClearFlds();
							
						});
					});
					 
			} 
			
			if(($mode == QRY_MODE)){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE);  
				 	eduplgRdlyflds($mode);
					eduplgfilldlgval($row); 
					showFIPAModel('liEducationPlg_Dialog','Life Insurance - Education Planning Details');  
					$('#liEducationPlg_Dialog').on('shown.bs.modal', function () {
						$("#liEducationPlg_Dialog").find(".modal-footer").find("button:eq(0)").text("OK");
						$("#liEducationPlg_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateeduplgDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			eduplgfilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liEducationPlg_Dialog').modal('hide'); 
								eduplgClearFlds();
							
						});
					});
					 
			} 
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#lfEduPlgDRow").on("click",function(){ 
	datatableDeleteRow('liEducationtbl',liEducationtbl); 

});

/*Clear Fields */
function eduplgClearFlds(){
	$("#liEducationPlg_Dialog").find("input[type=text]").val("");
	$("#liEducationPlg_Dialog").find("textarea").val("");
	$("#liEducationPlg_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function eduplgRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#liEducationPlg_Dialog :input").prop("disabled", false); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#liEducationPlg_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateeduplgDetails(){
	 
	if(!(validateFocusFlds('liEducationPlg_Dialog','selDlgEdPlgChldName',LIEDU_CHLDNAME))) return; 
	if(!(validateFocusFlds('liEducationPlg_Dialog','txtFldDlgEdPlgTerEdcAge',LIEDU_TEREDAGE))) return;
	if(!(validateFocusFlds('liEducationPlg_Dialog','txtFldDlgEdPlgBankIntRate',LIEDU_BANKRATE))) return;
	
	  return true; 
}
 

/*Mandatory Fields Tooltip*/ 
$("#selDlgEdPlgChldName,#txtFldDlgEdPlgTerEdcAge,#txtFldDlgEdPlgBankIntRate").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function eduplgfilldlgval($lastRow){
	  
	  $('#liEducationPlg_Dialog #txtFldDlgEduPlgId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#liEducationPlg_Dialog #selDlgEdPlgChldName').val($lastRow.find("td:eq(2)").find('select:eq(0)').val());
	  $('#liEducationPlg_Dialog #txtFldDlgEdPlgTerEdcAge').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#liEducationPlg_Dialog #txtFldDlgEdPlgBankIntRate').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#liEducationPlg_Dialog #txtFldDlgEdPlgInfRate').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#liEducationPlg_Dialog #txtFldDlgEduPlgChlBegAge').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#liEducationPlg_Dialog #txtFldDlgEduPlgTotProPaid').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#liEducationPlg_Dialog #txtFldDlgEduPlgChldTerAge').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#liEducationPlg_Dialog #txtFldDlgEduPlgCrtdBy').val($lastRow.find("td:eq(8)").find('input:eq(1)').val()); 
	  $('#liEducationPlg_Dialog #txtFldDlgEduPlgCrtdDate').val($lastRow.find("td:eq(8)").find('input:eq(2)').val()); 
	  
	
}

/* Filling Table Fields*/
function eduplgfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('select:eq(0)').val($("#selDlgEdPlgChldName").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgEdPlgTerEdcAge").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgEdPlgBankIntRate").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgEdPlgInfRate").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgEduPlgChlBegAge").val()); 
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgEduPlgTotProPaid").val());
	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgEduPlgChldTerAge").val());   
		
}

 
 
 /*###########################################################################################################################################################*/
 /**
 * Retirement Planning -Retirement
 * 
 */

/*Datatable Initialisation*/
var liRetirementPlgtbl = $('#liRetirementPlgtbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#lfRetPlgARow").on("click",function(){
	
	var disimburse = $("#retMultionret").val();
	if(disimburse == "Y"){
		
		
		retplgClearFlds();
		showFIPAModel('liRetirementPlg_Dialog','Life Insurance - Retirement Planning Details');
		
		var savingdeprate = $("#caSavingDeprate");
		var liretbankintrate = $("#txtFldDlgRetPlgAssBankIntRate");
		if(isEmpty(liretbankintrate.val())){
			liretbankintrate.val(savingdeprate.val());
		}
		
		$('#liRetirementPlg_Dialog').on('shown.bs.modal', function () {
			$("#liRetirementPlg_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
			$("#liRetirementPlg_Dialog").find("input[id=txtFldDlgRetPlgCommOfAge]").focus();//Aravindh
			$("#liRetirementPlg_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
					if(!validateretplgDetails())return;
				   	retplgRdlyflds(INS_MODE);  
				   	getRetPlgRows(null); 
					$('#liRetirementPlg_Dialog').modal('hide'); 
			  });  
		});
		
	}else{
		if(isEmpty(disimburse)){
			showAlert("Select the multiple disbursment of income", $("#retMultionret"));
			return false;
		}else{
			showAlert("Since the multiple disbursment of income is No");
		}
		
	}
	
			
			
			
});



/*Populate Data */
function getRetPlgRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldretplgMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldMvRetId">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radretplgSelect"/><label>&nbsp;</label></div>'; 
 
var cell2 ='<input type="text" name="txtFldCommenceAge" onmouseover="fipaTooltip(this);" class="form-control editable"  />';	 
var cell3 ='<input type="text" name="txtFldEndAge"  onmouseover="fipaTooltip(this);" class="form-control editable" />';	 
var cell4= '<input type="text" name="txtFldEsclationRate" onmouseover="fipaTooltip(this);"  class="form-control editable" />';  
var cell5='<input type="text" name="txtFldGtdIncome" onmouseover="fipaTooltip(this);" class="form-control editable"  />';	 
var cell6 ='<input type="text" name="txtFldNonGtdIncome"  onmouseover="fipaTooltip(this);" class="form-control editable" />';
var cell6_1 ='<input type="text" name="txtFldTotalIncome"  onmouseover="fipaTooltip(this);" class="form-control editable" />';
var cell7 = '<input type="text" name="txtFldIncomeStream" class="form-control editable" />'; 
var cell8= '<input type="text" name="txtFldPvFvOnRet" class="form-control editable" />';
var cell9 ='<input type="text" name="txtFldAssumedBankInt" class="form-control editable" />'+
'<input type="hidden" name="txtFldMvRetCrtdBy"/><input type="hidden" name="txtFldMvRetCrtdDate"/>'; 


 
liRetirementPlgtbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell6_1,cell7,cell8,cell9] ).draw( false );

var rowCount = $('#liRetirementPlgtbl tbody tr').length;	
var $lastRow = $("#liRetirementPlgtbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radretplg"+$lastRow.index())
.parent().find('label').attr('for',"radretplg"+$lastRow.index());

  

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgRetPlgCommOfAge").val()); 
$lastRow.find("td:eq(2)").find('input:eq(0)').addClass("applyEvntYrs"); 
$lastRow.find("td:eq(2)").find('input:eq(0)').on("change", function(){
	StartAgeValidate($(this),$lastRow.find("td:eq(3)").find('input:eq(0)'));
	setRetPlanMVIncomeDhtml($lastRow);
	setRetPlanMVRetAgeDhtml($lastRow);
	dhtmlModChange($lastRow); 
	RetPlgcalculateRow(); 
});



$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgRetPlgEndOfAge").val());
$lastRow.find("td:eq(3)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(3)").find('input:eq(0)').on("change", function(){

	EndAgeValidate($(this),$lastRow.find("td:eq(2)").find('input:eq(0)'));
	dhtmlModChange($lastRow); 
	RetPlgcalculateRow(); 
	EndAgeValidate($(this),$lastRow.find("td:eq(2)").find('input:eq(0)'));
});

$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgRetPlgEscaltAge").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntpCent3");
$lastRow.find("td:eq(4)").find('input:eq(0)').on("change", function(){

	dhtmlModChange($lastRow); 
	RetPlgcalculateRow(); 
}); 

$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgRetPlgGTDIncome").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd26");
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change", function(){
	
	$lastRow.find("td:eq(7)").find('input:eq(0)').val(setTotalGtdDhtml($lastRow));
	setRetPlanMVIncomeDhtml($lastRow);
	setRetPlanMVRetAgeDhtml($lastRow);
	dhtmlModChange($lastRow); 
	RetPlgcalculateRow(); 
}); 

$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgRetPlgNonGTDIncome").val());
$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntUsd26");
$lastRow.find("td:eq(6)").find('input:eq(0)').on("change", function(){
	
	$lastRow.find("td:eq(7)").find('input:eq(0)').val(setTotalGtdDhtml($lastRow));
	setRetPlanMVIncomeDhtml($lastRow);
	setRetPlanMVRetAgeDhtml($lastRow);
	dhtmlModChange($lastRow);
	RetPlgcalculateRow(); 
	 
}); 

$lastRow.find("td:eq(7)").find('input:eq(0)').val(Number($("#txtFldDlgRetPlgTotalIncome").val()));
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntUsd26");
$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow);
	RetPlgcalculateRow(); 
});



$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgRetPlgPVIncOfIncomePay").val());
$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntUsd26");
$lastRow.find("td:eq(8)").find('input:eq(0)').on("change", function(){
	
	setRetPlanMVRetAgeDhtml($lastRow);
	dhtmlModChange($lastRow);
	RetPlgcalculateRow(); 
	 
});

$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgRetPlgPVFValAtRetRate").val());
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd26");
$lastRow.find("td:eq(9)").find('input:eq(0)').on("change", function(){
	dhtmlModChange($lastRow); 
	RetPlgcalculateRow();
});

$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgRetPlgAssBankIntRate").val());
$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntpCent3");
$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
	setRetPlanMVIncomeDhtml($lastRow);	
	setRetPlanMVRetAgeDhtml($lastRow);
	dhtmlModChange($lastRow); 
	RetPlgcalculateRow(); 
});



applyEventHandlers();


if(dataset != null){

	 
	$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "mvretId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col);  
				break;
				
				

			case "commenceAge":
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
				break;
				
	
			case "endAge":
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col);  
				break;
				
		 
			case "esclationRate": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col);  
				break;
			 
			case "gtdIncome": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col);  
				break;
			 
			case "nongtdIncome": 
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 
				break;
				
			case "mvrettotinc": 
				$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 
				break;
				
			case "incomeStream": 
				$lastRow.find("td:eq(8)").find('input:eq(0)').val(col);  
				break;  
				
			case "pvfvOnRet": 
				$lastRow.find("td:eq(9)").find('input:eq(0)').val(col);  
				break; 
				
			case "assumedBankInt": 
				$lastRow.find("td:eq(10)").find('input:eq(0)').val(col);  
				break;
				
			case "mvretCrtdBy": 
				$lastRow.find("td:eq(10)").find('input:eq(1)').val(col);
				
				infoDetsArr.push(col);				
				break;
				
			case "mvretCrtdDate":
				$lastRow.find("td:eq(10)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "mvretModBy":
				infoDetsArr.push(col);
				break;
				
			case "mvretModDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}

retplgClearFlds();
RetPlgcalculateRow(); 
}


 
/*Edit Row Click */
$("#lfRetPlgERow").on("click",function(){
	$("#lfRetPlgVRow").click();
});


/*View Row Click */
$("#lfRetPlgVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#liRetirementPlgtbl tbody tr').length;	
	var $lastRow = $("#liRetirementPlgtbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	
	
	$("#liRetirementPlgtbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
		
			
	});
	
	
	
	$("#liRetirementPlgtbl tbody").find('input[name="radretplgSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#liRetirementPlgtbl tbody").find('input[name="radretplgSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'});
				});
				 	retplgRdlyflds($mode);
					retplgfilldlgval($row); 
					showFIPAModel('liRetirementPlg_Dialog','Life Insurance - Retirement Planning Details');  
					$('#liRetirementPlg_Dialog').on('shown.bs.modal', function () {
						$("#liRetirementPlg_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#liRetirementPlg_Dialog").find("input[id=txtFldDlgRetPlgCommOfAge]").focus();//Aravindh
						$("#liRetirementPlg_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateretplgDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			retplgfilldomval($RowId,$row); 
					     		}  
					     		RetPlgcalculateRow();
								$('#liRetirementPlg_Dialog').modal('hide'); 
								retplgClearFlds();
							
						});
					});
					 
			}  
			
			if(($mode == QRY_MODE)){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE); 
				 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'});
					});
				 	retplgRdlyflds($mode);
					retplgfilldlgval($row); 
					showFIPAModel('liRetirementPlg_Dialog','Life Insurance - Retirement Planning Details');  
					$('#liRetirementPlg_Dialog').on('shown.bs.modal', function () {
						$("#liRetirementPlg_Dialog").find(".modal-footer").find("button:eq(0)").text("OK");
						$("#liRetirementPlg_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateretplgDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			retplgfilldomval($RowId,$row); 
					     		}  
					     		RetPlgcalculateRow();
								$('#liRetirementPlg_Dialog').modal('hide'); 
								retplgClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#lfRetPlgDRow").on("click",function(){ 
	datatableDeleteRow('liRetirementPlgtbl',liRetirementPlgtbl); 
	RetPlgcalculateRow();

});

/*Clear Fields */
function retplgClearFlds(){
	$("#liRetirementPlg_Dialog").find("input[type=text]").val("");
	$("#liRetirementPlg_Dialog").find("textarea").val("");
	$("#liRetirementPlg_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function retplgRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#liRetirementPlg_Dialog :input").prop("disabled", false); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
		 
			$("#liRetirementPlg_Dialog :input").prop("disabled", false);
			
			
	 }
}

/*Validation */
function validateretplgDetails(){
	 
	if(!(validateFocusFlds('liRetirementPlg_Dialog','txtFldDlgRetPlgCommOfAge',LIRET_COMAGE))) return; 
	if(!(validateFocusFlds('liRetirementPlg_Dialog','txtFldDlgRetPlgEndOfAge',LIRET_ENDAGE))) return;
	if(!(validateFocusFlds('liRetirementPlg_Dialog','txtFldDlgRetPlgEscaltAge',LIRET_ESCAGE))) return;
	
	  return true; 
}
 

/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgRetPlgCommOfAge,#txtFldDlgRetPlgEndOfAge,#txtFldDlgRetPlgEscaltAge").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function retplgfilldlgval($lastRow){
	  
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgCommOfAge').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgEndOfAge').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgEscaltAge').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgGTDIncome').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgNonGTDIncome').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgTotalIncome').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgPVIncOfIncomePay').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgPVFValAtRetRate').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgAssBankIntRate').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgCrtdBy').val($lastRow.find("td:eq(10)").find('input:eq(1)').val()); 
	  $('#liRetirementPlg_Dialog #txtFldDlgRetPlgCrtdDate').val($lastRow.find("td:eq(10)").find('input:eq(2)').val()); 
	  
	
}

/* Filling Table Fields*/
function retplgfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgRetPlgCommOfAge").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgRetPlgEndOfAge").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgRetPlgEscaltAge").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgRetPlgGTDIncome").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgRetPlgNonGTDIncome").val()); 
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgRetPlgTotalIncome").val());
	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgRetPlgPVIncOfIncomePay").val());   
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgRetPlgPVFValAtRetRate").val());   
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgRetPlgAssBankIntRate").val());   
}

 
 /*###########################################################################################################################################################*/
/**
 * Retirement Planning -Nominees
 * 
 */


	

/*Datatable Initialisation*/
var fnaLINomineesTbl = $('#fnaLINomineesTbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "20vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#NomARow").on("click",function(){
			nomineClearFlds();
			showFIPAModel('liNominees_Dialog','Life Insurance - Nominee Name');   
			$('#liNominees_Dialog').on('shown.bs.modal', function () {
				$("#liNominees_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#liNominees_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatenomineDetails())return;
					   	nomineRdlyflds(INS_MODE);  
					   	getNomNameRows(null); 
						$('#liNominees_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getNomNameRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldnomineMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldNomineeId">';
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radnomineSelect"/><label>&nbsp;</label></div>'; 
var cell2 ='<input type="text" name="txtFldNomineeName"  maxlength="150" class="form-control editable" />';
var cell3 ='<input type="text" name="txtFldNomineePercnt" class="form-control editable" />'+
'<input type="hidden" name="txtFldNomineeCrtdBy"/><input type="hidden" name="txtFldNomineeCrtdDate"/>'; 


 
fnaLINomineesTbl.row.add( [cell0,cell1,cell2,cell3] ).draw( false );

var rowCount = $('#fnaLINomineesTbl tbody tr').length;	
var $lastRow = $("#fnaLINomineesTbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radnomine"+$lastRow.index())
.parent().find('label').attr('for',"radnomine"+$lastRow.index());

  

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgNomineeName").val()); 
$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 
});


$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgNomineePercnt").val()); 
$lastRow.find("td:eq(3)").find('input:eq(0)').addClass("applyEvntpCent");
$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){
	dhtmlModChange($lastRow); 
});



applyEventHandlers();


if(dataset != null){

	 
	$lastRow.find("td:eq(0)").find('input:eq(0)').val("Q");
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "nomineeId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col);  
				break;
				 
			case "nomineeName":
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col);   
				break;
				 
			case "nomineePrcnt":
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col);  
				break;
				 
			case "nomineeCrtdBy": 
				$lastRow.find("td:eq(3)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "nomineeCrtdDate":
				$lastRow.find("td:eq(3)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "nomineeModBy":
				infoDetsArr.push(col);
				break;
				
			case "nomineeModDate":
				infoDetsArr.push(col);
				break;	
		}			 
		 
	}
	}

nomineClearFlds();

}


 
/*Edit Row Click */
$("#NomERow").on("click",function(){
	$("#NomVRow").click(); 
});


/*View Row Click */
$("#NomVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#fnaLINomineesTbl tbody tr').length;	
	var $lastRow = $("#fnaLINomineesTbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	
	$("#fnaLINomineesTbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
		
			
	});
	
	
	
	$("#fnaLINomineesTbl tbody").find('input[name="radnomineSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#fnaLINomineesTbl tbody").find('input[name="radnomineSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'});
				});
				 	nomineRdlyflds($mode);
					nominefilldlgval($row); 
					showFIPAModel('liNominees_Dialog','Life Insurance - Nominee Name');  
					$('#liNominees_Dialog').on('shown.bs.modal', function () {
						$("#liNominees_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#liNominees_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatenomineDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			nominefilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liNominees_Dialog').modal('hide'); 
								nomineClearFlds();
							
						});
					});
					 
			} 
			
			
			if(($mode == QRY_MODE)){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val(UPD_MODE);  
				 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'});
				});
				 	nomineRdlyflds($mode);
					nominefilldlgval($row); 
					showFIPAModel('liNominees_Dialog','Life Insurance - Nominee Name');  
					$('#liNominees_Dialog').on('shown.bs.modal', function () {
						$("#liNominees_Dialog").find(".modal-footer").find("button:eq(0)").text("Ok");
						$("#liNominees_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatenomineDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			nominefilldomval($RowId,$row); 
					     		}  
					     		 
								$('#liNominees_Dialog').modal('hide'); 
								nomineClearFlds();
							
						});
					});
					 
			}  
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#NomDRow").on("click",function(){ 
	datatableDeleteRow('fnaLINomineesTbl',fnaLINomineesTbl); 

});

/*Clear Fields */
function nomineClearFlds(){
	$("#liNominees_Dialog").find("input[type=text]").val("");
	$("#liNominees_Dialog").find("textarea").val("");
	$("#liNominees_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function nomineRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#liNominees_Dialog :input").prop("disabled", false); 
			$("#liNominees_Dialog").find("button").prop("disabled", false);
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#liNominees_Dialog :input").prop("disabled", false); 
	 }
}

/*Validation */
function validatenomineDetails(){
	 
	if(!(validateFocusFlds('liNominees_Dialog','txtFldDlgNomineeName',NOM_NAME))) return;  
	
	  return true; 
}
 

/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgNomineeName").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function nominefilldlgval($lastRow){
	  
	  $('#liNominees_Dialog #txtFldDlgNomineeId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#liNominees_Dialog #txtFldDlgNomineeName').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#liNominees_Dialog #txtFldDlgNomineePercnt').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#liNominees_Dialog #txtFldDlgNomineeCrtdBy').val($lastRow.find("td:eq(3)").find('input:eq(1)').val()); 
	  $('#liNominees_Dialog #txtFldDlgNomineeCrtdDate').val($lastRow.find("td:eq(3)").find('input:eq(2)').val()); 
	  
	
}

/* Filling Table Fields*/
function nominefilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgNomineeName").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgNomineePercnt").val());  
		
}
/*#####################OTHER VALIDATION####################*/

function RetPlgcalculateRow(){
	
	
	 var sum1=0,sum2=0,sum3=0,sum4=0,sum5=0,sum6=0;  
	 
	 
	 var $liretplgcount = liRetirementPlgtbl.rows().count();
	 
	 
	 if($liretplgcount >0){
		 
		 $("#liRetirementPlgtbl tbody tr").each(function(i,row){
				
				var liretEndage=$(this).find("td:eq(3)").find("input:eq(0)").val(); 
				var liretEscrate=$(this).find("td:eq(4)").find("input:eq(0)").val(); 
				var liretGurInc=$(this).find("td:eq(5)").find("input:eq(0)").val(); 
				var liretNonGurInc=$(this).find("td:eq(6)").find("input:eq(0)").val(); 
				var liretPVInc=$(this).find("td:eq(8)").find("input:eq(0)").val(); 
				var liretPVFVInc=$(this).find("td:eq(9)").find("input:eq(0)").val(); 
				
				
				 
				if(!isEmpty(liretEndage)){
					sum1 +=Number(liretEndage); 
				}
				
				if(!isEmpty(liretEscrate)){
					sum2 +=Number(liretEscrate); 
				}
				
				if(!isEmpty(liretGurInc)){
					sum3 +=Number(liretGurInc); 
				}
				
				if(!isEmpty(liretNonGurInc)){
					sum4 +=Number(liretNonGurInc); 
				}
				
				if(!isEmpty(liretPVInc)){
					sum5 +=Number(liretPVInc); 
				}
				
				if(!isEmpty(liretPVFVInc)){
					sum6 +=Number(liretPVFVInc); 
				}
				
		 });
		  
	 }
	  
	 
	 if(!(sum1 == 0 && sum2 == 0 && sum3 == 0 && sum4 == 0 && sum5 == 0 && sum6 == 0)){ 
		 
	 $("#fnaLIRetPlgTblfooter #txtFldTotEndAge").val(remPriceAfDec(sum1)); 
	 $("#fnaLIRetPlgTblfooter #txtFldTotEscalRate").val(remPriceAfDec(sum2)); 
	 $("#fnaLIRetPlgTblfooter #txtFldTotGtdIncome").val(remPriceAfDec(sum3)); 
	 $("#fnaLIRetPlgTblfooter #txtFldTotNGtdIncome").val(remPriceAfDec(sum4)); 
	 $("#fnaLIRetPlgTblfooter #txtFldTotComuteIncome").val(remPriceAfDec(sum5)); 
	 $("#fnaLIRetPlgTblfooter #txtFldTotComutePVFV").val(remPriceAfDec(sum6)); 
	 
	 }
	 
	 if(sum1 == 0){$("#fnaLIRetPlgTblfooter #txtFldTotEndAge").val("0");}
	 if(sum2 == 0){$("#fnaLIRetPlgTblfooter #txtFldTotEscalRate").val("0");} 
	 if(sum3 == 0){$("#fnaLIRetPlgTblfooter #txtFldTotGtdIncome").val("0");} 
	 if(sum4 == 0){$("#fnaLIRetPlgTblfooter #txtFldTotNGtdIncome").val("0");} 
	 if(sum5 == 0){$("#fnaLIRetPlgTblfooter #txtFldTotComuteIncome").val("0");} 
	 if(sum6 == 0){$("#fnaLIRetPlgTblfooter #txtFldTotComutePVFV").val("0");} 
	    
}
function setTotalGtdDhtml($lastRow){

	var gtdamt = $lastRow.find("td:eq(5)").find("input:eq(0)").val();//txtFldDlgRetPlgGTDIncome
	var nongtdamt =$lastRow.find("td:eq(6)").find("input:eq(0)").val();//txtFldDlgRetPlgNonGTDIncome
	var total = 0;
	
	if(!isEmpty(gtdamt)){
		total = gtdamt;
	}
	
	if(!isEmpty(nongtdamt)){
		total = nongtdamt;
	}
	
	if(!isEmpty(gtdamt) && !isEmpty(nongtdamt)){
		total = Number(gtdamt)+Number(nongtdamt);
	}
	
	return total;

}
function setTotalGtd(){
	
	var gtdamt = $("#txtFldDlgRetPlgGTDIncome").val();
	var nongtdamt = $("#txtFldDlgRetPlgNonGTDIncome").val();
	var total = 0;
	
	if(!isEmpty(gtdamt)){
		total = gtdamt;
	}
	
	if(!isEmpty(nongtdamt)){
		total = nongtdamt;
	}
	
	if(!isEmpty(gtdamt) && !isEmpty(nongtdamt)){
		total = Number(gtdamt)+Number(nongtdamt);
	}
	
	return total;
	
}

$(".calctotgtdamt").on("change",function(){
	$("#txtFldDlgRetPlgTotalIncome").val(setTotalGtd());
	
});

$(".calclifemvpvincome").on("change",function(){
	setRetPlanMVIncome();	
});



function setRetPlanMVIncome() {

	var rate = $("#txtFldDlgRetPlgAssBankIntRate").val();
	var startage = $("#txtFldDlgRetPlgCommOfAge").val();
	var endage = $("#txtFldDlgRetPlgEndOfAge").val();
	var gtdamt = $("#txtFldDlgRetPlgGTDIncome").val();
	var nongtdamt = $("#txtFldDlgRetPlgNonGTDIncome").val();
	
	var nper = endage - startage;
	var pmtid =  Number((-1 * gtdamt) - nongtdamt);
	
	
	var pvvalue = PVCalculation((rate / 100),nper,pmtid,0,1);
	$("#txtFldDlgRetPlgPVIncOfIncomePay").val(pvvalue.toFixed(2));
	
}

function setRetPlanMVIncomeDhtml($lastRow) {

	var rate 	  = $lastRow.find("td:eq(10)").find("input:eq(0)").val();//txtFldDlgRetPlgAssBankIntRate
	var startage  = $lastRow.find("td:eq(2)").find("input:eq(0)").val();//txtFldDlgRetPlgCommOfAge
	var endage 	  = $lastRow.find("td:eq(3)").find("input:eq(0)").val();//txtFldDlgRetPlgEndOfAge
	var gtdamt 	  = $lastRow.find("td:eq(5)").find("input:eq(0)").val();//txtFldDlgRetPlgGTDIncome
	var nongtdamt = $lastRow.find("td:eq(6)").find("input:eq(0)").val();//txtFldDlgRetPlgNonGTDIncome
	
	var nper = endage - startage;
	var pmtid =  Number((-1 * gtdamt) - nongtdamt);
	
	
	var pvvalue = PVCalculation((rate / 100),nper,pmtid,0,1);
	$lastRow.find("td:eq(8)").find("input:eq(0)").val(pvvalue.toFixed(2));//txtFldDlgRetPlgPVIncOfIncomePay
	
}


$(".calclifemvpvretage").on("change",function(){
	setRetPlanMVRetAge();
});

function setRetPlanMVRetAge() {

	var rate = $("#txtFldDlgRetPlgAssBankIntRate").val();
	var startage = $("#txtFldDlgRetPlgCommOfAge").val();
	var endage = $("#txtFldDlgRetPlgEndOfAge").val();
	var gtdamt = $("#txtFldDlgRetPlgGTDIncome").val();
	var nongtdamt = $("#txtFldDlgRetPlgNonGTDIncome").val();
	
	var retselfage = $("#retSelfretage").val();
	var retspsage = $("#retSpouseretage").val();
	var mvincome = $("#txtFldDlgRetPlgPVIncOfIncomePay").val();
	
	var nper = startage - retselfage;
	var fv =  (-1* Number(mvincome));
	
	
	var pvvalue = PVCalculation((rate / 100),nper,0,fv);
	$("#txtFldDlgRetPlgPVFValAtRetRate").val(pvvalue.toFixed(2));
	
}


function setRetPlanMVRetAgeDhtml($lastRow) {

	var rate 	  = $lastRow.find("td:eq(10)").find("input:eq(0)").val();//txtFldDlgRetPlgAssBankIntRate
	var startage  = $lastRow.find("td:eq(2)").find("input:eq(0)").val();//txtFldDlgRetPlgCommOfAge
	var endage 	  = $lastRow.find("td:eq(3)").find("input:eq(0)").val();//txtFldDlgRetPlgEndOfAge
	var gtdamt 	  = $lastRow.find("td:eq(5)").find("input:eq(0)").val();//txtFldDlgRetPlgGTDIncome
	var nongtdamt = $lastRow.find("td:eq(6)").find("input:eq(0)").val();//txtFldDlgRetPlgNonGTDIncome
	
	var retselfage = $("#retSelfretage").val();
	var retspsage = $("#retSpouseretage").val();
	var mvincome = $lastRow.find("td:eq(8)").find("input:eq(0)").val();//txtFldDlgRetPlgPVIncOfIncomePay
	
	var nper = startage - retselfage;
	var fv =  (-1* Number(mvincome));
	
	
	var pvvalue = PVCalculation((rate / 100),nper,0,fv);
	$lastRow.find("td:eq(9)").find("input:eq(0)").val(pvvalue.toFixed(2));//txtFldDlgRetPlgPVFValAtRetRate
	
}

$("#txtFldDlgDfIncepDate").change(function(){ 
	if(!chkFromToDateValidation('txtFldDlgDfIncepDate','txtFldDlgDfExpiryDate'),"Expiry Date should greater than the Inception Date"); 
});

$("#txtFldDlgDfIncepDate").change(function(){
	 checkDateFormat($(this));
});

$("#txtFldDlgDfExpiryDate").change(function(){    
	if(!chkFromToDateValidation('txtFldDlgDfIncepDate','txtFldDlgDfExpiryDate'),"Expiry Date should greater than the Inception Date");
}); 

$("#txtFldDlgDfExpiryDate").change(function(){    
 checkDateFormat($(this));
}); 

$("#txtFldDlgRetPlgCommOfAge").on("change",function(){
	StartAgeValidate($(this),$("#txtFldDlgRetPlgEndOfAge"));
});


$("#txtFldDlgRetPlgEndOfAge").on("change",function(){
	EndAgeValidate($(this),$("#txtFldDlgRetPlgCommOfAge"));
});

function StartAgeValidate(start,end){
	var startage=start.val();
	var endage=end.val();
	
	if(!isEmpty(startage) && !isEmpty(endage)){
		if(startage >  endage ){
			showAlert("Age Income Starts must be less than Age Income Ends",start);
			start.val("");
			return false;
		}
	}
	
}

function EndAgeValidate(end,start){
	var startage=start.val();
	var endage=end.val();
	
	if(!isEmpty(startage) && !isEmpty(endage)){
		if(endage <  startage ){
			showAlert("Age Income Ends must be Greater than Age Income Starts",end);
			end.val("");
			return false;
		}
	}
	
}
