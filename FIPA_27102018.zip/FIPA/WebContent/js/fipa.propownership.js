/**
 * Fna CPF Property Ownership Script
 */ 
$("a#syncproperty").on("click",function(){ 
	
	calcTotalPropertyAmts();
	if($("#powncpfARow").hasClass("blinking")){
		$("#powncpfARow").removeClass("blinking");
	} 
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(6)").find("a").click();	 
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#powncpfARow").addClass("blinking"); 
	
	if($("#powncpfARow").hasClass("blinking")){
		setTimeout(function() {
		$("#property").scrollTop(0);
	}, 100);
		
	} 
	
	 
}); 



$("a#annualrentalincome").on("click",function(){ 
	
	calcTotalPropertyAmts();  
	if($("#powncpfARow").hasClass("blinking")){
		$("#powncpfARow").removeClass("blinking");
	} 
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(6)").find("a").click();	 
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#powncpfARow").addClass("blinking"); 
	
	if($("#powncpfARow").hasClass("blinking")){
		setTimeout(function() {
		$("#property").scrollTop(0); 
		},1500);
	} 
	
	 
}); 

function openBackToCpfAD(){

	if($("#CpfADARow").hasClass("blinking")){
		$("#CpfADARow").removeClass("blinking");
	}
	
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(10)").find("a").click();	 
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#CpfADARow").addClass("blinking");  
	if($("#CpfADARow").hasClass("blinking")){
		setTimeout(function() {
		$("#centralpro").scrollTop(8000);
		},1500);
		
	} 
	 
}
/*Datatable Initialisation*/
var fnaPropOwnTblByCPF = $('#fnaPropOwnTblByCPF').DataTable( {
   destroy: true,
   responsive: false,         
   ordering: false,
   searching: false,     
   scrollY:  "40vh",
   scrollX: true,
   scroller: false,
   scrollCollapse:false,
   paging:false, 
   filter:false,   
   columnDefs: [], 
   dom: '<<"top" ip>flt>',  
   columnDefs: [  { width: '20px', targets: [0,1]},
  	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
   
		 }, 
}).draw();
	


/*Add Row Click */
$("#powncpfARow").on("click",function(){
	if(!valpropTbl())return; 
//	var clientmartstst = $("#dfSelfMartsts").val();
//	clientmartstst = isEmpty(clientmartstst) ? "" : clientmartstst.toUpperCase()

			propClearFlds(); 
			propObjChange($("#txtFldDlgCpfPropObj"),$("#txtFldDlgPropCurAnlRetInc"));
			
//			propyearstorent($("#txtFldDlgCpfPropObj"),$("#txtFldDlgCpfPropSold"),$("#txtFldDlgPropRentOnRetire"),$("#txtFldDlgPropYrsToRent"));
			
			onSoldChange($("#txtFldDlgCpfPropSold"),$("#txtFldDlgPropRentOnRetire"),$("#txtFldDlgPropCurRetInc")); 
			retOnRetFnc($("#txtFldDlgPropRentOnRetire"),$("#txtFldDlgPropCurRetInc"));
		 	
//			if(clientmartstst == "SINGLE"){
//     		 $("input[name=txtFldDlgPropLoanBySpsCash]").val("");
//     		 $("input[name=txtFldDlgPropLoanBySpsCash]").prop("disabled",true);
//     		 $("input[name=txtFldDlgPropLoanBySpsCpf]").val("");
//    		 $("input[name=txtFldDlgPropLoanBySpsCpf]").prop("disabled",true);
//     		}
//			 $("#propOwnCpf_Dialog #txtFldDlgPropFVOnRent").prop("disabled", true);
			
			showFIPAModel('propOwnCpf_Dialog','Property Ownership');   
			$('#propOwnCpf_Dialog').on('shown.bs.modal', function () {
				$("#propOwnCpf_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#propOwnCpf_Dialog").find("input[id=txtFldDlgPropOwnCpfDesc]").focus();
				$("#propOwnCpf_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatepropDetails())return;
					   	propRdlyflds(INS_MODE);  
					   	getPropOwnCpfRows(null); 
					   	chkClientSingleOrNot();
					   	/*if($("#dfSelfMartsts").val() == "Single"){
						   	 $("input[name=txtFldPropCpfLoanBySpsCpf]").each(function() {  
						   		 $(this).prop("disabled",true); 
								 $(this).val("");
						     });
						  $("input[name=txtFldPropCpfLoanBySpsCash]").each(function() {  
								$(this).prop("disabled",true);  
							    $(this).val("");
						   });  
				     	}*/
					   	
					   	
						$('#propOwnCpf_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getPropOwnCpfRows(dataset){ 

var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldpropMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldPropCpfOwnId"><input type="hidden" name="txtFldPropRefId" >';

var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radpropSelect"/><label>&nbsp;</label></div>'; 

var cell2 = '<input type="text" name="txtFldPropCpfOwnDesc" maxlength="300" class="form-control editable" onmouseover="fipaTooltip(this);" />';

var cell3 = '<input type="text" name="txtFldPropCpfMktVal" class="form-control editable"   onmouseover="fipaTooltip(this);" />';


var cell4 = '<select   name="txtFldPropCpfOwnership" class="form-control editable"></select>';

var cell5 = '<input type="text" name="txtFldPropCpfApprecrate" class="form-control editable" onmouseover="fipaTooltip(this);" />'; 

var cell6 = '<input type="text" name="txtFldPropCpfOsloanPerd" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

var cell7 = '<input type="text" name="txtFldPropCpfMortageos" class="form-control editable" onmouseover="fipaTooltip(this);" />'; 

//var cell8 = '<input type="text" name="txtFldPropCpfYrstoPay" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

var cell8 = '<select   name="txtFldPropCpfObj" class="form-control editable"></select>';

var cell9 = '<input type="text" name="txtFldPropCurAnlRetInc" class="form-control editable"   onmouseover="fipaTooltip(this);" />'; 

var cell10 = '<input type="text" name="txtFldPropCpfLoanBySlfCpf" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

var cell11 = '<input type="text" name="txtFldPropCpfLoanBySlfCash" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

var cell12 = '<input type="text" name="txtFldPropCpfLoanBySpsCpf" class="form-control editable clsfipaSpouse"   onmouseover="fipaTooltip(this);" />';

var cell13 = '<input type="text" name="txtFldPropCpfLoanBySpsCash" class="form-control editable clsfipaSpouse"   onmouseover="fipaTooltip(this);" />';

var cell14 = '<select  name="txtFldPropCpfSold" class="form-control editable"></select>'; 

var cell15 = '<select  name="txtFldPropRentOnRetire" class="form-control editable"></select>';

var cell16 ='<input type="text" name="txtFldPropCurRetInc" class="form-control editable"   onmouseover="fipaTooltip(this);" />'+
'<input type="hidden" name="txtFldPropCpfCrtdBy"/><input type="hidden" name="txtFldPropCpfCrtdDate"/>';

var cell17 = '<input type="text" name="txtFldPropYrsToRent" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

var cell18 = '<input type="text" name="txtFldPropFvOnRent" class="form-control editable" readonly="true"  onmouseover="fipaTooltip(this);" />';

fnaPropOwnTblByCPF.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10,cell11,cell12,cell13,cell14,cell15,cell16,cell17,cell18] ).draw( false );

var rowCount = $('#fnaPropOwnTblByCPF tbody tr').length;	
var $lastRow = $("#fnaPropOwnTblByCPF tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radprop"+$lastRow.index())
.parent().find('label').attr('for',"radprop"+$lastRow.index());

 

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgPropOwnCpfDesc").val());
$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){ 
 
	syncPropTblEditRow($lastRow);
			return;
		 
});


$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgCpfPropMktVal").val());
$lastRow.find("td:eq(3)").find('input:eq(0)').addClass("applyEvntUsd"); 
$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){
	calculateCrtRentIncome($(this),$lastRow.find("td:eq(5)").find('input:eq(0)'),$("#retYrstoret"),$lastRow.find("td:eq(18)").find('input:eq(0)'));	
});



var Ownership = $("#txtFldDlgCpfPropOwnership > option").clone();
$lastRow.find("td:eq(4)").find('select:eq(0)').append(Ownership);
$lastRow.find("td:eq(4)").find('select:eq(0)').val($("#txtFldDlgCpfPropOwnership").val());
$lastRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
	calcTotalPropertyAmts();	 
	newRowPropCpfEditTbl($lastRow);
	syncPropTblEditRow($lastRow);
	return;
});


$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgCpfPropApprecrate").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntpCent3"); 
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
	calculateCrtRentIncome($lastRow.find("td:eq(3)").find('input:eq(0)'),$(this),$("#retYrstoret"),$lastRow.find("td:eq(18)").find('input:eq(0)'));	
});


$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgCpfPropOsloanPerd").val());
$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntYrs"); 


$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgCpfPropMortageos").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntUsd"); 


//$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgCpfPropYrstoPay").val());
//$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntYrs"); 

var Objective = $("#txtFldDlgCpfPropObj > option").clone();
$lastRow.find("td:eq(8)").find('select:eq(0)').append(Objective);
$lastRow.find("td:eq(8)").find('select:eq(0)').val($("#txtFldDlgCpfPropObj").val());
$lastRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
	calcTotalPropertyAmts();
	propObjChange($(this),$lastRow.find("td:eq(9)").find('input:eq(0)')); 
	propyearstorent($(this),$lastRow.find("td:eq(14)").find('select:eq(0)'),$lastRow.find("td:eq(15)").find('select:eq(0)'),$lastRow.find("td:eq(17)").find('input:eq(0)'));
	
 
	return;
});
//

$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgPropCurAnlRetInc").val());
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){ 
	calcTotalPropertyAmts(); 
	propObjChange($lastRow.find("td:eq(8)").find('select:eq(0)'),$(this)); 
	return;
});

 
$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgPropLoanBySlfCpf").val());
$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
	calcTotalPropertyAmts();	 
	newRowPropCpfEditTbl($lastRow);
	return;
});
 

$lastRow.find("td:eq(11)").find('input:eq(0)').val($("#txtFldDlgPropLoanBySlfCash").val());
$lastRow.find("td:eq(11)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(11)").find('input:eq(0)').on("change",function(){
	calcTotalPropertyAmts(); 
		return;
	
});


$lastRow.find("td:eq(12)").find('input:eq(0)').val($("#txtFldDlgPropLoanBySpsCpf").val());
$lastRow.find("td:eq(12)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(12)").find('input:eq(0)').on("change",function(){
	calcTotalPropertyAmts();	 
	newRowPropCpfEditTbl($lastRow);
		return;
});

$lastRow.find("td:eq(13)").find('input:eq(0)').val($("#txtFldDlgPropLoanBySpsCash").val());
$lastRow.find("td:eq(13)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(13)").find('input:eq(0)').on("change",function(){
	calcTotalPropertyAmts();  
	return;
});

var Sold = $("#txtFldDlgCpfPropSold > option").clone();
$lastRow.find("td:eq(14)").find('select:eq(0)').append(Sold);
$lastRow.find("td:eq(14)").find('select:eq(0)').val($("#txtFldDlgCpfPropSold").val());
$lastRow.find("td:eq(14)").find('select:eq(0)').on("change",function(){ 
	onSoldChange($(this),$lastRow.find("td:eq(15)").find('select:eq(0)'),$lastRow.find("td:eq(16)").find('input:eq(0)'));
	propyearstorent($lastRow.find("td:eq(8)").find('select:eq(0)'),$(this),$lastRow.find("td:eq(15)").find('select:eq(0)'),$lastRow.find("td:eq(17)").find('input:eq(0)'));
	return;
});



var Retirement = $("#txtFldDlgPropRentOnRetire > option").clone();
$lastRow.find("td:eq(15)").find('select:eq(0)').append(Retirement);
$lastRow.find("td:eq(15)").find('select:eq(0)').val($("#txtFldDlgPropRentOnRetire").val());
$lastRow.find("td:eq(15)").find('select:eq(0)').on("change",function(){ 
	if($(this).val() == 'Y'){ 
		 if(!validationRetirementScreen())return; 
	}
	onSoldChange($lastRow.find("td:eq(14)").find('select:eq(0)'),$(this),$lastRow.find("td:eq(16)").find('input:eq(0)'));
	retOnRetFnc($(this),$lastRow.find("td:eq(16)").find('input:eq(0)'));
	 syncPropTblEditRow($lastRow);
	 propyearstorent($lastRow.find("td:eq(8)").find('select:eq(0)'),$lastRow.find("td:eq(14)").find('select:eq(0)'),$(this),$lastRow.find("td:eq(17)").find('input:eq(0)'));
		return;
});

$lastRow.find("td:eq(16)").find('input:eq(0)').val($("#txtFldDlgPropCurRetInc").val());
$lastRow.find("td:eq(16)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(16)").find('input:eq(0)').on("change",function(){
	onSoldChange($lastRow.find("td:eq(14)").find('select:eq(0)'),$lastRow.find("td:eq(15)").find('select:eq(0)'),$(this));
	retOnRetFnc($lastRow.find("td:eq(15)").find('select:eq(0)'),$(this));
	calcTotalPropertyAmts();
	 syncPropTblEditRow($lastRow);
		return;
});


$lastRow.find("td:eq(17)").find('input:eq(0)').val($("#txtFldDlgPropYrsToRent").val());
$lastRow.find("td:eq(17)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(17)").find('input:eq(0)').on("change",function(){
	calculateCrtRentIncome($lastRow.find("td:eq(3)").find('input:eq(0)'),$lastRow.find("td:eq(5)").find('input:eq(0)'),$(this),$lastRow.find("td:eq(18)").find('input:eq(0)'));	
});

 
 
$lastRow.find("td:eq(18)").find('input:eq(0)').val($("#txtFldDlgPropFVOnRent").val());
$lastRow.find("td:eq(18)").find('input:eq(0)').addClass("applyEvntUsd"); 


applyEventHandlers();


if(dataset != null){

	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
		case "propownId": 
			$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
			break;
			

		case "propRefId": 
			$lastRow.find("td:eq(0)").find('input:eq(2)').val(col);  
			if(!isEmpty(col)){$lastRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid");}
			break;
			
			
		case "propDescription": 
			$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
			break;
	

		case "propMktvalue": 
			$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
			break;
			
		case "propOwnership": 
			selectNullvalChk($lastRow.find("td:eq(4)"),col);
			break;
		 
		case "propApprecrate": 
			$lastRow.find("td:eq(5)").find('input:eq(0)').val(col); 
			break;
			 
		case "propOsloanperd": 
			$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 
			break;
		
			
		case "propMortageos": 
			$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 
			break; 
			
		case "propObj": 
			selectNullvalChk($lastRow.find("td:eq(8)"),col);			
			break;
		
		case "propAnlRetInc":
			$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
			break;
			 
		case "propLoanBySelfcpf":
			$lastRow.find("td:eq(10)").find('input:eq(0)').val(col); 
			break;
			
		case "propLoanBySelfcash":
			$lastRow.find("td:eq(11)").find('input:eq(0)').val(col); 
			break;
			
		case "propLoanBySpscpf":
			$lastRow.find("td:eq(12)").find('input:eq(0)').val(col); 
			break;
			
		case "propLoanBySpscash":
			$lastRow.find("td:eq(13)").find('input:eq(0)').val(col); 
			break;
			
		case "propSold":
			selectNullvalChk($lastRow.find("td:eq(14)"),col);
			break;
			
		case "propRentOnret":
			$lastRow.find("td:eq(15)").find('select:eq(0)').val(col); 
			break;
			
		case "propCurRetInc":
			$lastRow.find("td:eq(16)").find('input:eq(0)').val(col); 
			break;
			
		case "propYrsToRent":
			$lastRow.find("td:eq(17)").find('input:eq(0)').val(col);
			break;
			
		case "propFvOnrent":
			$lastRow.find("td:eq(18)").find('input:eq(0)').val(col);
			break;
			
		
		case "propCreatedBy": 
			$lastRow.find("td:eq(16)").find('input:eq(1)').val(col);
			infoDetsArr.push(col);				
			break;
			
		case "propCreatedDate":
			$lastRow.find("td:eq(16)").find('input:eq(2)').val(col);
			infoDetsArr.push(col);
			break;
		
	
		case "propModifiedBy":
			infoDetsArr.push(col);
			break;
			
		case "propModifiedDate":
			infoDetsArr.push(col);
			break;	
		}			 
		 
	}
	}


propObjChange($lastRow.find("td:eq(8)").find('select:eq(0)'),$lastRow.find("td:eq(9)").find('input:eq(0)')); 
propyearstorent($lastRow.find("td:eq(8)").find('select:eq(0)'),$lastRow.find("td:eq(14)").find('select:eq(0)'),$lastRow.find("td:eq(15)").find('select:eq(0)'),$lastRow.find("td:eq(17)").find('input:eq(0)'));
onSoldChange($lastRow.find("td:eq(14)").find('select:eq(0)'),$lastRow.find("td:eq(15)").find('select:eq(0)'),$lastRow.find("td:eq(16)").find('input:eq(0)'));
retOnRetFnc($lastRow.find("td:eq(15)").find('select:eq(0)'),$lastRow.find("td:eq(16)").find('input:eq(0)'));


//sync property row
if(dataset == null){
if($lastRow.find("td:eq(15)").find('select:eq(0)').val() == "Y"){
	if(!($lastRow.find("td:eq(4)").find('select:eq(0)').val() == "Joint")){
		syncPropTblRow();
//		syncPropTblEditRow($lastRow);
	}
}

newRowPropCpfTbl($lastRow);
calcTotalPropertyAmts();
}
//propClearFlds();
}


 
/*Edit Row Click */
$("#powncpfERow").on("click",function(){
	$("#powncpfVRow").click();
});


/*View Row Click */
$("#powncpfVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#fnaPropOwnTblByCPF tbody tr').length;	
	var $lastRow = $("#fnaPropOwnTblByCPF tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	

	$("#fnaPropOwnTblByCPF tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
	});
	
	
	$("#fnaPropOwnTblByCPF tbody").find('input[name="radpropSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#fnaPropOwnTblByCPF tbody").find('input[name="radpropSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'});
				});  
					
					
				 	propRdlyflds($mode);
					propfilldlgval($row); 
 
					propObjChange($("#txtFldDlgCpfPropObj"),$("#txtFldDlgPropCurAnlRetInc"));
					onSoldChange($("#txtFldDlgCpfPropSold"),$("#txtFldDlgPropRentOnRetire"),$("#txtFldDlgPropCurRetInc")); 
					retOnRetFnc($("#txtFldDlgPropRentOnRetire"),$("#txtFldDlgPropCurRetInc")); 
					propyearstorent($("#txtFldDlgCpfPropObj"),$("#txtFldDlgCpfPropSold"),$("#txtFldDlgPropRentOnRetire"),$("#txtFldDlgPropYrsToRent"));
					if($("#dfSelfMartsts").val() == "Single"){
			     		 $("input[name=txtFldDlgPropLoanBySpsCash]").val("");
			     		 $("input[name=txtFldDlgPropLoanBySpsCash]").prop("disabled",true);
			     		 $("input[name=txtFldDlgPropLoanBySpsCpf]").val("");
			    		 $("input[name=txtFldDlgPropLoanBySpsCpf]").prop("disabled",true);
			     	}
					$("#propOwnCpf_Dialog #txtFldDlgPropFVOnRent").prop("disabled", true);	 
					showFIPAModel('propOwnCpf_Dialog','Property Ownership');  
					$('#propOwnCpf_Dialog').on('shown.bs.modal', function () {
						$("#propOwnCpf_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#propOwnCpf_Dialog").find("input[id=txtFldDlgPropOwnCpfDesc]").focus();//Aravindh
						$("#propOwnCpf_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatepropDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			propfilldomval($RowId,$row); 
					     		}   
					     		calcTotalPropertyAmts();
 
					     		newRowPropCpfEditTbl($row);
					     		syncPropTblEditRow($row); 
						 		 
						 		
					     		if($("#dfSelfMartsts").val() == "Single"){
								   	 $("input[name=txtFldPropCpfLoanBySpsCpf]").each(function() {  
								   		 $(this).prop("disabled",true); 
										 $(this).val("");
								     });
								  $("input[name=txtFldPropCpfLoanBySpsCash]").each(function() {  
										$(this).prop("disabled",true);  
									    $(this).val("");
								   });  
						     	}
					     		
					     		propObjChange($row.find("td:eq(8)").find('select:eq(0)'),$row.find("td:eq(9)").find('input:eq(0)')); 
					     		propyearstorent($row.find("td:eq(8)").find('select:eq(0)'),$row.find("td:eq(14)").find('select:eq(0)'),$row.find("td:eq(15)").find('select:eq(0)'),$row.find("td:eq(17)").find('input:eq(0)'));
					     		onSoldChange($row.find("td:eq(14)").find('select:eq(0)'),$row.find("td:eq(15)").find('select:eq(0)'),$row.find("td:eq(16)").find('input:eq(0)'));
					     		retOnRetFnc($row.find("td:eq(15)").find('select:eq(0)'),$row.find("td:eq(16)").find('input:eq(0)'));
								$('#propOwnCpf_Dialog').modal('hide'); 
								propClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#powncpfDRow").on("click",function(){  
	
	var rowCount = $('#fnaPropOwnTblByCPF tbody tr').length;	 
	if(rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	}
	var isOneRowSelected=false;
	$('#fnaPropOwnTblByCPF tbody').find('input[type=checkbox]').each(function(){
		if($(this).is(":checked")){
			
			 
			var row = $(this).parents("tr");                                    
			var mode = $(this).parents("tr").find("td:first").find('input:eq(0)').val();
			
			
			var refId=$(this).parents("tr").find("td:eq(0)").find("input.rowrefid");//Retirement Reference 
			
			//Retirement Reference Delete function
			if(isValidObject(refId)){  
				    
					  
				var message=false;
				 
				
				$("#IncAssRetPlgtbl tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
					if(refId.val() == $(this).val()){
						message=true;
						IncAssRetPlgtbl.row($(this).closest("tr")).remove().draw();
					}
				});	
				 
//				$("#cpfAccAddDedTable tbody tr[rowref='"+refId+"']").each(function(){
			   $("#cpfAccAddDedTable tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
				if(refId.val() == $(this).val()){
							 
					message=true;
					cpfAccAddDedTable.row($(this).closest("tr")).remove().draw();
				}
				});	
				
//				$("#fnaPropOwnTblByCPF tbody tr[rowref='"+refId+"']").each(function(){
			   $("#fnaPropOwnTblByCPF tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
					if(refId.val() == $(this).val()){
					if(message){
						showAlert("There is row exists in other sections, will also be deleted!");
					}
					fnaPropOwnTblByCPF.row($(this).closest("tr")).remove().draw();
					}
				});  
			}
	
			 
			
		 
			
			//Normal without reference Delete function
//			if(!isValidObject($(this).parents("tr").attr("rowref"))){
//				fnaPropOwnTblByCPF.row($(this).parent().parent()).remove().draw();
//			}
//			
			if(!isValidObject($(this).parents("tr").find("td:eq(0)").find("input.rowrefid"))){
				if(refId.val() == $(this).val()){
					fnaPropOwnTblByCPF.row($(this).closest("tr")).remove().draw();
				}
			}
			
			
				
			$(this).attr("checked",false);
			isOneRowSelected=true;
			
		}
	});
	if(rowCount==1){
		fnaPropOwnTblByCPF.clear().draw();
	}

	
	if(!isOneRowSelected){
		showAlert("No Rows Selected");
	} 
	
	
	reorderSino("IncAssRetPlgtbl"); 
	reorderSino("cpfAccAddDedTable");
	reorderSino("fnaPropOwnTblByCPF");
	
	
	
	$('#fnaPropOwnTblByCPF tbody tr').find('td:eq(0) input.rowrefid').each(function(){
		
		var oldval = $(this).val();
		var bankrowindex= $(this).closest("tr").index();
		var newval = "PROP_"+bankrowindex;
		
		
		$("#IncAssRetPlgtbl tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
     	   if(oldval == $(this).val()){
     		   $(this).val(newval);
     	   }
        });
		
		
		$("#cpfAccAddDedTable tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
     	   if(oldval == $(this).val()){
     		   $(this).val(newval);
     	   }
        });
		
		$(this).val(newval);
	});
	
	
	calcTotalPropertyAmts();

	

});

/*Clear Fields */
function propClearFlds(){
	$("#propOwnCpf_Dialog").find("input[type=text]").val("");
	$("#propOwnCpf_Dialog").find("textarea").val("");
	$("#propOwnCpf_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function propRdlyflds(mode){ 
	
	 if(mode == QRY_MODE ){
			$("#propOwnCpf_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#propOwnCpf_Dialog :input").prop("disabled", false);
	 }
	 
	 $("#propOwnCpf_Dialog #txtFldDlgPropFVOnRent").prop("disabled", true);	 
	 
	 if($("#dfSelfMartsts").val() == "Single"){
		 $("input[name=txtFldDlgPropLoanBySpsCash]").val("");
 		 $("input[name=txtFldDlgPropLoanBySpsCash]").prop("disabled",true);
 		 $("input[name=txtFldDlgPropLoanBySpsCpf]").val("");
		 $("input[name=txtFldDlgPropLoanBySpsCpf]").prop("disabled",true);
	 }
	 
}

/*Validation */
function validatepropDetails(){ 
	if(!(validateFocusFlds('propOwnCpf_Dialog','txtFldDlgPropOwnCpfDesc',PROP_DESC))) return;
	if(!(validateFocusFlds('propOwnCpf_Dialog','txtFldDlgCpfPropOwnership',PROP_OWNER))) return; 
	if(!(validateFocusFlds('propOwnCpf_Dialog','txtFldDlgCpfPropMktVal',PROP_MARKETVAL))) return;
	
	  return true; 
}

function valpropTbl(){ 
	var $lastRow = $("#fnaPropOwnTblByCPF tbody tr:last");	
	var $RowCount = fnaPropOwnTblByCPF.rows().count();

	var valid=true;
	if($RowCount > 0 ){ 
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(2)").find('input:eq(0)'), PROP_DESC))) return; 
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(4)").find('select:eq(0)'), PROP_OWNER))) return;  
		if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(3)").find('input:eq(0)'), PROP_MARKETVAL))) return;  
	}  
  return true; 
}

/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgPropOwnCpfDesc,#txtFldDlgCpfPropMktVal,#txtFldDlgCpfPropOwnership").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
 


/* Filling Model Fields*/
function propfilldlgval($lastRow){
	  

	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropOwnId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropRefId').val($lastRow.find("td:eq(0)").find('input:eq(2)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropOwnCpfDesc').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropMktVal').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropOwnership').val($lastRow.find("td:eq(4)").find('select:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropApprecrate').val($lastRow.find("td:eq(5)").find('input:eq(0)').val()); 
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropOsloanPerd').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropMortageos').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
//	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropYrstoPay').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropObj').val($lastRow.find("td:eq(8)").find('select:eq(0)').val()); 
	  $('#propOwnCpf_Dialog #txtFldDlgPropCurAnlRetInc').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropLoanBySlfCpf').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropLoanBySlfCash').val($lastRow.find("td:eq(11)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropLoanBySpsCpf').val($lastRow.find("td:eq(12)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropLoanBySpsCash').val($lastRow.find("td:eq(13)").find('input:eq(0)').val()); 
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropSold').val($lastRow.find("td:eq(14)").find('select:eq(0)').val()); 
	  $('#propOwnCpf_Dialog #txtFldDlgPropRentOnRetire').val($lastRow.find("td:eq(15)").find('select:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropCurRetInc').val($lastRow.find("td:eq(16)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropCrtdBy').val($lastRow.find("td:eq(16)").find('input:eq(1)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgCpfPropCrtdDate').val($lastRow.find("td:eq(16)").find('input:eq(2)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropYrsToRent').val($lastRow.find("td:eq(17)").find('input:eq(0)').val());
	  $('#propOwnCpf_Dialog #txtFldDlgPropFVOnRent').val($lastRow.find("td:eq(18)").find('input:eq(0)').val());
}

/* Filling Table Fields*/
function propfilldomval($RowId,$row){ 
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgPropOwnCpfDesc").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgCpfPropMktVal").val()); 
	$row.find("td:eq(4)").find('select:eq(0)').val($("#txtFldDlgCpfPropOwnership").val()); 
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgCpfPropApprecrate").val());  
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgCpfPropOsloanPerd").val()); 
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgCpfPropMortageos").val());
//	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgCpfPropYrstoPay").val()); 
	$row.find("td:eq(8)").find('select:eq(0)').val($("#txtFldDlgCpfPropObj").val()); 
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgPropCurAnlRetInc").val());    
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgPropLoanBySlfCpf").val()); 
	$row.find("td:eq(11)").find('input:eq(0)').val($("#txtFldDlgPropLoanBySlfCash").val()); 
	$row.find("td:eq(12)").find('input:eq(0)').val($("#txtFldDlgPropLoanBySpsCpf").val()); 
	$row.find("td:eq(13)").find('input:eq(0)').val($("#txtFldDlgPropLoanBySpsCash").val()); 
	$row.find("td:eq(14)").find('select:eq(0)').val($("#txtFldDlgCpfPropSold").val());  
	$row.find("td:eq(15)").find('select:eq(0)').val($("#txtFldDlgPropRentOnRetire").val());  
	$row.find("td:eq(16)").find('input:eq(0)').val($("#txtFldDlgPropCurRetInc").val());   
	$row.find("td:eq(17)").find('input:eq(0)').val($("#txtFldDlgPropYrsToRent").val());   
	$row.find("td:eq(18)").find('input:eq(0)').val($("#txtFldDlgPropFVOnRent").val());   
}
/*###########################################################################################################################################################*/

//Sync Prop with Retirement
function syncPropTblRow(){
	
	
		getincassrtRows(null,"N"); 

	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	
	var $tblPropRow=$("#fnaPropOwnTblByCPF tbody tr:last");
	var $tblRetRow=$("#IncAssRetPlgtbl tbody tr:last"); 
	  
	
	var rowRefID = "PROP_"+$tblPropRow.index();
	 

	$tblPropRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(rowRefID); 
	$tblRetRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(rowRefID);
	
	
//	var dte=new Date(); 
//	var rowRefID=$tblPropRow.attr("rowref");
//		if(isValidObject(rowRefID)){
//			rowRefID=rowRefID;
//		}else{
//			rowRefID="PROP_"+$tblPropRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
//			 dte.getSeconds()+dte.getMilliseconds();
//		}
//
//	$tblPropRow.attr("rowref",rowRefID);
//	$tblRetRow.attr("rowref",rowRefID); 
//	
//
//	$tblPropRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
//	$tblRetRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
	
	
	
	$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Properties"); 
	
	
	$tblRetRow.find("td:eq(3)").find('input:eq(0)').val(isEmpty($tblPropRow.find("td:eq(2)").find('input:eq(0)').val())?"":$tblPropRow.find("td:eq(2)").find('input:eq(0)').val());
 
	
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR");
//	$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
//		if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
//	}); 

 	
	
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').val((isEmpty($tblPropRow.find("td:eq(16)").find('input:eq(0)').val())?Number(0):Number($tblPropRow.find("td:eq(16)").find('input:eq(0)').val())));
//	$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').val("");
//	$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
 	
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').val(""); 
//	$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	var owner=$tblPropRow.find("td:eq(4)").find('select:eq(0)').val().toUpperCase(); 
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner); 
//	$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
//		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
//	}); 


	
	
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage)); 
//	$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
//		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
//	}); 

	
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge)); 
//	$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//		if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
//	}); 
	
	
//	applyEventHandlers();
	applyToastrAlert("Property Ownership data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
	
	 
	return true;
}

function syncPropTblEditRow($lastrow){
//	console.log("inside syncPropTblEditRow .")
	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	
	var $rowref=$lastrow.find("td:eq(0)").find("input.rowrefid").val(); 
	$lastrow.find("td:eq(0)").find("input.rowrefid").val($rowref);
	
	 
	
	var desc,amt,owner,obj,refId;
//	 var chkExist=isValidObject($("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]"));
//	 var chklength=$("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]").length;
//	 var chklength=$("#IncAssRetPlgtbl  tbody").find("tr").find("td:eq(0)").find("input.rowrefid").length;
//	 $tblPropRow.find("td:eq(0)").find("input.rowrefid").val(rowRefID);
		

	
 var chklength=$("#IncAssRetPlgtbl  tbody").find("tr").find("td:eq(0)").find("input.rowrefid").length; 
				
	if(chklength > 0){ 
				 
//	$("#fnaPropOwnTblByCPF tbody").find("tr[rowref="+$rowref+"]").each(function(){  
	$("#fnaPropOwnTblByCPF tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
		if($rowref == $(this).val()){
	      var $tblPropRow=$(this).closest("tr");
		  desc=$tblPropRow.find("td:eq(2)").find('input:eq(0)').val();		 
		  owner=$tblPropRow.find("td:eq(4)").find('select:eq(0)').val().toUpperCase();   
		  obj=$tblPropRow.find("td:eq(15)").find('select:eq(0)').val();
		  amt=$tblPropRow.find("td:eq(16)").find('input:eq(0)').val();
		  refId=$(this).val();
		}
		  
	});
	 
	if(isValidObject(refId)){
		if($lastrow.find("td:eq(15)").find('select:eq(0)').val()  ==  "Y" ){
			if(!($lastrow.find("td:eq(4)").find('select:eq(0)').val() == "Joint")){
				newRowPropTblRow($lastrow); 
			}
		}
	} 
	
	if(!(owner == "Joint")){
	if(obj == "Y"){
		
//		$("#IncAssRetPlgtbl tbody").find("tr[rowref="+$rowref+"]").each(function(){
		$("#IncAssRetPlgtbl tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
			if($rowref == $(this).val()){
//			var $tblRetRow=$(this);
			var $tblRetRow=$(this).closest("tr"); 
			$(this).addClass("rowrefid").val(refId); 
		
		$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Properties"); 
		$tblRetRow.find("td:eq(3)").find('input:eq(0)').val(isEmpty(desc)?"":desc); 
		$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR"); 
		$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
			if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
		}); 

		
		$tblRetRow.find("td:eq(5)").find('input:eq(0)').val((isEmpty(amt)?Number(0):Number(amt)));
		$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
		
		$tblRetRow.find("td:eq(6)").find('input:eq(0)').val("");
		$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
		
		$tblRetRow.find("td:eq(7)").find('input:eq(0)').val(""); 
		$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
		
		$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner);
		$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
			if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
		}); 

		
		$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage));
		$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
			if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
		}); 
		
		$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge));
//		$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//			if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
//		}); 
		 
		applyEventHandlers();
		
			} 
	 });
		
		applyToastrAlert("Property Ownership data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
		 
		
	}else{
//		IncAssRetPlgtbl.row($("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]")).remove().draw();
		$("#IncAssRetPlgtbl tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
			if($rowref == $(this).val()){
//			$(this).closest("tr").remove().draw();
			IncAssRetPlgtbl.row($(this).closest("tr")).remove().draw();
			reorderSino("IncAssRetPlgtbl"); 
			}
		});
	 }
}
	 else{
//			IncAssRetPlgtbl.row($("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]")).remove().draw();
			$("#IncAssRetPlgtbl tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
				if($rowref == $(this).val()){
					IncAssRetPlgtbl.row($(this).closest("tr")).remove().draw();
					reorderSino("IncAssRetPlgtbl"); 
				}
			});
		}
	}
	else{ 
		
		
		if($lastrow.find("td:eq(15)").find('select:eq(0)').val()  ==  "Y" ){
			if(!($lastrow.find("td:eq(4)").find('select:eq(0)').val() == "Joint")){
				newRowPropTblRow($lastrow); 
			}
		}
	}
	
	return true;
}


function newRowPropTblRow($tblPropRow){
	var owner=$tblPropRow.find("td:eq(4)").find('select:eq(0)').val().toUpperCase(); 
	
	if(!(owner == "Joint")){
	getincassrtRows(null,"N");
//	getSyncIncAssRows(null,"N");

	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	 
	var $tblRetRow=$("#IncAssRetPlgtbl tbody tr:last");  
	
//	var dte=new Date(); 
//	var rowRefID=$tblPropRow.attr("rowref");
//		if(isValidObject(rowRefID)){
//			rowRefID=rowRefID;
//		}else{
//			rowRefID="PROP_"+$tblPropRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
//			 dte.getSeconds()+dte.getMilliseconds();
//		}
		
		var rowRefID = "PROP_"+$tblPropRow.index();
		 

		$tblPropRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(rowRefID); 
		$tblRetRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(rowRefID);
		
		
//	$tblPropRow.attr("rowref",rowRefID);
//	$tblRetRow.attr("rowref",rowRefID); 
	
//
//	$tblPropRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
//	$tblRetRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
	
	
	$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Properties"); 
	
	
	$tblRetRow.find("td:eq(3)").find('input:eq(0)').val(isEmpty($tblPropRow.find("td:eq(2)").find('input:eq(0)').val())?"":$tblPropRow.find("td:eq(2)").find('input:eq(0)').val());
 
	
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR");
//	$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
//		if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
//	}); 

 	
	
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').val((isEmpty($tblPropRow.find("td:eq(16)").find('input:eq(0)').val())?Number(0):Number($tblPropRow.find("td:eq(16)").find('input:eq(0)').val())));
//	$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').val("");
//	$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
 	
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').val(""); 
//	$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner); 
//	$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
//		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
//	}); 


	
	
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage)); 
//	$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
//		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
//	}); 

	
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge)); 
//	$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//		if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
//	}); 
	
	
//	applyEventHandlers();
	applyToastrAlert("Property Ownership data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");

	}
	return true;
}

//-End
function calcTotalPropertyAmts(){ 
	 var sumslfcash=0,sumspscash=0,sumslfcpf=0,sumspscpf=0;
	 var sumcurincself=0,sumcurincsps=0,sumcurincfam=0;
var $fnaPropOwnTblByCPF = fnaPropOwnTblByCPF.rows().count();
var ownership; 

	 if($fnaPropOwnTblByCPF >0){
		 
		 $("#fnaPropOwnTblByCPF tbody tr").each(function(i,row){
			 ownership=$(this).find("td:eq(4)").find('select:eq(0)').val();
			 var totClntLnCash	=Number($(this).find("td:eq(11)").find("input:eq(0)").val()); 
			 var totSpsLnCash	=Number($(this).find("td:eq(13)").find("input:eq(0)").val());
			 var totClntLnCpf   =Number($(this).find("td:eq(10)").find("input:eq(0)").val());
			 var totSpsLnCpf	=Number($(this).find("td:eq(12)").find("input:eq(0)").val());
			 var totRetCurInc;
			 
			 //Annual Rental Income
			 var RetCurInc		=Number($(this).find("td:eq(9)").find("input:eq(0)").val());//Current Annual Rental Income
			 var marketvalue 	=Number($(this).find("td:eq(3)").find("input:eq(0)").val());//Market Value
			 var apprRate		=Number($(this).find("td:eq(5)").find("input:eq(0)").val()/100);//Appreciation Rate
			 var numofyears		= $("#retYrstoret").val()//Number($(this).find("td:eq(17)").find("input:eq(0)").val());//Years to Rent
			 
			 
//			 totRetCurInc= marketvalue* Math.pow((1+apprRate),numofyears);
			totRetCurInc  = FVCalculation(apprRate, numofyears, -1*marketvalue, 0, 0);
//			 console.log("totClntLnCash-->"+totClntLnCash+","+totSpsLnCash+","+totClntLnCpf+","+totSpsLnCpf)
			 
			 if(!isEmpty(totClntLnCash)){
				 sumslfcash +=(totClntLnCash); 
			 }
			 
			 if(!isEmpty(totSpsLnCash)){
				 sumspscash +=(totSpsLnCash); 
			 }
			 
			 if(!isEmpty(totClntLnCpf)){
				 sumslfcpf +=(totClntLnCpf); 
			 }
			 
			 if(!isEmpty(totSpsLnCpf)){
				 sumspscpf +=(totSpsLnCpf);  
			 }
			 
			 if(!isEmpty(totRetCurInc)){
				if(ownership =="Self"){sumcurincself +=(totRetCurInc);}
				if(ownership =="Spouse"){sumcurincsps +=(totRetCurInc);}
				if(ownership =="Joint"){sumcurincfam +=(totRetCurInc);}
			 }
//			 console.log("totRetCurInc-->"+totRetCurInc);
			 
		 });
	 } 
	 
	
	 
	 
	 if(!( sumslfcash==0 && sumspscash==0 && sumslfcpf==0 && sumspscpf==0 && sumcurincself==0 && sumcurincsps==0 && sumcurincfam==0)){
		
	 /*hidden property ownership value*/
		$("#hTotClntLnCash").val(remPriceAfDec(sumslfcash));
		$("#hTotSpsLnCash").val(remPriceAfDec(sumspscash));  
		$("#hTotClntLnCpf").val(remPriceAfDec(sumslfcpf));
		$("#hTotSpsLnCpf").val(remPriceAfDec(sumspscpf));
		$("#hTotRetCurInc").val(remPriceAfDec(sumcurincself+sumcurincsps+sumcurincfam));
		
	/*annual expenditure values*/   
	   $("#expdSelfProploan").val(remPriceAfDec(sumslfcash));
	   $("#expdSpsProploan").val(remPriceAfDec(sumspscash)); 
		
	 if(sumslfcash>0 || sumspscash>0){
			 applyToastrAlert("Property loan repayment is calculated and Reflected to Expected fund Inflow and Outflow Screen");
		 }
		
		$("#incsrcSelfNempRentamt").val(remPriceAfDec(sumcurincself));
		$("#incsrcSpsNempRentamt").val(remPriceAfDec(sumcurincsps));
		$("#incsrcJointNempRentamt").val(remPriceAfDec(sumcurincfam));
		
		 if(sumcurincself>0 || sumcurincsps>0 || sumcurincfam>0){
			 applyToastrAlert("Annual Rental Income is calculated and Reflected to Expected fund Inflow and Outflow Screen");
		 } 
	 } 
	 
	 
	 if(sumslfcash==0){$("#hTotClntLnCash").val("0");$("#expdSelfProploan").val("0");}
	 if(sumspscash==0){$("#hTotSpsLnCash").val("0");$("#expdSpsProploan").val("0");}
	 if(sumslfcpf==0){$("#hTotClntLnCpf").val("0");}
	 if(sumspscpf==0){$("#hTotSpsLnCpf").val("0");}
	 if(sumcurincself==0){$("#incsrcSelfNempRentamt").val("0");}
	 if(sumcurincsps==0){$("#incsrcSpsNempRentamt").val("0");}
	 if(sumcurincfam==0){$("#incsrcJointNempRentamt").val("0");}
	 
	 calcSum(null,SrcOF_Inc.SRCOFINCM_SLF);
	 calcSum(null,SrcOF_Inc.SRCOFINCM_SPS);
	 calcSum(null,SrcOF_Inc.SRCOFINCM_JOINT);
	 
	 
	 calcSum(this,'SUMOF_ANNEXP_SELF');
	 calcSum(this,'SUMOF_ANNEXP_SPS');
	 calcSum(this,'SUMOF_ANNEXP_FAM');
	 
	 
	 return true;
}


/*********************************************Synchronize Property Ownership to Cpf Addition and Deduction***********************************************/

function newRowPropCpfEditTbl($lastrow){
	 
	
	
	var flg=false;
	var $tblCpfRow=$("#cpfAccAddDedTable tbody tr:last"); 
		
//	var $lastrowDel=$lastrow;
	var $rowref=$lastrow.find("td:eq(0)").find("input.rowrefid").val(); 
	$lastrow.find("td:eq(0)").find("input.rowrefid").val($rowref);
	
	var ownership,ClntLnCpf,SpsLnCpf,refid;
	 
//	 var chkExist=isValidObject($("#cpfAccAddDedTable  tbody").find("tr[rowref="+$rowref+"]")); 
	 var chklength=$("#cpfAccAddDedTable  tbody").find("tr").find("td:eq(0)").find("input.rowrefid").length; 
		
		if(chklength > 0){  
		  
			$("#fnaPropOwnTblByCPF tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
				if($rowref == $(this).val()){
			      var $tblPropRow=$(this).closest("tr");
//	$("#fnaPropOwnTblByCPF tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
		  ownership	=$tblPropRow.find("td:eq(4)").find('select:eq(0)').val();
		  ClntLnCpf =$tblPropRow.find("td:eq(10)").find("input:eq(0)").val();
		  SpsLnCpf	=$tblPropRow.find("td:eq(12)").find("input:eq(0)").val();
		  refid		=$tblPropRow.find("td:eq(0)").find("input.rowrefid").val();
		 }

	});
		
	$("#cpfAccAddDedTable tbody").find("tr").find("td:eq(0)").find("input.rowrefid").each(function(){
		if($rowref == $(this).val()){ 
		cpfAccAddDedTable.row($(this).closest("tr")).remove().draw();
		}
	});
	
	
//	if(isValidObject(refid)){
//		 var ClntLnCpf =$lastrow.find("td:eq(10)").find("input:eq(0)").val();
//		 var SpsLnCpf =$lastrow.find("td:eq(12)").find("input:eq(0)").val();
//
//		 if(!isEmpty(SpsLnCpf) || (!isEmpty(ClntLnCpf))){
//			 newRowPropCpfTbl($lastrow);
//		}
//	} 
	if($rowref == refid){
		  if(!isEmpty(ClntLnCpf)){
				
				getCADRows(null); 	
				
				$tblCpfRow = $("#cpfAccAddDedTable tbody tr:last");	
//				$tblCpfRow.attr("rowref",$rowref); 
				 
				$tblCpfRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(refid);
				
				$tblCpfRow.find("td:eq(2)").find('option:eq(1)').prop("selected","selected"); 
//				$tblCpfRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
//					 changeOnCADType($(this));
//					 reverseCpfSync($tblCpfRow);
//				});
				 
				  
				$tblCpfRow.find("td:eq(3)").find('select:eq(0)').val("Self");
//				$tblCpfRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
//						reverseCpfSync($tblCpfRow);	
//					});
				 
				$tblCpfRow.find("td:eq(4)").find('select:eq(0)').val("Loan Repayment"); 

		 
				$tblCpfRow.find("td:eq(5)").find('select:eq(0)').val("Deduction"); 



				$tblCpfRow.find("td:eq(6)").find('input:eq(0)').val("CPFACC000001");
				$tblCpfRow.find("td:eq(6)").find('input:eq(1)').val("Ordinary");
//				$tblCpfRow.find("td:eq(6)").find('input:eq(1)').on("change",function(){
//					reverseCpfSync($tblCpfRow);	
//				});
				 
				$tblCpfRow.find("td:eq(7)").find('input:eq(0)').val("");
//				$tblCpfRow.find("td:eq(7)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
//				 	 checkDateFormat($(this));  
//				 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
//				 }); 

				 
				$tblCpfRow.find("td:eq(8)").find('input:eq(0)').val("");
//				$tblCpfRow.find("td:eq(8)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
//				 	 checkDateFormat($(this));  
//				 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
//				 });

			 
				$tblCpfRow.find("td:eq(9)").find('input:eq(0)').val(ClntLnCpf);
//				$tblCpfRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
//				$tblCpfRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
//					reverseCpfSync($tblCpfRow);	
//				});
				  
				$tblCpfRow.find("td:eq(10)").find('select:eq(0)').val(""); 


				  
				 $tblCpfRow.find("td:eq(11)").find('select:eq(0)').val(""); 
				 reorderSino("cpfAccAddDedTable");
//				 applyEventHandlers();
				 applyToastrAlert("Property Ownership (SELF) data will be reflected to CPF Account - Additions & Deductions of funds into CPF A/C in Central Provident Fund Screen !");
			}  
			
			if(!isEmpty(SpsLnCpf)){
				
				getCADRows(null); 	 
				$tblCpfRow = $("#cpfAccAddDedTable tbody tr:last");	
//				$tblCpfRow.attr("rowref",$rowref); 
//				 
//				$tblCpfRow.find("td:eq(0)").find('input:eq(2)').val($rowref);
				$tblCpfRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(refid);
				
				$tblCpfRow.find("td:eq(2)").find('option:eq(2)').prop("selected","selected");
//				$tblCpfRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
//					 changeOnCADType($(this));
//					 reverseCpfSync($lastRow);
//				});
				  
				$tblCpfRow.find("td:eq(3)").find('select:eq(0)').val("Spouse");
//				$tblCpfRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
//						reverseCpfSync($tblCpfRow);	
//					});
				 
				$tblCpfRow.find("td:eq(4)").find('select:eq(0)').val("Loan Repayment"); 


				 
				$tblCpfRow.find("td:eq(5)").find('select:eq(0)').val("Deduction"); 



				$tblCpfRow.find("td:eq(6)").find('input:eq(0)').val("CPFACC000001");
				$tblCpfRow.find("td:eq(6)").find('input:eq(1)').val("Ordinary");
//				$tblCpfRow.find("td:eq(6)").find('input:eq(1)').on("change",function(){
//						reverseCpfSync($tblCpfRow);	
//					});
				  
				$tblCpfRow.find("td:eq(7)").find('input:eq(0)').val("");
//				$tblCpfRow.find("td:eq(7)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
//				 	 checkDateFormat($(this));  
//				 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
//				 }); 

				$tblCpfRow.find("td:eq(8)").find('input:eq(0)').val("");
//				$tblCpfRow.find("td:eq(8)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
//				 	 checkDateFormat($(this));  
//				 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
//				 });

			 
				$tblCpfRow.find("td:eq(9)").find('input:eq(0)').val(SpsLnCpf);
//				$tblCpfRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
//				$tblCpfRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
//						reverseCpfSync($tblCpfRow);	
//					});
				  
				$tblCpfRow.find("td:eq(10)").find('select:eq(0)').val(""); 


				  
				$tblCpfRow.find("td:eq(11)").find('select:eq(0)').val(""); 
				reorderSino("cpfAccAddDedTable");
//				 applyEventHandlers();
				applyToastrAlert("Property Ownership (SPOUSE) data will be reflected to CPF Account - Additions & Deductions of funds into CPF A/C in Central Provident Fund Screen !");
			}
//			else{ 
//		 
//		cpfAccAddDedTable.row($("#cpfAccAddDedTable  tbody").find("tr[rowcpfref="+$rowcpfref+"]")).remove().draw();
//			 
	}
 }else{
	 var ClntLnCpf =$lastrow.find("td:eq(10)").find("input:eq(0)").val();
	 var SpsLnCpf =$lastrow.find("td:eq(12)").find("input:eq(0)").val();

	 if(!isEmpty(SpsLnCpf) || (!isEmpty(ClntLnCpf))){
		 newRowPropCpfTbl($lastrow);
	}
 }
return true;
}


function newRowPropCpfTbl($tblPropRow){
	
	 
//	 getCADRows(null);
	  
	
	var $tblPropRow=$("#fnaPropOwnTblByCPF tbody tr:last");
	var $tblCpfRow;
	  

	/*var dte=new Date(); 
	var rowRefID=$tblPropRow.attr("rowref");
		if(isValidObject(rowRefID)){
			rowRefID=rowRefID;
		}else{
			rowRefID="PROP_"+$tblPropRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
			 dte.getSeconds()+dte.getMilliseconds();
		}*/
	
	var rowRefID = "PROP_"+$tblPropRow.index();
 
	$tblPropRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(rowRefID); 
	
	
	 
		
	var ownership	=$tblPropRow.find("td:eq(4)").find('select:eq(0)').val();
	var ClntLnCpf   =$tblPropRow.find("td:eq(10)").find("input:eq(0)").val();
	var SpsLnCpf	=$tblPropRow.find("td:eq(12)").find("input:eq(0)").val();

	if(!isEmpty(ClntLnCpf)){
		
		getCADRows(null);
		$tblCpfRow = $("#cpfAccAddDedTable tbody tr:last"); 
		$tblCpfRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(rowRefID);
//		$tblCpfRow.attr("rowref",rowRefID);
//		$tblPropRow.attr("rowref",rowRefID);
		
//		$tblCpfRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
//		$tblPropRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
		 
		$tblCpfRow.find("td:eq(2)").find('option:eq(1)').prop("selected","selected"); 
		
		/*$tblCpfRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
			 changeOnCADType($(this));
			 reverseCpfSync($tblCpfRow);
		});
		 */
		  
		$tblCpfRow.find("td:eq(3)").find('select:eq(0)').val("Self");
		
		/*$tblCpfRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
				reverseCpfSync($tblCpfRow);	
			});*/
		 
		$tblCpfRow.find("td:eq(4)").find('select:eq(0)').val("Loan Repayment");
 
		$tblCpfRow.find("td:eq(5)").find('select:eq(0)').val("Deduction"); 



		$tblCpfRow.find("td:eq(6)").find('select:eq(0)').val("CPFACC000001");
		$tblCpfRow.find("td:eq(6)").find('input:eq(0)').val("Ordinary")
		
		/*$tblCpfRow.find("td:eq(6)").find('input:eq(1)').on("change",function(){
			reverseCpfSync($tblCpfRow);	
		});*/
		 
		/*$tblCpfRow.find("td:eq(7)").find('input:eq(0)').val("");
		$tblCpfRow.find("td:eq(7)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
		 	 checkDateFormat($(this));  
		 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
		 }); */

		 
		/*$tblCpfRow.find("td:eq(8)").find('input:eq(0)').val("");
		$tblCpfRow.find("td:eq(8)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
		 	 checkDateFormat($(this));  
		 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
		 });*/

	 
		$tblCpfRow.find("td:eq(9)").find('input:eq(0)').val(ClntLnCpf);
		
		/*$tblCpfRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
		$tblCpfRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
				reverseCpfSync($tblCpfRow);	
			});*/
		  
		 $tblCpfRow.find("td:eq(10)").find('select:eq(0)').val(""); 
		  
		 $tblCpfRow.find("td:eq(11)").find('select:eq(0)').val("");
		 
//		 applyToastrAlert("Property Ownership (SELF) data will be reflected to CPF Account - Additions & Deductions of funds into CPF A/C in Central Provident Fund Screen !");
		 applyToastrAlert("Property Load repayment through the CPF - Ordinary Account by Self is reflected to CPF Addition & Deduction screen");
		 
//		 applyEventHandlers();
		
	} 
	
	if(!isEmpty(SpsLnCpf)){
		
		getCADRows(null);
		$tblCpfRow = $("#cpfAccAddDedTable tbody tr:last");	 
		/*$tblCpfRow.attr("rowref",rowRefID);
		$tblPropRow.attr("rowref",rowRefID);*/
		
		$tblCpfRow.find("td:eq(0)").find('input:eq(2)').addClass("rowrefid").val(rowRefID);
		

//		$tblCpfRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
//		$tblPropRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
		 
		$tblCpfRow.find("td:eq(2)").find('option:eq(2)').prop("selected","selected");
		/*$tblCpfRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
			 changeOnCADType($(this));
			 reverseCpfSync($tblCpfRow);
		});*/
		  
		$tblCpfRow.find("td:eq(3)").find('select:eq(0)').val("Spouse");
		/*$tblCpfRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
			reverseCpfSync($tblCpfRow);	
		});*/
		 
		$tblCpfRow.find("td:eq(4)").find('select:eq(0)').val("Loan Repayment");
		 
		$tblCpfRow.find("td:eq(5)").find('select:eq(0)').val("Deduction");
		
		$tblCpfRow.find("td:eq(6)").find('select:eq(0)').val("CPFACC000001");
		$tblCpfRow.find("td:eq(6)").find('input:eq(0)').val("Ordinary");
		/*This function is important to make a reverse sync*/
		$tblCpfRow.find("td:eq(6)").find('input:eq(1)').on("change",function(){
//				reverseCpfSync($tblCpfRow);	
			});
		  
/*		$tblCpfRow.find("td:eq(7)").find('input:eq(0)').val("");
		$tblCpfRow.find("td:eq(7)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
		 	 checkDateFormat($(this));  
		 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
		 }); 
*/
		/*$tblCpfRow.find("td:eq(8)").find('input:eq(0)').val("");
		$tblCpfRow.find("td:eq(8)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
		 	 checkDateFormat($(this));  
		 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
		 });
*/
	 
		$tblCpfRow.find("td:eq(9)").find('input:eq(0)').val(SpsLnCpf);
		/*$tblCpfRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");*/
		/*This function is important to make a reverse sync*/
		$tblCpfRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
//			reverseCpfSync($tblCpfRow);	
		});
		  
		$tblCpfRow.find("td:eq(10)").find('select:eq(0)').val(""); 


		  
		$tblCpfRow.find("td:eq(11)").find('select:eq(0)').val(""); 
		 
//		 applyEventHandlers();
//		 applyToastrAlert("Property Ownership (SPOUSE) data will be reflected to CPF Account - Additions & Deductions of funds into CPF A/C in Central Provident Fund Screen !");
		 applyToastrAlert("Property Load repayment through the CPF - Ordinary Account by Spouse is reflected to CPF Addition & Deduction screen");
	} 
	 
	 
	return true;
}
 
$("#txtFldDlgCpfPropObj").on("change",function(){
	propObjChange($(this),$("#txtFldDlgPropCurAnlRetInc"));
});

$("#txtFldDlgCpfPropSold").on("change",function(){
	onSoldChange($(this),$("#txtFldDlgPropRentOnRetire"),$("#txtFldDlgPropCurRetInc"));
});

function onSoldChange(elmid,chgeid1,chgeid2){
//	solddiv
	var value=elmid.val();

	if(value=="N"){ 
		
		$(".solddiv").css("display","block");
		$(".soldrentdiv").css("display","none"); 
		chgeid1.prop("disabled",false);
		chgeid2.prop("disabled",true);
		
//	}else if(value=="Y"){ 
//		
//		$(".solddiv").css("display","none");
//		$(".soldrentdiv").css("display","none"); 
//		chgeid1.prop("disabled",true);
//		chgeid2.prop("disabled",true);
//		chgeid1.val("");
//		chgeid2.val("");
		
	}else{

		$(".solddiv").css("display","none");
		$(".soldrentdiv").css("display","none");
		chgeid1.prop("disabled",true);
		chgeid2.prop("disabled",true);
		chgeid1.val("");
		chgeid2.val("");
		
	}
	return true;
}

function propObjChange(elmid,changeId){
	
	var value=elmid.val();

	if(value=="Inv"){
//		$("#currentinc").css("display","block");
		$("#currentinc").removeClass("hidden");
		changeId.prop("disabled",false);
	
//	}else if(value=="Res"){ 
////		$("#currentinc").css("display","none");
//		$("#currentinc").addClass("hidden");
//		changeId.prop("disabled",true);
//		changeId.val("");
	}else{

//		$("#currentinc").css("display","none");
		$("#currentinc").addClass("hidden");
		changeId.prop("disabled",true);
		changeId.val("");
	}
	return true;
}


$("#txtFldDlgPropRentOnRetire").on("change",function(){
	retOnRetFnc($(this),$("#txtFldDlgPropCurRetInc"));
	if($(this).val() == 'Y'){ 
		 if(!validationRetirementScreen())return; 
	}
});


function retOnRetFnc(elmid,changeid){
	var retonretval=elmid.val(); 
	if(retonretval == 'Y'){  
		$(".soldrentdiv").css("display","block"); 
		changeid.prop("disabled",false);
//	}else if(retonretval == 'N'){ 
//		$(".soldrentdiv").css("display","none")
//		changeid.prop("disabled",true);
//		changeid.val("");
	} else{
		$(".soldrentdiv").css("display","none")
		changeid.prop("disabled",true);
		changeid.val("");
	}
	return true;
}





$("#txtFldDlgCpfPropObj,#txtFldDlgCpfPropSold,#txtFldDlgPropRentOnRetire").on("change",function(){  
		propyearstorent($("#txtFldDlgCpfPropObj"),$("#txtFldDlgCpfPropSold"),$("#txtFldDlgPropRentOnRetire"),$("#txtFldDlgPropYrsToRent")); 
});

$("#txtFldDlgCpfPropMktVal,#txtFldDlgCpfPropApprecrate,#retYrstoret").on("change",function(){  
	calculateCrtRentIncome($("#txtFldDlgCpfPropMktVal"),$("#txtFldDlgCpfPropApprecrate"),$("#retYrstoret"),$("#txtFldDlgPropFVOnRent")); 
});


function propyearstorent(elmid,sold,rent,changeid){
	var invobject=elmid.val();
	var soldval = sold.val();
	var rentval = rent.val();
	
	if(invobject == 'Inv' && soldval=="N" && rentval=="Y"){  
		$(".yearstorentdiv").css("display","block"); 
		changeid.prop("disabled",false);
	}else if(invobject == 'Res'){ 
		$(".yearstorentdiv").css("display","none"); 
		changeid.prop("disabled",true);
		changeid.val("");
	} else{
		$(".yearstorentdiv").css("display","none"); 
		changeid.prop("disabled",true);
		changeid.val("");
	}
	return true;
}


function calculateCrtRentIncome(mart,aprate,yrtoret,chgeid){
	
	var mktval=Number(mart.val());
	var apprate=Number(aprate.val())/100;
	yrtoret=Number(yrtoret.val());
//	var result=mktval*(1+apprate);
//	FV = Current Market Value x (1+ Appreciation Rate %)^ Number of Years to Retirement Age
//	var result = mktval * Math.pow(((1+apprate)),yrtoret);
	var result = FVCalculation(apprate, yrtoret, -1*mktval, 0, 0);
	chgeid.val(remPriceAfDec(result));
	
}
