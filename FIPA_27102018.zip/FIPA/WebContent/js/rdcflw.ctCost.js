 var ctcostdescription;
 var rdcflwTbl; 


 /*Datatable Initialisation*/
 var RDExptbl = $('#RDExptbl').DataTable({
 	destroy: true,
  	responsive: false,         
     ordering: false,
     searching: false,     
     scrollY:  "40vh",
     scrollX: true,
     scroller: false,
     scrollCollapse:false,
     paging:false, 
     filter:false,   
     columnDefs: [], 
     dom: '<<"top" ip>flt>',  
   columnDefs: [  { width: '20px', targets: [0,1]},
    	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7],"orderable": false,"searchable": false}],		 
 		 fnDrawCallback: function(oSettings) {
 			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
 				 
 			    } 
     
 		 }, 
 }).draw();
 
 var dataDescSet=[];
 $("button#btnRPCFAnalysis").on("click",function(){ 
	
	 if(!validationRetirementScreen())return; 
	 showLoader();
	 retirementToRpcfAnalysis();
	 $("#generateproExptbl").html("");
		$("#generateproIncometbl").html("");
		$("#generatetoamendincExp").html(""); 
		
		clrRdCfTable();
		
	 syncToRpcf1();
	 syncToRpcf2();
	 syncToRpcf3(); 
	 getRDcfExpDets(); 
	 getRDcfIncDets();
	 $("#txtFldRDClientName").focus(); 
//	 if(!validationRetirementPlnSection())return;
	 showFIPAModel('rpCashFlwAnlys_Dialog','RP CF Analysis');
	 hideLoader();
	  
 });
 function clrRdCfTable(){
	 var dataTableIdsAll = [ 'RDExptbl', 'RDInctbl','RDIncAsstbl']; 
	             	$.each(dataTableIdsAll, function(index, value) {
	             		$("#" + value).dataTable().fnClearTable(); 
	             		showInfoError(value);
	             	});
 
 }
 
$('#rpCashFlwAnlys_Dialog').find("button[id=btnRetOk]").click(function (){  
	  $('#rpCashFlwAnlys_Dialog').modal('hide'); 
}); 

$('#rpCashFlwAnlys_Dialog').find("a[id=btnRetReset]").click(function (){ 
clearAllInputsOfRPCFAnalysis(); 
});

$('#rpCashFlwAnlys_Dialog').find("a[id=btnRetPrint]").click(function (){ 
	 showLoader();	
	 genPDF();
});


function genPDF()
 {
	 
	 var pdf = new jsPDF('p','mm',"a2",true); 

		pdf.setFontSize(13);
		pdf.page=1; 
    	//new
    	var NORMAL_FONTSIZE = ['11pt','11pt'];
    	var HIGHRES_FONTSIZE = ["10pt","7pt"];

    	function setFonSize(elm,fontsize){ 
    		$(elm).find("label").css("font-size",fontsize[0]);
    		$(elm).find(".headerlabel").css("font-size",fontsize[1]);
    		
    	}
    	
    	var $wrapper = document.getElementById('printHtmlPdf');
    	   var setFonSizeOfWrapper = setFonSize.bind(null, $wrapper);

     $("#printHtmlPdf").css("visibility","visible");
    	
//    	var pdfModelWidth=$("#rpCashFlwAnlys_Dialog").width();
//    	var pdfNeedWidth="1366px"
    	
    	$("#rpCashFlwAnlys_Dialog .btn-group").hide();
    	$("#rpCashFlwAnlys_Dialog .pdf-hide").hide();
//    	$("#rpCashFlwAnlys_Dialog").css("width",pdfNeedWidth);
    	
     
//     var $printElm=$("#rpt1").clone();
	
    /* $(".tempSvgImg").show();
     $(".regularSvg").hide();*/
 showLoader();		
    	
 html2canvas(document.getElementById('rpt1'),
     {scale:1,
    	 useCORS:true,
	 	 allowTaint:true,
	 	 windowWidth:1366,
	 	 windowHeight:676,
	 	 logging:true,
	 	 async:false
         }).then(function(canvas) {
         showLoader();		 
    	 document.body.appendChild(canvas);
    	 var img = canvas.toDataURL('image/png'); 
    	 var widthT = pdf.internal.pageSize.width;    
	     var heightT = pdf.internal.pageSize.height;
	     var imgData = canvas.toDataURL("image/png", 1.0);
	     
	     pdf.addImage(imgData,'png',5,12,widthT-10,180);
	     pdfheader(pdf,170);
	     footer(pdf,0);
	     
	     console.log("1 ---------------------------------------------__>");
	     
	     document.body.removeChild(canvas);
	     
	     html2canvas(document.getElementById('rpt2'),
	             {scale:1,
	      	 	 useCORS:true,
	      	 	 allowTaint:true,
	      	 	 logging:true,
	      	 	 windowWidth:1366,
	      	 	 windowHeight:676,
	      	 	async:false
	      	 	 }).then(function(canvas) {
	          	 document.body.appendChild(canvas);
	          	 var img = canvas.toDataURL('image/png');
	          	 
	          	 var widthT = pdf.internal.pageSize.width;    
	      	     var heightT = /*pdf.internal.pageSize.height;550*/100;
	      	     var imgData = canvas.toDataURL("image/png", 1.0);
	      	    	
//	      	     if($("#RDExptbl tbody tr:first td:first").hasClass('dataTables_empty')){
//	      	    	 heightT=270;
//	      	     }
	      	     
	      	     
	      	     pdf.addImage(imgData,'JPEG',5,200,widthT-10,heightT);
	      	     
	      	     if(!$("#RDExptbl tbody tr:first td:first").hasClass("dataTables_empty")){
	      	     
	      	     pdf.addPage();
	      	     pdfheader(pdf,170);
	      	     footer(pdf,0);
	      	     
	      	     addAutoTblRDEExp(pdf,"");
	      	     
	      	     }
	      	     
	      	     if(!$("#RDExptbl tbody tr:first td:first").hasClass('dataTables_empty')){ 
	      	     pdf.addPage('a2','portrait');//landscape 
	      	     pdfheader(pdf,170);//250
	      	     footer(pdf,0);//80
	      	     
	      	     pdf.text(10,15,"Projection of Expenditure Details on Retirement (Detailed Representation)")
	      	     
//	      	     pdf.text(10,10," ");
	      	     
	      	     addTableData(pdf,"");
	      	     }
	      	     
	      	   if($("#RDExptbl tbody tr:first td:first").hasClass('dataTables_empty')){
//	    	     savePdf(pdf);
	      	   } 
	      	     console.log("2 ---------------------------------------------__>");
	      	     document.body.removeChild(canvas);
	      	   
	      	    
	     		  html2canvas(document.getElementById('chart1'),
	     		          {
	     		 	 	 scale:1,
	     		 	 	 useCORS:true,
	     		 	 	 allowTaint:true,
	     		 	 	 windowWidth:1366,
	     		 	 	 windowHeight:676,
	     		 	 	async:false
	     		 	 	 }).then(function(canvas) {
	     		 	 	  if(!$("#RDExptbl tbody tr:first td:first").hasClass('dataTables_empty')){  	 
	     		     	 document.body.appendChild(canvas);
	     		     	 var img = canvas.toDataURL('image/png');
	     		 	    
	     		 	     pdf.addPage("a2","portrait");
	     		 	     pdfheader(pdf,170);
	     		 	     footer(pdf,0);
	     		 	     
	     		 	     var widthT = pdf.internal.pageSize.width;    
	     		 	     var heightT = /*pdf.internal.pageSize.height;550*/200;
	     		 	     var imgData = canvas.toDataURL("image/png", 1.0);
	     		 	     
	     		 	     pdf.text(10,15,"Projection of Expenditure on Retirement Graphical View");
	     		 	     
//	     		 	     pdf.text(10,17," ");
	     		 	     
	     		 	     pdf.addImage(imgData,'JPEG',5,40,widthT-10,heightT);
	     		 	    
//	     			     savePdf(pdf);
	     		 	     
	     		 	     document.body.removeChild(canvas);
	     		 	     
	     		 	 	 } 
	     		 	 	  
	     		 	 	html2canvas($("#rpt3")[0],
	     		 	  		   {
	     		 	  			 	 scale:1,
	     		 	  			 	 useCORS:false,
	     		 	  			 	 allowTaint:true,
	     		 	  			 	 windowWidth:1366,
	     		 	  			 	 windowHeight:676
	     		 	  		 }).then(function(canvas) {
	     		 	  			 	
	     		 	  			if(!$("#RDInctbl tbody tr:first td:first").hasClass("dataTables_empty")){
	     		 	  			 	 pdf.addPage("a2","portrait");
	     		 	  		    	 document.body.appendChild(canvas);
	     		 	  		    	 var img = canvas.toDataURL('image/png'); 
	     		 	  	        	 var widthT = pdf.internal.pageSize.width;    
	     		 	  	    	     var heightT =280;
	     		 	  	    	     var imgData = canvas.toDataURL("image/png", 1.0);
	     		 	  	    	     
	     		 	  	    	     pdfheader(pdf,170);
	     		 	  	    	     footer(pdf,0);
	     		 	  	    	     
	     		 	  	    	     pdf.text(10,15,"Income to be received during retirement")
	     		 	  	    	     addAutoTblRDInc(pdf,20);
	     		 	  	    	     
	     		 	  			}  
	     		 	  			
	     		 	  		if(!$("#RDIncAsstbl tbody tr:first td:first").hasClass("dataTables_empty")){
	     		 	  	    	    pdf.addPage();
	     		 	  	    	    pdfheader(pdf,170);
	     			      	     	footer(pdf,0);
	     			      	     	
	     			      	     	pdf.text(10,15,"Income and assets available for retirement(obtained from data keyed in earlier,also allow new entry with indication)")
	     			      	     	addAutoTblRDIncAss(pdf,20)
	     		 	  		}	     
	     		 	  	    	     if($("#generateproIncometbl tbody tr").length==0 || $("#generateproIncometbl tbody tr:first td:first").hasClass('dataTables_empty')){ 
//	     		 	  	    	    	 heightT=280;
	     		 	  	    	     }
	     		 	  	    	     console.log("3 ---------------------------------------------__>");
	     		 	  	    	     
//	     		 	  	    	     pdf.addImage(imgData,'png',5,12,widthT-10,heightT);
	     		 	  	    	     
	     		 	  	    	     
	     		 	  			     
	     		 	  	    	   if($("#generateproIncometbl tbody tr").length>0 && !$("#generateproIncometbl tbody tr:first td:first").hasClass('dataTables_empty')){ 
	     		 	      	    	 pdf.addPage('a2','portrait');//landscape
	     		 	      	    	 pdfheader(pdf,170);//250
	     		 	      	    	 footer(pdf,0);//80
	     		 	      	    	 
	     		 	      	    	 pdf.text(10,15,"Projected Income avaliable on retirement (Detailed Representation)")
	     		 	          	     
//	     		 	          	     pdf.text(10,10," ")
	     		 	      	    	 
	     		 	      	    	 addGenTableData(pdf,"");
	     		 	      	     }
	     		 	  	    	     
	     		 	  	    	     
	     		 	  			 document.body.removeChild(canvas);
	     		 	  			 
	     		 	  		  	 html2canvas(document.getElementById('chart2'),
	     		 	  		  	         {
	     		 	  		  		 	 scale:1,
	     		 	  		  		 	 useCORS:false,
	     		 	  		  		 	 allowTaint:true,
	     		 	  		  		 	 windowWidth:1366,
	     		 	  		  		 	 windowHeight:676
	     		 	  		  		 	 }).then(function(canvas) {
	     		 	  		  		 	if($("#generateproIncometbl tbody tr").length>0 && !$("#generateproIncometbl tbody tr:first td:first").hasClass('dataTables_empty')){	 
	     		 	  		  		 	 document.body.appendChild(canvas);
	     		 	  		  	    	 var img = canvas.toDataURL('image/png');
	     		 	  		  	    	
	     		 	  		  	    	 pdf.addPage("a2","portrait");
	     		 	  		  	    	 
	     		 	  		  	    	 var widthT = pdf.internal.pageSize.width;    
	     		 	  		  		     var heightT = 200;
	     		 	  		  		     var imgData = canvas.toDataURL("image/png", 1.0);
	     		 	  		  		    
	     		 	  		  		     pdfheader(pdf,170);
	     		 	  		  		     footer(pdf,0);
	     		 	  		  		     
	     		 	  		  		     pdf.text(10,15,"Projection of Income on Retirement Graphical Representation")
	     		 	  		  		     
//	     		 	  		  		     pdf.text(10,17," ")
	     		 	  		  		     
	     		 	  		  		     pdf.addImage(imgData,'JPEG',5,40,widthT-10,heightT); 
	     		 	  		  		     
	     		 	  		  		     document.body.removeChild(canvas);
	     		 	  		  		} 
	     		 	  		  	
	     		 	  		  if($("#projInvRettbldiv").is(":visible")){ 	  		 	
	     		 	  		  		 	
	     		 	  		  		html2canvas(document.getElementById('rpt4'),
	     		 	  		  	        {scale:1,
	     		 	  		  	   	 useCORS:false,
	     		 	  		  		 	 allowTaint:true,
	     		 	  		  		 	 windowWidth:1366,
	     		 	  		  		 	 windowHeight:676,
	     		 	  		  		 	 logging:true
	     		 	  		  	        }).then(function(canvas) {
	     		 	  		  	       	 
	     		 	  		  	   	 document.body.appendChild(canvas);
	     		 	  		  	   	 var img = canvas.toDataURL('image/png'); 
	     		 	  		  	   	 var widthT = pdf.internal.pageSize.width;    
	     		 	  		  		     var heightT =/* pdf.internal.pageSize.height*/35;
	     		 	  		  		     var imgData = canvas.toDataURL("image/png", 1.0);
	     		 	  		  		    
//	     		 	  		  		     if(!$("#projInvRettbldiv").is(":visible")){ 
//	     		 	  		  		    	 heightT=40;
//	     		 	  		  		     }

	     		 	  		  		    
	     		 	  		  		     
//	     		 	  		  		     pdf.addImage(imgData,'png',5,12,widthT-10,heightT);
	     		 	  		  		     
	     		 	  		  		     if($("#projInvRettbldiv").is(":visible")){ 
//	     		 	  		  		    	 pdf.addPage();
//	     		 	  		  		    	 footer(pdf)
	     		 	  		  		    	 
//	     		 	  		  		     pdf.text(10,10,"Interactive cashflow projection of retirement Income and Expenditure (Detailed View)")
	     		 	  		  	   	     
//	     		 	  		  	   	     pdf.text(10,10," ");
	     		 	  		  		    	 pdf.addPage("a2","portrait");//landscape
	     		 	  		  		    	 pdfheader(pdf,170);//250
	     		 	  		  		    	 footer(pdf,0);//80
	     		 	  		  		    	 
	     		 	  		  		    	 addAmendTableData(pdf,10);
	     		 	  		  		    	 
	     		 	  		  		     }
	     		 	  		  		     
	     		 	  		  		     console.log("4 ---------------------------------------------__>");
	     		 	  		  		     
	     		 	  		  		     if(!$("#projInvRettbldiv").is(":visible")){ 
	     		 	  		  		    	 savePdf(pdf)
	     		 	  		  		     }
	     		 	  		  		     
	     		 	  		  		     document.body.removeChild(canvas);
//	     		 	  		  		     $("#generatetoamendincExp_wrapper").css("visibility","visible");
	     		 	  		  		  
	     		 	  		  		if($("#projInvRettbldiv").is(":visible")){ 	
	     		 	  		  		 html2canvas(document.getElementById('chart3'),
	     		 	  		  	            {
	     		 	  		  	   	 	 scale:1,
	     		 	  		  	   	 	 useCORS:false,
	     		 	  		  	   	 	 allowTaint:true,
	     		 	  		  	   	 	 windowWidth:1366,
	     		 	  		  	   	 	 windowHeight:676,
	     		 	  		  	   	 	 }).then(function(canvas) {
	     		 	  		  	   	     if($("#projInvRettbldiv").is(":visible")){	 
	     		 	  		  	       	 document.body.appendChild(canvas);
	     		 	  		  	       	 var img = canvas.toDataURL('image/png');
	     		 	  		  	       	 
	     		 	  		  	       	 pdf.addPage("a2","portrait");
	     		 	  		  	       	 
	     		 	  		  	       	 var widthT = pdf.internal.pageSize.width;    
	     		 	  		  	   	     var heightT = /*pdf.internal.pageSize.height;550*/180;
	     		 	  		  	   	     var imgData = canvas.toDataURL("image/png", 1.0);
	     		 	  		  	   	    
	     		 	  		  	   	     pdfheader(pdf,170);
	     		 	  		  	   	     footer(pdf,0);
	     		 	  		  	   	     
	     		 	  		  	   	     pdf.text(10,15,"Projection of Expenditure on Retirement Graphical Representation")
	     		 	  		  	   	     
	     		 	  		  	   	     pdf.addImage(imgData,'JPEG',5,40,widthT-10,heightT);
	     		 	  		  	   	     
	     		 	  		  	   	     document.body.removeChild(canvas);
	     		 	  		  	   	     savePdf(pdf);
	     		 	  		  	   	 	 }
	     		 	});	  	
	     		 	}
  		  	     });	   
	     		 }else{
	     			 savePdf(pdf);
	     		 }	  		  		
	     	  });	 	  		 
	      }); 
	   });
   });
});
      
 

 
} 


function retirementToRpcfAnalysis(){ 
	var date=new Date();
	var curDate=date.getDate()+"/"+(date.getMonth()+1)+"/"+date.getFullYear();
	
	$("span[id='txtFldRDClientName']").text("");
	$("span[id='txtFldRDClientAge']").text("");
	$("span[id='txtFldRDSpouseName']").text("");
	$("span[id='txtFldRDSpouseAge']").text("");
	$("span[id='txtFldRDDate']").text("");
	
	if(!isEmpty($("#dfSelfName").val())){$("span[id='txtFldRDClientName']").text($("#dfSelfName").val());}
	if(!isEmpty($("#dfSelfAge").val())){$("span[id='txtFldRDClientAge']").text($("#dfSelfAge").val());}
	if(!isEmpty($("#dfSpsName").val())){$("span[id='txtFldRDSpouseName']").text($("#dfSpsName").val());}
	if(!isEmpty($("#dfSpsAge").val())){$("span[id='txtFldRDSpouseAge']").text($("#dfSpsAge").val());}
	$("span[id='txtFldRDDate']").text(curDate); 
	
	
	if(!isEmpty($("#retSelfAge").val())){$("input[name='txtFldRDSlfIntAge']").val($("#retSelfAge").val());}
	if(!isEmpty($("#retSpsAge").val())){$("input[name='txtFldRDSpsIntAge']").val($("#retSpsAge").val());}	  
	if(!isEmpty($("#retAgeBasedon").val())){$("select[name='selRDRetAgebasedOn']").val($("#retAgeBasedon").val());}	
	if(!isEmpty($("#retYrstoret").val())){$("input[name='txtFldRDYrsToRet']").val($("#retYrstoret").val());}  
	if(!isEmpty($("#retSelfCoordinateage").val())){$("input[name='txtFldRDSlfCoRetAge']").val($("#retSelfCoordinateage").val());}
	if(!isEmpty($("#retSpsCoordinateage").val())){$("input[name='txtFldSpsRDCoRetAge']").val($("#retSpsCoordinateage").val());}	  
	if(!isEmpty($("#retSelfProjage").val())){$("input[name='txtFldRDSlfProjLfe']").val($("#retSelfProjage").val());}	 
	if(!isEmpty($("#retSpsProjage").val())){$("input[name='txtFldRDSpsProjLfe']").val($("#retSpsProjage").val());}	   
	if(!isEmpty($("#retSelfLivyrs").val())){$("input[name='txtFldRDSlfProlvyrs']").val($("#retSelfLivyrs").val());}	  
	if(!isEmpty($("#retSpsLivyrs").val())){$("input[name='txtFldRDSpsProlvyrs']").val($("#retSpsLivyrs").val());}	   
	if(!isEmpty($("#retFamLivyrs").val())){$("input[name='txtFldRDFamProlvyrs']").val($("#retFamLivyrs").val());}	  
	if(!isEmpty($("#retSelfProjroi").val())){$("input[name='txtFldRDSlfROI']").val($("#retSelfProjroi").val());	assEffrate();}	  
	if(!isEmpty($("#retSpsProjroi").val())){$("input[name='txtFldRDSpsROI']").val($("#retSpsProjroi").val());	assEffrate();}	 
	if(!isEmpty($("#retFamProjroi").val())){$("input[name='txtFldRDFamROI']").val($("#retFamProjroi").val());	assEffrate();} 
	if(!isEmpty($("#retSelfAnnlexpdamt").val())){$("input[name='txtFldRDSlfLvAmt']").val($("#retSelfAnnlexpdamt").val());}	 
	if(!isEmpty($("#retSpsAnnlexpdamt").val())){$("input[name='txtFldRDSpsLvAmt']").val($("#retSpsAnnlexpdamt").val());}	 
	if(!isEmpty($("#retFamAnnlexpdamt").val())){$("input[name='txtFldRDFamLvAmt']").val($("#retFamAnnlexpdamt").val());}	 
	if(!isEmpty($("#txtFldRDSlfCoRetAge").val())){$("input[name='txtFldRDSlfLvCorAge']").val($("#txtFldRDSlfCoRetAge").val());}	 
	if(!isEmpty($("#txtFldSpsRDCoRetAge").val())){$("input[name='txtFldRDSpsLvCorAge']").val($("#txtFldSpsRDCoRetAge").val());}	   
	if(!isEmpty($("#retFamCoordretage").val())){$("input[name='txtFldRDFamLvCorAge']").val($("#retFamCoordretage").val());}	  
	if(!isEmpty($("#txtFldRDSlfProlvyrs").val())){$("input[name='txtFldRDSlfLvProAge']").val($("#txtFldRDSlfProlvyrs").val());}	 
	if(!isEmpty($("#txtFldRDSpsProlvyrs").val())){$("input[name='txtFldRDSpsLvProAge']").val($("#txtFldRDSpsProlvyrs").val());}	 
	if(!isEmpty($("#txtFldRDFamProlvyrs").val())){$("input[name='txtFldRDFamLvProAge']").val($("#txtFldRDFamProlvyrs").val());}	 

}
 
 function validationRetirementScreen(){
  	
 		 
 		if(!(validateFocusRDFlds('focusfmIntage','retSelfAge',RETSCREEN_INTSLFAGE))) return; 
 		if(!(validateFocusRDFlds('focusfmIntage','retSpsAge',RETSCREEN_INTSPSAGE))) return;
 		if(!(validateFocusRDFlds('focusfmRdAge','retAgeBasedon',RETSCREEN_RETAGEBASE))) return;
 		if(!(validateFocusRDFlds('focusfmyrstord','retYrstoret',RETSCREEN_YRSTORET))) return;
 		if(!(validateFocusRDFlds('focusfmcoyrs','retSelfCoordinateage',RETSCREEN_CORSLFAGE))) return;
 		if(!(validateFocusRDFlds('focusfmcoyrs','retSpsCoordinateage',RETSCREEN_CORSPSAGE))) return;
 		if(!(validateFocusRDFlds('focusfmprojlife','retSelfProjage',RETSCREEN_PROSLFAGE))) return;
 		if(!(validateFocusRDFlds('focusfmprojlife','retSpsProjage',RETSCREEN_PROSPSAGE))) return;
 		if(!(validateFocusRDFlds('focusfmprojlvyrs','retSelfLivyrs',RETSCREEN_PROSLFLVYRRET))) return;
 		if(!(validateFocusRDFlds('focusfmprojlvyrs','retSpsLivyrs',RETSCREEN_PROSPSLVYRRET))) return;
 		if(!(validateFocusRDFlds('focusfmprojlvyrs','retFamLivyrs',RETSCREEN_PROFAMLVYRRET))) return;
 		if(!(validateFocusRDFlds('focusfmroi','retSelfProjroi',RETSCREEN_ROISLF))) return;
 		if(!(validateFocusRDFlds('focusfmroi','retSpsProjroi',RETSCREEN_ROISPS))) return;
 		if(!(validateFocusRDFlds('focusfmroi','retFamProjroi',RETSCREEN_ROIFAM))) return;
 		 
 		  
 		if(!(validateFocusRDFlds('focusfmlvself','retSelfAnnlexpdamt',RETSCREEN_LVYRSLF)))return; 
 		if(!(validateFocusRDFlds('focusfmlvsps','retSpsAnnlexpdamt',RETSCREEN_LVYRSPS))) return; 
 		if(!(validateFocusRDFlds('focusfmlvfam','retFamAnnlexpdamt',RETSCREEN_LVYRFAM))) return;
 		
 		
 		
 		return true;
 	 
 }
 /*Mandatory Fields Tooltip*/ 
 $("#retSelfAge,#retSpsAge,#retAgeBasedon,#retYrstoret," +
 		"#retSelfCoordinateage,#retSpsCoordinateage," +
 		"#retSelfProjage,#retSpsProjage,#retSelfLivyrs," +
 		"#retSpsLivyrs,#retFamLivyrs,#retSelfProjroi,#retSpsProjroi,#retFamProjroi," +
 		"#retSelfAnnlexpdamt,#retSpsAnnlexpdamt,#retFamAnnlexpdamt").on("change",function(){
 			if(!isEmpty($(this).val())){
 	$(this).qtip('disable');
 	$(this).qtip('destroy',true);
 	$(this).removeClass("mandatoryFillFlds");
 			}
 });


function validationRetirementPlnSection(){
 	
		 
		if(!(validateFocusRDFlds('focusIntage','txtFldRDSlfIntAge',RETSCREEN_INTSLFAGE))) return; 
		if(!(validateFocusRDFlds('focusIntage','txtFldRDSpsIntAge',RETSCREEN_INTSPSAGE	))) return;
		if(!(validateFocusRDFlds('focusRdAge','selRDRetAgebasedOn',RETSCREEN_RETAGEBASE))) return;
		if(!(validateFocusRDFlds('focusyrstord','txtFldRDYrsToRet',RETSCREEN_YRSTORET))) return;
		if(!(validateFocusRDFlds('focuscoyrs','txtFldRDSlfCoRetAge',RETSCREEN_CORSLFAGE))) return;
		if(!(validateFocusRDFlds('focuscoyrs','txtFldSpsRDCoRetAge',RETSCREEN_CORSPSAGE))) return; 
		if(!(validateFocusRDFlds('focusprojlife','txtFldRDSlfProjLfe',RETSCREEN_PROSLFAGE))) return;
		if(!(validateFocusRDFlds('focusprojlife','txtFldRDSpsProjLfe',RETSCREEN_PROSPSAGE))) return;
		if(!(validateFocusRDFlds('focusprojlvyrs','txtFldRDSlfProlvyrs',RETSCREEN_PROSLFLVYRRET))) return;
		if(!(validateFocusRDFlds('focusprojlvyrs','txtFldRDSpsProlvyrs',RETSCREEN_PROSPSLVYRRET))) return;
		if(!(validateFocusRDFlds('focusprojlvyrs','txtFldRDFamProlvyrs',RETSCREEN_PROFAMLVYRRET))) return;
		if(!(validateFocusRDFlds('focusroi','txtFldRDSlfROI',RETSCREEN_ROISLF))) return;
		if(!(validateFocusRDFlds('focusroi','txtFldRDSpsROI',RETSCREEN_ROISPS))) return;
		if(!(validateFocusRDFlds('focusroi','txtFldRDFamROI',RETSCREEN_ROIFAM))) return;
	 
		  
		if(!(validateFocusRDFlds('focuslvself','txtFldRDSlfLvAmt',RETSCREEN_LVYRSLF)))return; 
		if(!(validateFocusRDFlds('focuslvsps','txtFldRDSpsLvAmt',RETSCREEN_LVYRSPS))) return; 
		if(!(validateFocusRDFlds('focuslvfam','txtFldRDFamLvAmt',RETSCREEN_LVYRFAM))) return;
		
		
		
		return true;
	 
}
/*Mandatory Fields Tooltip*/ 
$("#txtFldRDSlfIntAge,#txtFldRDSpsIntAge,#selRDRetAgebasedOn,#txtFldRDYrsToRet," +
		"#txtFldRDSlfCoRetAge,#txtFldSpsRDCoRetAge," +
		"#txtFldRDSlfProjLfe,#txtFldRDSpsProjLfe,#txtFldRDSlfProlvyrs," +
		"#txtFldRDSpsProlvyrs,#txtFldRDFamProlvyrs,#txtFldRDSlfROI,#txtFldRDSpsROI,#txtFldRDFamROI," +
		"#txtFldRDInfRate,#txtFldRDBankIntRate,#txtFldRDSlfLvAmt,#txtFldRDSpsLvAmt," +
		"#txtFldRDFamLvAmt").on("change",function(){
			if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
			}
});
  

function clearAllInputsOfRPCFAnalysis(){
	$("table#assumptionsectiontbl").find("input,select").each(function(){ $(this).val(""); return; });
	$("table#livingneedrdtbl").find("input,select").each(function(){ $(this).val(""); return; });
	
	RDExptbl.rows().remove().draw();
	RDInctbl.rows().remove().draw();
	RDIncAsstbl.rows().remove().draw(); 
	
	$("#generateproExptbl").html("");
	$("#generateproIncometbl").html("");
	$("#generatetoamendincExp").html(""); 
	  
	

	$("#RetirementValueBasedOn").val("");
	d3.select("#projectionOfExp").selectAll("svg").remove();
	$("#projOfExpetbldiv").css("display","none"); 


	 $("#projOfIncometblediv").css("display","none");
	$("#RetirementValueBasedOnInc").val("");
	d3.select("#projectionOfInc").selectAll("svg").remove();


	$("#projInvRettbldiv").css("display","none"); 
	d3.select("#CashFlwprojectionOnRtmnt").selectAll("svg").remove();
	
}




//############################On Search data populate###################   
function retirement_cashflow(cont,contvalue){
 
		if(cont=="retSelfAge"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSlfIntAge']").val(contvalue);}	 
		} 
		if(cont=="retSpsAge"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSpsIntAge']").val(contvalue);}	 
		}
		if(cont=="retAgeBasedon"){
			if(!isEmpty(contvalue)){$("select[name='selRDRetAgebasedOn']").val(contvalue);}	 
		}
		if(cont=="retYrstoret"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDYrsToRet']").val(contvalue);}	 
		} 
		if(cont=="retSelfCoordinateage"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSlfCoRetAge']").val(contvalue);}	 
		}
		if(cont=="retSpsCoordinateage"){
			if(!isEmpty(contvalue)){$("input[name='txtFldSpsRDCoRetAge']").val(contvalue);}	 
		}
		if(cont=="retSelfProjage"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSlfProjLfe']").val(contvalue);}	 
		}
		if(cont=="retSpsProjage"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSpsProjLfe']").val(contvalue);}	 
		}
		if(cont=="retSelfLivyrs"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSlfProlvyrs']").val(contvalue);}	 
		} 
		if(cont=="retSpsLivyrs"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSpsProlvyrs']").val(contvalue);}	 
		}
		if(cont=="retFamLivyrs"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDFamProlvyrs']").val(contvalue);}	 
		}
		if(cont=="retSelfProjroi"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSlfROI']").val(contvalue);}	 
		}
		if(cont=="retSpsProjroi"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSpsROI']").val(contvalue);}	 
		}
		if(cont=="retFamProjroi"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDFamROI']").val(contvalue);}	 
		}
		if(cont=="retSelfAnnlexpdamt"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSlfLvAmt']").val(contvalue);}
		}
		if(cont=="retSpsAnnlexpdamt"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDSpsLvAmt']").val(contvalue);}
		}
		if(cont=="retFamAnnlexpdamt"){
			if(!isEmpty(contvalue)){$("input[name='txtFldRDFamLvAmt']").val(contvalue);}
		}
		
		assEffrate();
		cordretage();
		projlvyrs();
}

//############################On Change Assumption Section###################  
$("#retSelfAge").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSlfIntAge']").val($(this).val());}
});  
$("#retSpsAge").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSpsIntAge']").val($(this).val());}	  
});  
$("#retAgeBasedon").on("change",function(){
	if(!isEmpty($(this).val())){$("select[name='selRDRetAgebasedOn']").val($(this).val());}	  
});  	
$("#retYrstoret").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDYrsToRet']").val($(this).val());}  
});  	
$("#retSelfCoordinateage").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSlfCoRetAge']").val($(this).val());}	  
});  
$("#retSpsCoordinateage").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldSpsRDCoRetAge']").val($(this).val());}	  
});  
$("#retSelfProjage").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSlfProjLfe']").val($(this).val());}	 
});  	
$("#retSpsProjage").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSpsProjLfe']").val($(this).val());}	   
});  	
$("#retSelfLivyrs").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSlfProlvyrs']").val($(this).val());}	  
});   
$("#retSpsLivyrs").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSpsProlvyrs']").val($(this).val());}	   
});  	
$("#retFamLivyrs").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDFamProlvyrs']").val($(this).val());}	  
});  	
$("#retSelfProjroi").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSlfROI']").val($(this).val());	assEffrate();}	  
});  	
$("#retSpsProjroi").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSpsROI']").val($(this).val());	assEffrate();}	  
});  	
$("#retFamProjroi").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDFamROI']").val($(this).val());	assEffrate();} 
});   

$("#retSelfAnnlexpdamt").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSlfLvAmt']").val($(this).val());}	 
});
$("#retSpsAnnlexpdamt").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSpsLvAmt']").val($(this).val());}	 
});
$("#retFamAnnlexpdamt").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDFamLvAmt']").val($(this).val());}	 
});

$("#txtFldRDSlfCoRetAge").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSlfLvCorAge']").val($(this).val());}	 
	
});
$("#txtFldSpsRDCoRetAge").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSpsLvCorAge']").val($(this).val());}	 
	
});
$("#txtFldFamRDCoRetAge").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDFamLvCorAge']").val($(this).val());}	 
	
});
$("#txtFldRDSlfProlvyrs").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSlfLvProAge']").val($(this).val());}	 
	
});
$("#txtFldRDSpsProlvyrs").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDSpsLvProAge']").val($(this).val());}	 
	
});
$("#txtFldRDFamProlvyrs").on("change",function(){
	if(!isEmpty($(this).val())){$("input[name='txtFldRDFamLvProAge']").val($(this).val());}	 
	
});
$("#selDlgprojORFreq").on("change",function(){
	if(!rdFrequencyValidation($('#txtFldDlgprojORAgePayends'),$("#txtFldDlgprojOREslrate"),$(this)))return; 
}); 

$("#txtFldDlgprojORAgePaySts,#selDlgprojORAgeBsOn").on("change",function(){
	if(!rdStartAgeValidate($('#txtFldDlgprojORAgePaySts'),$('#selDlgprojORAgeBsOn')))return;
});
$("#txtFldDlgprojORAgePayends").on("change",function(){
	if(!rdEndAgeValidate($('#txtFldDlgprojORAgePaySts'),$(this)))return;
});

function rdFrequencyValidation(ageendid,eclaRate,elmid){
//	if(!isEmpty(elmid.val())){
		 if(elmid.val() == "SINGLE"){
			 ageendid.prop("disabled",true);
			 eclaRate.prop("disabled",true);
			 ageendid.val("");
			 eclaRate.val("");
			 
		 }else{
			 ageendid.prop("disabled",false);
			 eclaRate.prop("disabled",false);
		 }
//		}else{
//			ageendid.prop("disabled",false);
//			eclaRate.prop("disabled",false);
//		}	 
	return true;
}
function rdStartAgeValidate(elmId,agebased){
	var intretslfage=Number($("#txtFldRDSlfIntAge").val()); 
	var intretspsage=Number($("#txtFldRDSpsIntAge").val());
	
	var totAge=Number($("#txtFldRDSlfProjLfe").val());    
	var ageBasedOn=isEmpty(agebased.val()) ? "" : agebased.val().toUpperCase(); 
	
	
	/*var flg;
	
	if(!isEmpty(ageBasedOn)){
		
		if(ageBasedOn == "SELF"){
			flg=ageBasedOn;
		}else if(ageBasedOn == "SPOUSE"){
			flg=ageBasedOn;
		}
		
	}*/
	
	if(ageBasedOn=="SELF"){
	if(!isEmpty(elmId.val())){
		if(elmId.val() <  intretslfage ){
			showAlert("Age Payment Starts should not be Less than Intended retirement Self Age ("+intretslfage+") ",elmId);
			elmId.val("");
			return false;
		}else if(elmId.val() > totAge){
			showAlert("Age Payment Starts should not be Greater than Projected life expectancy Self Age  ("+totAge+")",elmId);
			elmId.val("");
			return false;
		}
	}
	
	}else if(ageBasedOn=="SPOUSE"){
		if(!isEmpty(elmId.val())){
			if(elmId.val() <  intretspsage ){
				showAlert("Age Payment Starts should not be Less than Intended retirement Spouse Age ("+intretspsage+")  ",elmId);
				elmId.val("");
				return false;
			}else if(elmId.val() > totAge){
				showAlert("Age Payment Starts should not be Greater than Projected life expectancy Self Age  ("+totAge+")",elmId);
				elmId.val("");
				return false;
			}
		}
	}
	
	
	return true;
} 

function rdEndAgeValidate(startAgeid,elmId){

	var intretslfage=Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=Number($("#txtFldRDSlfProjLfe").val());
	
	var startAge=Number(startAgeid.val());
	
	if(isEmpty(startAge)){
		if(!isEmpty(elmId.val())){
			showAlert(AGE_PAYMENT_STARTS,startAgeid);
			elmId.val("");
			return false;
		}
	}
	  
 
	if(!isEmpty(elmId.val())){
		if(elmId.val() <  startAge){
			showAlert("Age Payment Ends should not be Less than Age Payment Start Age ("+startAge+") ",elmId);
			elmId.val("");
			return false;
		}else
		if( elmId.val() > totAge){
			showAlert("Age Payment Ends should not be Greater than Projected life expectancy(Age)(Self) ("+totAge+")",elmId);
			elmId.val("");
			return false;
		}
	}
	return true;
} 


$("#txtFldRDSlfROI,#txtFldRDInfRate").on("change",function(){
	assEffrate();
});

function assEffrate(){
	 var RDSlfROI=(!isEmpty($("#txtFldRDSlfROI").val()))?Number($("#txtFldRDSlfROI").val())/100 : 0;
	 var RDInfROI =(!isEmpty($("#txtFldRDInfRate").val()))?Number($("#txtFldRDInfRate").val())/100 : 0;
	 var manupulate=[(1+RDSlfROI)/(1+RDInfROI)]-1;
	 manupulate=manupulate*100
	 $("input[name='txtFldRDAssRate']").val(manupulate.toPrecision(4));
}




 


/*Add Row Click */
$("#RDExpAddRow").on("click",function(){
if(!validationRetirementPlnSection())return;
	$("#RDExpAddRow").parent().css("border","");
	$('#generatetoamendincExp').html("");
	d3.select("#CashFlwprojectionOnRtmnt").selectAll("svg").remove();
	
			RDothretClearFlds();
			showFIPAModel('ProjOfExp_Dialog','Other Payment to be made durning Retirement');   
			$('#ProjOfExp_Dialog').on('shown.bs.modal', function () {
				$("#ProjOfExp_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#ProjOfExp_Dialog").find("input[id=txtFldDlgprojORtyofpay]").focus();
				$("#ProjOfExp_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatRDExpEditRowDetails())return;
					   	RDothretRdlyflds(INS_MODE);  
					   	getRDothretRows(null); 
						$('#ProjOfExp_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getRDothretRows(dataset){
	
	
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFlRDExpDelRowMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldprojORId">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="raRDExpDelRowSelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<input type="text" name="txtFldprojORtyofpay" class="form-control editable"   onmouseover="fipaTooltip(this);" />'; 
var cell3 = '<select type="text" name="selprojORFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
var cell4 = '<input type="text" name="txtFldprojORAnlExp" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell5 = '<input type="text" name="txtFldprojOREslrate" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell6 = '<select type="text" name="selprojORAgeBsOn" class="form-control editable"   onmouseover="fipaTooltip(this);" ></select>';
var cell7 = '<input type="text" name="txtFldprojORAgePaySts" class="form-control editable"  onmouseover="fipaTooltip(this);" />';
var cell8 = '<input type="text" name="txtFldprojORAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
var cell9 ='<input type="text" name="txtFldprojORRemarks" class="form-control editable"  onmouseover="fipaTooltip(this);" />'+
'<input type="hidden" name="txtFldprojORCrtdBy"/><input type="hidden" name="txtFldprojORCrtdDate"/>'; 


RDExptbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9] ).draw( false );

var rowCount = $('#RDExptbl tbody tr').length;	
var $lastRow = $("#RDExptbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"raRDExpDelRow"+$lastRow.index())
.parent().find('label').attr('for',"raRDExpDelRow"+$lastRow.index());

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgprojORtyofpay").val());
$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){
	if(!isEmpty($(this).val()) ){getRDcfExpDets();}
});


var orfreq = $("#selDlgprojORFreq > option").clone();
$lastRow.find("td:eq(3)").find('select:eq(0)').append(orfreq);
$lastRow.find("td:eq(3)").find('select:eq(0)').val($("#selDlgprojORFreq").val());
$lastRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){ 
	if(!rdFrequencyValidation($lastRow.find("td:eq(8)").find('input:eq(0)'),$lastRow.find("td:eq(5)").find('input:eq(0)'),$(this)))return; 
	if(!isEmpty($(this).val()) ){getRDcfExpDets();}
});


$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgprojORAnlExp").val());
$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(4)").find('input:eq(0)').on("change",function(){
	if(!isEmpty($(this).val()) ){getRDcfExpDets();}
});

$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgprojOREslrate").val());
$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntpCent3");
$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
	if(!isEmpty($(this).val()) ){getRDcfExpDets();}
});


var oragebsed =  $("#selDlgprojORAgeBsOn > option").clone();
$lastRow.find("td:eq(6)").find('select:eq(0)').append(oragebsed);
$lastRow.find("td:eq(6)").find('select:eq(0)').val($("#selDlgprojORAgeBsOn").val());
$lastRow.find("td:eq(6)").find('select:eq(0)').on("change",function(){ 
//	if(!rdFrequencyValidation($lastRow.find("td:eq(6)").find('select:eq(0)'),$(this)))return; 
	if(!rdStartAgeValidate($lastRow.find("td:eq(7)").find('select:eq(0)'),$(this)))return;
	if(!isEmpty($(this).val()) ){getRDcfExpDets();}
});


 
$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgprojORAgePaySts").val());
$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){ 
	if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(6)").find('select:eq(0)')))return; 
	if(!isEmpty($(this).val()) ){getRDcfExpDets();}
});

$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgprojORAgePayends").val());
$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(8)").find('input:eq(0)').on("change",function(){ 
	if(!rdEndAgeValidate($lastRow.find("td:eq(7)").find('input:eq(0)'),$(this)))return;
	if(!isEmpty($(this).val()) ){getRDcfExpDets();}
});


$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgprojORRemarks").val());
$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){  
	if(!isEmpty($(this).val()) ){getRDcfExpDets();}
});

applyEventHandlers();
  
if(dataset != null){

	
	if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
			$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
	}
	
			var infoDetsArr = new Array();
			
			for(var data in dataset){
			var col = dataset[data];
			
			switch(data){
			
			case "opId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
				break;
				
			case "retPaytype": 
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
				
				break;
				
			case "retFrequency":
				selectNullvalChk($lastRow.find("td:eq(3)"),col);   
				break;
			 
			case "retAnnualexp": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col); 
				break;
			 
			case "retEscarate": 
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(col); 
				break;
			 
			 
			case "retAgebasedon": 
				selectNullvalChk($lastRow.find("td:eq(6)"),col);   
				 
				break;
			 
			 
			case "retAgestart": 
				$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 
				break;
			 
			 
			case "retAgeend": 
				$lastRow.find("td:eq(8)").find('input:eq(0)').val(col); 
				break;
				
			case "retOthRemarks": 
				$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
				break;
			  
			case "retCrtdBy": 
				$lastRow.find("td:eq(9)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "retCrtdDate":
				$lastRow.find("td:eq(9)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "retModBy":
				infoDetsArr.push(col);
				break;
				
			case "retModDate":
				infoDetsArr.push(col);
				break;	
			}			 
			 
			}
}	
if(!rdFrequencyValidation($lastRow.find("td:eq(8)").find('input:eq(0)'),$lastRow.find("td:eq(5)").find('input:eq(0)'),$lastRow.find("td:eq(3)").find('select:eq(0)')))return; 
getRDcfExpDets();
RDothretClearFlds();

}


 


function getRDcfExpDets(){
	

	var intretslfage=Number($("#txtFldRDSlfIntAge").val());
	var intretspsage=Number($("#txtFldRDSpsIntAge").val());

	var totAge=Number($("#txtFldRDSlfProjLfe").val());
	
	
	$("#generateproExptbl tbody").html("");

	var $rowCount = RDExptbl.rows().count();	
	var $lastRow = $("#RDExptbl tbody tr:last");
	var projOfExpdata = []; 
	 
	
	if(!isEmpty(intretslfage) && !isEmpty(totAge)){
var slfroi=$("#txtFldRDSlfROI").val();
var spsroi=$("#txtFldRDSlfROI").val();
var agebasedon=$("#selRDRetAgebasedOn").val().toUpperCase();

var headlist=[];



var dataHeader=[
                {"data":"Self Age","title":"Self Age"},
                {"data":"Spouse Age","title":"Spouse Age"},
                {"data":"Self","title":"Self"},
                {"data":"Spouse","title":"Spouse"},
                {"data":"Family","title":"Family"},
                {"data":"Relative % adjustment","title":"Relative % adjustment"},
                {"data":"Adjusted Personal Expenditure","title":"Adjusted Personal Expenditure"}
                ];

var dupChk=[];


$("#RDExptbl tbody tr").each(function(i,row){
	
	var crnthd=$(this).find("td:eq(2)").find("input:eq(0)").val(); 
	
	if((i!=0 && $.inArray(crnthd,dupChk) == -1) || i==0){
		var my_item = {};
		my_item.data=crnthd;
		my_item.title=crnthd;	
		headlist.push(crnthd);
		dataHeader.push(my_item); 
	}  
	dupChk.push(crnthd);
	
});

 

dataHeader.push({"data":"Total Annual Expenditure","title":"Total Annual Expenditure"});
dataHeader.push({"data":"Total Accumulation Expenditure","title":"Total Accumulation Expenditure"});



/*Data Set*/
 

var slflvamt=Number($("#txtFldRDSlfLvAmt").val());
var spslvamt=Number($("#txtFldRDSpsLvAmt").val());
var famlvamt=Number($("#txtFldRDFamLvAmt").val());

var inflrate=Number($("#txtFldRDInfRate").val())/100;

var retAadj=Number(100);


var dataset=[];

/*Data Set*/
$("#RetirementValueBasedOn").val(agebasedon);
  
var count=0;
var oldval=0;

if($rowCount == 0){
	$("#projOfExpetbldiv").css("display","none"); 
	d3.select("#projectionOfExp").selectAll("svg").remove();
}

if(intretslfage > 0 && totAge >= intretslfage){
if($rowCount > 0){
	$("#projOfExpetbldiv").css("display","block"); 
	d3.select("#projectionOfExp").selectAll("svg").remove();
	
	var spouseage=intretspsage;
	
for(var i=intretslfage;i<=totAge;i++){ 
	
	var arrlist={};
			
			arrlist["Self Age"]=i+'<input type="hidden" value="'+(count+1)+'"/>'; //self age
			arrlist["Spouse Age"]=spouseage; //spouse age
			
			//self
			if(i==intretslfage){ 
				arrlist["Self"]=RemDecimalNumber(slflvamt); 
			}else{ 
				slflvamt=slflvamt*(1+inflrate);
				arrlist["Self"]=RemDecimalNumber(slflvamt);  
			}
			
			//spouse
			if(i==intretslfage){ 
				arrlist["Spouse"]=RemDecimalNumber(spslvamt); 
			}else{  
				spslvamt=spslvamt*(1+inflrate);
				arrlist["Spouse"]=RemDecimalNumber(spslvamt); 
			}
			
			//family
			if(i==intretslfage){ 
				arrlist["Family"]=RemDecimalNumber(famlvamt); 
			}else{   
				famlvamt=famlvamt*(1+inflrate);
				arrlist["Family"]=RemDecimalNumber(famlvamt);  
				
			}
			  
			//rel adj
			arrlist["Relative % adjustment"]=retAadj; 
			
			//adj per exp
			var adjperexp=(slflvamt+spslvamt+famlvamt)*(retAadj/100);
			arrlist["Adjusted Personal Expenditure"]=adjperexp; 
			
			  var counting= 6;
			var totAnlExp=0;
			$.each(headlist,function(j,hdr){
				$("#RDExptbl tbody tr").each(function(count,value){
					
					 var $desclt 	  = $(this).find("td:eq(2)").find("input:eq(0)").val();
					 var $freqlt 	  = $(this).find("td:eq(3)").find("select:eq(0)").val();
					 var $anlexplt	  = (isEmpty($(this).find("td:eq(4)").find("input:eq(0)").val())) ? Number(0) : Number($(this).find("td:eq(4)").find("input:eq(0)").val());
					 var $esclratelt  = (isEmpty($(this).find("td:eq(5)").find("input:eq(0)").val())) ? Number(0) : Number($(this).find("td:eq(5)").find("input:eq(0)").val());
					 var $agebasedlt  = $(this).find("td:eq(6)").find("select:eq(0)").val(); 
					 var $startslfagelt = Number($(this).find("td:eq(7)").find("input:eq(0)").val());  
					 var $endagelt   = (isEmpty($(this).find("td:eq(8)").find("input:eq(0)").val())) ? Number(totAge) : Number($(this).find("td:eq(8)").find("input:eq(0)").val()); 
					 var $noofyrslt=Math.abs($startslfagelt-$endagelt);
					 var $startspsagelt = intretslfage-intretspsage;
					 $startspsagelt=$startspsagelt+intretslfage;
					   
					 
					 if($desclt == hdr){
							if($agebasedlt == "SELF"){ 
								if($freqlt == "REGULAR"){
										if(i >= $startslfagelt &&  (i<$endagelt)){ 
											if(i==$startslfagelt){ 
												arrlist[hdr]=(isNaN($anlexplt)) ? 0 : RemDecimalNumber(Number($anlexplt));  
											}else{
												var olddata=dataset[dataset.length-1][$desclt]; 
												olddata*=(1+($esclratelt/100));
												arrlist[hdr]=(isNaN(olddata)) ? 0 : RemDecimalNumber(Number(olddata));  
											}
											
										}else{
											arrlist[hdr]=0; 
										}
							}else if($freqlt == "SINGLE"){
								if(i == $startslfagelt){
									if(i==$startslfagelt){ 
										arrlist[hdr]=(isNaN($anlexplt)) ? 0 : RemDecimalNumber(Number($anlexplt));   
									}else{   
										var olddata=dataset[dataset.length-1][$desclt]; 
										olddata*=(1+($esclratelt/100));
										arrlist[hdr]=(isNaN(olddata)) ? 0 : RemDecimalNumber(Number(olddata));  
									}
									 
								}else{
									arrlist[hdr]=0; 
								}
							}
						}else if($agebasedlt == "SPOUSE"){
							if($freqlt == "REGULAR"){
									if(spouseage >= $startslfagelt &&  (spouseage<$endagelt)){ 
										if($startslfagelt==spouseage){ 
											arrlist[hdr]=(isNaN($anlexplt)) ? 0 : RemDecimalNumber(Number($anlexplt));   
										}else{   
											var olddata=dataset[dataset.length-1][$desclt]; 
											olddata*=(1+($esclratelt/100));
											arrlist[hdr]=(isNaN(olddata)) ? 0 : RemDecimalNumber(Number(olddata));  
										} 
									
								}else{
									arrlist[hdr]=0; 
								}
									
							}else if($freqlt == "SINGLE"){
								if(spouseage == $startslfagelt){ 
									if($startslfagelt==spouseage){ 
										arrlist[hdr]=(isNaN($anlexplt)) ? 0 : RemDecimalNumber(Number($anlexplt));   
									}else{   
										var olddata=dataset[dataset.length-1][$desclt]; 
										olddata*=(1+($esclratelt/100));
										arrlist[hdr]=(isNaN(olddata)) ? 0 : RemDecimalNumber(Number(olddata));  
									} 
								}else{
									arrlist[hdr]=0; 
								}
							}
						}
					 } 
				}); 

				totAnlExp=Number(totAnlExp)+Number(arrlist[hdr]) ;  
			});
			
			var adj=arrlist["Adjusted Personal Expenditure"];
			
			arrlist["Total Annual Expenditure"]=(isNaN(totAnlExp)) ? 0 : RemDecimalNumber(Number(adj)+Number(totAnlExp));  
			
			
			if(i==intretslfage){ 
				arrlist["Total Accumulation Expenditure"]=(isNaN(totAnlExp)) ? 0 : RemDecimalNumber(Number(adj)+Number(totAnlExp));  
				  oldval=Number(adj)+totAnlExp;
			}else{     
				arrlist["Total Accumulation Expenditure"]=(isNaN(totAnlExp+oldval)) ? 0 : RemDecimalNumber(Number(Number(adj)+totAnlExp+oldval));
				oldval=Number(adj)+totAnlExp+oldval
			}
			
			 
			
			dataset.push(arrlist)
			
			spouseage++;
			count++;
			
			projOfExpdata.push({ctCostlineAge:i, ctCostlineAmt : oldval ,ctCostbarAge:i, ctCostbarAmt : totAnlExp }); 
			
		 
	}

genProjChartOfExp(projOfExpdata);
if ($.fn.DataTable.isDataTable( '#generateproExptbl') ) {
	rdcflwTbl.destroy();
	$('#generateproExptbl').html("");
}

 

rdcflwTbl=$('#generateproExptbl').DataTable( { 
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>', 
    "columns": dataHeader,  
    data:dataset,
   	columnDefs: [
   	             {"className": "dt-right","targets": "_all","orderable": false,"searchable": false}, 
   				], 
	fnDrawCallback: function(oSettings) { 
	
	if(this.fnSettings().bSorted){
	    			reorderSino('generateproExptbl');  
	    		}
	    		 
	    			
	    		 
	}    	
}).draw();
}


}
  }
	
	var len=Number($("#generateproExptbl thead tr").find("th").length)-1;  


	$("#generateproExptbl_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th").css("text-align","center");
	
	$("#generateproExptbl_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th:eq('"+len+"')").css("background-color","#337AB7").css("color","white");
	
	$("#generateproExptbl_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th:eq('"+(Number(len)-1)+"')").css("background-color","#337AB7").css("color","white");
	
	$("#generateproExptbl_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th:eq(6)").css("background-color","#337AB7").css("color","white");
	
//	$("#generateproExptbl_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th:eq(5)").css("width","12px");
	
	$("#generateproExptbl_wrapper").find(".dataTables_scrollBody").find("table tbody tr").each(function(){
		$(this).find("td:eq(0)").css("text-align","left");
		$(this).find("td:eq(1)").css("text-align","left");
//		$(this).find("td:eq(5)").css("width","9%");
	});
	
	$("#generateproExptbl_wrapper").find(".dataTables_scrollBody").find("table tbody tr").find("td:eq('"+len+"')").css("background-color","rgb(110, 162, 206)").css("color","#FFF").css("border","1px solid #FAFDFF").css("font-weight","bold");
	$("#generateproExptbl_wrapper").find(".dataTables_scrollBody").find("table tbody tr").find("td:eq('"+(Number(len)-1)+"')").css("background-color","rgb(110, 162, 206)").css("color","#FFF").css("border","1px solid #FAFDFF").css("font-weight","bold");
	$("#generateproExptbl_wrapper").find(".dataTables_scrollBody").find("table tbody tr").find("td:eq(6)").css("background-color","rgb(110, 162, 206)").css("color","#FFF").css("border","1px solid #FAFDFF").css("font-weight","bold");
		
	
}

 

 
/*Edit Row Click */
$("#RDExpEditRow").on("click",function(){ 
	var isOneRowSelected=0;
	var $rowCount = $('#RDExptbl tbody tr').length;	
	var $lastRow = $("#RDExptbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#RDExptbl tbody").find('input[name="raRDExpDelRowSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#RDExptbl tbody").find('input[name="raRDExpDelRowSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 	RDothretRdlyflds($mode);
					RDothretfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgprojORAgePayends'),$("#txtFldDlgprojOREslrate"),$("#selDlgprojORFreq")))return; 
					showFIPAModel('ProjOfExp_Dialog','Other Payment to be made durning Retirement');  
					$('#ProjOfExp_Dialog').on('shown.bs.modal', function () {
						$("#ProjOfExp_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#ProjOfExp_Dialog").find("input[id=txtFldDlgprojORtyofpay]").focus();
						$("#ProjOfExp_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatRDExpEditRowDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			RDothretfilldomval($RowId,$row); 
					     		}  
					     		if(!rdFrequencyValidation($row.find("td:eq(8)").find('input:eq(0)'),$row.find("td:eq(5)").find('input:eq(0)'),$row.find("td:eq(3)").find('select:eq(0)')))return; 
					     		getRDcfExpDets();
								$('#ProjOfExp_Dialog').modal('hide'); 
								RDothretClearFlds();
							
						});
					});
					 
			}  
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

});


/*View Row Click */
$("#RDExpViewRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#RDExptbl tbody tr').length;	
	var $lastRow = $("#RDExptbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#RDExptbl tbody").find('input[name="raRDExpDelRowSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#RDExptbl tbody").find('input[name="raRDExpDelRowSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 	RDothretRdlyflds($mode);
					RDothretfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgprojORAgePayends'),$("#txtFldDlgprojOREslrate"),$("#selDlgprojORFreq")))return; 
					showFIPAModel('ProjOfExp_Dialog','Other Payment to be made durning Retirement');  
					$('#ProjOfExp_Dialog').on('shown.bs.modal', function () {
						$("#ProjOfExp_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#ProjOfExp_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatRDExpEditRowDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			RDothretfilldomval($RowId,$row); 
					     		}  

					     		getRDcfExpDets();
								$('#ProjOfExp_Dialog').modal('hide'); 
								RDothretClearFlds();
							
						});
					});
					 
			}  
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#RDExpDelRow").on("click",function(){ 
	datatableDeleteRow('RDExptbl',RDExptbl); 
	getRDcfExpDets();
 
});

/*Clear Fields */
function RDothretClearFlds(){
	$("#ProjOfExp_Dialog").find("input[type=text]").val("");
	$("#ProjOfExp_Dialog").find("textarea").val("");
	$("#ProjOfExp_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function RDothretRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#ProjOfExp_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#ProjOfExp_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatRDExpEditRowDetails(){
	 
	if(!(validateFocusFlds('ProjOfExp_Dialog','txtFldDlgprojORtyofpay',OR_TYPE))) return; 
	if(!(validateFocusFlds('ProjOfExp_Dialog','selDlgprojORFreq',OR_FREQ))) return;
//	if(!(validateFocusFlds('ProjOfExp_Dialog','txtFldDlgprojORAnlExp',OR_ANLEXP))) return;
//	if(!(validateFocusFlds('ProjOfExp_Dialog','txtFldDlgprojOREslrate', OR_ESC))) return;
	if(!(validateFocusFlds('ProjOfExp_Dialog','selDlgprojORAgeBsOn', OR_AGEBSE))) return; 
	if(!(validateFocusFlds('ProjOfExp_Dialog','txtFldDlgprojORAgePaySts', OR_AGESTS))) return;
//	if(!(validateFocusFlds('ProjOfExp_Dialog','txtFldDlgprojORAgePayends', OR_AGEENDS))) return; 
	if(!rdFrequencyValidation($('#txtFldDlgprojORAgePayends'),$("#txtFldDlgprojOREslrate"),$("#selDlgprojORFreq")))return; 
	if(!rdStartAgeValidate($('#txtFldDlgprojORAgePaySts'),$('#selDlgprojORAgeBsOn')))return;
	if(!rdEndAgeValidate($('#txtFldDlgprojORAgePaySts'),$("#txtFldDlgprojORAgePayends")))return;
	
	  return true; 
}



/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgprojORtyofpay,#selDlgprojORFreq," +
		"#selDlgprojORAgeBsOn,#txtFldDlgprojORAgePaySts").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  

/* Filling Model Fields*/
function RDothretfilldlgval($lastRow){
	  
	  $('#ProjOfExp_Dialog #txtFldDlgprojORId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#ProjOfExp_Dialog #txtFldDlgprojORtyofpay').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#ProjOfExp_Dialog #selDlgprojORFreq').val($lastRow.find("td:eq(3)").find('select:eq(0)').val());
	  $('#ProjOfExp_Dialog #txtFldDlgprojORAnlExp').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#ProjOfExp_Dialog #txtFldDlgprojOREslrate').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#ProjOfExp_Dialog #selDlgprojORAgeBsOn').val($lastRow.find("td:eq(6)").find('select:eq(0)').val());
	  $('#ProjOfExp_Dialog #txtFldDlgprojORAgePaySts').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#ProjOfExp_Dialog #txtFldDlgprojORAgePayends').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#ProjOfExp_Dialog #txtFldDlgprojORRemarks').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#ProjOfExp_Dialog #txtFldDlgprojORCrtdBy').val($lastRow.find("td:eq(9)").find('input:eq(1)').val());
	  $('#ProjOfExp_Dialog #txtFldDlgprojORCrtdDate').val($lastRow.find("td:eq(9)").find('input:eq(2)').val());
	
}

/* Filling Table Fields*/
function RDothretfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgprojORtyofpay").val()); 
	$row.find("td:eq(3)").find('select:eq(0)').val($("#selDlgprojORFreq").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgprojORAnlExp").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgprojOREslrate").val()); 
	$row.find("td:eq(6)").find('select:eq(0)').val($("#selDlgprojORAgeBsOn").val());
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgprojORAgePaySts").val()); 
	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgprojORAgePayends").val()); 
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgprojORRemarks").val()); 
		
}


function syncToRpcf1(){
	
	 var intretslfage=Number($("#retSelfAge").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();

	 var totAge=Number($("#retSelfProjage").val());
	

	 
	var cell0 = '<span></span>'+
	'<input type="hidden" name="txtFlRDExpDelRowMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldprojORId">';
	 
	var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="raRDExpDelRowSelect"/><label>&nbsp;</label></div>'; 
	var cell2 = '<input type="text" name="txtFldprojORtyofpay" class="form-control editable"  onmouseover="fipaTooltip(this);" />'; 
	var cell3 = '<select type="text" name="selprojORFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
	var cell4 = '<input type="text" name="txtFldprojORAnlExp" class="form-control editable"  onmouseover="fipaTooltip(this);" />';
	var cell5 = '<input type="text" name="txtFldprojOREslrate" class="form-control editable"  onmouseover="fipaTooltip(this);" />';
	var cell6 = '<select type="text" name="selprojORAgeBsOn" class="form-control editable"   onmouseover="fipaTooltip(this);" ></select>';
	var cell7 = '<input type="text" name="txtFldprojORAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell8 = '<input type="text" name="txtFldprojORAgePaySts" class="form-control editable"    onmouseover="fipaTooltip(this);" />';
	var cell9 ='<input type="text" name="txtFldprojORRemarks" class="form-control editable"   onmouseover="fipaTooltip(this);" />'+
	'<input type="hidden" name="txtFldprojORCrtdBy"/><input type="hidden" name="txtFldprojORCrtdDate"/>'; 
 

		 var rowCount;
		 var $lastRow;	
		
		
		 $("#OthRetPlgtbl tbody tr").each(function(i,row){
			 var $rowCount = OthRetPlgtbl.rows().count(); 
			 if($rowCount >0){
			 RDExptbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9] ).draw( false );
					 
					  rowCount = $('#RDExptbl tbody tr').length;	
					  $lastRow = $("#RDExptbl tbody tr:last");	
					  
					  
					  $lastRow.find("td:first").find('span').text(rowCount); 

						$lastRow.find("td:eq(1)").find("input:first").click(function(){
							selectSingleRow(this);
						})

						$lastRow.find("td:eq(1)").find("input:first").attr('id',"raRDExpDelRow"+$lastRow.index())
						.parent().find('label').attr('for',"raRDExpDelRow"+$lastRow.index());

						$lastRow.find("td:eq(2)").find('input:eq(0)').val($(this).find("td:eq(2)").find('input:eq(0)').val());
						$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){
							if(!isEmpty($(this).val()) ){getRDcfExpDets();}
						});
							

						var orfreq = $("#selDlgORFreq > option").clone();
						$lastRow.find("td:eq(3)").find('select:eq(0)').append(orfreq);
						$lastRow.find("td:eq(3)").find('select:eq(0)').val((isEmpty($(this).find("td:eq(3)").find('select:eq(0)').val())? "REGULAR" : $(this).find("td:eq(3)").find('select:eq(0)').val()));
//						$lastRow.find("td:eq(3)").find('select:eq(0)').prop("disabled",true);
						$lastRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){ 
							if(!rdFrequencyValidation($lastRow.find("td:eq(8)").find('input:eq(0)'),$lastRow.find("td:eq(5)").find('input:eq(0)'),$(this)))return; 
							if(!isEmpty($(this).val()) ){getRDcfExpDets();}
						});
						
						
						$lastRow.find("td:eq(4)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(4)").find('input:eq(0)').val())? Number("0") : $(this).find("td:eq(4)").find('input:eq(0)').val()));
//						$lastRow.find("td:eq(4)").find('input:eq(0)').prop("disabled",true);
						$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntUsd");
						$lastRow.find("td:eq(4)").find('input:eq(0)').on("change",function(){
							if(!isEmpty($(this).val()) ){getRDcfExpDets();}
						});
						
						$lastRow.find("td:eq(5)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(5)").find('input:eq(0)').val())? Number("0") : $(this).find("td:eq(5)").find('input:eq(0)').val()));
//						$lastRow.find("td:eq(5)").find('input:eq(0)').prop("disabled",true);
						$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntpCent3");
						$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
							if(!isEmpty($(this).val()) ){getRDcfExpDets();}
						});
						
						var oragebsed =  $("#selDlgORAgeBsOn > option").clone();
						$lastRow.find("td:eq(6)").find('select:eq(0)').append(oragebsed);
						$lastRow.find("td:eq(6)").find('select:eq(0)').val((isEmpty($(this).find("td:eq(6)").find('select:eq(0)').val())? basedon : $(this).find("td:eq(6)").find('select:eq(0)').val()));
//						$lastRow.find("td:eq(6)").find('select:eq(0)').prop("disabled",true);
						$lastRow.find("td:eq(6)").find('select:eq(0)').on("change",function(){ 
//							if(!rdFrequencyValidation($lastRow.find("td:eq(6)").find('select:eq(0)'),$(this)))return; 
							if(!rdStartAgeValidate($lastRow.find("td:eq(7)").find('input:eq(0)'),$(this)))return;
							if(!isEmpty($(this).val()) ){getRDcfExpDets();}	
						});

						
						
						$lastRow.find("td:eq(7)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(7)").find('input:eq(0)').val())? intretslfage :$(this).find("td:eq(7)").find('input:eq(0)').val()));
//						$lastRow.find("td:eq(7)").find('input:eq(0)').prop("disabled",true);
						$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntYrs");
						$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){ 
							if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(6)").find('select:eq(0)')))return;
							if(!isEmpty($(this).val()) ){getRDcfExpDets();}
						});

						
						$lastRow.find("td:eq(8)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(8)").find('input:eq(0)').val())? totAge :$(this).find("td:eq(8)").find('input:eq(0)').val()));
//						$lastRow.find("td:eq(8)").find('input:eq(0)').prop("disabled",true);
						$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntYrs");
						$lastRow.find("td:eq(8)").find('input:eq(0)').on("change",function(){ 
							if(!rdEndAgeValidate($lastRow.find("td:eq(7)").find('input:eq(0)'),$(this)))return;
							if(!isEmpty($(this).val()) ){getRDcfExpDets();}
						});
						
						
						$lastRow.find("td:eq(9)").find('input:eq(0)').val($(this).find("td:eq(9)").find('input:eq(0)').val());
//						$lastRow.find("td:eq(9)").find('input:eq(0)').prop("disabled",true);
						$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
							if(!isEmpty($(this).val()) ){getRDcfExpDets();}
						});
						applyEventHandlers();
			 }
		});  
}
