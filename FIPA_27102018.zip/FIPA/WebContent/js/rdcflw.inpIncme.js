var rdcflwIncAssTbl; 

/*Validations*/
/*Table1*/
$("#selDlgprojIRFreq").on("change",function(){
	if(!rdFrequencyValidation($('#txtFldDlgprojIRAgePayends'),$("#txtFldDlgprojIREslrate"),$(this)))return; 
}); 

$("#txtFldDlgprojIRAgePaySts").on("change",function(){
	if(!rdStartAgeValidate($('#txtFldDlgprojIRAgePaySts'),$('#selDlgprojIRAgeBsOn')))return;
});
$("#txtFldDlgprojIRAgePayends").on("change",function(){
	if(!rdEndAgeValidate($('#txtFldDlgprojIRAgePaySts'),$(this)))return;
});
/*Table2*/ 
$("#selDlgprojIncAssFreq").on("change",function(){
	if(!rdFrequencyValidation($('#txtFldDlgprojIncAssAgePayends'),$("#txtFldDlgprojIncAssEslrate"),$(this)))return; 
}); 

$("#txtFldDlgprojIncAssAgePaySts").on("change",function(){
	if(!rdStartAgeValidate($('#txtFldDlgprojIncAssAgePaySts'),$('#selDlgprojIncAssAgeBsOn')))return;
});
$("#txtFldDlgprojIncAssAgePayends").on("change",function(){
	if(!rdEndAgeValidate($('#txtFldDlgprojIncAssAgePaySts'),$(this)))return;
});

/**/


/*Datatable Initialisation*/
var RDInctbl = $('#RDInctbl').DataTable( {
	destroy: true,
  	responsive: false,         
     ordering: false,
     searching: false,     
     scrollY:  "40vh",
     scrollX: true,
     scroller: false,
     scrollCollapse:false,
     paging:false, 
     filter:false,   
     columnDefs: [], 
     dom: '<<"top" ip>flt>',  
   columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#RDIncAddRow").on("click",function(){
	if(!validationRetirementPlnSection())return;
	$("#RDIncAddRow").parent().css("border","");
	$('#generatetoamendincExp').html("");
	d3.select("#CashFlwprojectionOnRtmnt").selectAll("svg").remove();
			RDincretClearFlds();
			showFIPAModel('ProjOfInc_Dialog','Income to be received during retirement');   
			$('#ProjOfInc_Dialog').on('shown.bs.modal', function () {
				$("#ProjOfInc_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#ProjOfInc_Dialog").find("input[id=txtFldDlgprojIRClsfy]").focus();
				$("#ProjOfInc_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatRDincretDetails())return;
					   	RDincretRdlyflds(INS_MODE);  
					   	getRDincretRows(null); 
						$('#ProjOfInc_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getRDincretRows(dataset){ 

	var cell0 = '<span></span>'+
	'<input type="hidden" name="txtFldRDincretMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldprojIRId">';
	 
	var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radRDincretSelect"/><label>&nbsp;</label></div>'; 
	var cell2 = '<input type="text" name="txtFldprojIRClsfy" class="form-control editable"   onmouseover="fipaTooltip(this);" />'; 
	var cell3 = '<input type="text" name="txtFldprojIRDesc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell4 = '<select type="text" name="selprojIRFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
	var cell5 = '<input type="text" name="txtFldprojIRAmtofInc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell6 = '<input type="text" name="txtFldprojIREslrate" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell7 = '<input type="text" name="txtFldprojIRRoi" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell8 = '<select type="text" name="selprojIRAgeBsOn" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
	var cell9 = '<input type="text" name="txtFldprojIRAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell10 ='<input type="text" name="txtFldprojIRAgePayends" class="form-control editable"  onmouseover="fipaTooltip(this);" />'+
	'<input type="hidden" name="txtFldprojIRCrtdBy"/><input type="hidden" name="txtFldprojIRCrtdDate"/>'; 


	RDInctbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10] ).draw( false );

	var rowCount = $('#RDInctbl tbody tr').length;	
	var $lastRow = $("#RDInctbl tbody tr:last");	

	$lastRow.find("td:first").find('span').text(rowCount); 

	$lastRow.find("td:eq(1)").find("input:first").click(function(){
		selectSingleRow(this);
	})

	$lastRow.find("td:eq(1)").find("input:first").attr('id',"radRDincret"+$lastRow.index())
	.parent().find('label').attr('for',"radRDincret"+$lastRow.index());

	$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgprojIRClsfy").val());
	$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){  
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});
//	
	$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgprojIRDesc").val());
	$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){  
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});


	var irfreq = $("#selDlgprojIRFreq > option").clone();
	$lastRow.find("td:eq(4)").find('select:eq(0)').append(irfreq);
	$lastRow.find("td:eq(4)").find('select:eq(0)').val($("#selDlgprojIRFreq").val());
	$lastRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
		if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return; 
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 


	$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgprojIRAmtofInc").val());
	$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){  
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});
	
	$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgprojIREslrate").val());
	$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
	$lastRow.find("td:eq(6)").find('input:eq(0)').on("change",function(){  
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});
	
	
	$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgprojIRRoi").val());
	$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
	$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){  
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});

	var iragebsed =  $("#selDlgprojIRAgeBsOn > option").clone();
	$lastRow.find("td:eq(8)").find('select:eq(0)').append(iragebsed);
	$lastRow.find("td:eq(8)").find('select:eq(0)').val($("#selDlgprojIRAgeBsOn").val());
	$lastRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){
		if(!rdStartAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 
	
	
	$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgprojIRAgePaySts").val());
	$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntYrs");
	$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
		if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(8)").find('select:eq(0)')))return;
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 
	
	$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgprojIRAgePayends").val());
	$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntYrs");
	$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
		if(!rdEndAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 


	
	applyEventHandlers();
	if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$lastRow.find("td:eq(4)").find('select:eq(0)')))return; 
getRDcfIncDets();

}
 

 
/*Edit Row Click */
$("#RDIncEditRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#RDInctbl tbody tr').length;	
	var $lastRow = $("#RDInctbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#RDInctbl tbody").find('input[name="radRDincretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#RDInctbl tbody").find('input[name="radRDincretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 	RDincretRdlyflds($mode);
					RDincretfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgprojIRAgePayends'),$("#txtFldDlgprojIREslrate"),$("#selDlgprojIRFreq")))return; 
					showFIPAModel('ProjOfInc_Dialog','Income to be received during retirement');  
					$('#ProjOfInc_Dialog').on('shown.bs.modal', function () {
						$("#ProjOfInc_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#ProjOfInc_Dialog").find("input[id=txtFldDlgprojIRClsfy]").focus();
						$("#ProjOfInc_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatRDincretDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			RDincretfilldomval($RowId,$row); 
					     		}  
					     		if(!rdFrequencyValidation($row.find("td:eq(10)").find('input:eq(0)'),$row.find("td:eq(6)").find('input:eq(0)'),$row.find("td:eq(4)").find('select:eq(0)')))return; 
					     		getRDcfIncDets();
								$('#ProjOfInc_Dialog').modal('hide'); 
								RDincretClearFlds();
							
						});
					});
					 
			}  
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

});


/*View Row Click */
$("#RDIncViewRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#RDInctbl tbody tr').length;	
	var $lastRow = $("#RDInctbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#RDInctbl tbody").find('input[name="radRDincretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#RDInctbl tbody").find('input[name="radRDincretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 	RDincretRdlyflds($mode);
					RDincretfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgprojIRAgePayends'),$("#txtFldDlgprojIREslrate"),$("#selDlgprojIRFreq")))return; 
					showFIPAModel('ProjOfInc_Dialog','Income to be received during retirement');  
					$('#ProjOfInc_Dialog').on('shown.bs.modal', function () {
						$("#ProjOfInc_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#ProjOfInc_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatRDincretDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			RDincretfilldomval($RowId,$row); 
					     		}  
					     		if(!rdFrequencyValidation($row.find("td:eq(10)").find('input:eq(0)'),$row.find("td:eq(6)").find('input:eq(0)'),$row.find("td:eq(4)").find('select:eq(0)')))return;
					     		getRDcfIncDets();
								$('#ProjOfInc_Dialog').modal('hide'); 
								RDincretClearFlds();
							
						});
					});
					 
			}  
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#RDIncDelRow").on("click",function(){ 
	datatableDeleteRow('RDInctbl',RDInctbl); 
	getRDcfIncDets();
});

/*Clear Fields */
function RDincretClearFlds(){
	$("#ProjOfInc_Dialog").find("input[type=text]").val("");
	$("#ProjOfInc_Dialog").find("textarea").val("");
	$("#ProjOfInc_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function RDincretRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#ProjOfInc_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#ProjOfInc_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatRDincretDetails(){
	   
	if(!(validateFocusFlds('ProjOfInc_Dialog','txtFldDlgprojIRClsfy', IR_CLSFY)))return; 
//	if(!(validateFocusFlds('ProjOfInc_Dialog','txtFldDlgprojIRDesc', IR_DESC)))return;
	if(!(validateFocusFlds('ProjOfInc_Dialog','selDlgprojIRFreq', IR_FRQ)))return;
//	if(!(validateFocusFlds('ProjOfInc_Dialog','txtFldDlgprojIRAmtofInc', IR_AMT)))return;
//	if(!(validateFocusFlds('ProjOfInc_Dialog','txtFldDlgprojIREslrate', IR_ESC)))return;
//	if(!(validateFocusFlds('ProjOfInc_Dialog','txtFldDlgprojIRRoi', IR_ROI)))return;
	if(!(validateFocusFlds('ProjOfInc_Dialog','selDlgprojIRAgeBsOn', IR_AGEBASED)))return;
	if(!(validateFocusFlds('ProjOfInc_Dialog','txtFldDlgprojIRAgePaySts', IR_AGESTS)))return;
//	if(!(validateFocusFlds('ProjOfInc_Dialog','txtFldDlgprojIRAgePayends',IR_AGEENDS)))return;
	if(!rdFrequencyValidation($('#txtFldDlgprojIRAgePayends'),$("#txtFldDlgprojIREslrate"),$("#selDlgprojIRFreq")))return; 
	if(!rdStartAgeValidate($('#txtFldDlgprojIRAgePaySts'),$('#selDlgprojIRAgeBsOn')))return;
	if(!rdEndAgeValidate($('#txtFldDlgprojIRAgePaySts'),$("#txtFldDlgprojIRAgePayends")))return;
	  return true; 
}


/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgprojIRClsfy,#selDlgprojIRFreq," +
		"#selDlgprojIRAgeBsOn,#txtFldDlgprojIRAgePaySts").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  



/* Filling Model Fields*/
function RDincretfilldlgval($lastRow){
	  
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRClsfy').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRDesc').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#ProjOfInc_Dialog #selDlgprojIRFreq').val($lastRow.find("td:eq(4)").find('select:eq(0)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRAmtofInc').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIREslrate').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRRoi').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#ProjOfInc_Dialog #selDlgprojIRAgeBsOn').val($lastRow.find("td:eq(8)").find('select:eq(0)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRAgePaySts').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRAgePayends').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRCrtdBy').val($lastRow.find("td:eq(10)").find('input:eq(1)').val());
	  $('#ProjOfInc_Dialog #txtFldDlgprojIRCrtdDate').val($lastRow.find("td:eq(10)").find('input:eq(2)').val());
	
}

/* Filling Table Fields*/
function RDincretfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgprojIRClsfy").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgprojIRDesc").val());
	$row.find("td:eq(4)").find('select:eq(0)').val($("#selDlgprojIRFreq").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgprojIRAmtofInc").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgprojIREslrate").val());
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgprojIRRoi").val()); 
	$row.find("td:eq(8)").find('select:eq(0)').val($("#selDlgprojIRAgeBsOn").val());  
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgprojIRAgePaySts").val());  
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgprojIRAgePayends").val());   
		
}

   


/*Datatable Initialisation*/
var RDIncAsstbl = $('#RDIncAsstbl').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	

  

/*Add Row Click */
$("#RDIncAssAddRow").on("click",function(){
	if(!validationRetirementPlnSection())return;
		$('#generatetoamendincExp').html("");
		d3.select("#CashFlwprojectionOnRtmnt").selectAll("svg").remove();
			RDincAssretClearFlds();
			showFIPAModel('ProjOfIncAss_Dialog','Income and assets available for retirement');   
			$('#ProjOfIncAss_Dialog').on('shown.bs.modal', function () {
				$("#ProjOfIncAss_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#ProjOfIncAss_Dialog").find("input[id=txtFldDlgprojIncAssClsfy]").focus();
				$("#ProjOfIncAss_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatRDincAssretDetails())return;
					   	RDincAssretRdlyflds(INS_MODE);  
					   	getRDincAssretRows(null); 
						$('#ProjOfIncAss_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getRDincAssretRows(dataset){ 

	var cell0 = '<span></span>'+
	'<input type="hidden" name="txtFldRDincAssretMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldprojIncAssId">';
	 
	var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radRDincAssretSelect"/><label>&nbsp;</label></div>'; 
	var cell2 = '<input type="text" name="txtFldprojIncAssClsfy" class="form-control editable"   onmouseover="fipaTooltip(this);" />'; 
	var cell3 = '<input type="text" name="txtFldprojIncAssDesc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell4 = '<select type="text" name="selprojIncAssFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
	var cell5 = '<input type="text" name="txtFldprojIncAssAmtofInc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell6 = '<input type="text" name="txtFldprojIncAssEslrate" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell7 = '<input type="text" name="txtFldprojIncAssRoi" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell8 = '<select type="text" name="selprojIncAssAgeBsOn" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
	var cell9 = '<input type="text" name="txtFldprojIncAssAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
	var cell10 ='<input type="text" name="txtFldprojIncAssAgePayends" class="form-control editable"  onmouseover="fipaTooltip(this);" />'+
	'<input type="hidden" name="txtFldprojIncAssCrtdBy"/><input type="hidden" name="txtFldprojIncAssCrtdDate"/>'; 


	RDIncAsstbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10] ).draw( false );

	var rowCount = $('#RDIncAsstbl tbody tr').length;	
	var $lastRow = $("#RDIncAsstbl tbody tr:last");	

	$lastRow.find("td:first").find('span').text(rowCount); 

	$lastRow.find("td:eq(1)").find("input:first").click(function(){
		selectSingleRow(this);
	})

	$lastRow.find("td:eq(1)").find("input:first").attr('id',"radRDincAssret"+$lastRow.index())
	.parent().find('label').attr('for',"radRDincAssret"+$lastRow.index());

	$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgprojIncAssClsfy").val());
	$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){ 
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 
	
	$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgprojIncAssDesc").val());
	$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){ 
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});


	var irfreq = $("#selDlgprojIncAssFreq > option").clone();
	$lastRow.find("td:eq(4)").find('select:eq(0)').append(irfreq);
	$lastRow.find("td:eq(4)").find('select:eq(0)').val($("#selDlgprojIncAssFreq").val());
	$lastRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
		if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 
	
	
	$lastRow.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgprojIncAssAmtofInc").val());
	$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){ 
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});
	
	
	$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgprojIncAssEslrate").val());
	$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
	$lastRow.find("td:eq(6)").find('input:eq(0)').on("change",function(){ 
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});
	
	$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgprojIncAssRoi").val());
	$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
	$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){ 
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	});

	var iragebsed =  $("#selDlgprojIncAssAgeBsOn > option").clone();
	$lastRow.find("td:eq(8)").find('select:eq(0)').append(iragebsed);
	$lastRow.find("td:eq(8)").find('select:eq(0)').val($("#selDlgprojIncAssAgeBsOn").val());
	$lastRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
		if(!rdStartAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 
	
	
	$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgprojIncAssAgePaySts").val());
	$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntYrs");
	$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
		if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(8)").find('select:eq(0)')))return;
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 
	
	$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgprojIncAssAgePayends").val());
	$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntYrs");
	$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
		if(!rdEndAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
		if(!isEmpty($(this).val()) ){getRDcfIncDets();}
	}); 
	
 
	applyEventHandlers();
	
	var intretslfage=Number($("#txtFldRDSlfIntAge").val());
	var intretspsage=Number($("#txtFldRDSpsIntAge").val());

	var totAge=Number($("#txtFldRDSlfProjLfe").val());
	
	if(dataset != null){

		
				if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
						$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
				}
				
		var infoDetsArr = new Array();
		
		for(var data in dataset){
			var col = dataset[data];
			
			switch(data){
			
			case "txtFldIncAssId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
				break;
				
			case "txtFldIncAssClsfy": 
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
				
				break;
				
				
			case "txtFldIncAssDesc": 
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
				
				break;
				
			case "selIncAssFreq": 
				var value=(isEmpty(col)? "REGULAR" : col);
				selectNullvalChk($lastRow.find("td:eq(4)"),value);   
				break;
			 
			case "txtFldIncAssAmtofInc": 
				var value=(isEmpty(col)? Number("0") : col);
				$lastRow.find("td:eq(5)").find('input:eq(0)').val(value); 
				break;
			 
			case "txtFldIncAssEslrate": 
				var value=(isEmpty(col)? Number("0") : col);
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(value); 
				break;
			 
			 
			case "txtFldIncAssRoi": 
				var value=(isEmpty(col)? Number("0") : col);
				$lastRow.find("td:eq(7)").find('input:eq(0)').val(value); 
				break;
			 
			 
			case "selIncAssAgeBsOn": 
				var value=(isEmpty(col)? "SELF" : col);
				selectNullvalChk($lastRow.find("td:eq(8)"),value);   
				break;
			 
			 
			case "txtFldIncAssAgePaySts": 
				var value=(isEmpty(col)? intretslfage : col);
				$lastRow.find("td:eq(9)").find('input:eq(0)').val(value); 
				break;
				
			case "txtFldIncAssAgePayends": 
				var value=(isEmpty(col)? totAge : col);
				$lastRow.find("td:eq(10)").find('input:eq(0)').val(value); 
				break;
			  
			  
			case "txtFldIncAssCrtdBy": 
				$lastRow.find("td:eq(10)").find('input:eq(1)').val(col);
				infoDetsArr.push(col);				
				break;
				
			case "txtFldIncAssCrtdDate":
				$lastRow.find("td:eq(10)").find('input:eq(2)').val(col);
				infoDetsArr.push(col);
				break;
				
			case "txtFldIncAssModBy":
				infoDetsArr.push(col);
				break;
				
			case "txtFldIncAssModDate":
				infoDetsArr.push(col);
				break;	
			}			 
			 
		}
		}
	if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$lastRow.find("td:eq(4)").find('select:eq(0)')))return;
	getRDcfIncDets();
//RDincAssretClearFlds();

}


function getRDcfIncDets(){
 
	
	var projOfIncdata = []; 
	$("#generateproIncometbl tbody").html("");
	 $("#projOfIncometblediv").css("display","block");
	 var agebasedon=$("#selRDRetAgebasedOn").val().toUpperCase();
	 var headlist=[];  
	 
	 
	 var dataHeader=[
	                 {"data":"Self Age","title":"Self Age"},
	                 {"data":"Spouse Age","title":"Spouse Age"},  
	                 ];

	 var dupChk=[];


	 var asstblcount=RDIncAsstbl.rows().count();
	 if(asstblcount>0){
	 $("#RDIncAsstbl tbody tr").each(function(i,row){
	 	
	 	var crnthd=$(this).find("td:eq(2)").find("input:eq(0)").val(); 
	 	
	 	if((i!=0 && $.inArray(crnthd,dupChk) == -1) || i==0){
	 		var my_item = {};
	 		my_item.data=crnthd;
	 		my_item.title=crnthd;	
	 		headlist.push(crnthd);
	 		dataHeader.push(my_item); 
	 	}  
	 	dupChk.push(crnthd);
	 	
	 });
	 }
	 
	 var inctblcount=RDInctbl.rows().count();
	 if(inctblcount>0){
	 $("#RDInctbl tbody tr").each(function(j,row){
		 	
		 	var crnthd=$(this).find("td:eq(2)").find("input:eq(0)").val(); 
		 	
		 	if((j!=0 && $.inArray(crnthd,dupChk) == -1) || j==0){
		 		var my_item = {};
		 		my_item.data=crnthd;
		 		my_item.title=crnthd;	
		 		headlist.push(crnthd);
		 		dataHeader.push(my_item); 
		 	}  
		 	dupChk.push(crnthd);
		 	
		 });
	 }

	 dataHeader.push({"data":"Total Annual Income","title":"Total Annual Income"});
	 dataHeader.push({"data":"Total Accumulation Income","title":"Total Accumulation Income"});

	
//	 alert("dupChk==>"+dupChk.length)

	 /*Data Set*/
	  
	 var intretslfage=Number($("#txtFldRDSlfIntAge").val());
	 var intretspsage=Number($("#txtFldRDSpsIntAge").val());

	 var totAge=Number($("#txtFldRDSlfProjLfe").val());
	 

	 var dataset=[];
	 
	 $("#RetirementValueBasedOnInc").val(agebasedon);
	 var $lastRow = $("#RDExptbl tbody tr:last");
	 
	 var count=0;
	 var oldval=0;
	 
	 if(asstblcount == 0  || inctblcount==0){
	 	$("#projOfIncometblediv").css("display","none"); 
	 	d3.select("#projectionOfInc").selectAll("svg").remove();
	 }

	 if(intretslfage > 0 && totAge >= intretslfage){
	 if(inctblcount > 0 || asstblcount > 0){
	 	$("#projOfIncometblediv").css("display","block"); 
	 	d3.select("#projectionOfInc").selectAll("svg").remove();
	 	var spouseage=intretspsage;
	 for(var i=intretslfage;i<=totAge;i++){ 
	 		
	 	var arrlist={};
	 			
	 			arrlist["Self Age"]=i+'<input type="hidden" value="'+(count+1)+'"/>'; //self age
	 			arrlist["Spouse Age"]=spouseage; //spouse age
	 			 
	 			var totAnlExp=0;
	 			$.each(headlist,function(j,hdr){ 
	 				 
	 				$("#RDInctbl tbody tr").each(function(count,value){
	 					 var $desc 	  = $(this).find("td:eq(2)").find("input:eq(0)").val();
	 					 var $freq 	  = $(this).find("td:eq(4)").find("select:eq(0)").val();
	 					 var $anlinc   = (isEmpty($(this).find("td:eq(5)").find("input:eq(0)"))) ? 0 : Number($(this).find("td:eq(5)").find("input:eq(0)").val());
	 					 var $esclrate = (isEmpty($(this).find("td:eq(6)").find("input:eq(0)"))) ? 0 : Number($(this).find("td:eq(6)").find("input:eq(0)").val());
	 					 var $roi	   = (isEmpty($(this).find("td:eq(7)").find("input:eq(0)"))) ? 0 : Number($(this).find("td:eq(7)").find("input:eq(0)").val());
	 					 
	 					 var $agebased = $(this).find("td:eq(8)").find("select:eq(0)").val(); 
	 					 var $startslfage = Number($(this).find("td:eq(9)").find("input:eq(0)").val());  
	 					 var $endage   = (isEmpty($(this).find("td:eq(10)").find("input:eq(0)"))) ? 0 : Number($(this).find("td:eq(10)").find("input:eq(0)").val());
//	 						 
	 					 var $noofyrs=Math.abs($startslfage-$endage);
	 					 var $startspsage = intretslfage-intretspsage;
	 					 $startspsage=$startspsage+intretslfage;
	 					  
	 					 if($desc == hdr){
	 							if($agebased == "SELF"){ 
	 								if($freq == "REGULAR"){
	 										if(i >= $startslfage &&  (i<$endage)){ 
	 											if(i==$startslfage){ 
	 												arrlist[hdr]=(isNaN($anlinc)) ? 0 : RemDecimalNumber(Number($anlinc));  
	 											}else{   
	 												var olddataAno=dataset[dataset.length-1][$desc]; 
	 												olddataAno*=(1+($esclrate/100));
	 												arrlist[hdr]=(isNaN(olddataAno)) ? 0 : RemDecimalNumber(Number(olddataAno));  
	 											}
	 											
	 										}else{
	 											arrlist[hdr]=0; 
	 										}
	 							}else if($freq == "SINGLE"){
	 								if(i == $startslfage){
	 									if(i==$startslfage){ 
	 										arrlist[hdr]=(isNaN($anlinc)) ? 0 : RemDecimalNumber(Number($anlinc));   
	 									}else{   
	 										var olddataAno=dataset[dataset.length-1][$desc]; 
	 										olddataAno*=(1+($esclrate/100));
	 										arrlist[hdr]=(isNaN(olddataAno)) ? 0 : RemDecimalNumber(Number(olddataAno));  
	 									}
	 									 
	 								}else{
	 									arrlist[hdr]=0; 
	 								}
	 							}
	 						}else if($agebased == "SPOUSE"){
	 							if($freq == "REGULAR"){
	 									if(spouseage >= $startslfage &&  (spouseage<$endage)){ 
	 										if($startslfage==spouseage){ 
	 											arrlist[hdr]=(isNaN($anlinc)) ? 0 : RemDecimalNumber(Number($anlinc));   
	 										}else{   
	 											var olddataAno=dataset[dataset.length-1][$desc]; 
	 											olddataAno*=(1+($esclrate/100));
	 											arrlist[hdr]=(isNaN(olddataAno)) ? 0 : RemDecimalNumber(Number(olddataAno));  
	 										} 
	 									
	 								}else{
	 									arrlist[hdr]=0; 
	 								}
	 									
	 							}else if($freq == "SINGLE"){
	 								if(spouseage == $startslfage){ 
	 									if($startslfage==spouseage){ 
	 										arrlist[hdr]=(isNaN($anlinc)) ? 0 : RemDecimalNumber(Number($anlinc));     
	 									}else{   
	 										var olddataAno=dataset[dataset.length-1][$desc]; 
	 										olddataAno*=(1+($esclrate/100));
	 										arrlist[hdr]=(isNaN(olddataAno)) ? 0 : RemDecimalNumber(Number(olddataAno));  
	 									} 
	 								}else{
	 									arrlist[hdr]=0; 
	 								}
	 							}
	 						}
	 					 } 
	 					}); 
	 				 
	 				$("#RDIncAsstbl tbody tr").each(function(count,value){
	 					 var $desclt 	  = $(this).find("td:eq(2)").find("input:eq(0)").val();
	 					 var $freqlt 	  = $(this).find("td:eq(4)").find("select:eq(0)").val();
	 					 var $anlinclt	  = (isEmpty($(this).find("td:eq(5)").find("input:eq(0)"))) ? 0 : Number($(this).find("td:eq(5)").find("input:eq(0)").val());
	 					 var $esclratelt  = (isEmpty($(this).find("td:eq(6)").find("input:eq(0)"))) ? 0 : Number($(this).find("td:eq(6)").find("input:eq(0)").val());
	 					 var $roilt	  	  = (isEmpty($(this).find("td:eq(7)").find("input:eq(0)"))) ? 0 : Number($(this).find("td:eq(7)").find("input:eq(0)").val()); 
	 					 var $agebasedlt = $(this).find("td:eq(8)").find("select:eq(0)").val(); 
	 					 var $startslfagelt = Number($(this).find("td:eq(9)").find("input:eq(0)").val());  
	 					 var $endagelt   = (isEmpty($(this).find("td:eq(10)").find("input:eq(0)"))) ? 0 : Number($(this).find("td:eq(10)").find("input:eq(0)").val()); 
	 					 var $noofyrslt=Math.abs($startslfagelt-$endagelt);
	 					 var $startspsagelt = intretslfage-intretspsage;
	 					 $startspsagelt=$startspsagelt+intretslfage;
	 					  
	 					 if($desclt == hdr){
	 							if($agebasedlt == "SELF"){ 
	 								if($freqlt == "REGULAR"){
	 										if(i >= $startslfagelt &&  (i<$endagelt)){ 
	 											if(i==$startslfagelt){ 
	 												arrlist[hdr]=(isNaN($anlinclt)) ? 0 : RemDecimalNumber(Number($anlinclt));   
	 											}else{   
	 												var olddata=dataset[dataset.length-1][$desclt]; 
	 												olddata*=(1+($esclratelt/100));
	 												arrlist[hdr]=(isNaN(olddata)) ? 0 : RemDecimalNumber(Number(olddata)); 
	 											}
	 											
	 										}else{
	 											arrlist[hdr]=0; 
	 										}
	 							}else if($freqlt == "SINGLE"){
	 								if(i == $startslfagelt){
	 									if(i==$startslfagelt){ 
	 										arrlist[hdr]=(isNaN($anlinclt)) ? 0 : RemDecimalNumber(Number($anlinclt)); 
	 									}else{   
	 										var olddata=dataset[dataset.length-1][$desclt]; 
	 										olddata*=(1+($esclratelt/100));
	 										arrlist[hdr]=(isNaN(olddata)) ? 0 : RemDecimalNumber(Number(olddata));  
	 									}
	 									 
	 								}else{
	 									arrlist[hdr]=0; 
	 								}
	 							}
	 						}else if($agebasedlt == "SPOUSE"){
	 							if($freqlt == "REGULAR"){
	 									if(spouseage >= $startslfagelt &&  (spouseage<$endagelt)){ 
	 										if($startslfagelt==spouseage){ 
	 											arrlist[hdr]=(isNaN($anlinclt)) ? 0 : RemDecimalNumber(Number($anlinclt));   
	 										}else{   
	 											var olddata=dataset[dataset.length-1][$desclt]; 
	 											olddata*=(1+($esclratelt/100));
	 											arrlist[hdr]=(isNaN(olddata)) ? 0 : RemDecimalNumber(Number(olddata));   
	 										} 
	 									
	 								}else{
	 									arrlist[hdr]=0; 
	 								}
	 									
	 							}else if($freqlt == "SINGLE"){
	 								if(spouseage == $startslfagelt){ 
	 									if($startslfagelt==spouseage){ 
	 										arrlist[hdr]=(isNaN($anlinclt)) ? 0 : RemDecimalNumber(Number($anlinclt));   
	 									}else{   
	 										var olddata=dataset[dataset.length-1][$desclt]; 
	 										olddata*=(1+($esclratelt/100));
	 										arrlist[hdr]=(isNaN(olddata)) ? 0 : RemDecimalNumber(Number(olddata));  
	 									} 
	 								}else{
	 									arrlist[hdr]=0; 
	 								}
	 							}
	 						}
	 					 } 
	 					}); 
	 				 
	 				 
	 				totAnlExp=Number(totAnlExp)+Number(arrlist[hdr]) ;  
	 			});
	 			
	 			 
	 			
	 			
	 			arrlist["Total Annual Income"]=(isNaN(totAnlExp)) ? 0 : RemDecimalNumber(Number(totAnlExp));  
	 			
	 			
	 			if(i==intretslfage){ 
	 				arrlist["Total Accumulation Income"]=(isNaN(totAnlExp)) ? 0 : RemDecimalNumber(Number(totAnlExp));
	 				  oldval=(isNaN(totAnlExp)) ? 0 : Number(totAnlExp);
	 			}else{     
	 				arrlist["Total Accumulation Income"]=(isNaN(totAnlExp+oldval)) ? 0 : RemDecimalNumber(Number(totAnlExp+oldval));
	 				oldval=(isNaN(totAnlExp+oldval)) ? 0 : Number(totAnlExp+oldval);
	 			}
	 			
	 			 
	 			
	 			dataset.push(arrlist)
	 			
	 			spouseage++;
	 			count++;
	 			 
	 			projOfIncdata.push({rdinclineAge:i, rdinclineAmt : oldval ,rdincbarAge:i, rdincbarAmt : totAnlExp }); 
	 		}
	
	 if(dupChk.length >= 1){
	 genProjChartOfInc(projOfIncdata);
	 }
	 /**/
	 
	 if ($.fn.DataTable.isDataTable( '#generateproIncometbl') ) {
		 rdcflwIncAssTbl.destroy();
	 	$('#generateproIncometbl').html("");
	 }			 
 
	 if(dupChk.length >= 1){
	 	/*Generate Proper header*/
	 rdcflwIncAssTbl=$('#generateproIncometbl').DataTable( { 
	 		destroy: true,
	 	 	responsive: false,         
	 	    ordering: false,
	 	    searching: false,     
	 	    scrollY:  "40vh",
	 	    scrollX: true,
	 	    scroller: false,
	 	    scrollCollapse:false,
	 	    paging:false, 
	 	    filter:false,   
	 	    columnDefs: [], 
	 	    dom: '<<"top" ip>flt>', 
	 	    "columns": dataHeader,  
	 	   data:dataset, 
	        	columnDefs: [{"className": "dt-right","targets": "_all","orderable": false,"searchable": false}, ],
//	        				{"className": "dt-left","targets": [1-7]},{visible:false,"targets":[8]},{visible:false,"targets":[9]},
//	        				{"className": "hidden","targets":[10]}],
	 		fnDrawCallback: function(oSettings) {
	 		    		if(this.fnSettings().bSorted){
	 		    			reorderSino('generateproIncometbl');
	 		    		}
	     	}    	
	 	}).draw();
	 }
	 }
 }


		var len=Number($("#generateproIncometbl thead tr").find("th").length)-1;  

		$("#generateproIncometbl_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th").css("text-align","center");
		
		$("#generateproIncometbl_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th:eq('"+len+"')").css("background-color","#337AB7").css("color","white");
		$("#generateproIncometbl_wrapper").find(".dataTables_scrollHeadInner").find("table thead tr").find("th:eq('"+(Number(len)-1)+"')").css("background-color","#337AB7").css("color","white");
		 
		$("#generateproIncometbl_wrapper").find(".dataTables_scrollBody").find("table tbody tr").each(function(){
			$(this).find("td:eq(0)").css("text-align","left");
			$(this).find("td:eq(1)").css("text-align","left");
		});
		
		$("#generateproIncometbl_wrapper").find(".dataTables_scrollBody").find("table tbody tr").find("td:eq('"+len+"')").css("background-color","rgb(110, 162, 206)").css("color","#FFF").css("border","1px solid #FAFDFF").css("font-weight","bold");
		$("#generateproIncometbl_wrapper").find(".dataTables_scrollBody").find("table tbody tr").find("td:eq('"+(Number(len)-1)+"')").css("background-color","rgb(110, 162, 206)").css("color","#FFF").css("border","1px solid #FAFDFF").css("font-weight","bold");
	 	
		
}
 

/*Edit Row Click */
$("#RDIncAssEditRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#RDIncAsstbl tbody tr').length;	
	var $lastRow = $("#RDIncAsstbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#RDIncAsstbl tbody").find('input[name="radRDincAssretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#RDIncAsstbl tbody").find('input[name="radRDincAssretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 	RDincAssretRdlyflds($mode);
					RDincAssretfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgprojIncAssAgePayends'),$("#txtFldDlgprojIncAssEslrate"),$("#selDlgprojIncAssFreq")))return; 
					showFIPAModel('ProjOfIncAss_Dialog','Income and assets available for retirement');  
					$('#ProjOfIncAss_Dialog').on('shown.bs.modal', function () {
						$("#ProjOfIncAss_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#ProjOfIncAss_Dialog").find("input[id=txtFldDlgprojIncAssClsfy]").focus();
						$("#ProjOfIncAss_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatRDincAssretDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			RDincAssretfilldomval($RowId,$row); 
					     		}  
					     		if(!rdFrequencyValidation($row.find("td:eq(10)").find('input:eq(0)'),$row.find("td:eq(6)").find('input:eq(0)'),$row.find("td:eq(4)").find('select:eq(0)')))return;
					     		getRDcfIncDets();
								$('#ProjOfIncAss_Dialog').modal('hide'); 
								RDincAssretClearFlds();
							
						});
					});
					 
			}  
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}
});


/*View Row Click */
$("#RDIncAssViewRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#RDIncAsstbl tbody tr').length;	
	var $lastRow = $("#RDIncAsstbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	$("#RDIncAsstbl tbody").find('input[name="radRDincAssretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#RDIncAsstbl tbody").find('input[name="radRDincAssretSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 	RDincAssretRdlyflds($mode);
					RDincAssretfilldlgval($row); 
					if(!rdFrequencyValidation($('#txtFldDlgprojIncAssAgePayends'),$("#txtFldDlgprojIncAssEslrate"),$("#selDlgprojIncAssFreq")))return; 
					showFIPAModel('ProjOfIncAss_Dialog','Income and assets available for retirement');  
					$('#ProjOfIncAss_Dialog').on('shown.bs.modal', function () {
						$("#ProjOfIncAss_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#ProjOfIncAss_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatRDincAssretDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			RDincAssretfilldomval($RowId,$row); 
					     		}  
					     		if(!rdFrequencyValidation($row.find("td:eq(10)").find('input:eq(0)'),$row.find("td:eq(6)").find('input:eq(0)'),$row.find("td:eq(4)").find('select:eq(0)')))return;
					     		getRDcfIncDets();
								$('#ProjOfIncAss_Dialog').modal('hide'); 
								RDincAssretClearFlds();
							
						});
					});
					 
			}  
		
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#RDIncAssDelRow").on("click",function(){  
	datatableDeleteRow("IncAssRetPlgtbl",IncAssRetPlgtbl); 
	getRDcfIncDets();
});

/*Clear Fields */
function RDincAssretClearFlds(){
	$("#ProjOfIncAss_Dialog").find("input[type=text]").val("");
	$("#ProjOfIncAss_Dialog").find("textarea").val("");
	$("#ProjOfIncAss_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function RDincAssretRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#ProjOfIncAss_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#ProjOfIncAss_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatRDincAssretDetails(){
	   

	if(!(validateFocusFlds('ProjOfIncAss_Dialog','txtFldDlgprojIncAssClsfy', INCASS_CLSFY))) return;
//	if(!(validateFocusFlds('ProjOfIncAss_Dialog','txtFldDlgprojIncAssDesc', INCASS_DESC))) return;
	if(!(validateFocusFlds('ProjOfIncAss_Dialog','selDlgprojIncAssFreq', INCASS_FREQ))) return;
//	if(!(validateFocusFlds('ProjOfIncAss_Dialog','txtFldDlgprojIncAssAmtofInc', INCASS_AMT))) return;
//	if(!(validateFocusFlds('ProjOfIncAss_Dialog','txtFldDlgprojIncAssEslrate', INCASS_ESC))) return; 
//	if(!(validateFocusFlds('ProjOfIncAss_Dialog','txtFldDlgprojIncAssRoi', INCASS_ROI))) return;
	if(!(validateFocusFlds('ProjOfIncAss_Dialog','selDlgprojIncAssAgeBsOn', INCASS_AGEBSD))) return;
	if(!(validateFocusFlds('ProjOfIncAss_Dialog','txtFldDlgprojIncAssAgePaySts',INCASS_AGESTS))) return;
//	if(!(validateFocusFlds('ProjOfIncAss_Dialog','txtFldDlgprojIncAssAgePayends', INCASS_AGEENDS))) return;
	
	if(!rdFrequencyValidation($('#txtFldDlgprojIRAgePayends'),$("#txtFldDlgprojIncAssEslrate"),$("#selDlgprojIncAssFreq")))return; 
	if(!rdStartAgeValidate($('#txtFldDlgprojIRAgePaySts'),$('#selDlgprojIRAgeBsOn')))return;
	if(!rdEndAgeValidate($('#txtFldDlgprojIRAgePaySts'),$("#txtFldDlgprojIncAssAgePayends")))return;
	  return true; 
}



/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgprojIncAssClsfy," +
		"#selDlgprojIncAssFreq," +
		"#selDlgprojIncAssAgeBsOn,#txtFldDlgprojIncAssAgePaySts").on("change",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});


/* Filling Model Fields*/
function RDincAssretfilldlgval($lastRow){
	  
	  
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssClsfy').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssDesc').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #selDlgprojIncAssFreq').val($lastRow.find("td:eq(4)").find('select:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssAmtofInc').val($lastRow.find("td:eq(5)").find('input:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssEslrate').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssRoi').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #selDlgprojIncAssAgeBsOn').val($lastRow.find("td:eq(8)").find('select:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssAgePaySts').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssAgePayends').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssCrtdBy').val($lastRow.find("td:eq(10)").find('input:eq(1)').val());
	  $('#ProjOfIncAss_Dialog #txtFldDlgprojIncAssCrtdDate').val($lastRow.find("td:eq(10)").find('input:eq(2)').val());
	
}

/* Filling Table Fields*/
function RDincAssretfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgprojIncAssClsfy").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgprojIncAssDesc").val());
	$row.find("td:eq(4)").find('select:eq(0)').val($("#selDlgprojIncAssFreq").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#txtFldDlgprojIncAssAmtofInc").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgprojIncAssEslrate").val());
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgprojIncAssRoi").val()); 
	$row.find("td:eq(8)").find('select:eq(0)').val($("#selDlgprojIncAssAgeBsOn").val());  
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgprojIncAssAgePaySts").val());  
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgprojIncAssAgePayends").val());  
			
}

   
/*Synchronizatin to Retirement to RPCF Analysis*/


function syncToRpcf2(){
	
	 var intretslfage=Number($("#retSelfAge").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();

	 var totAge=Number($("#retSelfProjage").val());
	

	 
		var cell0 = '<span></span>'+
		'<input type="hidden" name="txtFldRDincretMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldprojIRId">';
		 
		var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radRDincretSelect"/><label>&nbsp;</label></div>'; 
		var cell2 = '<input type="text" name="txtFldprojIRClsfy" class="form-control editable"   onmouseover="fipaTooltip(this);" />'; 
		var cell3 = '<input type="text" name="txtFldprojIRDesc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell4 = '<select type="text" name="selprojIRFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
		var cell5 = '<input type="text" name="txtFldprojIRAmtofInc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell6 = '<input type="text" name="txtFldprojIREslrate" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell7 = '<input type="text" name="txtFldprojIRRoi" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell8 = '<select type="text" name="selprojIRAgeBsOn" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
		var cell9 = '<input type="text" name="txtFldprojIRAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell10 ='<input type="text" name="txtFldprojIRAgePayends" class="form-control editable"  onmouseover="fipaTooltip(this);" />'+
		'<input type="hidden" name="txtFldprojIRCrtdBy"/><input type="hidden" name="txtFldprojIRCrtdDate"/>'; 



		 var rowCount;
		 var $lastRow;	
		
		
		 $("#IncRetPlgtbl tbody tr").each(function(i,row){ 
			 var $rowCount = IncRetPlgtbl.rows().count(); 
			 if($rowCount >0){
			 RDInctbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10] ).draw( false );

				var rowCount = $('#RDInctbl tbody tr').length;	
				var $lastRow = $("#RDInctbl tbody tr:last");	
					  
				$lastRow.find("td:first").find('span').text(rowCount); 

				$lastRow.find("td:eq(1)").find("input:first").click(function(){
					selectSingleRow(this);
				})

				$lastRow.find("td:eq(1)").find("input:first").attr('id',"radRDincret"+$lastRow.index())
				.parent().find('label').attr('for',"radRDincret"+$lastRow.index());


				$lastRow.find("td:eq(2)").find('input:eq(0)').val($(this).find("td:eq(2)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(2)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 
				
				$lastRow.find("td:eq(3)").find('input:eq(0)').val($(this).find("td:eq(3)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(3)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 


				var irfreq = $("#selDlgIRFreq > option").clone();
				$lastRow.find("td:eq(4)").find('select:eq(0)').append(irfreq);
				$lastRow.find("td:eq(4)").find('select:eq(0)').val(isEmpty($(this).find("td:eq(4)").find('select:eq(0)').val())? "REGULAR" : $(this).find("td:eq(4)").find('select:eq(0)').val());
//				$lastRow.find("td:eq(4)").find('select:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
					if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;  
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 

				

				$lastRow.find("td:eq(5)").find('input:eq(0)').val(isEmpty($(this).find("td:eq(5)").find('input:eq(0)').val())? Number("0") : $(this).find("td:eq(5)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(5)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
				$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				});
				
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(isEmpty($(this).find("td:eq(6)").find('input:eq(0)').val())? Number("0") : $(this).find("td:eq(6)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(6)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
				$lastRow.find("td:eq(6)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				});
				
				$lastRow.find("td:eq(7)").find('input:eq(0)').val(isEmpty($(this).find("td:eq(7)").find('input:eq(0)').val())? Number("0") : $(this).find("td:eq(7)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(7)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
				$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				});
				
				var iragebsed =  $("#selDlgIRAgeBsOn > option").clone();
				$lastRow.find("td:eq(8)").find('select:eq(0)').append(iragebsed);
				$lastRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty($(this).find("td:eq(8)").find('select:eq(0)').val())?  basedon : $(this).find("td:eq(8)").find('select:eq(0)').val());
//				$lastRow.find("td:eq(8)").find('select:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){
					if(!rdStartAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 


				
				$lastRow.find("td:eq(9)").find('input:eq(0)').val(isEmpty($(this).find("td:eq(9)").find('input:eq(0)').val())? Number("0") :$(this).find("td:eq(9)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(9)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
					if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(8)").find('select:eq(0)')))return;
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 

				
				
				$lastRow.find("td:eq(10)").find('input:eq(0)').val(isEmpty($(this).find("td:eq(10)").find('input:eq(0)').val())?  Number("0") : $(this).find("td:eq(10)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(10)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
					if(!rdEndAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 

				applyEventHandlers();
			 }
		});  	 
			 
}





function syncToRpcf3(){
	
	 var intretslfage=Number($("#retSelfAge").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();

	 var totAge=Number($("#retSelfProjage").val());
	
		var cell0 = '<span></span>'+
		'<input type="hidden" name="txtFldRDincAssretMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldprojIncAssId">';
		 
		var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radRDincAssretSelect"/><label>&nbsp;</label></div>'; 
		var cell2 = '<input type="text" name="txtFldprojIncAssClsfy" class="form-control editable"   onmouseover="fipaTooltip(this);" />'; 
		var cell3 = '<input type="text" name="txtFldprojIncAssDesc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell4 = '<select type="text" name="selprojIncAssFreq" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
		var cell5 = '<input type="text" name="txtFldprojIncAssAmtofInc" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell6 = '<input type="text" name="txtFldprojIncAssEslrate" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell7 = '<input type="text" name="txtFldprojIncAssRoi" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell8 = '<select type="text" name="selprojIncAssAgeBsOn" class="form-control editable"  onmouseover="fipaTooltip(this);" ></select>';
		var cell9 = '<input type="text" name="txtFldprojIncAssAgePaySts" class="form-control editable"   onmouseover="fipaTooltip(this);" />';
		var cell10 ='<input type="text" name="txtFldprojIncAssAgePayends" class="form-control editable"  onmouseover="fipaTooltip(this);" />'+
		'<input type="hidden" name="txtFldprojIncAssCrtdBy"/><input type="hidden" name="txtFldprojIncAssCrtdDate"/>'; 



		 var rowCount;
		 var $lastRow;	
		
		
		 $("#IncAssRetPlgtbl tbody tr").each(function(i,row){  
			 var $rowCount = IncAssRetPlgtbl.rows().count(); 
			 if($rowCount >0){
				RDIncAsstbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10] ).draw( false );

				var rowCount = $('#RDIncAsstbl tbody tr').length;	
				var $lastRow = $("#RDIncAsstbl tbody tr:last");	

				$lastRow.find("td:first").find('span').text(rowCount); 

				$lastRow.find("td:eq(1)").find("input:first").click(function(){
					selectSingleRow(this);
				})

				$lastRow.find("td:eq(1)").find("input:first").attr('id',"radRDincAssret"+$lastRow.index())
				.parent().find('label').attr('for',"radRDincAssret"+$lastRow.index());




				$lastRow.find("td:eq(2)").find('input:eq(0)').val($(this).find("td:eq(2)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(2)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(2)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				});
				
				$lastRow.find("td:eq(3)").find('input:eq(0)').val($(this).find("td:eq(3)").find('input:eq(0)').val());
//				$lastRow.find("td:eq(3)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(3)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				});
				
				var iasfreq = $("#selDlgIncAssFreq > option").clone();
				$lastRow.find("td:eq(4)").find('select:eq(0)').append(iasfreq);
				$lastRow.find("td:eq(4)").find('select:eq(0)').val((isEmpty($(this).find("td:eq(4)").find('select:eq(0)').val())? "REGULAR" :  $(this).find("td:eq(4)").find('select:eq(0)').val()) );
//				$lastRow.find("td:eq(4)").find('select:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
					if(!rdFrequencyValidation($lastRow.find("td:eq(10)").find('input:eq(0)'),$lastRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 
				
				
				
				$lastRow.find("td:eq(5)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(5)").find('input:eq(0)').val())? Number("0") :  Number($(this).find("td:eq(5)").find('input:eq(0)').val())));
//				$lastRow.find("td:eq(5)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
				$lastRow.find("td:eq(5)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				});
				
				$lastRow.find("td:eq(6)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(6)").find('input:eq(0)'))? Number("0") :  Number($(this).find("td:eq(6)").find('input:eq(0)').val())));
//				$lastRow.find("td:eq(6)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
				$lastRow.find("td:eq(6)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				});
				
				$lastRow.find("td:eq(7)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(7)").find('input:eq(0)').val())? Number("0") :  Number($(this).find("td:eq(7)").find('input:eq(0)').val()))); 
//				$lastRow.find("td:eq(7)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
				$lastRow.find("td:eq(7)").find('input:eq(0)').on("change",function(){
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				});

				var iassagebsed =  $("#selDlgIncAssAgeBsOn > option").clone();
				$lastRow.find("td:eq(8)").find('select:eq(0)').append(iassagebsed);
				$lastRow.find("td:eq(8)").find('select:eq(0)').val((isEmpty($(this).find("td:eq(8)").find('select:eq(0)').val())? basedon :  $(this).find("td:eq(8)").find('select:eq(0)').val()));
//				$lastRow.find("td:eq(8)").find('select:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
					if(!rdStartAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 

				
				
				$lastRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(9)").find('input:eq(0)').val())? intretslfage : Number($(this).find("td:eq(9)").find('input:eq(0)').val())));
//				$lastRow.find("td:eq(9)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
					if(!rdStartAgeValidate($(this),$lastRow.find("td:eq(8)").find('select:eq(0)')))return;
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 
				
				
				$lastRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty($(this).find("td:eq(10)").find('input:eq(0)').val())? totAge : Number($(this).find("td:eq(10)").find('input:eq(0)').val())));
//				$lastRow.find("td:eq(10)").find('input:eq(0)').prop("disabled",true);
				$lastRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
					if(!rdEndAgeValidate($lastRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return;
					if(!isEmpty($(this).val()) ){getRDcfIncDets();}
				}); 

				applyEventHandlers();
				
			 }
				  
		});  	 
			 
}
