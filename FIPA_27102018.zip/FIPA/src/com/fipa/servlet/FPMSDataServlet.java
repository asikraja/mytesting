package com.fipa.servlet;

public class FPMSDataServlet {

}
