/**
 * Cash of banks
 */ 


function openBackToProperty(){ 
	
	if($("#powncpfARow").hasClass("blinking")){
		$("#powncpfARow").removeClass("blinking");
	}
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(6)").find("a").click();	 
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#powncpfARow").addClass("blinking"); 
	
	if($("#powncpfARow").hasClass("blinking")){
		setTimeout(function() {
		$("#property").scrollTop(0);
		}, 100);
//		$("#powncpfARow").focus();
	}
	
	 
}

function openBackToInv(){
	if($("#InvestARow").hasClass("blinking")){
		$("#InvestARow").removeClass("blinking");
	} 
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(5)").find("a").click();	
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#InvestARow").addClass("blinking"); 
}

$("a.addnaviCobFixed").on("click",function(){  
	naviCOB();  
});
$("a.addnaviCobSaving").on("click",function(){  
	naviCOB(); 
});
$("a.addnaviCobCashEq").on("click",function(){  
	naviCOB(); 
});
$("a.addnaviCobSRS").on("click",function(){  
	naviCOB(); 
});

function openBackbackToCashAsset(elmtofocus){
		 if($("#"+elmtofocus).hasClass("blinking")){
				$("#"+elmtofocus).removeClass("blinking");
			} 
			$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(8)").find("a").click();	 
			$("#"+elmtofocus).addClass("blinking"); 
			$("#"+elmtofocus).focus();
	 }
function naviCOB(){  
	if($("#CobARow").hasClass("blinking")){
		$("#CobARow").removeClass("blinking");
	} 
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(7)").find("a").click();	 
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#CobARow").addClass("blinking");  
	$("#CobARow").focus();
}


/*Datatable Initialisation*/
var cashOfBanksTable = $('#cashOfBanksTable').DataTable( {
   destroy: true,
   responsive: false,         
   ordering: false,
   searching: false,     
   scrollY:  "40vh",
   scrollX: true,
   scroller: false,
   scrollCollapse:false,
   paging:false, 
   filter:false,   
   columnDefs: [], 
   dom: '<<"top" ip>flt>',  
   columnDefs: [  { width: '20px', targets: [0,1]},
  	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
   
		 }, 
}).draw();
	


/*Add Row Click */
$("#CobARow").on("click",function(){
			CobClearFlds(); 
			openDivCobObject($("#selDlgCOBObjective").val());
			showFIPAModel('Cob_Dialog','Cash At Banks');   
			$('#Cob_Dialog').on('shown.bs.modal', function () {
				$("#Cob_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#Cob_Dialog").find("select[id=txtFldDlgMainAccHolderName]").focus(); 
				$("#Cob_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validateCobDetails())return;
					   	CobRdlyflds(INS_MODE);  
					   	getCobRows(null); 
						$('#Cob_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getCobRows(dataset){ 

var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldCobMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldCashBankId">';

var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radCobSelect"/><label>&nbsp;</label></div>'; 
 
var cell2 = '<select name="txtFldMainAccHolderName" class="form-control editable"  onmouseover="fipaTooltip(this);"  ></select>'; 
 
var cell3 = '<input type="text"  name="txtFldSuppAccHolderName" class="form-control editable"  maxlength="75" />'; 

var cell4 = '<select name="selCOBRelationship" class="form-control editable" ></select>';

var cell5 = '<select name="selCOBOwnershipType" class="form-control editable" ></select>'; 

var cell6 = '<input type="text" name="txtFldCOBBankName" class="form-control editable"   maxlength="150"  onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell7 = '<input type="text" name="txtFldCOBBankAccNo" class="form-control editable"  maxlength="60"  onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell8 = '<select  name="selCOBAccountType" class="form-control editable"   onmouseover="fipaTooltip(this);" ></select>';

var cell9 = '<input type="text" name="txtFldCOBCurBalance" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell10 = '<input type="text" name="txtFldCOBRegDeposit" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell11 = '<select name="selCOBDepositFreq" class="form-control editable"   onmouseover="fipaTooltip(this);" ></select>';

var cell12 = '<input type="text" name="txtFldCOBPerFrom" class="form-control editable"   maxlength="10" onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell13 = '<input type="text" name="txtFldCOBPerTo" class="form-control editable"   maxlength="10" onmouseover="fipaTooltip(this);" maxlength="300"/>';

var cell14 = '<select name="selCOBObjective" class="form-control editable"   onmouseover="fipaTooltip(this);" ></select>';

var cell15 ='<input type="text" name="txtFldCOBRetrmntPrcnt"   class="form-control editable"   onmouseover="fipaTooltip(this);"  />';
 
var cell16 = '<select name="selCOBChildName"   class="form-control editable"   onmouseover="fipaTooltip(this);"></select>';

var cell17 = '<input type="text" name="txtFldCOBRemarks" class="form-control editable"    maxlength="300" onmouseover="fipaTooltip(this);" maxlength="300"/>'
+'<input type="hidden" name="txtFldCOBCrtdBy"/><input type="hidden" name="txtFldCOBCrtdDate"/>';

cashOfBanksTable.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10,cell11,cell12,cell13,cell14,cell15,cell16,cell17] ).draw( false );

var rowCount = $('#cashOfBanksTable tbody tr').length;	
var $lastRow = $("#cashOfBanksTable tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radCob"+$lastRow.index())
.parent().find('label').attr('for',"radCob"+$lastRow.index());


var accholdname = $("#txtFldDlgMainAccHolderName > option").clone();
$lastRow.find("td:eq(2)").find('select:eq(0)').append(accholdname);
$lastRow.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgMainAccHolderName").val());
 
$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgSuppAccHolderName").val());
 

var relationship = $("#selDlgCOBRelationship > option").clone();
$lastRow.find("td:eq(4)").find('select:eq(0)').append(relationship);
$lastRow.find("td:eq(4)").find('select:eq(0)').val($("#selDlgCOBRelationship").val());
 

var ownership =  $("#selDlgCOBOwnershipType > option").clone();
$lastRow.find("td:eq(5)").find('select:eq(0)').append(ownership);
$lastRow.find("td:eq(5)").find('select:eq(0)').val($("#selDlgCOBOwnershipType").val());
$lastRow.find("td:eq(5)").find('select:eq(0)').on("change",function(){
	 	
		syncCashAtBankTblEditRow($lastRow);
		return; 
});



$lastRow.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgCOBBankName").val());
 

$lastRow.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgCOBBankAccNo").val());
 

var ownership =  $("#selDlgCOBAccountType > option").clone();
$lastRow.find("td:eq(8)").find('select:eq(0)').append(ownership);
$lastRow.find("td:eq(8)").find('select:eq(0)').val($("#selDlgCOBAccountType").val());
 
 
$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgCOBCurBalance").val());
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd26");
$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){ 
		syncCashAtBankTblEditRow($lastRow);
		return;
});


$lastRow.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgCOBRegDeposit").val());
$lastRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntUsd26");
 

var depositfreq =  $("#selDlgCOBDepositFreq > option").clone();
$lastRow.find("td:eq(11)").find('select:eq(0)').append(depositfreq);  
$lastRow.find("td:eq(11)").find('select:eq(0)').val($("#selDlgCOBDepositFreq").val());
 
$lastRow.find("td:eq(12)").find('input:eq(0)').val($("#txtFldDlgCOBPerFrom").val());
$lastRow.find("td:eq(12)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
	 checkDateFormat($(this));  
	 if(!dhtmlChkDateValidation($lastRow.find("td:eq(12)").find('input:eq(0)'),$lastRow.find("td:eq(13)").find('input:eq(0)'),"To Date should greater than the From Date"));  
	  
			return;
});

$lastRow.find("td:eq(13)").find('input:eq(0)').val($("#txtFldDlgCOBPerTo").val());
$lastRow.find("td:eq(13)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
	 checkDateFormat($(this));  
	 if(!dhtmlChkDateValidation($lastRow.find("td:eq(12)").find('input:eq(0)'),$lastRow.find("td:eq(13)").find('input:eq(0)'),"To Date should greater than the From Date"));  
	  
			return;
});


var objective =  $("#selDlgCOBObjective > option").clone();
$lastRow.find("td:eq(14)").find('select:eq(0)').append(objective);
$lastRow.find("td:eq(14)").find('select:eq(0)').val($("#selDlgCOBObjective").val());
$lastRow.find("td:eq(14)").find('select:eq(0)').on("change",function(){ 
	if($(this).val() == "Retirement"){	if(!validationRetirementScreen())return;} 
		syncCashAtBankTblEditRow($lastRow); 
		return;
});



$lastRow.find("td:eq(15)").find('input:eq(0)').val($("#txtFldDlgCOBRetrmntPrcnt").val());
$lastRow.find("td:eq(15)").find('input:eq(0)').addClass("applyEvntpCent26"); 
 

var sel1 =  $("#selDlgCOBChildName > option").clone();
$lastRow.find("td:eq(16)").find('select:eq(0)').append(sel1);
$lastRow.find("td:eq(16)").find('select:eq(0)').val($("#selDlgCOBChildName").val());
 

$lastRow.find("td:eq(17)").find('input:eq(0)').val($("#txtFldDlgCOBRemarks").val());
 

applyEventHandlers();


if(dataset != null){

	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
		case "cashBankId": 
			$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
			break;
			
		case "mainAccountHolder": 
			selectNullvalChk($lastRow.find("td:eq(2)"),col);
			break;
			
		case "suppAccountHolder": 
			$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
			break;
		 
		case "relationship": 
			selectNullvalChk($lastRow.find("td:eq(4)"),col);
			break;
		 
		case "ownershipType": 
			selectNullvalChk($lastRow.find("td:eq(5)"),col);
			break;
			
			
		case "bankName": 
			$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 			
			break;
			
		case "bankAccNo": 
			$lastRow.find("td:eq(7)").find('input:eq(0)').val(col); 			
			break;
		
		case "accountType": 
			selectNullvalChk($lastRow.find("td:eq(8)"),col);
			break;
		
		case "currentBalance": 
			$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
			break;
			
		case "regularDeposit":
			$lastRow.find("td:eq(10)").find('input:eq(0)').val(col); 
			break;
			
		case "depositFrequency":
			selectNullvalChk($lastRow.find("td:eq(11)"),col);
			break;
			
		case "periodFrom":
			$lastRow.find("td:eq(12)").find('input:eq(0)').val(col); 
			break;
				
		case "periodTo":
			$lastRow.find("td:eq(13)").find('input:eq(0)').val(col); 
			break;
			
		case "objective":
			selectNullvalChk($lastRow.find("td:eq(14)"),col);
			break;
		
		case "retirementPrcnt":
			$lastRow.find("td:eq(15)").find('input:eq(0)').val(col); 
			break;
			
		case "childName":
			selectNullvalChk($lastRow.find("td:eq(16)"),col);
			break;
		
			
		case "remarks":
			$lastRow.find("td:eq(17)").find('input:eq(0)').val(col); 
			break;	
		
		case "bankAccCrtdBy": 
			$lastRow.find("td:eq(17)").find('input:eq(1)').val(col);
			infoDetsArr.push(col);				
			break;
			
		case "bankAccCrtdDate":
			$lastRow.find("td:eq(17)").find('input:eq(2)').val(col);
			infoDetsArr.push(col);
			break;
			
		case "bankAccModifiedBy":
			infoDetsArr.push(col);
			break;
			
		case "bankAccModifiedDate":
			infoDetsArr.push(col);
			break;	
		}			 
		 
	}
	}
if(dataset == null){
	if($lastRow.find("td:eq(14)").find('select:eq(0)').val() == "Retirement"){
		if(!($lastRow.find("td:eq(5)").find('select:eq(0)').val() == "Joint")){
			syncCashAtTblRow();
		}
	}
}


//CobClearFlds();

}



/*Edit Row Click */
$("#CobERow").on("click",function(){
	$("#CobVRow").click();
//	var isOneRowSelected=false;
//	$("#cashOfBanksTable tbody").find('input[name="radCobSelect"]').each(function(){ 
//		if($(this).is(":checked")){ 
//			var $row = $(this).parents("tr"); 
//			var $mode = $(this).parents("tr").find("td:first").find('input:eq(0)').val(); 
//			
//			 
//			if($mode == INS_MODE){ 
//				$(this).parents("tr").find("td:first").find('input:eq(0)').val($mode); 
//				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
//					$(this).attr("disabled",false); 
//					$row.removeClass('selected');  
//					$(this).parent().css({border:'1px solid green'});
//					$row.css({border:'1px solid green'});
//					$row.find("td").css({border:'1px solid green'});
//				});  
//			}
//			
//			$(this).attr("checked",false);
//			isOneRowSelected=true;
//		}
//	});	    
//	if(!isOneRowSelected){
//		showAlert("No Rows Selected");
//	}
});


/*View Row Click */
$("#CobVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#cashOfBanksTable tbody tr').length;	
	var $lastRow = $("#cashOfBanksTable tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	

	$("#cashOfBanksTable tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
	});
	
	
	
	$("#cashOfBanksTable tbody").find('input[name="radCobSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#cashOfBanksTable tbody").find('input[name="radCobSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
					$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'}); 
					});  
	 
				 	CobRdlyflds($mode);
					Cobfilldlgval($row); 
					openDivCobObject($row.find("td:eq(14)").find('select:eq(0)').val());
					showFIPAModel('Cob_Dialog','Cash At Banks');  
					$('#Cob_Dialog').on('shown.bs.modal', function () {
						$("#Cob_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#Cob_Dialog").find("select[id=txtFldDlgMainAccHolderName]").focus();
						$("#Cob_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateCobDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			Cobfilldomval($RowId,$row); 
					     		}  
					     		if($curElm.parents("tr").find("td:eq(14)").find('select:eq(0)').val() == "Retirement"){
					     			var $rowref=$curElm.parents("tr").attr("rowref");
							 		if(isValidObject($rowref)){	
							 			syncCashAtBankTblEditRow($curElm.parents("tr"));
							 		}  
					     		}
								$('#Cob_Dialog').modal('hide'); 
								CobClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#CobDRow").on("click",function(){   
	var rowCount = $('#cashOfBanksTable tbody tr').length;	
	if(rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	}
	var isOneRowSelected=false;
	$('#cashOfBanksTable tbody').find('input[type=checkbox]').each(function(){
		if($(this).is(":checked")){
			
			 
			var row = $(this).parents("tr");                                    
			var mode = $(this).parents("tr").find("td:first").find('input:eq(0)').val();
			var refId=$(this).parents("tr").attr("rowref");//Retirement Reference
			
			//Retirement Reference Delete function
			if(isValidObject($(this).parents("tr").attr("rowref"))){
			  
					
				var refTbl=refId.split("-")[0];  
				
				showAlert("The Existing Reference Record from Other Screens will also be deleted");
				
				$("#IncAssRetPlgtbl tr[rowref='"+refId+"']").each(function(){
					IncAssRetPlgtbl.row($(this)).remove().draw();
				});	
				 
				$("#cashOfBanksTable tr[rowref='"+refId+"']").each(function(){
					cashOfBanksTable.row($(this)).remove().draw();
				}); 
				
			 
			}  
			
			//Normal without reference Delete function
			if(!isValidObject($(this).parents("tr").attr("rowref"))){
				
				cashOfBanksTable.row($(this).parent().parent()).remove().draw();
			 
			}
			
				
			$(this).attr("checked",false);
			isOneRowSelected=true;
			
		}
	});
	if(rowCount==1){
		cashOfBanksTable.clear().draw();
	}

	
	if(!isOneRowSelected){
		showAlert("No Rows Selected");
	} 
	
	
	reorderSino("IncAssRetPlgtbl");  
	reorderSino("cashOfBanksTable");
	
});

/*Clear Fields */
function CobClearFlds(){
	$("#Cob_Dialog").find("input[type=text]").val("");
	$("#Cob_Dialog #txtFldDlgCOBRetrmntPrcnt").val("");
	$("#Cob_Dialog #selDlgCOBChildName").val("");
	
	$("#Cob_Dialog").find("input[type=text]").val("");
	$("#Cob_Dialog").find("textarea").val("");
	$("#Cob_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function CobRdlyflds(mode){ 
	 
	
	 if(mode == QRY_MODE ){
			$("#Cob_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#Cob_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateCobDetails(){
	  
		if(!(validateFocusFlds('Cob_Dialog','txtFldDlgMainAccHolderName', MAIN_HOLDER_NAME))) return;
		if(!(validateFocusFlds('Cob_Dialog','txtFldDlgCOBBankName', BANK_NAME))) return;
		if(!(validateFocusFlds('Cob_Dialog','txtFldDlgCOBBankAccNo', BANK_NO))) return;
	
	  return true; 
}


/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgMainAccHolderName,#txtFldDlgCOBBankName,#txtFldDlgCOBBankAccNo").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
 


/* Filling Model Fields*/
function Cobfilldlgval($lastRow){
	  
	  $('#Cob_Dialog #txtFldDlgCashBankId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#Cob_Dialog #txtFldDlgMainAccHolderName').val($lastRow.find("td:eq(2)").find('select:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgSuppAccHolderName').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#Cob_Dialog #selDlgCOBRelationship').val($lastRow.find("td:eq(4)").find('select:eq(0)').val());
	  $('#Cob_Dialog #selDlgCOBOwnershipType').val($lastRow.find("td:eq(5)").find('select:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgCOBBankName').val($lastRow.find("td:eq(6)").find('input:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgCOBBankAccNo').val($lastRow.find("td:eq(7)").find('input:eq(0)').val());
	  $('#Cob_Dialog #selDlgCOBAccountType').val($lastRow.find("td:eq(8)").find('select:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgCOBCurBalance').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgCOBRegDeposit').val($lastRow.find("td:eq(10)").find('input:eq(0)').val());
	  $('#Cob_Dialog #selDlgCOBDepositFreq').val($lastRow.find("td:eq(11)").find('select:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgCOBPerFrom').val($lastRow.find("td:eq(12)").find('input:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgCOBPerTo').val($lastRow.find("td:eq(13)").find('input:eq(0)').val());
	  $('#Cob_Dialog #selDlgCOBObjective').val($lastRow.find("td:eq(14)").find('select:eq(0)').val());
	  
	  $('#Cob_Dialog #txtFldDlgCOBRetrmntPrcnt').val($lastRow.find("td:eq(15)").find('input:eq(0)').val());
	  
	  $('#Cob_Dialog #selDlgCOBChildName').val($lastRow.find("td:eq(16)").find('select:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgCOBRemarks').val($lastRow.find("td:eq(17)").find('input:eq(0)').val());
	  $('#Cob_Dialog #txtFldDlgCOBCrtdBy').val($lastRow.find("td:eq(17)").find('input:eq(1)').val());
	  $('#Cob_Dialog #txtFldDlgCOBCrtdDate').val($lastRow.find("td:eq(17)").find('input:eq(2)').val());
}

/* Filling Table Fields*/
function Cobfilldomval($RowId,$row){
	$row.find("td:eq(2)").find('select:eq(0)').val($("#txtFldDlgMainAccHolderName").val()); 
	$row.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgSuppAccHolderName").val());
	$row.find("td:eq(4)").find('select:eq(0)').val($("#selDlgCOBRelationship").val()); 
	$row.find("td:eq(5)").find('select:eq(0)').val($("#selDlgCOBOwnershipType").val()); 
	$row.find("td:eq(6)").find('input:eq(0)').val($("#txtFldDlgCOBBankName").val()); 
	$row.find("td:eq(7)").find('input:eq(0)').val($("#txtFldDlgCOBBankAccNo").val()); 
	$row.find("td:eq(8)").find('select:eq(0)').val($("#selDlgCOBAccountType").val()); 
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgCOBCurBalance").val()); 
	$row.find("td:eq(10)").find('input:eq(0)').val($("#txtFldDlgCOBRegDeposit").val()); 
	$row.find("td:eq(11)").find('select:eq(0)').val($("#selDlgCOBDepositFreq").val());
	$row.find("td:eq(12)").find('input:eq(0)').val($("#txtFldDlgCOBPerFrom").val()); 
	$row.find("td:eq(13)").find('input:eq(0)').val($("#txtFldDlgCOBPerTo").val()); 
	$row.find("td:eq(14)").find('select:eq(0)').val($("#selDlgCOBObjective").val()); 
	$row.find("td:eq(15)").find('input:eq(0)').val($("#txtFldDlgCOBRetrmntPrcnt").val()); 
	$row.find("td:eq(16)").find('select:eq(0)').val($("#selDlgCOBChildName").val());
	$row.find("td:eq(17)").find('input:eq(0)').val($("#txtFldDlgCOBRemarks").val());  
		
}
/*###########################################################################################################################################################*/


function UpdCastAtBankChildName(existingName,newchildname){
  
	var table = document.getElementById("cashOfBanksTable"); 
	var tbody = table.tBodies[0];
	var rowCount = tbody.rows.length;
	var editFlag = 0;
	
 
	
	var cashAtBankindex = cashOfBanksTable.row().count();
 
		if(cashAtBankindex>0){
	for(var editrow=0;editrow<rowCount;editrow++){ 
			 var editCurRow = tbody.rows[editrow];   
			 if( existingName == editCurRow.cells[17].childNodes[0].value ){  
				 var RowId=editCurRow.rowIndex; 
				 table.rows[RowId].cells[17].childNodes[0].value = newchildname; 	 
			 }
			 
			 
			 
	}
	}
}

$("#selDlgCOBObjective").on("change",function(){ 
	openDivCobObject($(this).val());
	if($(this).val() == "Retirement"){	if(!validationRetirementScreen())return;} 
});


function openDivCobObject(elmid){ 
	if(!isEmpty(elmid)){ 
		if(elmid == "Retirement"){ 
			$("#Cob_Dialog #COBRetirementPrcnt").css("display","block");
			$("#Cob_Dialog #COBChildName").css("display","none");
		}else if(elmid == "Child Education"){
			$("#Cob_Dialog #COBChildName").css("display","block");
			$("#Cob_Dialog #COBRetirementPrcnt").css("display","none");
		}else if(elmid == ""){
			$("#Cob_Dialog #COBChildName").css("display","none");	
			$("#Cob_Dialog #COBRetirementPrcnt").css("display","none");
		}
	}else{
		 
			$("#Cob_Dialog #COBChildName").css("display","none");	
			$("#Cob_Dialog #COBRetirementPrcnt").css("display","none");
		 
	}
	
	return;
}
 
$("#txtFldDlgCOBPerFrom").blur(function(){ 
	if(!chkFromToDateValidation('txtFldDlgCOBPerFrom','txtFldDlgCOBPerTo'),"Period To Date should greater than the Period From Date"); 
});

$("#txtFldDlgCOBPerFrom").change(function(){
	 checkDateFormat($(this));
});

$("#txtFldDlgCOBPerTo").blur(function(){    
	if(!chkFromToDateValidation('txtFldDlgCOBPerFrom','txtFldDlgCOBPerTo'),"Period To Date should greater than the Period From Date");
}); 

$("#txtFldDlgCOBPerTo").change(function(){    
 checkDateFormat($(this));
}); 


function syncCashAtTblRow(){
	
	applyToastrAlert("Cash At Banks data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
	getincassrtRows(null,"N"); 

	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	
	
	var $tblCabRow=$("#cashOfBanksTable tbody tr:last");
	var $tblRetRow=$("#IncAssRetPlgtbl tbody tr:last"); 

	var dte=new Date();
	var rowRefID="CABREF-"+$tblCabRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
				 dte.getSeconds()+dte.getMilliseconds();

	$tblCabRow.attr("rowref",rowRefID);
	$tblRetRow.attr("rowref",rowRefID); 
	
	$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Cash At Bank"); 
	
	
	$tblRetRow.find("td:eq(3)").find('input:eq(0)').val(""); 
	
	
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR"); 
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
		if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
	}); 
	
	
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').val((isEmpty($("#txtFldDlgCOBCurBalance").val())) ? Number("0") : Number($("#txtFldDlgCOBCurBalance").val()));
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').val(""); 
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').val(""); 
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	
	var owner=$("#selDlgCOBOwnershipType").val().toUpperCase(); 
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner); 
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
	}); 

	
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage)); 
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
	}); 

	
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge)); 
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//		if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
	}); 


	applyEventHandlers();
	return true;
}



function syncCashAtBankTblEditRow($lastrow){
	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	
	var $rowref=$lastrow.attr("rowref");
	$lastrow.attr("rowref",$rowref); 
	
	var amt,owner,obj;
	 


	var chkExist=isValidObject($("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]"));
	
	if(chkExist){ 
	
	$("#cashOfBanksTable tbody").find("tr[rowref="+$rowref+"]").each(function(){  
		  amt=$(this).find("td:eq(9)").find('input:eq(0)').val();
		  owner=$(this).find("td:eq(5)").find('select:eq(0)').val().toUpperCase();  
		  obj=$(this).find("td:eq(14)").find('select:eq(0)').val();
		
	});
	if(!(owner == "Joint")){
	if(obj == "Retirement"){
		
		applyToastrAlert("Cash At Banks data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");

	
	$("#IncAssRetPlgtbl tbody").find("tr[rowref="+$rowref+"]").each(function(){  
		var $tblRetRow=$(this);
		$tblRetRow.attr("rowref",$rowref);  
		$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Cash At Bank");   
		$tblRetRow.find("td:eq(3)").find('input:eq(0)').val("");  
		$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR");  
		$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
			if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
		}); 

		
		$tblRetRow.find("td:eq(5)").find('input:eq(0)').val((isEmpty(amt)) ? Number("0") : Number(amt));
		$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
		
		$tblRetRow.find("td:eq(6)").find('input:eq(0)').val(""); 
		$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
		
		$tblRetRow.find("td:eq(7)").find('input:eq(0)').val("");  
		$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
		
		
		$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner); 
		$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
			if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
		}); 
		
		$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage)); 
		$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
			if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
		}); 

		
		$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge)); 
		$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//			if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
		}); 
	 });


	applyEventHandlers();
		} else{
		IncAssRetPlgtbl.row($("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]")).remove().draw(); 
	 }
	
	}
	}else{
		if($lastrow.find("td:eq(14)").find('select:eq(0)').val() == "Retirement"){
			if(!($lastrow.find("td:eq(5)").find('select:eq(0)').val() == "Joint")){
				newRowCashAtTblRow($lastrow);
			}
		}
	}
	return true;
}



function newRowCashAtTblRow($tblCabRow){
	applyToastrAlert("Cash At Banks data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
	getincassrtRows(null,"N"); 

	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	
	
//	var $tblCabRow=$("#cashOfBanksTable tbody tr:last");
	var $tblRetRow=$("#IncAssRetPlgtbl tbody tr:last"); 

	var dte=new Date();
	var rowRefID="CABREF-"+$tblCabRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
				 dte.getSeconds()+dte.getMilliseconds();

	$tblCabRow.attr("rowref",rowRefID);
	$tblRetRow.attr("rowref",rowRefID); 
	
	$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Cash At Bank"); 
	
	
	$tblRetRow.find("td:eq(3)").find('input:eq(0)').val(""); 
	
	
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR"); 
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
		if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
	}); 
	
	
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').val((isEmpty($tblCabRow.find("td:eq(9)").find('input:eq(0)').val())) ? Number("0") : Number($tblCabRow.find("td:eq(9)").find('input:eq(0)').val()));
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').val(""); 
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').val(""); 
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	
	var owner=$tblCabRow.find("td:eq(5)").find('select:eq(0)').val().toUpperCase(); 
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner); 
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
	}); 

	
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage)); 
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
	}); 

	
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge)); 
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//		if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
	}); 


	applyEventHandlers();
	return true;
}
 
