/**
 * 
 */

function submitLogin(){

	
	var loginFrm = document.forms["fipaLogin"];
	var userIdFld = loginFrm.txtFldUserId;
	var passwordFld = loginFrm.txtFldUserPassword;
	
	if(isEmpty(userIdFld.value)){
		showAlert("Key in the UserId!",userIdFld);
		return false;
	}
	
	if(isEmpty(passwordFld.value)){
		showAlert("Key in the Password!",passwordFld);		
		return false;
	}
	
	
	loginFrm.action = "LoginValidate.do";
	loginFrm.submit();
	 
	
}


function relogin(){ 
	window.location.href="Login.do"; 
	
//	document.forms[0].action="Login.do";	
//	document.forms[0].submit();
	
}
