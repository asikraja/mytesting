/**
 * 
//**************************************Input Life Insurance*********************************************
 */

var liRetirementPlgtbl = $('#liRetirementPlgtbl').DataTable( { 
	destroy: true,       
    ordering: false,
    searching: false,     
    scrollY:  "38vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>', 
     fnDrawCallback: function(oSettings) {
	        if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) {  
	        } 
	    },

	} );

	  
	
$(document).ready(function() { 
 
	$('#selamlLanguageUse').multiselect({ 
		 includeSelectAllOption: true, 
	        buttonWidth: '180px',  
	        onSelectAll: function() { 
	        	MultiSelectOption("selamlLanguageUse","amlLanguageUse","ALL",null); 
	        	 $("#txtFldAmlOtherLang").attr("disabled",false);
	        	
	        },
	        onDeselectAll: function() {
	        	MultiSelectOption("selamlLanguageUse","amlLanguageUse","NONE",null); 
	        	 $("#txtFldAmlOtherLang").attr("disabled",true);
           },
	        onChange: function(option, checked, select) { 
	            var SelLangTypes = [];  
	            var NtSelLangTypes = [];  
	            var DeSelLangTypes = []; 
	            
	            
	            if (checked == false) {  
	        		 $('#selamlLanguageUse option:selected').each(function() { 	
	        			 NtSelLangTypes.push($(this).val());    
	                  $.each( NtSelLangTypes, function( index, value ) { 
	                	  MultiSelectOption("selamlLanguageUse","amlLanguageUse","REMOVE",NtSelLangTypes); 
	                	 
	                	 }); 
	                  
	                 }); 
	        		 
	        		 if($.inArray("OTH",NtSelLangTypes)==-1)
	        			 $("#txtFldAmlOtherLang").attr("disabled",true);
	        		 else
	        			 $("#txtFldAmlOtherLang").attr("disabled",false);
	        	 }
	            
	            
	            
	            if(checked == true){
               $('#selamlLanguageUse option:selected').each(function() { 	
               	SelLangTypes.push($(this).val());    
                $.each( SelLangTypes, function( index, value ) { 
               	 MultiSelectOption("selamlLanguageUse","amlLanguageUse","SELECT",SelLangTypes); 
              	 }); 
                
               }); 
               
               	if($.inArray("OTH",SelLangTypes)==-1)
      			 $("#txtFldAmlOtherLang").attr("disabled",true);
      		 	else
      			 $("#txtFldAmlOtherLang").attr("disabled",false);
               	
	            }else{  
	            	$('#selamlLanguageUse option:not(:selected)').each(function() { 	
	            		DeSelLangTypes.push($(this).val());   
	                    $.each( DeSelLangTypes, function( index, value ) {   
	                   	  
	                  	 }); 
	            	});
	            }
	            
	            
	        } ,
	        
	    });
	 
	
	$('#sellipCoveragetype').multiselect({ 
		 includeSelectAllOption: true, 
	        buttonWidth: '180px',  
	        onSelectAll: function() {
	        	 var SelCovValOfIns = [];
	        	
	        	MultiSelectOption("sellipCoveragetype","lipCoveragetype","ALL",null);
	        	typeOfCoverage("All","block");
	        	
	        	 $('#sellipCoveragetype option:selected').each(function() { 
	        		 SelCovValOfIns.push($(this).val());  
               });
	        	 
	        	
            	 
	        	 if($.inArray("RP",SelCovValOfIns) != -1){   
	        		 $('#sellipCoveragetype').multiselect('deselect','RP');
	                 if(!$("#RDIncAsstbl .lifeIns").length > 0){ 
	                	 if(!validationRetirementScreen())return; 
	                	 if(!($("#lipOwner").val() == "Joint") || !($("#lipOwner").val() == "Parents")){
		                	 if (!valilifeinsurance())return;  
		                	 applyToastrAlert("Life Insurance data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
		                	 $('#sellipCoveragetype').multiselect('select','RP');
		                	 getincassrtRows(null,"Y");
	                	 }
	                 }
	                 
	                 
	                }
	        	 
	        	
	        },
	        onDeselectAll: function() {
	        	 var SelCovValOfIns=[];
	        	MultiSelectOption("sellipCoveragetype","lipCoveragetype","NONE",null);
	        	typeOfCoverage("All","none");
	        	
	        	 $('#sellipCoveragetype option:selected').each(function() {     
	        		 SelCovValOfIns.push($(this).val());  
	                }); 
	        	 
	        	 //remove row
	                $("#IncAssRetPlgtbl .lifeIns").each(function(){
	                    IncAssRetPlgtbl.row($(this)).remove().draw();
	                    reorderSino("IncAssRetPlgtbl");
	                });
	                
	                $("#RDIncAsstbl .lifeIns").each(function(){
	                    RDIncAsstbl.row($(this)).remove().draw();
	                    reorderSino("RDIncAsstbl");
	                });
            },
	        onChange: function(option, checked, select) { 
	            var SelCoverageTypes = [];  
	            var NtSelCoverageTypes = [];  
	            var DeSelCoverageTypes = []; 
	            var SelCovValOfIns=[];
	            
	            if (checked == false) {  
	        		 $('#sellipCoveragetype option:selected').each(function() { 	
	        			 NtSelCoverageTypes.push($(this).val());    
	                  $.each( NtSelCoverageTypes, function( index, value ) { 
	                	  MultiSelectOption("sellipCoveragetype","lipCoveragetype","REMOVE",NtSelCoverageTypes); 
	                	 
	                	 }); 
	                  
	                 }); 
	        	 }
	            
	            
	            
	            if(checked == true){
                $('#sellipCoveragetype option:selected').each(function() { 	
                	SelCoverageTypes.push($(this).val());    
                 $.each( SelCoverageTypes, function( index, value ) { 
                	 MultiSelectOption("sellipCoveragetype","lipCoveragetype","SELECT",SelCoverageTypes);
                	 typeOfCoverage(value,"block"); 
                	 
                	 
               	 }); 
                 
                }); 
	            }else{  
	            	$('#sellipCoveragetype option:not(:selected)').each(function() { 	
	            		DeSelCoverageTypes.push($(this).val());   
	                    $.each( DeSelCoverageTypes, function( index, value ) {   
	                   	 	typeOfCoverage(value,"none"); 
	                  	 }); 
	            	});
	            }
	            
	            
	            $('#sellipCoveragetype option:selected').each(function() {     
	            	SelCovValOfIns.push($(this).val());  
                }); 
	            
	            
	            if($.inArray("RP",SelCovValOfIns) != -1){
	            	 $('#sellipCoveragetype').multiselect('deselect','RP');
	            	 if(!validationRetirementScreen())return; 
	            	 if(!($("#lipOwner").val() == "Joint") || !($("#lipOwner").val() == "Parents")){
		            	 if (!(valilifeinsurance()))	return;
		            	 $('#sellipCoveragetype').multiselect('select','RP');
	                	applyToastrAlert("Life Insurance data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
	                    if(!$("#RDIncAsstbl .lifeIns").length > 0)getincassrtRows(null,"Y");
	            	 }
                }else{
                    //remove row
                    $("#IncAssRetPlgtbl .lifeIns").each(function(){
                        IncAssRetPlgtbl.row($(this)).remove().draw();
                        reorderSino("IncAssRetPlgtbl");
                    });
                    
                    $("#RDIncAsstbl .lifeIns").each(function(){
                        RDIncAsstbl.row($(this)).remove().draw();
                        reorderSino("RDIncAsstbl");
                    });
                }
	        } ,
	        
	    });
	 
	
	 
	
	
	 $('#selmulCriticalLevelofDD').multiselect({ 
        includeSelectAllOption: true, 
        buttonWidth: '180px', 
        onSelectAll: function() {
        	MultiSelectOption("selmulCriticalLevelofDD","selCriticalLevelofDD","ALL",null);
        	CriticalLevelofDD("All","block");
        },
        onDeselectAll: function() {
        	MultiSelectOption("selmulCriticalLevelofDD","selCriticalLevelofDD","NONE",null);
        	CriticalLevelofDD("All","none");
        },
        onChange: function(option, checked, select) { 
        	 var SelCriticalDD = [];   
	         var NtSelCriticalDD=[];   
	         var DeSelCriticalDD = []; 
	            
	            if (checked == false) {  
	        		 $('#selmulCriticalLevelofDD option:selected').each(function() { 	
	        			 NtSelCriticalDD.push($(this).val());    
	                  $.each( NtSelCriticalDD, function( index, value ) { 
	                	  MultiSelectOption("selmulCriticalLevelofDD","selCriticalLevelofDD","REMOVE",NtSelCriticalDD);
	                	 }); 
	                  
	                 }); 
	        	 }
	            
	            
	            if(checked == true){
             $('#selmulCriticalLevelofDD option:selected').each(function() { 	
            	 SelCriticalDD.push($(this).val());  
             }); 
            	 $.each( SelCriticalDD, function( index, value ) {  
            	  MultiSelectOption("selmulCriticalLevelofDD","selCriticalLevelofDD","SELECT",SelCriticalDD);
            	  CriticalLevelofDD(value,"block",'NO',SelCriticalDD.length); 
            	 }); 
             
	       } else{ 
           	$('#selmulCriticalLevelofDD option:not(:selected)').each(function() { 	
           		DeSelCriticalDD.push($(this).val());   
           	}); 	
                $.each( DeSelCriticalDD, function( index, value ) {  
                	if(DeSelCriticalDD.length>1)
                	{	
                	CriticalLevelofDD(value,"none",'NO',DeSelCriticalDD.length); 
                	}else{
                	CriticalLevelofDD(value,"none",'YES',DeSelCriticalDD.length);	
                	}
                });
        }
	            
        },
    });
	  
	 
	 
//	 $('#sellipIsnurObject').multiselect({ 
//		 includeSelectAllOption: true, 
//	        buttonWidth: '180px', 
//	        maxHeight: 120,
//	        onSelectAll: function() {
//	        	MultiSelectOption("sellipIsnurObject","lipIsnurObject","ALL",null);
//	        	ObjOfInsurance("All","block");
//	        },
//	        onDeselectAll: function() {
//	        	MultiSelectOption("sellipIsnurObject","lipIsnurObject","NONE",null);
//	        	ObjOfInsurance("All","none");
//	        },
//	        onChange: function(option, checked, select) { 
//	        	var SelObjOfIns = [];  
//	            var NtSelObjOfIns = [];  
//	            var DeSelObjOfIns = []; 
//	            
//	            if (checked == false) {  
//	        		 $('#sellipIsnurObject option:selected').each(function() { 	
//	        			 NtSelObjOfIns.push($(this).val());    
//	                  $.each( NtSelObjOfIns, function( index, value ) { 
//	                	  MultiSelectOption("sellipIsnurObject","lipIsnurObject","REMOVE",NtSelObjOfIns);
//	                	 }); 
//	                  
//	                 }); 
//	        	 }
//	            
//	            
//	            
//	            if(checked == true){
//             $('#sellipIsnurObject option:selected').each(function() { 	
//            	 SelObjOfIns.push($(this).val());   
//              $.each( SelObjOfIns, function( index, value ) {  
//            	  MultiSelectOption("sellipIsnurObject","lipIsnurObject","SELECT",SelObjOfIns);
//            	  ObjOfInsurance(value,"block"); 
//            	 }); 
//              
//             }); 
//	            }else{ 
//	            	$('#sellipIsnurObject option:not(:selected)').each(function() { 	
//	            		DeSelObjOfIns.push($(this).val());   
//	                    $.each( DeSelObjOfIns, function( index, value ) {   
//	                    	ObjOfInsurance(value,"none"); 
//	                  	 }); 
//	            	});
//	            } 
//	             
//	            
//	        } ,
//	        
//	    });
//	 
//		$('.multiselect-container li a label').removeClass("checkbox");
	 $('#sellipIsnurObject').multiselect({ 
         includeSelectAllOption: true, 
            buttonWidth: '180px', 
            maxHeight: 120,
            onSelectAll: function() {
                var SelValOfIns = [];
                
                MultiSelectOption("sellipIsnurObject","lipIsnurObject","ALL",null);
                ObjOfInsurance("All","block");
                
                $('#sellipIsnurObject option:selected').each(function() { 
                	  SelValOfIns.push($(this).val());  
                }); 
                 
            },
            onDeselectAll: function() {
                MultiSelectOption("sellipIsnurObject","lipIsnurObject","NONE",null);
                ObjOfInsurance("All","none");
                
                $('#sellipIsnurObject option:selected').each(function() {     
                    SelValOfIns.push($(this).val());  
                }); 
                
                
            },
            onChange: function(option, checked, select) { 
                var SelObjOfIns = [];  
                var NtSelObjOfIns = [];  
                var DeSelObjOfIns = []; 
                var SelValOfIns = [];
                
                if (checked == false) {  
                     $('#sellipIsnurObject option:selected').each(function() {     
                         NtSelObjOfIns.push($(this).val());    
                      $.each( NtSelObjOfIns, function( index, value ) { 
                          MultiSelectOption("sellipIsnurObject","lipIsnurObject","REMOVE",NtSelObjOfIns);
                      }); 
                     }); 
                 }
                
                
                
                if(checked == true){
                    $('#sellipIsnurObject option:selected').each(function() {     
                        SelObjOfIns.push($(this).val());  
                        $.each( SelObjOfIns, function( index, value ) {  
                            MultiSelectOption("sellipIsnurObject","lipIsnurObject","SELECT",SelObjOfIns);
                            ObjOfInsurance(value,"block"); 
                        });
             
                    }); 
                }else{ 
                    $('#sellipIsnurObject option:not(:selected)').each(function() {     
                        DeSelObjOfIns.push($(this).val());  
                        $.each( DeSelObjOfIns, function( index, value ) {  
                            ObjOfInsurance(value,"none"); 
                           }); 
                    });
                } 
                
                $('#sellipIsnurObject option:selected').each(function() {     
                    SelValOfIns.push($(this).val());  
                }); 
                
                
            } ,
            
        });
    
        $('.multiselect-container li a label').removeClass("checkbox"); 

        /*Mandatory Fields Tooltip*/ 
        $("#lipOwner,#lipPlanname,#lipAssured,#lipCompany,#lipPolicyno,#policyStatus,#lipIncepdate,#lipSa").on("change blur",function(){
        	if(!isEmpty($(this).val())){
        	$(this).removeClass("mandatoryFillFlds");
        	$(this).qtip('disable');
        	$(this).qtip('destroy',true);
        	}
        });
          
});



function typeOfCoverage(ElmVals,opt){ 

	
	if(ElmVals=="DB"){
 		$('#lifeInsNavTabsDets a[href="#li_DeathBenef_tab"]').css("display",opt); 
 	} 
	if(ElmVals=="DS"){
 		$('#lifeInsNavTabsDets a[href="#li_Disability_tab"]').css("display",opt);
 	} 
	if(ElmVals=="CI"){
 		$('#lifeInsNavTabsDets a[href="#li_CriticalIllness_tab"]').css("display",opt);
 	} 
	if(ElmVals=="HP"){
 		$('#lifeInsNavTabsDets a[href="#li_Hospitalisation_tab"]').css("display",opt);
 	}
	if(ElmVals=="RP"){  
		$('#lifeInsNavTabsDets a[href="#li_RetirementPlg_tab"]').css("display",opt);  
		liRetirementPlgtbl.columns.adjust().draw(false);
		setMainRPtoLifeRP();

 	} 
	if(ElmVals=="EP"){  
 		$('#lifeInsNavTabsDets a[href="#li_EducationPlg_tab"]').css("display",opt);
 	} 
	if(ElmVals=="All"){
		$('#lifeInsNavTabsDets a[href="#li_DeathBenef_tab"]').css("display",opt);
		$('#lifeInsNavTabsDets a[href="#li_Disability_tab"]').css("display",opt);
		$('#lifeInsNavTabsDets a[href="#li_CriticalIllness_tab"]').css("display",opt);
		$('#lifeInsNavTabsDets a[href="#li_Hospitalisation_tab"]').css("display",opt);
		$('#lifeInsNavTabsDets a[href="#li_RetirementPlg_tab"]').css("display",opt); 
 		$('#lifeInsNavTabsDets a[href="#li_EducationPlg_tab"]').css("display",opt);
 		setMainRPtoLifeRP();
	} 
}

function CriticalLevelofDD(ElmVals,opt,chk,arrLen){
	if(ElmVals=="ES"){
		if(chk=='NO'){
		$('#LIDDCovergePanel').css("display",opt); 
		}
		$('#LIDDCovergeNavTabDets a[href="#li_EarlyStageCI_tab"]').css("display",opt);  
			$('#LIDDCovergeNavTabDets a[href="#li_EarlyStageCI_tab"]').parent().removeClass('active');
			$('#LIDDCovergeNavTabDets a[href="#li_AdvStageCI_tab"]').parent().removeClass('active');
			$('#li_EarlyStageCI_tab').removeClass('active');
			$('#li_AdvStageCI_tab').removeClass('active');
			$('#LIDDCovergeNavTabDets a[href="#li_EarlyStageCI_tab"]').click(); 
	} 
	if(ElmVals=="AS"){
		if(chk=='NO'){
		$('#LIDDCovergePanel').css("display",opt); 
		}
		$('#LIDDCovergeNavTabDets a[href="#li_AdvStageCI_tab"]').css("display",opt); 
			$('#LIDDCovergeNavTabDets a[href="#li_AdvStageCI_tab"]').parent().removeClass('active');
			$('#LIDDCovergeNavTabDets a[href="#li_EarlyStageCI_tab"]').parent().removeClass('active');
			$('#li_AdvStageCI_tab').removeClass('active');
			$('#li_EarlyStageCI_tab').removeClass('active');
			$('#LIDDCovergeNavTabDets a[href="#li_AdvStageCI_tab"]').click(); 
	} 
	if(ElmVals=="All"){
		$('#LIDDCovergePanel').css("display",opt); 
 		$('#LIDDCovergeNavTabDets a[href="#li_EarlyStageCI_tab"]').css("display",opt); 
 		$('#LIDDCovergeNavTabDets a[href="#li_AdvStageCI_tab"]').css("display",opt); 
	}
	if(arrLen==1 && ElmVals=='ES' && opt=='none'){
		$('#LIDDCovergeNavTabDets a[href="#li_AdvStageCI_tab"]').parent().removeClass('active');
		$('#LIDDCovergeNavTabDets a[href="#li_EarlyStageCI_tab"]').parent().removeClass('active');
		$('#li_AdvStageCI_tab').removeClass('active');
		$('#li_EarlyStageCI_tab').removeClass('active');
		$('#LIDDCovergeNavTabDets a[href="#li_AdvStageCI_tab"]').click();
	}
	if(arrLen==1 && ElmVals=='AS' && opt=='none'){
		$('#LIDDCovergeNavTabDets a[href="#li_AdvStageCI_tab"]').parent().removeClass('active');
		$('#LIDDCovergeNavTabDets a[href="#li_EarlyStageCI_tab"]').parent().removeClass('active');
		$('#li_AdvStageCI_tab').removeClass('active');
		$('#li_EarlyStageCI_tab').removeClass('active'); 
		$('#LIDDCovergeNavTabDets a[href="#li_EarlyStageCI_tab"]').click();
	}
}

function ObjOfInsurance(ElmVals,opt){
	if(ElmVals=="RP"){  
//		$('#lifeInsNavTabsDets a[href="#li_RetirementPlg_tab"]').css("display",opt); 
 	} 
	if(ElmVals=="EP"){  
// 		$('#lifeInsNavTabsDets a[href="#li_EducationPlg_tab"]').css("display",opt);
 	} 
	if(ElmVals=="All"){ 
// 		$('#lifeInsNavTabsDets a[href="#li_RetirementPlg_tab"]').css("display",opt); 
// 		$('#lifeInsNavTabsDets a[href="#li_EducationPlg_tab"]').css("display",opt);
	}
}

function DisabilitySubDets (elmid){
	var disabilityInc = $("#"+elmid).val(); 
	 
	if(!isEmpty(elmid)){  
		if(disabilityInc == 'TPD'){
			 $('#liTypesOfCovBenefdiv').css("display","block");
		}else if(disabilityInc == 'Disability Income'){
			 $('#liTypesOfCovBenefdiv').css("display","block");
		}else if(disabilityInc == 'Long term disability'){
			 $('#liTypesOfCovBenefdiv').css("display","block");
		}else if(disabilityInc == ''){ 
			 $('#liTypesOfCovBenefdiv').css("display","none");
		} 
		
		  
	} else{
		 $('#liTypesOfCovBenefdiv').css("display","none");
	}
		  
}


function MultiSelectOption(multiSelId,elmId,options,arrayList){
	
	if(multiSelId == "selamlLanguageUse"){
		if(options=="ALL"){ 
			$('#'+elmId).val("ENG,MAN,MAL,TAM,OTH"); 
			}else if(options=="NONE"){
			$('#'+elmId).val(""); 
			}else if(options=="SELECT"){  
			$('#'+elmId).val(arrayList);
			}else if(options=="REMOVE"){ 
			$('#'+elmId).val(arrayList);
			}
	}
	
	
	if(multiSelId == "sellipCoveragetype"){ 
		if(options=="ALL"){ 
		$('#'+elmId).val("CI,DS,DB,HP,EP,RP"); 
		}else if(options=="NONE"){
		$('#'+elmId).val(""); 
		}else if(options=="SELECT"){  
		$('#'+elmId).val(arrayList);
		}else if(options=="REMOVE"){ 
		$('#'+elmId).val(arrayList);
		}
	}
	
	if(multiSelId == "sellipIsnurObject"){ 
		if(options=="ALL"){  
		$('#'+elmId).val("RP,EP,SV,ES,DD,TPD,DI,LTC,PA,TI,NI"); 
		}else if(options=="NONE"){
		$('#'+elmId).val(""); 
		}else if(options=="SELECT"){  
		$('#'+elmId).val(arrayList);
		}else if(options=="REMOVE"){ 
		$('#'+elmId).val(arrayList);
		}
	}
	
	if(multiSelId == "selmulCriticalLevelofDD"){ 
		if(options=="ALL"){ 
		$('#'+elmId).val("ES,AS"); 
		}else if(options=="NONE"){
		$('#'+elmId).val(""); 
		}else if(options=="SELECT"){  
		$('#'+elmId).val(arrayList);
		}else if(options=="REMOVE"){ 
			$('#'+elmId).val(arrayList);	
		}
	} 
}


function enableRetCashValOnRet(sel,elmid){ 
	var retval=false;
	var selvalue = sel.value;
	
	if(!isEmpty(selvalue)){
		if(selvalue == 'N'){
			showAlert(CASH_VAL_RET,$("#"+elmid)); 
			retval=true;
		}else{		
			retval=false; 
		}
		
	 }
	
	if(retval){
		$("#"+elmid).attr("readonly",false);
		$("#"+elmid).removeClass("readOlyCursor"); 
//		$("#listofLifeIns_Dialog #divRetirementPlgtbl").css("display","block");
	}else{ 
		$("#"+elmid).attr("readonly",true); 
		$("#"+elmid).addClass("readOlyCursor");
//		$("#listofLifeIns_Dialog #divRetirementPlgtbl").css("display","block");
	}
	
}



function enableNomineeDiv(sel){  
	if(!isEmpty(sel)){
		if(sel.value == 'Revocable'){
			showAlert(NOMINEE_NAME);
			$("#lifeInsdetstab #NomineesTblDiv").css("display","block");
		}else if(sel.value == 'Trust'){
			showAlert(NOMINEE_NAME);
			$("#lifeInsdetstab #NomineesTblDiv").css("display","block");
		}else if(sel.value == 'None'){
			$("#lifeInsdetstab #NomineesTblDiv").css("display","none");
		}else if( sel.value == ''){ 
			$("#lifeInsdetstab #NomineesTblDiv").css("display","none");
		}
		
	} 
}



function setMainRPtoLifeRP(){
	
	
	var lirpretageself = $("#retSelfretage");
	var lirpretagesps = $("#retSpouseretage");
	var lirpyrstoret = $("#lfretYrstoret");
	
	
	var rpretageself = $("#retSelfCoordinateage");
	var rpretagesps = $("#retSpsCoordinateage");
	var rpyrstoret = $("#retYrstoret");
	
	if(isEmpty(lirpretageself.val())){
		lirpretageself.val(rpretageself.val());
	}
	
	if(isEmpty(lirpretagesps.val())){
		lirpretagesps.val(rpretagesps.val());
	}
	
	if(isEmpty(lirpyrstoret.val())){
		lirpyrstoret.val(rpyrstoret.val());
	}
	
}

function valilifeinsurance(){

	if (!(validateFocusFlds('lifeInsdetstab', 'lipOwner', Li_OWN)))
		return;
	
	if (!(validateFocusFlds('lifeInsdetstab', 'lipAssured', Li_ASS)))
		return;
	if (!(validateFocusFlds('lifeInsdetstab', 'lipCompany', Li_INS)))
		return;
	if (!(validateFocusFlds('lifeInsdetstab', 'lipPolicyno', Li_POL)))
		return;
	if (!(validateFocusFlds('lifeInsdetstab', 'policyStatus', Li_POLSTS)))
		return;
	if (!(validateFocusFlds('lifeInsdetstab', 'lipIncepdate', Li_DATE)))
		return;
	if (!(validateFocusFlds('lifeInsdetstab', 'lipSa', Li_SA)))
		return;
	if (!(validateFocusFlds('lifeInsdetstab', 'lipPlanname', Li_PLAN)))
		return; 
	return true;
}



