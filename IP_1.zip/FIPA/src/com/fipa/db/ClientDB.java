package com.fipa.db;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;

import com.fipa.dbinterface.DBInterface;  
import com.fipa.dto.FnaAdvDeclare;
import com.fipa.dto.FnaApptypes;
import com.fipa.dto.FnaApptypes;
import com.fipa.dto.FnaAssetBusiandpersdets;
import com.fipa.dto.FnaAssetCashdets;
import com.fipa.dto.FnaAssetOtherdets; 
import com.fipa.dto.FnaCashAtBank;  
import com.fipa.dto.FnaChilddetails; 
import com.fipa.dto.FnaContingencyDets;
import com.fipa.dto.FnaCpfBalanceDets;
import com.fipa.dto.FnaCpfDeductions; 
import com.fipa.dto.FnaCpfMonthcontDets; 
import com.fipa.dto.FnaCurassDets;
import com.fipa.dto.FnaDependantDets;
import com.fipa.dto.FnaEstatePlan;
import com.fipa.dto.FnaExpenditureDets;
import com.fipa.dto.FnaFinLiability; 
import com.fipa.dto.FnaFingoalsconcern; 
import com.fipa.dto.FnaHealthinsInfo;
import com.fipa.dto.FnaInputinvestmentsDets; 
import com.fipa.dto.FnaInvsetmentSummary; 
import com.fipa.dto.FnaLifeinsuranceBasicriders;
import com.fipa.dto.FnaLifeinsuranceChildedc;
import com.fipa.dto.FnaLifeinsuranceCoverages;
import com.fipa.dto.FnaLifeinsuranceDets;
import com.fipa.dto.FnaLifeinsuranceDisablebenfs;
import com.fipa.dto.FnaLifeinsuranceMvRet;
import com.fipa.dto.FnaLifeinsuranceNominees;
import com.fipa.dto.FnaOthareaconcern; 
import com.fipa.dto.FnaPersprio;
import com.fipa.dto.FnaPropownDets;
import com.fipa.dto.FnaRecomFundDet;
import com.fipa.dto.FnaRecomPrdtplanDet;
import com.fipa.dto.FnaRecomReasons;
import com.fipa.dto.FnaRetireplanDets;
import com.fipa.dto.FnaRetireplanIncomeasset;
import com.fipa.dto.FnaRetireplanOthpayment;
import com.fipa.dto.FnaRiskprefDets;
import com.fipa.dto.FnaSavingsinvDets;
import com.fipa.dto.FnaSelfspouseDets;
import com.fipa.dto.FnaSrcofincome;
import com.fipa.dto.FnaSummaryAnalysis; 
import com.fipa.dto.FnaSwtchrepFundDet;
import com.fipa.dto.FnaSwtchrepPlanDet;
import com.fipa.dto.FnaVehicleownDets;
import com.fipa.dto.MasterCpfAcctype;
//import com.fipa.dto.FipaAgreements;
//import com.fipa.dto.FipaCustomerDets;
//import com.fipa.dto.FipaDependantDets;
//import com.fipa.dto.FipaSpouseDets;
import com.fipa.util.ApplicationContextUtils;
import com.fipa.util.FipaConstant;
import com.fipa.util.FipaUtils;
import com.fipa.dbinterface.DBInterfaceImpl;





public class ClientDB{
	
	
	@SuppressWarnings("unchecked")
	public List getLoginMsgDets() {
		
		List lstLoginMsgDets = new ArrayList();
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");
 
//			String SQL_ADVSTF_QUERY = "select LOGIN_MSG,MSG_AUTHOR FROM FNA_LOGINPAGE_MSG where SYSDATE between DISP_DATE_FROM and NVL(DISP_DATE_TO,SYSDATE)";
			String SQL_ADVSTF_QUERY = "select LOGIN_MSG,MSG_AUTHOR FROM FNA_LOGINPAGE_MSG where THIS_WEEK_QUOTE ='Y'";
			
			lstLoginMsgDets = dao.searchByNativeSQLQuery(SQL_ADVSTF_QUERY);
			
 
		return lstLoginMsgDets;
	}


	
	@SuppressWarnings("unchecked")
	public List<FnaApptypes> getAllAnalysisTypes() {
		
		List<FnaApptypes> lstAllAnalysisTypes = new ArrayList<FnaApptypes>();

		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

		lstAllAnalysisTypes = (List<FnaApptypes>) dao.selectQueryByFind(" from com.fipa.dto.MasterAnalysisTypes ",null);

		return lstAllAnalysisTypes;
	}
	
	public String saveClientDetails(FnaSelfspouseDets slfspsdet){
		 
		String strClientId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(slfspsdet, "fnaId");	
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "FNA", 16);
		 
			strClientId = strMaxId;
			slfspsdet.setFnaId(strClientId);
				
			dao.saveObject(slfspsdet);

 
		return strClientId;
	}
	 
	public void saveAnalysisTypesDetails(FnaApptypes fnaAnalytypes,String strClientId) {
		// TODO Auto-generated method stub
		String strAnalTypeId = "";
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaAnalytypes, "anaPkid");			
			
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "ANA", 16);
			
			strAnalTypeId = strMaxId; 
			fnaAnalytypes.setAppTypeid(strAnalTypeId); 
			
			
			dao.saveObject(fnaAnalytypes);
 
	}
	
	public void saveAppTypesDetails(Vector vectFnaAppTypes,String strClientId) {
		// TODO Auto-generated method stub
		String strApptypesId = "";
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			
			Object objFnaAppTypes = null;
			List insertList = new ArrayList(0);
			List updateList = new ArrayList(1);
			List deleteList = new ArrayList(2);
			
			int vectorSize = vectFnaAppTypes.size();

			if (vectorSize > 0) {
				insertList = (List) vectFnaAppTypes.elementAt(0);
				updateList = (List) vectFnaAppTypes.elementAt(1);
				deleteList = (List) vectFnaAppTypes.elementAt(2);
			}
			
			int delSize = deleteList.size();
			 
			if (delSize > 0) {
				dao.deleteTableObject(deleteList, objFnaAppTypes);
			}
			

			int insSize = insertList.size();
			if (insSize > 0) {
				
				FnaApptypes fnaAppTypes=new FnaApptypes();
				FnaSelfspouseDets custDets = new FnaSelfspouseDets();
				
				if(!FipaUtils.nullOrBlank(strClientId)){
					custDets.setFnaId(strClientId);				
				}
				
				String strMaxId = (String) dao.fetchMaxId(fnaAppTypes, "appTypeid");
				
				
				Iterator itIns = insertList.iterator();
				while (itIns.hasNext()) {
					 
					
					strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "DCL", 17);
					strApptypesId = strMaxId;
					
					 
					fnaAppTypes = (FnaApptypes) itIns.next();
					fnaAppTypes.setAppTypeid(strApptypesId);
					fnaAppTypes.setFnaSelfspouseDets(custDets);
			
			     
				}
				objFnaAppTypes =fnaAppTypes;			
				dao.insertTableObject(insertList, objFnaAppTypes);

			}
			
	}
	
	public void saveAdvDeclareDetails(FnaAdvDeclare fnaAdvDclDets,String strClientId) {
		// TODO Auto-generated method stub
		String strADclId = "";
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaAdvDclDets, "advDecId");			
			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CDA", 16);
			
			strADclId = strMaxId; 
			fnaAdvDclDets.setAdvDecId(strADclId);
			fnaAdvDclDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaAdvDclDets);
 
	}
	
	
	
	public void saveExpenditureDetails(FnaExpenditureDets fnaExpDets,String strClientId) {
		// TODO Auto-generated method stub
		String strExpId = "";
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaExpDets, "expdId");			
			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "EXP", 16);
			
			strExpId = strMaxId; 
			fnaExpDets.setExpdId(strExpId);
			fnaExpDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaExpDets);
 
	}
	
	
	public void saveContgDetails(FnaContingencyDets fnaContgDets,String strClientId) {
		// TODO Auto-generated method stub
		String strContId = "";
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaContgDets, "conId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CON", 16);
			
			strContId = strMaxId; 
			fnaContgDets.setConId(strContId);
			fnaContgDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaContgDets);
 
		
	}
	
//	public void saveContingencyDetails(FnaContingencyDets fnaContDets,String strClientId) {
//		// TODO Auto-generated method stub
//		String strContId = "";
// 
//			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//			String strMaxId = (String) dao.fetchMaxId(fnaContDets, "txtFldContId");			
//			
//			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
//			fnaslfsps.setFnaId(strClientId);
//			 
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CON", 16);
//			
//			strContId = strMaxId; 
//			fnaContDets.setTxtFldContId(strContId);
//			fnaContDets.setFnaSelfspouseDets(fnaslfsps);
//			
//			
//			dao.saveObject(fnaContDets);
// 
//		
//	}
	
	public void savePersPrioDetails(FnaPersprio fnaPersDets, String strClientId) {
		// TODO Auto-generated method stub
		String strPPId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaPersDets, "persprioId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
		 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "PPT", 16);
			
			strPPId = strMaxId; 
			fnaPersDets.setPersprioId(strPPId);
			fnaPersDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaPersDets);
 
		
		
	}

	public void saveSrcOfIncDetails(FnaSrcofincome fnaSrcOfincDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strSrcOfIncId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaSrcOfincDets, "incsrcId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "SOI", 16);
			
			strSrcOfIncId = strMaxId; 
			fnaSrcOfincDets.setIncsrcId(strSrcOfIncId);
			fnaSrcOfincDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaSrcOfincDets);
 
	}

//	public void saveCpfDetails(FnaCpfDets fnCpfDets, String strClientId) {
//		// TODO Auto-generated method stub
//		String strCpfId = ""; 
//			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//			String strMaxId = (String) dao.fetchMaxId(fnCpfDets, "cpfId");			
//			
//			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
//			fnaslfsps.setFnaId(strClientId);
//			 
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CPF", 16);
//			
//			strCpfId = strMaxId;
//			 
//			fnCpfDets.setTxtFldCpfId(strCpfId);
//			fnCpfDets.setFnaSelfspouseDets(fnaslfsps);
//			
//			
//			dao.saveObject(fnCpfDets); 
//	}

	public void saveFinLbltyDetails(FnaFinLiability fnaFinLbltyDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strFnLbltyId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaFinLbltyDets, "liabId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "LIA", 16);
			
			strFnLbltyId = strMaxId; 
			fnaFinLbltyDets.setLiabId(strFnLbltyId);
			fnaFinLbltyDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaFinLbltyDets);
 
	}

	public void saveCurAssDetails(FnaCurassDets fnaCurAssDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strCAId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaCurAssDets, "caId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CUA", 16);
			
			strCAId = strMaxId;
			 
			fnaCurAssDets.setCaId(strCAId);
			fnaCurAssDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaCurAssDets);
 
		
	}

	public void saveRetirePlnDetails(FnaRetireplanDets fnaRetirePlnDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strRPId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaRetirePlnDets, "retId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RPL", 16);
			
			strRPId = strMaxId;
			 
			fnaRetirePlnDets.setRetId(strRPId);
			fnaRetirePlnDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaRetirePlnDets);
 
	}

	public void saveInvstDetails(FnaInvsetmentSummary fnaInvstDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strInvId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaInvstDets, "invstId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "INV", 16);
			
			strInvId = strMaxId;
			 
			fnaInvstDets.setInvstId(strInvId);
			fnaInvstDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaInvstDets);
 
	}

	public void saveCashAssDetails(FnaAssetCashdets fnaCashAssDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strCSHASId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaCashAssDets, "casstId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CSA", 16);
			 	
			strCSHASId = strMaxId;
			 
			fnaCashAssDets.setCasstId(strCSHASId);
			fnaCashAssDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaCashAssDets);
 
	}

	public void saveOthAssDetails(FnaAssetOtherdets fnaOthAssDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strOthAssId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaOthAssDets, "othId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "OAD", 16);
			strOthAssId = strMaxId;
			 
			fnaOthAssDets.setOthId(strOthAssId);
			fnaOthAssDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaOthAssDets);
 
		
	}
	
	public void saveRskPrefDetails(FnaRiskprefDets fnaRskPrefDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strRskPrefId = "";  
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaRskPrefDets, "riskId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RSK", 16);
			
			strRskPrefId = strMaxId;
			 
			fnaRskPrefDets.setRiskId(strRskPrefId);
			fnaRskPrefDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaRskPrefDets);
 
		
	}
	
	public void saveSAnalDetails(FnaSummaryAnalysis fnaSummaryAnalyDets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strSumAnalyId = "";
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaSummaryAnalyDets, "saId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			
 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "SAN", 16);
			
			strSumAnalyId = strMaxId;
			 
			fnaSummaryAnalyDets.setSaId(strSumAnalyId);
			fnaSummaryAnalyDets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaSummaryAnalyDets);
 
	}
	
	public void saveCdAhocDetails(FnaAdvDeclare fnaCdAhocDets,
			String strClientId) {
		// TODO Auto-generated method stub
//		String strCdAhocId = "";
// 
//			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//			String strMaxId = (String) dao.fetchMaxId(fnaCdAhocDets, "advDecId");			
//			
//			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
//			fnaslfsps.setFnaId(strClientId);
//			
// 
//			
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "DLC", 16);
//			
//			strCdAhocId = strMaxId;
//			 
//			fnaCdAhocDets.setAdvDecId(strCdAhocId);
//			fnaCdAhocDets.setFnaSelfspouseDets(fnaslfsps);
//			
//			
//			dao.saveObject(fnaCdAhocDets);
 
	}
	
	
	
	public String saveLifeInsrceDetails(FnaLifeinsuranceDets fnaLifeInsdets,
			String strClientId) {
		// TODO Auto-generated method stub
		String strLifeInsId = "";
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			String strMaxId = (String) dao.fetchMaxId(fnaLifeInsdets, "lipId");			
			
			FnaSelfspouseDets fnaslfsps=new FnaSelfspouseDets();
			fnaslfsps.setFnaId(strClientId);
			
 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "LIS", 16);
			
			strLifeInsId = strMaxId;
			 
			fnaLifeInsdets.setLipId(strLifeInsId);
			fnaLifeInsdets.setFnaSelfspouseDets(fnaslfsps);
			
			
			dao.saveObject(fnaLifeInsdets);
			
			return strLifeInsId;
 
	}
	
	 
	public void deleteClientDetails(FnaSelfspouseDets client) {
		// TODO Auto-generated method stub
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			 
			dao.deleteObject(client); 
		
	}
	
//	public void delAgreementsDetails(FipaAgreements fnaAgreements) {
//		// TODO Auto-generated method stub 
// 
//			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
//			dao.deleteObject(fnaAgreements);
//			
//	}
//	
	public void delAppTypesDetails(FnaApptypes fnaApptypes) {
		// TODO Auto-generated method stub 
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaApptypes);
			
	}
	
	public void delAnalysisTypesDetails(FnaApptypes fnaAnalytypes) {
		// TODO Auto-generated method stub 
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaAnalytypes);
			
	}
	
	
	public void deleteAdvDeclareDetails(FnaAdvDeclare AdvDcl) {
		// TODO Auto-generated method stub 
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(AdvDcl);
			
	}
	
	
	public void deleteExpenditureDetails(FnaExpenditureDets Exp) {
		// TODO Auto-generated method stub 
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(Exp); 
			
	}

	public void delContgDetails(FnaContingencyDets fnaContDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaContDets); 
	}
	
	
	public void delContingencyDetails(FnaContingencyDets fnaContDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaContDets); 
	}

	public void delPersPrioDetails(FnaPersprio fnaPersDets) {
		// TODO Auto-generated method stub  
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaPersDets); 
	}

	public void delSrcOfIncDetails(FnaSrcofincome fnaSrcOfincDets) {
		// TODO Auto-generated method stub  
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaSrcOfincDets); 
	}
	
//	public void delCpfDetails(FnaCpfDets fnCpfDets) {
//		// TODO Auto-generated method stub 
//			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
//			dao.deleteObject(fnCpfDets); 
//	}
	public void delFinLbltyDetails(FnaFinLiability fnaFinLbltyDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaFinLbltyDets); 
	}

	public void delCurAssDetails(FnaCurassDets fnaCurAssDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaCurAssDets); 
	}

	public void delRetirePlnDetails(FnaRetireplanDets fnaRetirePlnDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaRetirePlnDets); 
	}

	public void delInvstDetails(FnaInvsetmentSummary fnaInvstDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaInvstDets); 
	}

	public void delCashAssDetails(FnaAssetCashdets fnaCashAssDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaCashAssDets); 
	}

	public void delOthAssDetails(FnaAssetOtherdets fnaOthAssDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaOthAssDets); 
	}


	public void delRskPrefDetails(FnaRiskprefDets fnaRiskPrefDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			 dao.deleteObject(fnaRiskPrefDets); 
	}
	
	
	public void delSumAnalysDetails(FnaSummaryAnalysis fnaSumAnalysisDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaSumAnalysisDets); 
	}
	
	
	public void delCdAhocDetails(FnaAdvDeclare fnaCdAdhocDets) {
		// TODO Auto-generated method stub 
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaCdAdhocDets);
 
	}
	
	
	public void delLifeInsurceDetails(FnaLifeinsuranceDets fnaLifeIns) {
		// TODO Auto-generated method stub 
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.deleteObject(fnaLifeIns);
 
	}
	public List  clientNRICSearch(DBInterface dao, String strBufQryParam) {

		List clientNRICSrchList = new ArrayList();
 
			
//			String HQL_CLIENT_SEARCH = "SELECT FNA_ID,DF_SELF_NAME,DF_SELF_NRIC,"
//					+ "DF_SELF_PERSEMAIL,DF_SELF_MOBILE,DF_SELF_HOMEADDR "
//					+ " FROM FNA_SELFSPOUSE_DETS CUST WHERE CUST.FNA_ID IS NOT NULL " + strBufQryParam + " ORDER BY UPPER(DF_SELF_NAME)";
			
			String HQL_CLIENT_SEARCH = "SELECT DISTINCT DF_SELF_NAME,DF_SELF_NRIC"
					+ " "
					+ " FROM FNA_SELFSPOUSE_DETS CUST WHERE CUST.FNA_ID IS NOT NULL " + strBufQryParam + " ORDER BY UPPER(DF_SELF_NAME)";
			
			
			clientNRICSrchList = dao.searchByNativeSQLQuery(HQL_CLIENT_SEARCH);
 
		return clientNRICSrchList;

	}
	

	public List  clntLifeInsSearch(DBInterface dao, String strBufQryParam) {

		List clientLISrchList = new ArrayList();
 
		
		String HQL_CLIENT_SEARCH = "from com.fipa.dto.FnaLifeinsuranceDets lipinc" 
				+ " left join fetch lipinc.fnaSelfspouseDets cust  " 	
				+ " WHERE cust.fnaId IS NOT NULL and lipinc.lipId=?" 
				+ " ORDER BY UPPER(lipinc.lipId)";
		 
			
			clientLISrchList = dao.selectQueryByFind(HQL_CLIENT_SEARCH,strBufQryParam);
			
		return clientLISrchList;

	}
	
	public List  clntLifeInsList(DBInterface dao, String strBufQryParam) {

		List clientLISrchList = new ArrayList();
		  
//			String HQL_CLIENT_SEARCH = "SELECT life.LIP_ID,life.FNA_ID,life.LIP_ASSURED," + 
//					"life.LIP_POLICYNO,life.LIP_PLANNAME,TO_CHAR(life.LIP_INCEPDATE,'DD/MM/YYYY'),life.LIP_SA," + 
//					"life.LIP_CREATED_BY,life.LIP_CREATED_DATE, life.POLICY_STATUS  FROM FNA_LIFEINSURANCE_DETS life , " + 
//					"FNA_SELFSPOUSE_DETS selfsps " + 
//					" WHERE life.FNA_ID  = selfsps.FNA_ID(+) " + 
//					strBufQryParam  +   
//					"ORDER BY UPPER(life.LIP_ID) DESC ";
//			
//			 
//			clientLISrchList = dao.searchByNativeSQLQuery(HQL_CLIENT_SEARCH);
		
		String HQL_CLIENT_SEARCH = " from com.fipa.dto.FnaLifeinsuranceDets lipinc" 
				+ " join fetch lipinc.fnaSelfspouseDets cust " 
				+ " WHERE cust.fnaId IS NOT NULL "
				+ strBufQryParam
				+ " ORDER BY UPPER(lipinc.lipId)";
		 
			
			clientLISrchList = dao.selectQueryByFind(HQL_CLIENT_SEARCH,null);
//			System.out.println(clientLISrchList);
 
		return clientLISrchList;

	}
	
	public List  clntLifeCovSearch(DBInterface dao, String strBufQryParam) {

		List clientLICovSrchList = new ArrayList();
 

//		
		
		String HQL_CLIENT_SEARCH = "from com.fipa.dto.FnaLifeinsuranceCoverages benf" 
				+ " left join fetch benf.fnaSelfspouseDets cust  "
				+ " left join fetch benf.fnaLifeinsuranceDets life  "
				+ " WHERE cust.fnaId IS NOT NULL and life.lipId=?" 
				+ " ORDER BY UPPER(life.lipId)";
		 
		
//			String HQL_CLIENT_SEARCH = "SELECT *  " 
//					+ " FROM FNA_LIFEINSURANCE_COVERAGES life WHERE life.FNA_ID IS NOT NULL " 
//					+ strBufQryParam + " ORDER BY UPPER(LIP_ID)";
//			 
			
			clientLICovSrchList = dao.selectQueryByFind(HQL_CLIENT_SEARCH,strBufQryParam);
 
		return clientLICovSrchList;

	}
	
	 
	
	public List  clntLifePlanDetsSearch(DBInterface dao, String strBufQryParam) {

		List clntLifePlanDetsSearch = new ArrayList();
 

			String HQL_CLIENT_SEARCH = "from com.fipa.dto.FnaLifeinsuranceBasicriders benf" 
					+ " left join fetch benf.fnaSelfspouseDets cust  "
					+ " left join fetch benf.fnaLifeinsuranceDets life  "
					+ " WHERE cust.fnaId IS NOT NULL and life.lipId=?" 
					+ " ORDER BY UPPER(life.lipId)";
			 
			
			clntLifePlanDetsSearch = dao.selectQueryByFind(HQL_CLIENT_SEARCH,strBufQryParam);
 
		return clntLifePlanDetsSearch;

	}
	
	public List  clntLifeBenfSearch(DBInterface dao, String strBufQryParam) {

		List clientLIBenfrSrchList = new ArrayList();
 

			String HQL_CLIENT_SEARCH = "from com.fipa.dto.FnaLifeinsuranceDisablebenfs benf" 
					+ " left join fetch benf.fnaSelfspouseDets cust  "
					+ " left join fetch benf.fnaLifeinsuranceDets life  "
					+ " WHERE cust.fnaId IS NOT NULL and life.lipId=?" 
					+ " ORDER BY UPPER(life.lipId)";
			 
			
			clientLIBenfrSrchList = dao.selectQueryByFind(HQL_CLIENT_SEARCH,strBufQryParam);
 
		return clientLIBenfrSrchList;

	}
	

	public List  clntLifeChldEduSearch(DBInterface dao, String strBufQryParam) {

		List clientLIChldEduSrchList = new ArrayList();
  
		String HQL_CLIENT_SEARCH = "from com.fipa.dto.FnaLifeinsuranceChildedc lischlded" 
				+ " left join fetch lischlded.fnaSelfspouseDets cust  "
				+ " left join fetch lischlded.fnaLifeinsuranceDets life  "
				+ " WHERE cust.fnaId IS NOT NULL and life.lipId=?" 
				+ " ORDER BY UPPER(life.lipId)";
		
		clientLIChldEduSrchList = dao.selectQueryByFind(HQL_CLIENT_SEARCH, strBufQryParam);
 
		return clientLIChldEduSrchList;

	}
	
	
	public List  clntLifeMVSearch(DBInterface dao, String strBufQryParam) {

		List clientLIMVSrchList = new ArrayList();
 
		String HQL_CLIENT_SEARCH = "from com.fipa.dto.FnaLifeinsuranceMvRet ret" 
				+ " left join fetch ret.fnaSelfspouseDets cust  "
				+ " left join fetch ret.fnaLifeinsuranceDets life  "
				+ " WHERE cust.fnaId IS NOT NULL and life.lipId=?" 
				+ " ORDER BY UPPER(life.lipId)";
		
		clientLIMVSrchList = dao.selectQueryByFind(HQL_CLIENT_SEARCH, strBufQryParam);
 
		return clientLIMVSrchList;

	}
	
	
	public List  clntLifeNomSearch(DBInterface dao, String strBufQryParam) {

		List clientLINomSrchList = new ArrayList();
 

		String HQL_CLIENT_SEARCH = "from com.fipa.dto.FnaLifeinsuranceNominees nom" 
				+ " left join fetch nom.fnaSelfspouseDets cust  "
				+ " left join fetch nom.fnaLifeinsuranceDets life  "
				+ " WHERE cust.fnaId IS NOT NULL and life.lipId=?" 
				+ " ORDER BY UPPER(life.lipId)";
		
		clientLINomSrchList = dao.selectQueryByFind(HQL_CLIENT_SEARCH, strBufQryParam);
 
		return clientLINomSrchList;

	}
	
	
	
	public List clientSearch(DBInterface dao, String ... strParams) {

		List clientSrchList = new ArrayList();

		String strParamFNA = "";
		String strParamFPMS="";
		String HQL_CLIENT_SEARCH ="";
		
		if(!FipaUtils.nullOrBlank(strParams[0])){
			strParamFNA +=" and upper(cust.DF_SELF_NAME) like '"+strParams[0].toUpperCase()+"'";
			strParamFPMS +=" and upper(cust.CUST_NAME) like '"+strParams[0].toUpperCase()+"'";
		}
		
		if(!FipaUtils.nullOrBlank(strParams[1])){
			strParamFNA += " and cust.DF_SELF_NRIC like '"+strParams[1]+"'";
			strParamFPMS += " and COALESCE(NRIC,CUST_PASSPORT_NUM,CUST_FIN) like '"+strParams[1]+"'";			
		}
		
		if(!strParams[3].equalsIgnoreCase(FipaConstant.STR_STFTYPE_STAFF)){
			strParamFNA += " AND CUST.ADVSTF_ID ='"+strParams[2]+"'";
			strParamFPMS += " and cust.AGENT_ID_CURRENT = '"+strParams[2]+"'";	
		}
		
		 
		if(!strParams[3].equalsIgnoreCase(FipaConstant.STR_STFTYPE_STAFF)){
			
			 HQL_CLIENT_SEARCH = "SELECT "
						+ "'' FNA_ID, DF_SELF_NAME, DF_SELF_NRIC, DF_SELF_PERSEMAIL, DF_SELF_MOBILE, '' DF_SELF_HOMEADDR,"
						+ "'Y' FIPA_EXISTS , "
						+ "(SELECT DISTINCT 'Y' FROM "+FipaConstant.FPMSNL_SCHEMA+".CUSTOMER_DETAILS WHERE NRIC = DF_SELF_NRIC AND CUSTID = FPMS_CUSTID) FPMS_EXIST, "
						+ "FPMS_CUSTID CUSTID "
						+ " FROM FNA_SELFSPOUSE_DETS CUST "
						+ " WHERE CUST.FNA_ID IS NOT NULL "
						+ strParamFNA
						+ " UNION "
						+ " SELECT '' FNA_ID,CUST_NAME, COALESCE(NRIC,CUST_PASSPORT_NUM,CUST_FIN)NRIC, "
						+ "EMAIL_ID, RES_HAND_PHONE, '' RES_ADDR1,"
						+ " (SELECT DISTINCT 'Y' FROM FNA_SELFSPOUSE_DETS WHERE DF_SELF_NAME = CUST_NAME and DF_SELF_NRIC = COALESCE(NRIC,CUST_PASSPORT_NUM,CUST_FIN) AND FPMS_CUSTID = CUSTID)FIPA_EXIST,"
						+ " 'Y' FPMS_EXIST, CUSTID "
						+ " FROM "+FipaConstant.FPMSNL_SCHEMA+".CUSTOMER_DETAILS CUST WHERE "
						+ " CUST.CUSTID IS NOT NULL "
						+ " and COALESCE(NRIC,CUST_PASSPORT_NUM,CUST_FIN) is not null"
						+ strParamFPMS; 
			
		}else{
			
			 HQL_CLIENT_SEARCH = "SELECT DISTINCT"
						+ "'' FNA_ID, DF_SELF_NAME, DF_SELF_NRIC, DF_SELF_PERSEMAIL, DF_SELF_MOBILE, '' DF_SELF_HOMEADDR,"
						+ "'Y' FIPA_EXISTS , "
						+ "(SELECT DISTINCT 'Y' FROM "+FipaConstant.FPMSNL_SCHEMA+".CUSTOMER_DETAILS WHERE NRIC = DF_SELF_NRIC) FPMS_EXIST, "
						+ "FPMS_CUSTID CUSTID "
						+ " FROM FNA_SELFSPOUSE_DETS CUST "
						+ " WHERE CUST.FNA_ID IS NOT NULL "
						+ strParamFNA;
		}
		 
		
		
		
		clientSrchList = dao.searchByNativeSQLQuery(HQL_CLIENT_SEARCH);

		return clientSrchList;

	}
	
	

	public List rcmPrdtSearch(DBInterface dao,String strCpfBufQryParam) {

		List cpfSrchList = new ArrayList(); 

		String HQL_CPF_SEARCH = "SELECT PLAN_CODE FROM MASTER_PRODUCT rcmPrdt"
				+ " WHERE rcmPrdt.PRIN_ID IS NOT NULL "+ strCpfBufQryParam + "";


		cpfSrchList = dao.searchByNativeSQLQuery(HQL_CPF_SEARCH); 

		return cpfSrchList;

	}	 
	
	
	public void updateClientDetails(FnaSelfspouseDets client) {
		// TODO Auto-generated method stub
//		System.out.println("update-"+client.getTxtFlddfCreatedDatetime());
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
		 
			dao.updateObject(client); 
	}
	
//	public void updateAgreementsDetails(FipaAgreements fnaAgreements) {
//		// TODO Auto-generated method stub 
//		
//		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
//			
//			dao.updateObject(fnaAgreements);
// 
//	}
	public void updateAppTypesDetails(FnaApptypes fnaApptypes) {
		// TODO Auto-generated method stub 
		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaApptypes);
 
	}
	public void updateAnalysisTypesDetails(FnaApptypes fnaAnalytypes) {
		// TODO Auto-generated method stub 
		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaAnalytypes);
 
	}
	public void updateAdvDclDetails(FnaAdvDeclare fnaAdvDcldets) {
		// TODO Auto-generated method stub 
		
		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaAdvDcldets);
 
	}


	public void updateExpDetails(FnaExpenditureDets fnaExpdets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaExpdets); 
	}


	public void updContgDetails(FnaContingencyDets fnaContgDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaContgDets); 
	}
	public void updContingencyDetails(FnaContingencyDets fnaContDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean"); 
			dao.updateObject(fnaContDets); 
	}

	public void updPersPrioDetails(FnaPersprio fnaPersDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaPersDets); 
		
	}

	public void updSrcOfIncDetails(FnaSrcofincome fnaSrcOfincDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			dao.updateObject(fnaSrcOfincDets);
			 
	}

//	public void updCpfDetails(FnaCpfDets fnCpfDets) {
//		// TODO Auto-generated method stub 
//			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
//			
//			dao.updateObject(fnCpfDets); 
//	}

	public void updFinLbltyDetails(FnaFinLiability fnaFinLbltyDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaFinLbltyDets); 
	}

	public void updCurAssDetails(FnaCurassDets fnaCurAssDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaCurAssDets); 
	}

	public void updRetirePlnDetails(FnaRetireplanDets fnaRetirePlnDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaRetirePlnDets); 
	}

	public void updInvstDetails(FnaInvsetmentSummary fnaInvstDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaInvstDets); 
	}

	public void updCashAssDetails(FnaAssetCashdets fnaCashAssDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaCashAssDets); 
	}

	public void updOthAssDetails(FnaAssetOtherdets fnaOthAssDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaOthAssDets); 
	}
	
	
	public void updRskPrefDetails(FnaRiskprefDets fnaRiskPrefDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaRiskPrefDets); 
	}
	
	public void updSumAnlysDetails(FnaSummaryAnalysis fnaSumAnalysisDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaSumAnalysisDets); 
	}

	
	public void updCdAhocDetails(FnaAdvDeclare fnaCdAdhocDets) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaCdAdhocDets); 
	}
	
	public void updLifeInsrceDetails(FnaLifeinsuranceDets fnaLifeInsurce) {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
			
			dao.updateObject(fnaLifeInsurce); 
	}
	
 
	

	public String saveSpseDetails() {
		
		String strSpouseId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");	
		 
		return strSpouseId;
		
	}


	public String saveAgrmtDetails() {
		// TODO Auto-generated method stub
		
		String strAgrId = ""; 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
 
		return strAgrId;
	}
	public void saveChilddetails(Vector vectChildDetails,String strClientId) { 
			String strChildPartId="";
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			
			Object objChildDets = null;
			List insertList = new ArrayList(0);
			List updateList = new ArrayList(1);
			List deleteList = new ArrayList(2);
			
			int vectorSize = vectChildDetails.size();

			if (vectorSize > 0) {
				insertList = (List) vectChildDetails.elementAt(0);
				updateList = (List) vectChildDetails.elementAt(1);
				deleteList = (List) vectChildDetails.elementAt(2);
			}

			int insSize = insertList.size();
			 
			if (insSize > 0) {
				
				FnaChilddetails childdetails=new FnaChilddetails();
				FnaSelfspouseDets custDets = new FnaSelfspouseDets();

				
				if(!FipaUtils.nullOrBlank(strClientId)){
					custDets.setFnaId(strClientId);				
				}
				
				String strMaxId = (String) dao.fetchMaxId(childdetails, "fnaChildId");
				
			
				
				Iterator itIns = insertList.iterator();
				while (itIns.hasNext()) {
					 
					strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CHD", 17);
					strChildPartId = strMaxId;
					
					 
					childdetails = (FnaChilddetails) itIns.next();
					childdetails.setFnaChildId(strChildPartId);
					childdetails.setFnaSelfspouseDets(custDets);
			
			     
				}
				
				objChildDets = childdetails;			
				dao.insertTableObject(insertList, objChildDets);

			}

			int updSize = updateList.size();
			 
			if (updSize > 0) {
			 
				dao.updateTableObject(updateList, objChildDets);
			}

			
			int delSize = deleteList.size();
			 
			if (delSize > 0) {
				dao.deleteTableObject(deleteList, objChildDets);
			}
			
		}
	public void saveFinGoalsdetails(Vector vectFinGoalsDetails,String strClientId) {
		 
			String strFinglsId="";
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
			
			Object objFinGoalsDets = null;
			List insertList = new ArrayList(0);
			List updateList = new ArrayList(1);
			List deleteList = new ArrayList(2);
			
			int vectorSize = vectFinGoalsDetails.size();

			if (vectorSize > 0) {
				insertList = (List) vectFinGoalsDetails.elementAt(0);
				updateList = (List) vectFinGoalsDetails.elementAt(1);
				deleteList = (List) vectFinGoalsDetails.elementAt(2);
			}

			int insSize = insertList.size();
			 
			if (insSize > 0) {
				
				FnaFingoalsconcern FinGoalsdetails=new FnaFingoalsconcern();
				FnaSelfspouseDets custDets = new FnaSelfspouseDets();

				
				if(!FipaUtils.nullOrBlank(strClientId)){
					custDets.setFnaId(strClientId);				
				}
				
				String strMaxId = (String) dao.fetchMaxId(FinGoalsdetails, "fnaGoalId");
				
				
				Iterator itIns = insertList.iterator();
				while (itIns.hasNext()) {
					 
					
					strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "FIN", 17);
					strFinglsId = strMaxId;
					
					
					
					 
					FinGoalsdetails = (FnaFingoalsconcern) itIns.next();
					FinGoalsdetails.setFnaGoalId(strFinglsId);
					FinGoalsdetails.setFnaSelfspouseDets(custDets);
			
			     
				}
				objFinGoalsDets =FinGoalsdetails;			
				dao.insertTableObject(insertList, objFinGoalsDets);

			}

			int updSize = updateList.size();
			 
			if (updSize > 0) {
			 
				dao.updateTableObject(updateList, objFinGoalsDets);
			}

			
			int delSize = deleteList.size();
			 
			if (delSize > 0) {
				dao.deleteTableObject(deleteList, objFinGoalsDets);
			}
			
		}
	
public void saveDepdetails(Vector vectDeptDetails,String strClientId) {
	  
		String strDepId="";
		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
		DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
		
		Object objDeptDets = null;
		List insertList = new ArrayList(0);
		List updateList = new ArrayList(1);
		List deleteList = new ArrayList(2);
		
		int vectorSize = vectDeptDetails.size();

		if (vectorSize > 0) {
			insertList = (List) vectDeptDetails.elementAt(0);
			updateList = (List) vectDeptDetails.elementAt(1);
			deleteList = (List) vectDeptDetails.elementAt(2);
		}

		int insSize = insertList.size();
	 
		if (insSize > 0) {
			
			FnaDependantDets deptdetails=new FnaDependantDets();
			FnaSelfspouseDets custDets = new FnaSelfspouseDets();

			
			if(!FipaUtils.nullOrBlank(strClientId)){
				custDets.setFnaId(strClientId);				
			}
			
			String strMaxId = (String) dao.fetchMaxId(deptdetails, "depnId");
			
			
			Iterator itIns = insertList.iterator();
			while (itIns.hasNext()) {
				 
				
				strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "DEP", 17);
				strDepId = strMaxId;
				
				
				 
				deptdetails = (FnaDependantDets) itIns.next();
				deptdetails.setDepnId(strDepId);
				deptdetails.setFnaSelfspouseDets(custDets);
		
		     
			}
			objDeptDets =deptdetails;			
			dao.insertTableObject(insertList, objDeptDets);

		}

		int updSize = updateList.size();
		 
		if (updSize > 0) { 
			dao.updateTableObject(updateList, objDeptDets);
		}

		
		int delSize = deleteList.size(); 
		if (delSize > 0) {
			dao.deleteTableObject(deleteList, objDeptDets);
		}
		
	}

public void saveSAInvdetails(Vector vectSavingInvDetails, String strClientId) {
	// TODO Auto-generated method stub 
	String strSAInvId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objSAInvDets = null;
	List insertSAInvList = new ArrayList(0);
	List updateSAInvList = new ArrayList(1);
	List deleteSAInvList = new ArrayList(2);
	
	int vectorSize = vectSavingInvDetails.size();

	if (vectorSize > 0) {
		insertSAInvList = (List) vectSavingInvDetails.elementAt(0);
		updateSAInvList = (List) vectSavingInvDetails.elementAt(1);
		deleteSAInvList = (List) vectSavingInvDetails.elementAt(2);
	}

	int insSize = insertSAInvList.size(); 
	if (insSize > 0) {
		
		FnaSavingsinvDets fnaSAInvdetails=new FnaSavingsinvDets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(fnaSAInvdetails, "sainvId");
		
		
		Iterator itIns = insertSAInvList.iterator();
		while (itIns.hasNext()) {
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "SIN", 17);
			strSAInvId = strMaxId;
			 
			 
			fnaSAInvdetails = (FnaSavingsinvDets) itIns.next();
			fnaSAInvdetails.setSainvId(strSAInvId);
			fnaSAInvdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objSAInvDets = fnaSAInvdetails;			
		dao.insertTableObject(insertSAInvList, objSAInvDets);

	}

	int updSize = updateSAInvList.size(); 
	if (updSize > 0) {
		dao.updateTableObject(updateSAInvList, objSAInvDets);
	}

	
	int delSize = deleteSAInvList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteSAInvList, objSAInvDets);
	}
}	





public void saveAssetsDetails(Vector vectAssetdetails, String strClientId) {
	// TODO Auto-generated method stub 
	
	String strAssetsId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objAsstDets = null;
	List insertAsstList = new ArrayList(0);
	List updateAsstList = new ArrayList(1);
	List deleteAsstList = new ArrayList(2);
	
	int vectorSize = vectAssetdetails.size();

	if (vectorSize > 0) {
		insertAsstList = (List) vectAssetdetails.elementAt(0);
		updateAsstList = (List) vectAssetdetails.elementAt(1);
		deleteAsstList = (List) vectAssetdetails.elementAt(2);
	}

	int insSize = insertAsstList.size(); 
	if (insSize > 0) {
		
		FnaAssetBusiandpersdets fnabusiperdetails=new FnaAssetBusiandpersdets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(fnabusiperdetails, "busipersId");
		
		
		Iterator itIns = insertAsstList.iterator();
		while (itIns.hasNext()) {
			  
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "BPA", 17);
			strAssetsId = strMaxId;
			  
			fnabusiperdetails = (FnaAssetBusiandpersdets) itIns.next();
			fnabusiperdetails.setBusipersId(strAssetsId);
			fnabusiperdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objAsstDets = fnabusiperdetails;			
		dao.insertTableObject(insertAsstList, objAsstDets);

	}

	int updSize = updateAsstList.size(); 
	if (updSize > 0) {
		dao.updateTableObject(updateAsstList, objAsstDets);
	}

	
	int delSize = deleteAsstList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteAsstList, objAsstDets);
	}
}	



public void saveOthArOfCnDetails(Vector vectOthArCrndetails, String strClientId) {
	// TODO Auto-generated method stub 
	
	String OthArofcnId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objOACnDets = null;
	List insertOACnList = new ArrayList(0);
	List updateOACnList = new ArrayList(1);
	List deleteOACnList = new ArrayList(2);
	
	int vectorSize = vectOthArCrndetails.size();

	if (vectorSize > 0) {
		insertOACnList = (List) vectOthArCrndetails.elementAt(0);
		updateOACnList = (List) vectOthArCrndetails.elementAt(1);
		deleteOACnList = (List) vectOthArCrndetails.elementAt(2);
	}

	int insSize = insertOACnList.size(); 
	if (insSize > 0) {
		
		FnaOthareaconcern fnaOACrndetails=new FnaOthareaconcern();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(fnaOACrndetails, "fnaOacId");
		
		
		Iterator itIns = insertOACnList.iterator();
		while (itIns.hasNext()) {
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "OAC", 17);
			OthArofcnId = strMaxId;
			
			 
			fnaOACrndetails = (FnaOthareaconcern) itIns.next();
			fnaOACrndetails.setFnaOacId(OthArofcnId);
			fnaOACrndetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objOACnDets = fnaOACrndetails;			
		dao.insertTableObject(insertOACnList, objOACnDets);

	}

	int updSize = updateOACnList.size(); 
	if (updSize > 0) {
		dao.updateTableObject(updateOACnList, objOACnDets);
	}

	
	int delSize = deleteOACnList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteOACnList, objOACnDets);
	}
}	


public void saveReasonsDetails(Vector vectReasonsdetails, String strClientId) {
	// TODO Auto-generated method stub 
	String ReasonsId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRsnDets = null;
	List insertRsnList = new ArrayList(0);
	List updateRsnList = new ArrayList(1);
	List deleteRsnList = new ArrayList(2);
	
	int vectorSize = vectReasonsdetails.size();

	if (vectorSize > 0) {
		insertRsnList = (List) vectReasonsdetails.elementAt(0);
		updateRsnList = (List) vectReasonsdetails.elementAt(1);
		deleteRsnList = (List) vectReasonsdetails.elementAt(2);
	}

	int insSize = insertRsnList.size(); 
	if (insSize > 0) {
		
		FnaRecomReasons fnaresndetails=new FnaRecomReasons();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(fnaresndetails, "fnaReasId");
		
		
		Iterator itIns = insertRsnList.iterator();
		while (itIns.hasNext()) {
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RSN", 17);
			ReasonsId = strMaxId;
			  
			fnaresndetails = (FnaRecomReasons) itIns.next();
			fnaresndetails.setFnaReasId(ReasonsId);
			fnaresndetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objRsnDets = fnaresndetails;			
		dao.insertTableObject(insertRsnList, objRsnDets);

	}

	int updSize = updateRsnList.size(); 
	if (updSize > 0) {
		dao.updateTableObject(updateRsnList, objRsnDets);
	}

	
	int delSize = deleteRsnList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteRsnList, objRsnDets);
	}
}	

//public void saveFinGldProiDetails(Vector vectFinGlsPrioDetails, String strClientId) {
//	// TODO Auto-generated method stub 
//	
//	String FinGlsPrioId="";
//	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//	
//	Object objFGProDets = null;
//	List insertFGProList = new ArrayList(0);
//	List updateFGProList = new ArrayList(1);
//	List deleteFGProList = new ArrayList(2);
//	
//	int vectorSize = vectFinGlsPrioDetails.size();
//
//	if (vectorSize > 0) {
//		insertFGProList = (List) vectFinGlsPrioDetails.elementAt(0);
//		updateFGProList = (List) vectFinGlsPrioDetails.elementAt(1);
//		deleteFGProList = (List) vectFinGlsPrioDetails.elementAt(2);
//	}
//
//	int insSize = insertFGProList.size(); 
//	if (insSize > 0) {
//		
//		FnaFingoalsconcern fnafgpriodets =new FnaFingoalsconcern();
//		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
//
//		
//		if(!FipaUtils.nullOrBlank(strClientId)){
//			custDets.setFnaId(strClientId);				
//		}
//		
//		String strMaxId = (String) dao.fetchMaxId(fnafgpriodets, "txtFldFgPkId");
//		
//		
//		Iterator itIns = insertFGProList.iterator();
//		while (itIns.hasNext()) {
//			  
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "FGP", 17);
//			FinGlsPrioId = strMaxId;
//			   
//			fnafgpriodets = (FnaFingoalsconcern) itIns.next();
//			fnafgpriodets.setFnaGoalId(FinGlsPrioId);
//			fnafgpriodets.setSelFnaFinGoalPriSelfspouseDets(custDets);
//			 
//		}
//		objFGProDets = fnafgpriodets;			
//		dao.insertTableObject(insertFGProList, objFGProDets);
//
//	}
//
//	int updSize = updateFGProList.size(); 
//	if (updSize > 0) {
//		dao.updateTableObject(updateFGProList, objFGProDets);
//	}
//
//	
//	int delSize = deleteFGProList.size(); 
//	if (delSize > 0) {
//		dao.deleteTableObject(deleteFGProList, objFGProDets);
//	}
//}	


public void saveCPFBalanDets(Vector vectCPFBalanceDets, String strClientId) {
	// TODO Auto-generated method stub 
	String cpfbalcId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objCpfMCtrbDets = null;
	List insertMCtrbList = new ArrayList(0);
	List updateMCtrbList = new ArrayList(1);
	List deleteMCtrbList = new ArrayList(2);
	
	int vectorSize = vectCPFBalanceDets.size();

	if (vectorSize > 0) {
		insertMCtrbList = (List) vectCPFBalanceDets.elementAt(0);
		updateMCtrbList = (List) vectCPFBalanceDets.elementAt(1);
		deleteMCtrbList = (List) vectCPFBalanceDets.elementAt(2);
	}

	int insSize = insertMCtrbList.size(); 
	if (insSize > 0) {
		
		FnaCpfBalanceDets fnaCPFBalance=new FnaCpfBalanceDets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(fnaCPFBalance, "cpfId");
		
		Iterator itIns = insertMCtrbList.iterator();
		while (itIns.hasNext()) {
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CBD", 17);
			cpfbalcId = strMaxId;
			  
			fnaCPFBalance = (FnaCpfBalanceDets) itIns.next();
			fnaCPFBalance.setCpfId(cpfbalcId);
			fnaCPFBalance.setFnaSelfspouseDets(custDets);
	
	     
		}
		objCpfMCtrbDets = fnaCPFBalance;			
		dao.insertTableObject(insertMCtrbList, objCpfMCtrbDets);

	}

	int updSize = updateMCtrbList.size(); 
	if (updSize > 0) {
		dao.updateTableObject(updateMCtrbList, objCpfMCtrbDets);
	}

	
	int delSize = deleteMCtrbList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteMCtrbList, objCpfMCtrbDets);
	}
}	

public void saveCpfMtlyCtbDetails(Vector vectCpfMonthlyCtrb, String strClientId) {
	// TODO Auto-generated method stub 
	String cpfMthCtdId="";
	
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objCpfMCtrbDets = null;
	List insertMCtrbList = new ArrayList(0);
	List updateMCtrbList = new ArrayList(1);
	List deleteMCtrbList = new ArrayList(2);
	
	int vectorSize = vectCpfMonthlyCtrb.size();

	if (vectorSize > 0) {
		insertMCtrbList = (List) vectCpfMonthlyCtrb.elementAt(0);
		updateMCtrbList = (List) vectCpfMonthlyCtrb.elementAt(1);
		deleteMCtrbList = (List) vectCpfMonthlyCtrb.elementAt(2);
	}

	int insSize = insertMCtrbList.size(); 
	if (insSize > 0) {
		
		FnaCpfMonthcontDets fnaCpfMthCtdetails=new FnaCpfMonthcontDets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(fnaCpfMthCtdetails, "ccPkId");
		
		
		Iterator itIns = insertMCtrbList.iterator();
		while (itIns.hasNext()) {
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CCP", 17);
			cpfMthCtdId = strMaxId;
			 
			fnaCpfMthCtdetails = (FnaCpfMonthcontDets) itIns.next();
			fnaCpfMthCtdetails.setCcPkId(cpfMthCtdId);
			fnaCpfMthCtdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objCpfMCtrbDets = fnaCpfMthCtdetails;			
		dao.insertTableObject(insertMCtrbList, objCpfMCtrbDets);

	}

	int updSize = updateMCtrbList.size(); 
	if (updSize > 0) {
		dao.updateTableObject(updateMCtrbList, objCpfMCtrbDets);
	}

	
	int delSize = deleteMCtrbList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteMCtrbList, objCpfMCtrbDets);
	}
}	


//public void saveCpfTopupsDetails(Vector vectCpfTopUpCtrb, String strClientId) {
//	// TODO Auto-generated method stub 
//	
//	String cpftopupId="";
//	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//	
//	Object objTopupsDets = null;
//	List insertTopupsList = new ArrayList(0);
//	List updateTopupsList = new ArrayList(1);
//	List deleteTopupsList = new ArrayList(2);
//	
//	int vectorSize = vectCpfTopUpCtrb.size();
//
//	if (vectorSize > 0) {
//		insertTopupsList = (List) vectCpfTopUpCtrb.elementAt(0);
//		updateTopupsList = (List) vectCpfTopUpCtrb.elementAt(1);
//		deleteTopupsList = (List) vectCpfTopUpCtrb.elementAt(2);
//	}
//
//	int insSize = insertTopupsList.size(); 
//	if (insSize > 0) {
//		
//		FnaCpfTopupDets fnaTopupdetails=new FnaCpfTopupDets();
//		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
//		MasterCpfAcctype CpfAcctype = new MasterCpfAcctype();
//
//		
//		if(!FipaUtils.nullOrBlank(strClientId)){
//			custDets.setFnaId(strClientId);				
//		}
//		
//		 
//		String strMaxId = (String) dao.fetchMaxId(fnaTopupdetails, "txtFldCtPkid");
//		
//		
//		Iterator itIns = insertTopupsList.iterator();
//		while (itIns.hasNext()) {
//			 
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CTP", 17);
//			cpftopupId = strMaxId; 
//			fnaTopupdetails = (FnaCpfTopupDets) itIns.next();
//			fnaTopupdetails.setTxtFldCtPkid(cpftopupId);
//			fnaTopupdetails.setFnaSelfspouseDets(custDets);
//	
//	     
//		}
//		objTopupsDets = fnaTopupdetails;			
//		dao.insertTableObject(insertTopupsList, objTopupsDets);
//
//	}
//
//	int updSize = updateTopupsList.size(); 
//	if (updSize > 0) {
//		dao.updateTableObject(updateTopupsList, objTopupsDets);
//	}
//
//	
//	int delSize = deleteTopupsList.size(); 
//	if (delSize > 0) {
//		dao.deleteTableObject(deleteTopupsList, objTopupsDets);
//	}
//}	


//public void saveCpfDedtDetails(Vector vectCpfDedtnCtrb, String strClientId) {
//	// TODO Auto-generated method stub 
//	String cpfdetsId="";
//	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//	
//	Object objDedtnDets = null;
//	List insertDedtnList = new ArrayList(0);
//	List updateDedtnList = new ArrayList(1);
//	List deleteDedtnList = new ArrayList(2);
//	
//	int vectorSize = vectCpfDedtnCtrb.size();
//
//	if (vectorSize > 0) {
//		insertDedtnList = (List) vectCpfDedtnCtrb.elementAt(0);
//		updateDedtnList = (List) vectCpfDedtnCtrb.elementAt(1);
//		deleteDedtnList = (List) vectCpfDedtnCtrb.elementAt(2);
//	}
//
//	int insSize = insertDedtnList.size(); 
//	if (insSize > 0) {
//		
//		FnaCpfDeductions fnadedtndetails=new FnaCpfDeductions();
//		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
//
//		
//		if(!FipaUtils.nullOrBlank(strClientId)){
//			custDets.setFnaId(strClientId);				
//		}
//		
//		String strMaxId = (String) dao.fetchMaxId(fnadedtndetails, "txtFldCdPkid");
//		
//		
//		Iterator itIns = insertDedtnList.iterator();
//		while (itIns.hasNext()) {
//			 
//			
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CDP", 17);
//			cpfdetsId = strMaxId;
//			 
//			fnadedtndetails = (FnaCpfDeductions) itIns.next();
//			fnadedtndetails.setCdPkid(cpfdetsId);
//			fnadedtndetails.setFnaSelfspouseDets(custDets);
//	
//	     
//		}
//		objDedtnDets = fnadedtndetails;			
//		dao.insertTableObject(insertDedtnList, objDedtnDets);
//
//	}
//
//	int updSize = updateDedtnList.size(); 
//	if (updSize > 0) {
//		dao.updateTableObject(updateDedtnList, objDedtnDets);
//	}
//
//	
//	int delSize = deleteDedtnList.size(); 
//	if (delSize > 0) {
//		dao.deleteTableObject(deleteDedtnList, objDedtnDets);
//	}
//}	
 






public void saveCADdetails(Vector vectCADdetails, String strClientId) {
	// TODO Auto-generated method stub 
	String CADId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objCADDets = null;
	List insertCADList = new ArrayList(0);
	List updateCADList = new ArrayList(1);
	List deleteCADList = new ArrayList(2);
	
	int vectorSize = vectCADdetails.size();

	if (vectorSize > 0) {
		insertCADList = (List) vectCADdetails.elementAt(0);
		updateCADList = (List) vectCADdetails.elementAt(1);
		deleteCADList = (List) vectCADdetails.elementAt(2);
	}

	int insSize = insertCADList.size(); 
	if (insSize > 0) {
		
		FnaCpfDeductions fnadedtndetails=new FnaCpfDeductions();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(fnadedtndetails, "cdPkid");
		 
		
		Iterator itIns = insertCADList.iterator();
		while (itIns.hasNext()) {
			 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CDP", 17);
			CADId = strMaxId;
			 
			fnadedtndetails = (FnaCpfDeductions) itIns.next();
			fnadedtndetails.setCdPkid(CADId);
			fnadedtndetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objCADDets = fnadedtndetails;			
		dao.insertTableObject(insertCADList, objCADDets);

	}

	int updSize = updateCADList.size(); 
	if (updSize > 0) {
		dao.updateTableObject(updateCADList, objCADDets);
	}

	
	int delSize = deleteCADList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteCADList, objCADDets);
	}
}	
 
public void saveLifeInsCoverageDetails(Vector vectLifeInsCovPlan, String strClientId,String strLICId) {
//	System.out.println("Life Insurance Coverage");
//	System.out.println("strClientId-------->>>"+strClientId); 
	// TODO Auto-generated method stub 
	String lifeInsCovrId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objLICovDets = null;
	List insertLICovList = new ArrayList(0); 
	
	int vectorSize = vectLifeInsCovPlan.size();

	if (vectorSize > 0) {
		insertLICovList = (List) vectLifeInsCovPlan.elementAt(0); 
	}

	int insSize = insertLICovList.size(); 
	if (insSize > 0) {
		FnaLifeinsuranceDets liInsdets=new FnaLifeinsuranceDets();
		FnaLifeinsuranceCoverages LICovdetails=new FnaLifeinsuranceCoverages();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId); 
		}
		
		if(!FipaUtils.nullOrBlank(strLICId)){
			
			liInsdets.setLipId(strLICId);
		}
		String strMaxId = (String) dao.fetchMaxId(LICovdetails, "coverId");
		
		
		Iterator itIns = insertLICovList.iterator();
		while (itIns.hasNext()) { 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "LIC", 17);
			lifeInsCovrId = strMaxId; 
			LICovdetails = (FnaLifeinsuranceCoverages) itIns.next();
			LICovdetails.setCoverId(lifeInsCovrId);
			LICovdetails.setFnaSelfspouseDets(custDets);
			LICovdetails.setFnaLifeinsuranceDets(liInsdets);
	
	     
		}
		objLICovDets = LICovdetails;			
		dao.insertTableObject(insertLICovList, objLICovDets);

	}
 
	
	
}




public void updateLifeInsCoverageDetails(Vector vectLifeInsCovPlan, String strClientId,String strLICId) { 
	
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objLICovDets = null;
	 
	List updateLICovList = new ArrayList(0); 
	
	int vectorSize = vectLifeInsCovPlan.size();

	if (vectorSize > 0) {
		 
		updateLICovList = (List) vectLifeInsCovPlan.elementAt(0); 
	}
	
	int updSize = updateLICovList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateLICovList, objLICovDets);
	}


}


public void saveRetPlgdetails(Vector vectliMvRetDetails, String strClientId,String strLICId) {
	// TODO Auto-generated method stub 
	
	String retPlgId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRetPlgDets = null;
	List insertRetPlgList = new ArrayList(0);
	List updateRetPlgList = new ArrayList(1);
	List deleteRetPlgList = new ArrayList(2);
	
	int vectorSize = vectliMvRetDetails.size();

	if (vectorSize > 0) {
		insertRetPlgList = (List) vectliMvRetDetails.elementAt(0);
		updateRetPlgList = (List) vectliMvRetDetails.elementAt(1);
		deleteRetPlgList = (List) vectliMvRetDetails.elementAt(2);
	}

	int insSize = insertRetPlgList.size(); 
	if (insSize > 0) {
		FnaLifeinsuranceDets liInsdets=new FnaLifeinsuranceDets();
		FnaLifeinsuranceMvRet liMvRetdetails=new FnaLifeinsuranceMvRet();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		if(!FipaUtils.nullOrBlank(strLICId)){
			
			liInsdets.setLipId(strLICId);
		}
		
		String strMaxId = (String) dao.fetchMaxId(liMvRetdetails, "mvretId");
		
		
		Iterator itIns = insertRetPlgList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RET", 17);
			retPlgId = strMaxId;
			  
			liMvRetdetails = (FnaLifeinsuranceMvRet) itIns.next();
			liMvRetdetails.setMvretId(retPlgId);
			liMvRetdetails.setFnaSelfspouseDets(custDets);
			liMvRetdetails.setFnaLifeinsuranceDets(liInsdets);
		}
		
		objRetPlgDets =liMvRetdetails;			
		dao.insertTableObject(insertRetPlgList, objRetPlgDets);

	}

	int updSize = updateRetPlgList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateRetPlgList, objRetPlgDets);
	}

	
	int delSize = deleteRetPlgList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteRetPlgList, objRetPlgDets);
	}
	
	
}


public void savePlnProdetails(Vector vectliPlanAndProDetails, String strClientId,String strLICId) {
	// TODO Auto-generated method stub 
	
	String PlnId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objPlnDets = null;
	List insertPlnList = new ArrayList(0);
	List updatePlnList = new ArrayList(1);
	List deletePlnList = new ArrayList(2);
	
	int vectorSize = vectliPlanAndProDetails.size();

	if (vectorSize > 0) {
		insertPlnList = (List) vectliPlanAndProDetails.elementAt(0);
		updatePlnList = (List) vectliPlanAndProDetails.elementAt(1);
		deletePlnList = (List) vectliPlanAndProDetails.elementAt(2);
	}

	int insSize = insertPlnList.size(); 
	if (insSize > 0) {
		FnaLifeinsuranceDets liInsdets=new FnaLifeinsuranceDets();
		FnaLifeinsuranceBasicriders liBasicridersdetails=new FnaLifeinsuranceBasicriders();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		if(!FipaUtils.nullOrBlank(strLICId)){
			
			liInsdets.setLipId(strLICId);
		}
		
		String strMaxId = (String) dao.fetchMaxId(liBasicridersdetails, "riderId");
		
		
		Iterator itIns = insertPlnList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "PLN", 17);
			PlnId = strMaxId; 
			liBasicridersdetails = (FnaLifeinsuranceBasicriders) itIns.next(); 
			liBasicridersdetails.setRiderId(PlnId);
			liBasicridersdetails.setFnaSelfspouseDets(custDets);
			liBasicridersdetails.setFnaLifeinsuranceDets(liInsdets);
		}
		
		objPlnDets =liBasicridersdetails;			
		dao.insertTableObject(insertPlnList, objPlnDets);

	}

	int updSize = updatePlnList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updatePlnList, objPlnDets);
	}

	
	int delSize = deletePlnList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deletePlnList, objPlnDets);
	}
	
	
}
public void saveEduPlgdetails(Vector vectliChildDets, String strClientId,String strLICId) {
	// TODO Auto-generated method stub 
	
	String eduPlgId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objEduPlgDets = null;
	List insertEduPlgList = new ArrayList(0);
	List updateEduPlgList = new ArrayList(1);
	List deleteEduPlgList = new ArrayList(2);
	
	int vectorSize = vectliChildDets.size();

	if (vectorSize > 0) {
		insertEduPlgList = (List) vectliChildDets.elementAt(0);
		updateEduPlgList = (List) vectliChildDets.elementAt(1);
		deleteEduPlgList = (List) vectliChildDets.elementAt(2);
	}

	int insSize = insertEduPlgList.size(); 
	if (insSize > 0) {
		FnaLifeinsuranceDets liInsdets=new FnaLifeinsuranceDets();
		FnaLifeinsuranceChildedc liChldEdcdetails=new FnaLifeinsuranceChildedc();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		if(!FipaUtils.nullOrBlank(strLICId)){
			
			liInsdets.setLipId(strLICId);
		}
		
		String strMaxId = (String) dao.fetchMaxId(liChldEdcdetails, "chliId");
		
		
		Iterator itIns = insertEduPlgList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "EDU", 17);
			eduPlgId = strMaxId;
			  
			liChldEdcdetails = (FnaLifeinsuranceChildedc) itIns.next();
			liChldEdcdetails.setChliId(eduPlgId);
			liChldEdcdetails.setFnaSelfspouseDets(custDets);
			liChldEdcdetails.setFnaLifeinsuranceDets(liInsdets);
		}
		
		objEduPlgDets =liChldEdcdetails;			
		dao.insertTableObject(insertEduPlgList, objEduPlgDets);

	}

	int updSize = updateEduPlgList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateEduPlgList, objEduPlgDets);
	}

	
	int delSize = deleteEduPlgList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteEduPlgList, objEduPlgDets);
	}
	
	
}

public void saveBenefdetails(Vector vectLiBenefits, String strClientId,String strLICId) {
	// TODO Auto-generated method stub 
	
	String libenefId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objliBenfDets = null;
	List insertliBenfList = new ArrayList(0);
	List updateliBenfList = new ArrayList(1);
	List deleteliBenfList = new ArrayList(2);
	
	int vectorSize = vectLiBenefits.size();

	if (vectorSize > 0) {
		insertliBenfList = (List) vectLiBenefits.elementAt(0);
		updateliBenfList = (List) vectLiBenefits.elementAt(1);
		deleteliBenfList = (List) vectLiBenefits.elementAt(2);
	}

	int insSize = insertliBenfList.size(); 
	if (insSize > 0) {
		FnaLifeinsuranceDets liInsdets=new FnaLifeinsuranceDets();
		FnaLifeinsuranceDisablebenfs lilibenefdetails=new FnaLifeinsuranceDisablebenfs();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		if(!FipaUtils.nullOrBlank(strLICId)){
			
			liInsdets.setLipId(strLICId);
		}
		
		String strMaxId = (String) dao.fetchMaxId(lilibenefdetails, "benfId");
		
		
		Iterator itIns = insertliBenfList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "BEF", 17);
			libenefId = strMaxId;
			  
			lilibenefdetails = (FnaLifeinsuranceDisablebenfs) itIns.next();
			lilibenefdetails.setBenfId(libenefId);
			lilibenefdetails.setFnaSelfspouseDets(custDets);
			lilibenefdetails.setFnaLifeinsuranceDets(liInsdets);
		}
		
		objliBenfDets =lilibenefdetails;			
		dao.insertTableObject(insertliBenfList, objliBenfDets);

	}

	int updSize = updateliBenfList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateliBenfList, objliBenfDets);
	}

	
	int delSize = deleteliBenfList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteliBenfList, objliBenfDets);
	}
	
	
}


public void saveNomineeNamedetails(Vector vectNomNamedetails, String strClientId,String strLICId) {
	// TODO Auto-generated method stub 
	
	String liNomNameId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objliNomNameDets = null;
	List insertliNomNameList = new ArrayList(0);
	List updateliNomNameList = new ArrayList(1);
	List deleteliNomNameList = new ArrayList(2);
	
	int vectorSize = vectNomNamedetails.size();

	if (vectorSize > 0) {
		insertliNomNameList = (List) vectNomNamedetails.elementAt(0);
		updateliNomNameList = (List) vectNomNamedetails.elementAt(1);
		deleteliNomNameList = (List) vectNomNamedetails.elementAt(2);
	}

	int insSize = insertliNomNameList.size(); 
	if (insSize > 0) {
		FnaLifeinsuranceDets liInsdets=new FnaLifeinsuranceDets();
		FnaLifeinsuranceNominees liliNominedetails=new FnaLifeinsuranceNominees();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		if(!FipaUtils.nullOrBlank(strLICId)){
			
			liInsdets.setLipId(strLICId);
		}
		
		String strMaxId = (String) dao.fetchMaxId(liliNominedetails, "nomineeId");
		
		
		Iterator itIns = insertliNomNameList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "NOM", 17);
			liNomNameId = strMaxId;
			  
			liliNominedetails = (FnaLifeinsuranceNominees) itIns.next();
			liliNominedetails.setNomineeId(liNomNameId);
			liliNominedetails.setFnaSelfspouseDets(custDets);
			liliNominedetails.setFnaLifeinsuranceDets(liInsdets);
		}
		
		objliNomNameDets =liliNominedetails;			
		dao.insertTableObject(insertliNomNameList, objliNomNameDets);

	}

	int updSize = updateliNomNameList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateliNomNameList, objliNomNameDets);
	}

	
	int delSize = deleteliNomNameList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteliNomNameList, objliNomNameDets);
	}
	
	
}

public void  delLifeInsCoverageDetails(Vector vectLifeInsCovPlan, String strClientId,String strLICId) { 
	
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objLisCovDets = null; 
	List deleteLisCovList = new ArrayList(0);
	
	int vectorSize = vectLifeInsCovPlan.size();

	if (vectorSize > 0) { 
		deleteLisCovList = (List) vectLifeInsCovPlan.elementAt(0); 
	}
	
	int delSize = deleteLisCovList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteLisCovList, objLisCovDets);
	}  
}

public void saveInvstdetails(Vector vectInputInvest, String strClientId) {
	// TODO Auto-generated method stub 
	
	String strOwnInvstId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objCOBDets = null;
	List insertInvList = new ArrayList(0);
	List updateInvList = new ArrayList(1);
	List deleteInvList = new ArrayList(2);
	
	int vectorSize = vectInputInvest.size();

	if (vectorSize > 0) {
		insertInvList = (List) vectInputInvest.elementAt(0);
		updateInvList = (List) vectInputInvest.elementAt(1);
		deleteInvList = (List) vectInputInvest.elementAt(2);
	}

	int insSize = insertInvList.size(); 
	if (insSize > 0) {
		
		FnaInputinvestmentsDets inputInvest=new FnaInputinvestmentsDets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(inputInvest,"owninvstId");
		
		
		Iterator itIns = insertInvList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "INV", 17);
			strOwnInvstId = strMaxId;
			  
			inputInvest = (FnaInputinvestmentsDets) itIns.next();
			inputInvest.setOwninvstId(strOwnInvstId);
			inputInvest.setFnaSelfspouseDets(custDets);
		}
		
		objCOBDets =inputInvest;			
		dao.insertTableObject(insertInvList, objCOBDets);

	}

	int updSize = updateInvList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateInvList, objCOBDets);
	}

	
	int delSize = deleteInvList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteInvList, objCOBDets);
	}
	
}


public void saveRdOthPaymenttails(Vector vectRdOthpay, String strClientId) {
	// TODO Auto-generated method stub 
	
	String strRdOthpayId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRdOthpayDets = null;
	List insertRdOthpayList = new ArrayList(0);
	List updateRdOthpayList = new ArrayList(1);
	List deleteRdOthpayList = new ArrayList(2);
	
	int vectorSize = vectRdOthpay.size();

	if (vectorSize > 0) {
		insertRdOthpayList = (List) vectRdOthpay.elementAt(0);
		updateRdOthpayList = (List) vectRdOthpay.elementAt(1);
		deleteRdOthpayList = (List) vectRdOthpay.elementAt(2);
	}

	int insSize = insertRdOthpayList.size(); 
	if (insSize > 0) {
		
		FnaRetireplanOthpayment retothpay=new FnaRetireplanOthpayment();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(retothpay,"opId");
		
		
		Iterator itIns = insertRdOthpayList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RIN", 17);
			strRdOthpayId = strMaxId;
			  
			retothpay = (FnaRetireplanOthpayment) itIns.next();
			retothpay.setOpId(strRdOthpayId);
			retothpay.setFnaSelfspouseDets(custDets);
		}
		
		objRdOthpayDets =retothpay;			
		dao.insertTableObject(insertRdOthpayList, objRdOthpayDets);

	}

	int updSize = updateRdOthpayList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateRdOthpayList, objRdOthpayDets);
	}

	
	int delSize = deleteRdOthpayList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteRdOthpayList, objRdOthpayDets);
	}
	
}



public void saveRdIncPaymenttails(Vector vectRdIncpay, String strClientId) {
	// TODO Auto-generated method stub 
	
	String strRdIncpayId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRdIncpayDets = null;
	List insertRdIncpayList = new ArrayList(0);
	List updateRdIncpayList = new ArrayList(1);
	List deleteRdIncpayList = new ArrayList(2);
	
	int vectorSize = vectRdIncpay.size();

	if (vectorSize > 0) {
		insertRdIncpayList = (List) vectRdIncpay.elementAt(0);
		updateRdIncpayList = (List) vectRdIncpay.elementAt(1);
		deleteRdIncpayList = (List) vectRdIncpay.elementAt(2);
	}

	int insSize = insertRdIncpayList.size(); 
	if (insSize > 0) {
		
		FnaRetireplanIncomeasset retinc=new FnaRetireplanIncomeasset();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(retinc,"iaId");
		
		
		Iterator itIns = insertRdIncpayList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RAS", 17);
			strRdIncpayId = strMaxId;
			  
			retinc = (FnaRetireplanIncomeasset) itIns.next();
			retinc.setIaId(strRdIncpayId);
			retinc.setFnaSelfspouseDets(custDets);
		}
		
		objRdIncpayDets =retinc;			
		dao.insertTableObject(insertRdIncpayList, objRdIncpayDets);

	}

	int updSize = updateRdIncpayList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateRdIncpayList, objRdIncpayDets);
	}

	
	int delSize = deleteRdIncpayList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteRdIncpayList, objRdIncpayDets);
	}
	
}



//public void saveExpFDFlwdetails(Vector vectExpFdFlowDetails, String strClientId) {
//	// TODO Auto-generated method stub 
//	String ExpFDFlwId="";
//	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//	
//	Object objFundFlowDets = null;
//	List insertFdFwList = new ArrayList(0);
//	List updateFdFwList = new ArrayList(1);
//	List deleteFdFwList = new ArrayList(2);
//	
//	int vectorSize = vectExpFdFlowDetails.size();
//
//	if (vectorSize > 0) {
//		insertFdFwList = (List) vectExpFdFlowDetails.elementAt(0);
//		updateFdFwList = (List) vectExpFdFlowDetails.elementAt(1);
//		deleteFdFwList = (List) vectExpFdFlowDetails.elementAt(2);
//	}
//
//	int insSize = insertFdFwList.size(); 
//	if (insSize > 0) {
//		
//		FnaFlowDets fnaflowdetails=new FnaFlowDets();
//		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
//
//		
//		if(!FipaUtils.nullOrBlank(strClientId)){
//			custDets.setFnaId(strClientId);				
//		}
//		
//		String strMaxId = (String) dao.fetchMaxId(fnaflowdetails, "txtFldFlowId");
//		
//		
//		Iterator itIns = insertFdFwList.iterator();
//		while (itIns.hasNext()) {
//			 
//			
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "FLW", 17);
//			ExpFDFlwId = strMaxId;
//			
//			 
//			fnaflowdetails = (FnaFlowDets) itIns.next();
//			fnaflowdetails.setTxtFldFlowId(ExpFDFlwId);
//			fnaflowdetails.setFnaSelfspouseDets(custDets);
//	
//	     
//		}
//		objFundFlowDets = fnaflowdetails;			
//		dao.insertTableObject(insertFdFwList, objFundFlowDets);
//
//	}
//
//	int updSize = updateFdFwList.size(); 
//	if (updSize > 0) {
//		dao.updateTableObject(updateFdFwList, objFundFlowDets);
//	}
//
//	
//	int delSize = deleteFdFwList.size(); 
//	if (delSize > 0) {
//		dao.deleteTableObject(deleteFdFwList, objFundFlowDets);
//	}
//}

//public void saveContgPlndetails(Vector vectContPlnDetails, String strClientId) {
//	// TODO Auto-generated method stub 
//	String contgplanId="";
//	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//	
//	Object objCtgplnDets = null;
//	List insertCtgplnList = new ArrayList(0);
//	List updateCtgplnList = new ArrayList(1);
//	List deleteCtgplnList = new ArrayList(2);
//	
//	int vectorSize = vectContPlnDetails.size();
//
//	if (vectorSize > 0) {
//		insertCtgplnList = (List) vectContPlnDetails.elementAt(0);
//		updateCtgplnList = (List) vectContPlnDetails.elementAt(1);
//		deleteCtgplnList = (List) vectContPlnDetails.elementAt(2);
//	}
//
//	int insSize = insertCtgplnList.size(); 
//	if (insSize > 0) {
//		
//		FnaContinDepnDets CtgPlndetails=new FnaContinDepnDets();
//		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
//
//		
//		if(!FipaUtils.nullOrBlank(strClientId)){
//			custDets.setFnaId(strClientId);				
//		}
//		
//		String strMaxId = (String) dao.fetchMaxId(CtgPlndetails, "txFldContgDepId");
//		
//		
//		Iterator itIns = insertCtgplnList.iterator();
//		while (itIns.hasNext()) {
//			 
//			
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "CTG", 17);
//			contgplanId = strMaxId;
//			
//			 
//			CtgPlndetails = (FnaContinDepnDets) itIns.next();
//			CtgPlndetails.setTxFldContgDepId(contgplanId);
//			CtgPlndetails.setFnaSelfspouseDets(custDets);
//	
//	     
//		}
//		objCtgplnDets =CtgPlndetails;			
//		dao.insertTableObject(insertCtgplnList, objCtgplnDets);
//
//	}
//
//	int updSize = updateCtgplnList.size(); 
//	if (updSize > 0) { 
//		dao.updateTableObject(updateCtgplnList, objCtgplnDets);
//	}
//
//	
//	int delSize = deleteCtgplnList.size(); 
//	if (delSize > 0) {
//		dao.deleteTableObject(deleteCtgplnList, objCtgplnDets);
//	}
//}

public void saveHIdetails(Vector vectHlthInsDetails, String strClientId) {
	// TODO Auto-generated method stub 
	String HIdetsId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objHIDets = null;
	List insertHIList = new ArrayList(0);
	List updateHIList = new ArrayList(1);
	List deleteHIList = new ArrayList(2);
	
	int vectorSize = vectHlthInsDetails.size();

	if (vectorSize > 0) {
		insertHIList = (List) vectHlthInsDetails.elementAt(0);
		updateHIList = (List) vectHlthInsDetails.elementAt(1);
		deleteHIList = (List) vectHlthInsDetails.elementAt(2);
	}

	int insSize = insertHIList.size(); 
	if (insSize > 0) {
		
		FnaHealthinsInfo HIdetails=new FnaHealthinsInfo();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(HIdetails, "hiId");
		
		
		Iterator itIns = insertHIList.iterator();
		while (itIns.hasNext()) {
			  
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "HIS", 17);
			HIdetsId = strMaxId;
			 
			HIdetails = (FnaHealthinsInfo) itIns.next();
			HIdetails.setHiId(HIdetsId);
			HIdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objHIDets = HIdetails;			
		dao.insertTableObject(insertHIList, objHIDets);

	}

	int updSize = updateHIList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateHIList, objHIDets);
	}

	
	int delSize = deleteHIList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteHIList, objHIDets);
	}
}

public void savePropOwndetails(Vector vectPropOwnDetails, String strClientId) {
	// TODO Auto-generated method stub 
	String propownId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objPropDets = null;
	List insertPropList = new ArrayList(0);
	List updatePropList = new ArrayList(1);
	List deletePropList = new ArrayList(2);
	
	int vectorSize = vectPropOwnDetails.size();

	if (vectorSize > 0) {
		insertPropList = (List) vectPropOwnDetails.elementAt(0);
		updatePropList = (List) vectPropOwnDetails.elementAt(1);
		deletePropList = (List) vectPropOwnDetails.elementAt(2);
	}

	int insSize = insertPropList.size(); 
	if (insSize > 0) {
		
		FnaPropownDets propdetails=new FnaPropownDets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(propdetails, "propownId");
		
		
		Iterator itIns = insertPropList.iterator();
		while (itIns.hasNext()) {
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "PRO", 17);
			propownId = strMaxId;
			 
			propdetails = (FnaPropownDets) itIns.next();
			propdetails.setPropownId(propownId);
			propdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objPropDets = propdetails;			
		dao.insertTableObject(insertPropList, objPropDets);

	}

	int updSize = updatePropList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updatePropList, objPropDets);
	}

	
	int delSize = deletePropList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deletePropList, objPropDets);
	}
}

public void saveVehOwndetails(Vector vectVehOwnDetails, String strClientId) {
	// TODO Auto-generated method stub 
	String vehownId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objVehDets = null;
	List insertVehList = new ArrayList(0);
	List updateVehList = new ArrayList(1);
	List deleteVehList = new ArrayList(2);
	
	int vectorSize = vectVehOwnDetails.size();

	if (vectorSize > 0) {
		insertVehList = (List) vectVehOwnDetails.elementAt(0);
		updateVehList = (List) vectVehOwnDetails.elementAt(1);
		deleteVehList = (List) vectVehOwnDetails.elementAt(2);
	}

	int insSize = insertVehList.size(); 
	if (insSize > 0) {
		
		FnaVehicleownDets vehdetails=new FnaVehicleownDets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(vehdetails, "vehiId");
		
		
		Iterator itIns = insertVehList.iterator();
		while (itIns.hasNext()) {
			 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "VEH", 17);
			vehownId = strMaxId;
			 
			vehdetails = (FnaVehicleownDets) itIns.next();
			vehdetails.setVehiId(vehownId);
			vehdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objVehDets =vehdetails;			
		dao.insertTableObject(insertVehList, objVehDets);

	}

	int updSize = updateVehList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateVehList, objVehDets);
	}

	
	int delSize = deleteVehList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteVehList, objVehDets);
	}
}



//public void saveLipInsurncedetails(Vector vectLIPDetails, String strClientId) {
//	// TODO Auto-generated method stub
//	 String lipInsId="";
//	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
//	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
//	
//	Object objLipDets = null;
//	List insertLipList = new ArrayList(0);
//	List updateLipList = new ArrayList(1);
//	List deleteLipList = new ArrayList(2);
//	
//	int vectorSize = vectLIPDetails.size();
//
//	if (vectorSize > 0) {
//		insertLipList = (List) vectLIPDetails.elementAt(0);
//		updateLipList = (List) vectLIPDetails.elementAt(1);
//		deleteLipList = (List) vectLIPDetails.elementAt(2);
//	}
//
//	int insSize = insertLipList.size(); 
//	if (insSize > 0) {
//		
//		FnaLifeinsuranceDets lipdetails=new FnaLifeinsuranceDets();
//		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
//
//		
//		if(!FipaUtils.nullOrBlank(strClientId)){
//			custDets.setFnaId(strClientId);				
//		}
//		
//		String strMaxId = (String) dao.fetchMaxId(lipdetails, "lipId");
//		
//		
//		Iterator itIns = insertLipList.iterator();
//		while (itIns.hasNext()) {
//			 
//			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "LIP", 17);
//			lipInsId = strMaxId;
//			 
//			lipdetails = (FnaLifeins) itIns.next();
//			lipdetails.setTxtFldLipId(lipInsId);
//			lipdetails.setFnaSelfspouseDets(custDets);
//	
//	     
//		}
//		objLipDets =lipdetails;			
//		dao.insertTableObject(insertLipList, objLipDets);
//
//	}
//
//	int updSize = updateLipList.size(); 
//	if (updSize > 0) { 
//		dao.updateTableObject(updateLipList, objLipDets);
//	}
//
//	
//	int delSize = deleteLipList.size(); 
//	if (delSize > 0) {
//		dao.deleteTableObject(deleteLipList, objLipDets);
//	}
//}



public void saveIpInvstdetails(Vector vectIpInvstDetails, String strClientId) {
	// TODO Auto-generated method stub 
	String IpInvstId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objIpInvDets = null;
	List insertIpInvList = new ArrayList(0);
	List updateIpInvList = new ArrayList(1);
	List deleteIpInvList = new ArrayList(2);
	
	int vectorSize = vectIpInvstDetails.size(); 
	
	if (vectorSize > 0) { 
		insertIpInvList = (List) vectIpInvstDetails.elementAt(0);
		updateIpInvList = (List) vectIpInvstDetails.elementAt(1);
		deleteIpInvList = (List) vectIpInvstDetails.elementAt(2); 
	}

	int insSize = insertIpInvList.size(); 
	if (insSize > 0) {
		
		FnaInputinvestmentsDets ipinvdetails=new FnaInputinvestmentsDets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(ipinvdetails, "owninvstId");
		
		
		Iterator itIns = insertIpInvList.iterator();
		while (itIns.hasNext()) {
			 

			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "IIN", 17);
			IpInvstId = strMaxId;
			 
			ipinvdetails = (FnaInputinvestmentsDets) itIns.next();
			ipinvdetails.setOwninvstId(IpInvstId);
			ipinvdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objIpInvDets = ipinvdetails;			
		dao.insertTableObject(insertIpInvList, objIpInvDets);

	}

	int updSize = updateIpInvList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateIpInvList, objIpInvDets);
	}

	
	int delSize = deleteIpInvList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteIpInvList, objIpInvDets);
	}
	
}
public void saveOthPerDetails(Vector vectOthpers, String strClientId) {
	// TODO Auto-generated method stub 
	String othrperId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objOPDets = null;
	List insertOPList = new ArrayList(0); 
	
	int vectorSize = vectOthpers.size();

	if (vectorSize > 0) {
		insertOPList = (List) vectOthpers.elementAt(0); 
	}

	int insSize = insertOPList.size(); 
	if (insSize > 0) {
		
		FnaAdvDeclare OthPerdetails=new FnaAdvDeclare();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(OthPerdetails, "advDecId");
		
		
		Iterator itIns = insertOPList.iterator();
		while (itIns.hasNext()) { 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "OPD", 17);
			othrperId = strMaxId; 
			OthPerdetails = (FnaAdvDeclare) itIns.next();
			OthPerdetails.setAdvDecId(othrperId);
			OthPerdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objOPDets = OthPerdetails;			
		dao.insertTableObject(insertOPList, objOPDets);

	}
 
	
	
}


public void saveEstPlanDetails(Vector vectEstPln, String strClientId) {
	// TODO Auto-generated method stub 
	String estplanId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objEstPlnDets = null;
	List insertEstPlnList = new ArrayList(0); 
	
	int vectorSize = vectEstPln.size();

	if (vectorSize > 0) {
		insertEstPlnList = (List) vectEstPln.elementAt(0); 
	}

	int insSize = insertEstPlnList.size(); 
	if (insSize > 0) {
		
		FnaEstatePlan estPlndetails=new FnaEstatePlan();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(estPlndetails, "estId");
		
		
		Iterator itIns = insertEstPlnList.iterator();
		while (itIns.hasNext()) { 
			
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "EST", 17);
			estplanId = strMaxId; 
			estPlndetails = (FnaEstatePlan) itIns.next();
			estPlndetails.setEstId(estplanId);
			estPlndetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objEstPlnDets = estPlndetails;			
		dao.insertTableObject(insertEstPlnList, objEstPlnDets);

	}
 
	
	
}


public void updEstPlanDetails(Vector vectEstPlan, String strClientId) { 
	
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objEstplnDets = null;
	 
	List updateEstplnList = new ArrayList(0); 
	
	int vectorSize = vectEstPlan.size();

	if (vectorSize > 0) {
		 
		updateEstplnList = (List) vectEstPlan.elementAt(0); 
	}
	
	int updSize = updateEstplnList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateEstplnList, objEstplnDets);
	}


}

public void updOthPerDetails(Vector vectOthpers, String strClientId) { 
	
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRcmDets = null;
	 
	List updateRcmList = new ArrayList(0); 
	
	int vectorSize = vectOthpers.size();

	if (vectorSize > 0) {
		 
		updateRcmList = (List) vectOthpers.elementAt(0); 
	}
	
	int updSize = updateRcmList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateRcmList, objRcmDets);
	}


}

public void  delEstPlnDetails(Vector vectEstPlan, String strClientId) { 
	
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objEstPlnDets = null; 
	List deleteEstPlnList = new ArrayList(0);
	
	int vectorSize = vectEstPlan.size();

	if (vectorSize > 0) { 
		deleteEstPlnList = (List) vectEstPlan.elementAt(0); 
	}
	
	int delSize = deleteEstPlnList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteEstPlnList, objEstPlnDets);
	}

	
}
public void  delOthPerDetails(Vector vectOthpers, String strClientId) { 
	
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRcmDets = null; 
	List deleteRcmList = new ArrayList(0);
	
	int vectorSize = vectOthpers.size();

	if (vectorSize > 0) { 
		deleteRcmList = (List) vectOthpers.elementAt(0); 
	}
	
	int delSize = deleteRcmList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteRcmList, objRcmDets);
	}

	
}
public void saveRcmPrdDetails(Vector vectRcmPrdDetails, String strClientId) {
	// TODO Auto-generated method stub 
	String rcmprdid="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRcmDets = null;
	List insertRcmList = new ArrayList(0);
	List updateRcmList = new ArrayList(1);
	List deleteRcmList = new ArrayList(2);
	
	int vectorSize = vectRcmPrdDetails.size();

	if (vectorSize > 0) {
		insertRcmList = (List) vectRcmPrdDetails.elementAt(0);
		updateRcmList = (List) vectRcmPrdDetails.elementAt(1);
		deleteRcmList = (List) vectRcmPrdDetails.elementAt(2);
	}

	int insSize = insertRcmList.size(); 
	if (insSize > 0) {
		
		FnaRecomPrdtplanDet Rmdetails=new FnaRecomPrdtplanDet();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(Rmdetails, "recomPpId");
		
		
		Iterator itIns = insertRcmList.iterator();
		while (itIns.hasNext()) {
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RCM", 17);
			rcmprdid = strMaxId;
			
			 
			Rmdetails = (FnaRecomPrdtplanDet) itIns.next();
			Rmdetails.setRecomPpId(rcmprdid);
			Rmdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objRcmDets = Rmdetails;			
		dao.insertTableObject(insertRcmList, objRcmDets);

	}

	int updSize = updateRcmList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateRcmList, objRcmDets);
	}

	
	int delSize = deleteRcmList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteRcmList, objRcmDets);
	}
}


public void saveRcmPrdPlndetails(Vector vectRcmPrdPlnDetails, String strClientId) {
	// TODO Auto-generated method stub 
	
	String rcmprdplnId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRPpDets = null;
	List insertRPpList = new ArrayList(0);
	List updateRPpList = new ArrayList(1);
	List deleteRPpList = new ArrayList(2);
	
	int vectorSize = vectRcmPrdPlnDetails.size();

	if (vectorSize > 0) {
		insertRPpList = (List) vectRcmPrdPlnDetails.elementAt(0);
		updateRPpList = (List) vectRcmPrdPlnDetails.elementAt(1);
		deleteRPpList = (List) vectRcmPrdPlnDetails.elementAt(2);
	}

	int insSize = insertRPpList.size(); 
	if (insSize > 0) {
		
		FnaRecomPrdtplanDet RmPpdetails=new FnaRecomPrdtplanDet();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(RmPpdetails, "recomPpId");
		
		
		Iterator itIns = insertRPpList.iterator();
		while (itIns.hasNext()) {
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RCM", 17);
			rcmprdplnId = strMaxId;
			 
			RmPpdetails = (FnaRecomPrdtplanDet) itIns.next();
			RmPpdetails.setRecomPpId(rcmprdplnId);
			RmPpdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objRPpDets =RmPpdetails;			
		dao.insertTableObject(insertRPpList, objRPpDets);

	}

	int updSize = updateRPpList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateRPpList, objRPpDets);
	}

	
	int delSize = deleteRPpList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteRPpList, objRPpDets);
	}
}

public void saveRcmPrdFunddetails(Vector vectRcmPrdFundDetails, String strClientId) {
	// TODO Auto-generated method stub 
	String rcmprdfdId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objRPfDets = null;
	List insertRPfList = new ArrayList(0);
	List updateRPfList = new ArrayList(1);
	List deleteRPfList = new ArrayList(2);
	
	int vectorSize = vectRcmPrdFundDetails.size();

	if (vectorSize > 0) {
		insertRPfList = (List) vectRcmPrdFundDetails.elementAt(0);
		updateRPfList = (List) vectRcmPrdFundDetails.elementAt(1);
		deleteRPfList = (List) vectRcmPrdFundDetails.elementAt(2);
	}

	int insSize = insertRPfList.size(); 
	if (insSize > 0) {
		
		FnaRecomFundDet RPfdetails=new FnaRecomFundDet();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(RPfdetails, "recomFfId");
		
		
		Iterator itIns = insertRPfList.iterator();
		while (itIns.hasNext()) {
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "RPF", 17);
			rcmprdfdId = strMaxId;
			 
			RPfdetails = (FnaRecomFundDet) itIns.next();
			RPfdetails.setRecomFfId(rcmprdfdId);
			RPfdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objRPfDets = RPfdetails;			
		dao.insertTableObject(insertRPfList, objRPfDets);

	}

	int updSize = updateRPfList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateRPfList, objRPfDets);
	}

	
	int delSize = deleteRPfList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteRPfList, objRPfDets);
	}
	
	
}


public void saveSwtPlndetails(Vector vectSwtPlnDetails, String strClientId) {
	// TODO Auto-generated method stub 
	String SwtPlnId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objSPpDets = null;
	List insertSPpList = new ArrayList(0);
	List updateSPpList = new ArrayList(1);
	List deleteSPpList = new ArrayList(2);
	
	int vectorSize = vectSwtPlnDetails.size();

	if (vectorSize > 0) {
		insertSPpList = (List) vectSwtPlnDetails.elementAt(0);
		updateSPpList = (List) vectSwtPlnDetails.elementAt(1);
		deleteSPpList = (List) vectSwtPlnDetails.elementAt(2);
	}

	int insSize = insertSPpList.size(); 
	if (insSize > 0) {
		
		FnaSwtchrepPlanDet SPpdetails=new FnaSwtchrepPlanDet();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(SPpdetails, "swrepPpId");
		
		
		Iterator itIns = insertSPpList.iterator();
		while (itIns.hasNext()) {
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "SPP", 17);
			SwtPlnId = strMaxId;
			 
			SPpdetails = (FnaSwtchrepPlanDet) itIns.next();
			SPpdetails.setSwrepPpId(SwtPlnId);
			SPpdetails.setFnaSelfspouseDets(custDets);
	
	     
		}
		objSPpDets =SPpdetails;			
		dao.insertTableObject(insertSPpList, objSPpDets);

	}

	int updSize = updateSPpList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateSPpList, objSPpDets);
	}

	
	int delSize = deleteSPpList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteSPpList, objSPpDets);
	}
}


public void saveSwtFunddetails(Vector vectSwtFundDetails, String strClientId) {
	// TODO Auto-generated method stub 
	
	String swtfdId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objSPfDets = null;
	List insertSPfList = new ArrayList(0);
	List updateSPfList = new ArrayList(1);
	List deleteSPfList = new ArrayList(2);
	
	int vectorSize = vectSwtFundDetails.size();

	if (vectorSize > 0) {
		insertSPfList = (List) vectSwtFundDetails.elementAt(0);
		updateSPfList = (List) vectSwtFundDetails.elementAt(1);
		deleteSPfList = (List) vectSwtFundDetails.elementAt(2);
	}

	int insSize = insertSPfList.size(); 
	if (insSize > 0) {
		
		FnaSwtchrepFundDet SPfdetails=new FnaSwtchrepFundDet();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();

		
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(SPfdetails, "swrepFfId");
		
		
		Iterator itIns = insertSPfList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "SPF", 17);
			swtfdId = strMaxId;
			  
			SPfdetails = (FnaSwtchrepFundDet) itIns.next();
			SPfdetails.setSwrepFfId(swtfdId);
			SPfdetails.setFnaSelfspouseDets(custDets); 
		}
		
		objSPfDets =SPfdetails;			
		dao.insertTableObject(insertSPfList, objSPfDets);

	}

	int updSize = updateSPfList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateSPfList, objSPfDets);
	}

	
	int delSize = deleteSPfList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteSPfList, objSPfDets);
	}
}





public void saveCashAtBankdetails(Vector vectCashOfBankDetails, String strClientId) {
	// TODO Auto-generated method stub 
	
	String cashAtBankId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objCOBDets = null;
	List insertCOBList = new ArrayList(0);
	List updateCOBList = new ArrayList(1);
	List deleteCOBList = new ArrayList(2);
	
	int vectorSize = vectCashOfBankDetails.size();

	if (vectorSize > 0) {
		insertCOBList = (List) vectCashOfBankDetails.elementAt(0);
		updateCOBList = (List) vectCashOfBankDetails.elementAt(1);
		deleteCOBList = (List) vectCashOfBankDetails.elementAt(2);
	}

	int insSize = insertCOBList.size(); 
	if (insSize > 0) {
		
		FnaCashAtBank COBdetails=new FnaCashAtBank();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(COBdetails, "cashBankId");
		
		
		Iterator itIns = insertCOBList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "COB", 17);
			cashAtBankId = strMaxId;
			  
			COBdetails = (FnaCashAtBank) itIns.next();
			COBdetails.setCashBankId(cashAtBankId);
			COBdetails.setFnaSelfspouseDets(custDets);
		}
		
		objCOBDets =COBdetails;			
		dao.insertTableObject(insertCOBList, objCOBDets);

	}

	int updSize = updateCOBList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateCOBList, objCOBDets);
	}

	
	int delSize = deleteCOBList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteCOBList, objCOBDets);
	}
	
	
}


public void  saveLifeInsuranceDets(Vector vectLifeInscDetails, String strClientId) {
	// TODO Auto-generated method stub 
	
	String LisId="";
	ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
	DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");			
	
	Object objLisDets = null;
	List insertLisList = new ArrayList(0);
	List updateLisList = new ArrayList(1);
	List deleteLisList = new ArrayList(2);
	
	int vectorSize = vectLifeInscDetails.size();

	if (vectorSize > 0) {
		insertLisList = (List) vectLifeInscDetails.elementAt(0);
		updateLisList = (List) vectLifeInscDetails.elementAt(1);
		deleteLisList = (List) vectLifeInscDetails.elementAt(2);
	}

	int insSize = insertLisList.size(); 
	if (insSize > 0) {
		
		FnaLifeinsuranceDets Lisdetails=new FnaLifeinsuranceDets();
		FnaSelfspouseDets custDets = new FnaSelfspouseDets();
		
 
		if(!FipaUtils.nullOrBlank(strClientId)){
			custDets.setFnaId(strClientId);				
		}
		
		String strMaxId = (String) dao.fetchMaxId(Lisdetails, "lipId");
		
		
		Iterator itIns = insertLisList.iterator();
		while (itIns.hasNext()) { 
			 
			strMaxId=FipaUtils.getFormattedMaxPK(strMaxId, "LIS", 17);
			LisId = strMaxId;
			  
			Lisdetails = (FnaLifeinsuranceDets) itIns.next();
			Lisdetails.setLipId(LisId);
			Lisdetails.setFnaSelfspouseDets(custDets);
		}
		
		objLisDets =Lisdetails;			
		dao.insertTableObject(insertLisList, objLisDets);

	}

	int updSize = updateLisList.size(); 
	if (updSize > 0) { 
		dao.updateTableObject(updateLisList, objLisDets);
	}

	
	int delSize = deleteLisList.size(); 
	if (delSize > 0) {
		dao.deleteTableObject(deleteLisList, objLisDets);
	}
	
	
}

 


public List openClientProfileList(DBInterfaceImpl dao, String  params) {

	List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = " SELECT  ss.FNA_ID,ss.DF_CREATED_BY,ss.DF_CREATED_DATETIME,"
				+ "ad.APP_ANALYSIS_FOR,ad.APP_PURPOSE,ad.APP_CLIENT_CHOICE,ad.APP_REPLACE_PRDT," 
				+ "rtrim(xmlagg (xmlelement (ana, ana.ANALYSIS || ',')).extract ('//text()'), ',') ANALYSIS ,"
				+ "ss.FPMS_CUSTID,ss.DF_SELF_NAME,ss.DF_SELF_NRIC,ss.FNA_TYPE,DECODE(FPMS_CUSTID,null,'N','Y')FPMS_EXISTS"
				+ " FROM FNA_SELFSPOUSE_DETS ss ,FNA_ADV_DECLARE ad ,FNA_APPTYPES app ,MASTER_ANALYSIS_TYPES ana"
				+ " where ss.FNA_ID = ad.FNA_ID(+) and ss.FNA_ID = app.FNA_ID(+) and ana.ANA_PKID(+) = app.ANALYSIS_ID ";
		
		String grpbyclause = " group by ss.FNA_ID,ss.DF_SELF_NAME,ss.DF_SELF_NRIC,ss.DF_CREATED_BY,ss.DF_CREATED_DATETIME,"
				+"ad.APP_ANALYSIS_FOR,ad.APP_PURPOSE,ad.APP_CLIENT_CHOICE,ad.APP_REPLACE_PRDT," 
				+ "ss.FPMS_CUSTID,ss.FNA_TYPE order by ss.DF_CREATED_DATETIME desc";
		 
//		System.out.println("--->>"+HQL_CLIENT_TAB_DETAILS + params + grpbyclause);
		
		clientTabDetsList = dao.searchByNativeSQLQuery(HQL_CLIENT_TAB_DETAILS + params + grpbyclause );
		


	return clientTabDetsList;

}

	public List openClientProfile(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaSelfspouseDets cust " 
					;
			
			StringBuffer whereclause = new StringBuffer(" where ");
			
			if(params.length == 2){
				
				whereclause.append("cust.dfSelfName = ?");
				whereclause.append(" and cust.dfSelfNric = ?");
				
			}else{
				whereclause.append("cust.fnaId=?");
			}
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS + whereclause, params);
			
 

		return clientTabDetsList;

	}
	
	public List openAppTypes(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaApptypes apptypes "
					+ " join fetch apptypes.masterAnalysisTypes analysis"
					+ "  left join fetch apptypes.fnaSelfspouseDets cust  " 
					;
			
			StringBuffer whereclause = new StringBuffer(" where ");
			
			if(params.length == 2){
				
				whereclause.append("cust.dfSelfName = ?");
				whereclause.append(" and cust.dfSelfNric = ?");
				
			}else{
				whereclause.append("cust.fnaId=?");
			}
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS + whereclause, params);
 

		return clientTabDetsList;

	}
	
	public List  openClntProfAnalyTypes(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaApptypes advDcl "
					+ "  left join fetch advDcl.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}
	
	public List openCdAdhoc(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaAdvDeclare cda "
					+ "  left join fetch cda.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}
	
	public List openAdvDeclare(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaAdvDeclare advDcl "
					+ "  left join fetch advDcl.fnaSelfspouseDets cust  " ;
			
			StringBuffer whereclause = new StringBuffer(" where ");
			
			if(params.length == 2){
				
				whereclause.append("cust.dfSelfName = ?");
				whereclause.append(" and cust.dfSelfNric = ?");
				
			}else{
				whereclause.append("cust.fnaId=?");
			}
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS + whereclause, params);
 

		return clientTabDetsList;

	}

	public List openExpenditure(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaExpenditureDets exp "
					+ "  left join fetch exp.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}
	public List openContg(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaContingencyDets con "
					+ "  left join fetch con.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 
		return clientTabDetsList;
	}
	
//	public List openContingency(DBInterfaceImpl dao, String ... params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
// 
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaContingencyDets con "
//					+ "  left join fetch con.selFnaSelfSpouseDets cust  "
//					+ "  where cust.fnaId =?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//		return clientTabDetsList;
//	}

	public List openPerprio(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaPersprio pp "
					+ "  left join fetch pp.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}

	public List openSrcOfInc(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaSrcofincome soi "
					+ "  left join fetch soi.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}

//	public List openCpf(DBInterfaceImpl dao, String ... params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
// 
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaCpfDets cpf "
//					+ "  left join fetch cpf.selFnaSelfSpouseDets cust  "
//					+ "  where cust.fnaId =?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//
//		return clientTabDetsList;
//	}

	public List openFinLblty(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaFinLiability flb "
					+ "  left join fetch flb.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}

	public List openCurAss(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaCurassDets cus "
					+ "  left join fetch cus.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}

	public List openRetirepln(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaRetireplanDets rtp "
					+ "  left join fetch rtp.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}

	public List openInvst(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaInvsetmentSummary inv "
					+ "  left join fetch inv.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}

	public List openCshAss(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaAssetCashdets cashasts "
					+ "  left join fetch cashasts.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}

	public List openOthAss(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
		
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaAssetOtherdets oth "
					+ "  left join fetch oth.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);

		return clientTabDetsList;
	}

	
	
	public List openRskPref(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaRiskprefDets rsk "
					+ "  left join fetch rsk.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}
	
	public List openSumAnl(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaSummaryAnalysis sa "
					+ "  left join fetch sa.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}
	

	
	
	public List openLifeInsuranceProfile(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
	 
		List clientTabDetsList = new ArrayList();  
		 	String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaLifeinsuranceDets lis "
				+ "  left join fetch lis.fnaSelfspouseDets cust "
				+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}
//	public List openOthPer(DBInterfaceImpl dao, String ... params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
// 
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaOtherpersonDets op "
//					+ "  left join fetch op.selFnaSelfSpouseDets cust  "
//					+ "  where cust.fnaId =?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//
//		return clientTabDetsList;
//	}
	
	
	public List openEstPlan(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaEstatePlan estpln "
					+ "  left join fetch estpln.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}
	
	
	
	public List openLifeInsCoveProfile(DBInterfaceImpl dao, String ... params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaLifeinsuranceCoverages lifecov "
					+ "  left join fetch lifecov.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId =?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;
	}
	
	public List openClntProfChild(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaChilddetails child "
					+ "  left join fetch child.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}
	
	public List openClntProfFinGoals(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaFingoalsconcern fin "
					+ "  left join fetch fin.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
  

		return clientTabDetsList;

	}
	
	public List openClntProfDepnt(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaDependantDets depnt "
					+ "  left join fetch depnt.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 
		return clientTabDetsList;

	}

	public List openClntProfSAInvt(DBInterfaceImpl dao, String ... params) {

		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaSavingsinvDets SAInv "
					+ "  left join fetch SAInv.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 
		return clientTabDetsList;

	}
//	public List openClntProfFDFlw(DBInterfaceImpl dao, String[] params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
// 
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaFlowDets flw "
//					+ "  left join fetch flw.selFnaSelfSpouseDets cust  "
//					+ "  where cust.fnaId=?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//
//		return clientTabDetsList;
//
//	}

//	public List openClntProfCtgDep(DBInterfaceImpl dao, String[] params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
// 
//			
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaContinDepnDets ctgdepn "
//					+ "  left join fetch ctgdepn.selFnaSelfSpouseDets cust  "
//					+ "  where cust.fnaId=?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//
//		return clientTabDetsList;
//
//	}
	
	
	public List openClntProfAssets(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaAssetBusiandpersdets bsper "
					+ "  left join fetch bsper.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 
		return clientTabDetsList;

	}
	
	public List openClntProfRdIncomeAss(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaRetireplanIncomeasset rdretpln "
					+ "  left join fetch rdretpln.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 
		return clientTabDetsList;

	}
	
	public List openClntProfArOfConcern(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaOthareaconcern othcrn "
					+ "  left join fetch othcrn.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}
	
	

//	public List openClntProfFinGlsPrio(DBInterfaceImpl dao, String[] params) {
//		// TODO Auto-generated method stub 
//		
//		
//		List clientTabDetsList = new ArrayList();  
// 
//			
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaFingoalpriority rcmrsn "
//					+ "  left join fetch rcmrsn.selFnaFinGoalPriSelfspouseDets cust  "
//					+ "  where cust.fnaId=?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//
//		return clientTabDetsList;
//
//	}
	 
	public List openClntProfRecmReasn(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaRecomReasons rcmrsn "
					+ "  left join fetch rcmrsn.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
					; 
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}
	public List openClntProfCpfMCtb(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaCpfMonthcontDets cpfmthctb "
					+ "  left join fetch cpfmthctb.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 
		return clientTabDetsList;

	}
	
	public List openClntProfCPFBalance(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaCpfBalanceDets cpfbal "
					+ "  left join fetch cpfbal.fnaSelfspouseDets cust "
					+ " left join fetch cpfbal.masterCpfAcctype "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}
	
//	public List openClntProfCpfTp(DBInterfaceImpl dao, String[] params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
// 
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaCpfTopupDets cpftp "
//					+ "  left join fetch cpftp.fnaSelfspouseDets cust "
//					+ " left join fetch cpftp.selmasterCpfAcctype acctype "
//					+ "  where cust.fnaId=?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//
//		return clientTabDetsList;
//
//	}
	
	 
	
//	public List openClntProfCpfDt(DBInterfaceImpl dao, String[] params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
// 
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaCpfDeductions cpfdedt "
//					+ "  left join fetch cpfdedt.fnaSelfspouseDets cust "
//					+ " left join fetch cpfdedt.selmasterCpfAcctype cpfacc"
//					+ "  where cust.fnaId=?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//
//		return clientTabDetsList;
//
//	}

	public List openClntProfCAD(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaCpfDeductions cpfadddect "
					+ "  left join fetch cpfadddect.fnaSelfspouseDets cust "
					+ " left join fetch cpfadddect.masterCpfAcctype cpfacc"
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 
 
		return clientTabDetsList;

	}
	
	public List openClntProfHI(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaHealthinsInfo hi "
					+ "  left join fetch hi.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 
		return clientTabDetsList;

	}

	public List openClntProfPrpOwn(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaPropownDets prop "
					+ "  left join fetch prop.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}

	public List openClntProfVehOwn(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaVehicleownDets veh "
					+ "  left join fetch veh.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}
	
	public List openClntAttachments(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
 
			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaAttachments att " 
					+ "  where att.fnaId=?  ORDER BY att.docid asc"; 
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
 

		return clientTabDetsList;

	}
	
//	public List openClntProfLIP(DBInterfaceImpl dao, String[] params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
// 
//			String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaLifeinsplansDets lip "
//					+ "  left join fetch lip.selFnaSelfSpouseDets cust  "
//					+ "  where cust.fnaId=?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
// 
//
//		return clientTabDetsList;
//
//	}
	
	

	public List openClntProfRcmPrd(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		///??????????111
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaRecomPrdtplanDet rcm "
					+ "  left join fetch rcm.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	 
	public List openClntProfRPln(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		////???????????2222222
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaRecomPrdtplanDet rpp "
					+ "  left join fetch rpp.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	public List openClntProfRFd(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaRecomFundDet rpf "
					+ "  left join fetch rpf.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	public List openClntProfSPln(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaSwtchrepPlanDet spp "
					+ "  left join fetch spp.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	
	public List openClntProfSFd(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaSwtchrepFundDet spf "
					+ "  left join fetch spf.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	
	
	public List openClntProfCashAtBank(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaCashAtBank cob "
					+ "  left join fetch cob.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	
	public List openRdOtherIncome(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaRetireplanOthpayment oth "
					+ "  left join fetch oth.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	public List openClntProfIPINV(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		/////???????111111111
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaInputinvestmentsDets ipinv "
					+ "  left join fetch ipinv.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	public List openInputInvestment(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		/////????????????????222222222
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaInputinvestmentsDets fid"
					+ "  left join fetch fid.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
//	public List openClntProfLISDets(DBInterfaceImpl dao, String[] params) {
//		// TODO Auto-generated method stub
//		List clientTabDetsList = new ArrayList();
//		
//		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaLifeinsuranceDets lis "
//					+ "  left join fetch lis.selFnaSelfspouseDets cust  "
//					+ "  where cust.fnaId=?";
//			
//			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
//			return clientTabDetsList;
//
//	}
	
	public List openClntProfLIRetPlgDets(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaLifeinsuranceMvRet lismv "
					+ "  left join fetch lismv.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	public List openClntProfLIBenefitsDets(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaLifeinsuranceDisablebenfs lisbf "
					+ "  left join fetch lisbf.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	
	
	public List openClntProfLINomNamesDets(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaLifeinsuranceNominees lisnomname "
					+ "  left join fetch lisnomname.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	public List openClntProfLIEduPlgDets(DBInterfaceImpl dao, String[] params) {
		// TODO Auto-generated method stub
		List clientTabDetsList = new ArrayList();
		
		String HQL_CLIENT_TAB_DETAILS = "from com.fipa.dto.FnaLifeinsuranceChildedc lischlded "
					+ "  left join fetch lischlded.fnaSelfspouseDets cust  "
					+ "  where cust.fnaId=?";
			
			clientTabDetsList = dao.selectQueryByFind(HQL_CLIENT_TAB_DETAILS, params);
			return clientTabDetsList;

	}
	



	public void deleteAgrDetails() {
		// TODO Auto-generated method stub 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterface dao = (DBInterface)appCtx.getBean("dbImplBean");
 
	}



	public void delAppTypesDets(String strClientId) {
		// TODO Auto-generated method stub
 
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

			String SQL_ADVSTF_QUERY = "DELETE FROM FNA_APPTYPES WHERE FNA_ID='"+strClientId+"'";
			 
			dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
		 
			
	}
	
	public void delCpfMtlyCtbDetails(HttpServletRequest request,String strClientId) {
		// TODO Auto-generated method stub
 
		
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

			String SQL_ADVSTF_QUERY = "DELETE FROM FNA_CPF_MONTHCONT_DETS WHERE FNA_ID='"+strClientId+"'";
			 
			 	dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
		 
	}
	
	public void delCpfBalcCtbDetails(HttpServletRequest request,String strClientId) {
		// TODO Auto-generated method stub
 
		
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

			String SQL_ADVSTF_QUERY = "DELETE FROM FNA_CPF_BALANCE_DETS WHERE FNA_ID='"+strClientId+"'";
			 
			
				 	dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
			
			 
			 
		 
	}



	public void deletePlnProdetails(String strLICId) {
		// TODO Auto-generated method stub 
		
		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

		String SQL_ADVSTF_QUERY = "DELETE FROM FNA_LIFEINSURANCE_BASICRIDERS WHERE LIP_ID='"+strLICId+"'";
		 
	 
		dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
		
	}



	public void deleteNomineeNamedetails(String strLICId) {
		// TODO Auto-generated method stub

		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

		String SQL_ADVSTF_QUERY = "DELETE FROM FNA_LIFEINSURANCE_NOMINEES WHERE LIP_ID='"+strLICId+"'";
	 
		dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
	}



	public void deleteBenefdetails(String strLICId) {
		// TODO Auto-generated method stub

		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

		String SQL_ADVSTF_QUERY = "DELETE FROM FNA_LIFEINSURANCE_DISABLEBENFS WHERE LIP_ID='"+strLICId+"'";
		 
		dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
	}



	public void deleteRetPlgdetails(String strLICId) {
		// TODO Auto-generated method stub

		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

		String SQL_ADVSTF_QUERY = "DELETE FROM FNA_LIFEINSURANCE_MV_RET WHERE LIP_ID='"+strLICId+"'";
		 
		dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
	}



	public void deleteEduPlgdetails(String strLICId) {
		// TODO Auto-generated method stub

		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

		String SQL_ADVSTF_QUERY = "DELETE FROM FNA_LIFEINSURANCE_CHILDEDC WHERE LIP_ID='"+strLICId+"'";
		 
		dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
	}


 


	public void deleteLifeInsurceDetails(String strClientId, String strLICId) {
		// TODO Auto-generated method stub

		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

		String SQL_ADVSTF_QUERY = "DELETE FROM FNA_LIFEINSURANCE_DETS WHERE LIP_ID='"+strLICId+"' AND FNA_ID='"+strClientId+"'";
		 
		dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
	}



	public void deleteCoveragesdetails(String strLICId) {
		// TODO Auto-generated method stub
		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterface dao = (DBInterface) appCtx.getBean("dbImplBean");

		String SQL_ADVSTF_QUERY = "DELETE FROM FNA_LIFEINSURANCE_COVERAGES WHERE LIP_ID='"+strLICId+"'";
	 
		dao.executeNativeSQLQuery(SQL_ADVSTF_QUERY);
	}

	

	
	
}



