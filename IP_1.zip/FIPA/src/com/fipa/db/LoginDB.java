package com.fipa.db;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;

import com.fipa.dbinterface.DBInterfaceImpl;
//import com.fipa.dto.FipaUser;
import com.fipa.util.ApplicationContextUtils;
import com.fipa.util.FipaConstant;
import com.fipa.util.FipaUtils;

public class LoginDB {

	 
	
	public Date getSysDate(DBInterfaceImpl dao) {

		if(FipaUtils.checkNullVal(dao)) {
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			dao = (DBInterfaceImpl) appCtx.getBean(FipaConstant.FP_DBIMP_BEAN);
		}
		
		String SQL_SYSDATE = "SELECT SYSDATE FROM DUAL";

		Date sysdate = null;
		List datelist;
		datelist = dao.searchByNativeSQLQuery(SQL_SYSDATE);
		if (datelist.size() > 0)
			sysdate = (Date) datelist.get(0);
		return sysdate;
	}
 
	public List validateLogin(String ... userparams) {
//		CRYPTIT.DECRYPT(
		List userList = new ArrayList(); 
		String SQL_FPMS_VALIDATE_USER = "SELECT FPU.USER_ID,FPU.USERNAME,FPU.STAFF_ID,"
				+ "ADV.ADVSTF_NAME,ADV.ADVSTF_INITIALS,ADV.STAFF_TYPE,ADV.DESIGNATION,"
				+ "ADV.MANAGER_ID,MGR.ADVSTF_NAME MANAGERNAME,SYSDATE CURRDATE,DESG.MGR_FLG,FPU.PASSWORD"
				+ " FROM "
				+ FipaConstant.FPMSNL_SCHEMA+".FPUSER FPU,"
				+ FipaConstant.FPMSNL_SCHEMA+".ADVISER_STAFF ADV,"
				+ FipaConstant.FPMSNL_SCHEMA+".ADVISER_STAFF MGR,"
				+ FipaConstant.FPMSNL_SCHEMA+".MASTER_DESIGNATION DESG"
				+ " where FPU.STAFF_ID = ADV.ADVSTF_ID "
				+ " AND ADV.MANAGER_ID = MGR.ADVSTF_ID "
				+ " AND ADV.DESIG_ID = DESG.DESIG_ID "
				+ " and FPU.USER_ID = '"+userparams[0]+"'"
				+ " and  FPU.PASSWORD ='"+userparams[1]+"'";
//				+ " and  FPU.PASSWORD ='"+userparams[1]+"'";

		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterfaceImpl dao = (DBInterfaceImpl) appCtx.getBean(FipaConstant.FP_DBIMP_BEAN);	
 
		
		userList = dao.searchByNativeSQLQuery(SQL_FPMS_VALIDATE_USER);

		return userList;

	}
	
	
	public List validateAPSLogin(String ... userparams) {
//		CRYPTIT.DECRYPT(
		List userList = new ArrayList(); 
		String SQL_FPMS_VALIDATE_USER = "SELECT FPU.USER_ID,FPU.USERNAME,FPU.STAFF_ID,"
				+ "ADV.ADVSTF_NAME,ADV.ADVSTF_INITIALS,ADV.STAFF_TYPE,ADV.DESIGNATION,"
				+ "ADV.MANAGER_ID,MGR.ADVSTF_NAME MANAGERNAME,SYSDATE CURRDATE,DESG.MGR_FLG,FPU.PASSWORD"
				+ " FROM "
				+ FipaConstant.FPMSNL_SCHEMA+".FPUSER FPU,"
				+ FipaConstant.FPMSNL_SCHEMA+".ADVISER_STAFF ADV,"
				+ FipaConstant.FPMSNL_SCHEMA+".ADVISER_STAFF MGR,"
				+ FipaConstant.FPMSNL_SCHEMA+".MASTER_DESIGNATION DESG"
				+ " where FPU.STAFF_ID = ADV.ADVSTF_ID "
				+ " AND ADV.MANAGER_ID = MGR.ADVSTF_ID "
				+ " AND ADV.DESIG_ID = DESG.DESIG_ID "
				+ " and ADV.ADVSTF_ID = '"+userparams[0]+"'"; 

		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		DBInterfaceImpl dao = (DBInterfaceImpl) appCtx.getBean(FipaConstant.FP_DBIMP_BEAN);	
 
		
		userList = dao.searchByNativeSQLQuery(SQL_FPMS_VALIDATE_USER);

		return userList;

	}

}
