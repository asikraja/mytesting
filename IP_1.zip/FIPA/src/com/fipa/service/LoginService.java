package com.fipa.service;


import java.util.Date;
import java.util.List;









import com.fipa.db.LoginDB;
import com.fipa.dbinterface.DBInterfaceImpl; 



public class LoginService {
	
	public Date getSysDate(DBInterfaceImpl dao){
		LoginDB logDB = new LoginDB();
		return logDB.getSysDate(dao);
	}
	
//	 public List validateLogin(FipaUser userparams){	 	
	 public List validateLogin(String ... userparams){
		LoginDB db = new LoginDB();
		return db.validateLogin(userparams);		
	}
	 
	 
	 public List validateAPSLogin(String ... userparams){
			LoginDB db = new LoginDB();
			return db.validateAPSLogin(userparams);		
		}
		 
}
