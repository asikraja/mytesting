package com.fipa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.fipa.db.ClientDB;
import com.fipa.dbinterface.DBInterface;
import com.fipa.dbinterface.DBInterfaceImpl; 
import com.fipa.dto.FnaAdvDeclare;
import com.fipa.dto.FnaApptypes;
import com.fipa.dto.FnaAssetBusiandpersdets;
import com.fipa.dto.FnaAssetCashdets;
import com.fipa.dto.FnaAssetOtherdets; 
import com.fipa.dto.FnaAttachments;
import com.fipa.dto.FnaCashAtBank; 
import com.fipa.dto.FnaChilddetails; 
import com.fipa.dto.FnaContingencyDets;
import com.fipa.dto.FnaCpfBalanceDets;
import com.fipa.dto.FnaCpfDeductions; 
import com.fipa.dto.FnaCpfMonthcontDets; 
import com.fipa.dto.FnaCurassDets;
import com.fipa.dto.FnaDependantDets;
import com.fipa.dto.FnaEstatePlan;
import com.fipa.dto.FnaExpenditureDets;
import com.fipa.dto.FnaFinLiability; 
import com.fipa.dto.FnaFingoalsconcern; 
import com.fipa.dto.FnaHealthinsInfo;
import com.fipa.dto.FnaInputinvestmentsDets; 
import com.fipa.dto.FnaInvsetmentSummary; 
import com.fipa.dto.FnaLifeinsuranceBasicriders;
import com.fipa.dto.FnaLifeinsuranceChildedc;
import com.fipa.dto.FnaLifeinsuranceCoverages;
import com.fipa.dto.FnaLifeinsuranceDets;
import com.fipa.dto.FnaLifeinsuranceDisablebenfs;
import com.fipa.dto.FnaLifeinsuranceMvRet;
import com.fipa.dto.FnaLifeinsuranceNominees;
import com.fipa.dto.FnaOthareaconcern; 
import com.fipa.dto.FnaPersprio;
import com.fipa.dto.FnaPropownDets;
import com.fipa.dto.FnaRecomFundDet;
import com.fipa.dto.FnaRecomPrdtplanDet;
import com.fipa.dto.FnaRecomReasons;
import com.fipa.dto.FnaRetireplanDets;
import com.fipa.dto.FnaRetireplanIncomeasset;
import com.fipa.dto.FnaRetireplanOthpayment;
import com.fipa.dto.FnaRiskprefDets;
import com.fipa.dto.FnaSavingsinvDets;
import com.fipa.dto.FnaSelfspouseDets;
import com.fipa.dto.FnaSrcofincome;
import com.fipa.dto.FnaSummaryAnalysis; 
import com.fipa.dto.FnaSwtchrepFundDet;
import com.fipa.dto.FnaSwtchrepPlanDet;
import com.fipa.dto.FnaVehicleownDets;
import com.fipa.dto.MasterCpfAcctype;
import com.fipa.dto.MasterPropertykv;
import com.fipa.util.FipaConstant;
import com.fipa.util.FipaDateUtils;
//import com.fipa.dto.FipaAgreements;
//import com.fipa.dto.FipaCustomerDets;
//import com.fipa.dto.FipaDependantDets;
//import com.fipa.dto.FipaSpouseDets;
import com.fipa.util.FipaUtils;
import com.fipa.util.ApplicationContextUtils;
import com.fipa.service.ClientService;  
import com.fipa.service.FPMSDataService;
import com.fipa.service.MasterCpfService;
import com.fipa.service.MasterService;

/**
 * Servlet implementation class ClientServlet
 */

public class FipaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final Logger logger = LoggerFactory.getLogger(FipaServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FipaServlet() {
        super();
        
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	 
		
		
		String strDBCallFor = FipaUtils.getParamValue(request, "DBCALLFOR"); 
		JSONArray retval = new JSONArray();
		PrintWriter out = response.getWriter();
		
		
		if(!FipaUtils.isSessionExpired(request)){
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("SESSION_EXPIRY", "SESSION_EXPIRY");
			retval.add(jsonObj);
			strDBCallFor = "";
		}
		
		
		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();		
		DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");		
	
		Date sysdate = FipaUtils.isValidDB(dao);
		
		if(retval.size() == 0 && FipaUtils.checkNullVal(sysdate) ){
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("DB_ERROR", "DB_ERROR");
			retval.add(jsonObj);
			strDBCallFor = "";
		}
		 

		if(strDBCallFor.equalsIgnoreCase("CLIENT_SEARCH")){
			retval =  clientSearch(request);
		}
		
		if(strDBCallFor.equalsIgnoreCase("OPEN_CLIENT_PROFILELIST")){
			retval = openClientProfileList(request);
		}	

		if(strDBCallFor.equalsIgnoreCase("GET_CUSTDETS_FROMFPMS")){
			retval = getCustomerDetsFromFPMS(request);
		}	
		
		if(strDBCallFor.equalsIgnoreCase("OPEN_CLIENT_PROFILE")){
			retval = openClientProfile(request);
		}
		if(strDBCallFor.equalsIgnoreCase("CHK_EXIST_NRIC")){
			retval = checkExistingNRIC(request);
		}
		
		if(strDBCallFor.equalsIgnoreCase("GET_FIPALIFEDATA")){
			retval = getLifeInsuranceDets(request);
		} 
		
		if(strDBCallFor.equalsIgnoreCase("DELETE_FIPALIFEDATA")){
			retval = deleteLifeInsuranceDets(request); 
		} 
		 
		if(strDBCallFor.equalsIgnoreCase("GET_FPMS_LIFEDATA")){
			retval = getFPMSlifeDets(request);
		}  
		 
		if(strDBCallFor.equalsIgnoreCase("PRODUCT_LIST")){
			retval = getRecomProductName(request);
		}
		
		if(strDBCallFor.equalsIgnoreCase("MASTER_CPF_SEARCH")){
			retval = cpfSearchDetails(request);
		}
		
		if(strDBCallFor.equalsIgnoreCase("CPF_SRCH_EXIST")){
			retval = cpfCheckExisting(request);
		}
		
		if(strDBCallFor.equalsIgnoreCase("CPF_ALLOC_SEARCH")){
			retval = cpfAllocSearchDetails(request);
		}
		
		if(strDBCallFor.equalsIgnoreCase("CPF_ALLOC_SRCH_EXIST")){
			retval=cpfAllocCheckExisting(request);
		} 
		
		if(strDBCallFor.equalsIgnoreCase("CPFACCTYPE_SEARCH")){ 
			retval=cpfAccountTypeSearch(request);
		}  
		
		if(strDBCallFor.equalsIgnoreCase("GET_DBQUOTES")){
			retval=QuotesSearch(request);
		}  
		
		if(strDBCallFor.equalsIgnoreCase("FETCH_NAV")){
			retval=fetchNav(request);
		} 
		if(strDBCallFor.equalsIgnoreCase("PROP_INSERT")){
			retval=propertyInsert(request);
		} 
		
		if(strDBCallFor.equalsIgnoreCase("PROP_SEARCH")){
			retval =  propertySearch(request);
		}
		if(strDBCallFor.equalsIgnoreCase("PROP_DELETE")){
			retval =  propertyDelete(request);
		}
		
		out.print(retval);
	}
	
	
	
private JSONArray fetchNav(HttpServletRequest request) {
		// TODO Auto-generated method stub
	JSONArray retValues = new JSONArray(); 
	JSONObject navTabJsnObj =  new JSONObject(); 
	List navSearchList = new ArrayList();		 
    MasterService navserv=new MasterService();

	
	try{
	
		ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
		
		DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
		
			 
		

		String strFundCode = FipaUtils.getParamValue(request, "strFundCode");
		strFundCode = java.net.URLDecoder.decode(strFundCode,"UTF-8");
		strFundCode= strFundCode.replace("\'", "\''");
		  
		


		String strDateInvest = FipaUtils.getParamValue(request, "strDateInvest");
		strDateInvest = java.net.URLDecoder.decode(strDateInvest,"UTF-8");
		strDateInvest= strDateInvest.replace("\'", "\''");
		  
		 
		navSearchList = navserv.navSearch(dao,strFundCode,strDateInvest); 
		
		if(navSearchList.size() > 0){
			
			Iterator it = navSearchList.iterator();
			   
			while(it.hasNext()){ 
				BigDecimal nav = (BigDecimal) it.next(); 			 
				navTabJsnObj.put("CURRENT_NAV", FipaUtils.getObjValue(nav)); 
			} 
		}else{
			navTabJsnObj.put("NO_NAV", "0"); 
		}
		 
		retValues.add(navTabJsnObj);
		  
		
	}catch(Exception ex){
	ex.printStackTrace();	
	}
	
	return retValues;
	}

public JSONArray propertySearch(HttpServletRequest request){
		 
		
		JSONArray retValues = new JSONArray();
		
		JSONObject propDataJsnObj = new JSONObject();
		JSONObject propTabJsnObj =  new JSONObject();
		JSONArray propDataJsnArr = new JSONArray();
		
		List propSearchList = new ArrayList();		 
        MasterService propserv=new MasterService();

		
		try{
		
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			
			DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
			
				 
			

			String strKey = FipaUtils.getParamValue(request, "strKey");
			strKey = java.net.URLDecoder.decode(strKey,"UTF-8");
			strKey= strKey.replace("\'", "\''");
			  
			 
			StringBuffer strBufQryParam = new StringBuffer();
		 
			
			if(!FipaUtils.nullOrBlank(strKey)){
				strBufQryParam.append(" and UPPER(MAST.PROP_KEY) = '").append(strKey.toUpperCase()).append("'");
				
			}
			
			
			propSearchList = propserv.propSearch(dao,strBufQryParam.toString()); 
			if(propSearchList.size() > 0){
				
				Iterator it = propSearchList.iterator();
				   
				while(it.hasNext()){
					
					Object[] propObj = (Object[]) it.next();					
 
					propDataJsnObj.put("propid", FipaUtils.getObjValue(FipaUtils.checkNullVal(propObj[0].toString())?"":propObj[0].toString())); 
					propDataJsnObj.put("propval", FipaUtils.getObjValue(FipaUtils.checkNullVal(propObj[1].toString())?"":propObj[1].toString())); 
						 
											
					propDataJsnArr.add(propDataJsnObj); 
						
				}
				propTabJsnObj.put("FINGLS", propDataJsnArr);
			
			}
			 
			
			
			retValues.add(propTabJsnObj);
			 
			 
			
			
		}catch(Exception ex){
		ex.printStackTrace();	
		}
		
		return retValues;
		
	}
	
	
	


public JSONArray propertyDelete(HttpServletRequest request){
		 
		
	 JSONArray retval=new JSONArray();

	  	JSONObject propDataJsnObj = new JSONObject();
		JSONObject propTabJsnObj =  new JSONObject(); 
		
		
	 String strid = FipaUtils.getParamValue(request, "strid"); 
	 String strKey = FipaUtils.getParamValue(request, "strKey");
	 
		
	 MasterService mastServ=new MasterService();
	 HttpSession session  = request.getSession(false);
	 Map<String,String> sessMap    = new HashMap<String,String>();
	 sessMap = (HashMap<String, String>)session.getAttribute(FipaConstant.LOGGED_USER_INFO);
	 String strCrtdUser = (String)sessMap.get(FipaConstant.LOGGED_USER_ID);
	 try{
		
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			
			DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
			  
			MasterPropertykv mastPropkv=new MasterPropertykv(); 
			  
			
			if(strKey.equalsIgnoreCase("FINGLS"))
			{
				mastPropkv.setPropKey(strKey);
				mastPropkv.setPropId(strid); 
				mastServ.delMasterKeys(mastPropkv);
				propTabJsnObj.put("FINGLS",true);
			}
			
			 retval.add(propTabJsnObj); 
			 
		}catch(Exception ex){
		ex.printStackTrace();	
		} 
	  
	 
	return retval;
		
	}	
	
	
	

	

	public JSONArray clientSearch(HttpServletRequest request){
		 
		
		JSONArray retValues = new JSONArray();
		
		JSONObject clntDataJsnObj = new JSONObject();
		JSONObject countryTabJsnObj =  new JSONObject();
		JSONArray clntDataJsnArr = new JSONArray();
		
		List clientSearchList = new ArrayList();		
		ClientService serv=new ClientService(); 

		
		try{
		
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			
			DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
			
				
			String strCustName = FipaUtils.getParamValue(request, "strSrchClntName");
			strCustName = java.net.URLDecoder.decode(strCustName,"UTF-8");
			strCustName= strCustName.replace("\'", "\''");
			
			String strCustNric = FipaUtils.getParamValue(request, "strSrchClntNric");
			strCustNric = java.net.URLDecoder.decode(strCustNric,"UTF-8");
			strCustNric= strCustNric.replace("\'", "\''");
			 
			
			StringBuffer strBufQryParam = new StringBuffer();
			
			HttpSession session = request.getSession(false);
			Map<String,String> sessMap = new HashMap<String,String>();
			sessMap =(Map<String,String>)session.getAttribute(FipaConstant.LOGGED_USER_INFO);
			String strLoggedAdvStfId = (String)sessMap.get(FipaConstant.LOGGED_USER_ADVSTFID);
			String strLoggedStfType = (String)sessMap.get(FipaConstant.LOGGED_USER_STFTYPE);
			

			
			clientSearchList = serv.clientSearch(dao,strCustName,strCustNric,strLoggedAdvStfId,strLoggedStfType);
			
			if(clientSearchList.size() > 0){
				
				Iterator it = clientSearchList.iterator();
				
				String strContDets  = "";
				int jsonSize=0;
				
				int sino=0;
				while(it.hasNext()){
					
					Object[] client = (Object[]) it.next();					
					

						clntDataJsnObj.put("sino",++sino);
						 
						
						
						
						clntDataJsnObj.put("fnaId",FipaUtils.getObjValue(FipaUtils.checkNullVal(client[0])?"":client[0].toString()));		
						
						clntDataJsnObj.put("dfSelfName", FipaUtils.getObjValue(FipaUtils.checkNullVal(client[1])?"":client[1].toString()));	
											
						clntDataJsnObj.put("dfSelfNric", FipaUtils.getObjValue(FipaUtils.checkNullVal(client[2])?"":client[2].toString()));	
						
						clntDataJsnObj.put("dfSelfPersemail", FipaUtils.getObjValue(FipaUtils.checkNullVal(client[3])?"":client[3].toString()));	
						
						clntDataJsnObj.put("dfSelfMobile", FipaUtils.getObjValue(FipaUtils.checkNullVal(client[4])?"":client[4].toString()));	
						
						clntDataJsnObj.put("dfSelfHomeaddr", FipaUtils.getObjValue(FipaUtils.checkNullVal(client[5])?"":client[5].toString()));	
						
						clntDataJsnObj.put("strFipaExists", FipaUtils.getObjValue(FipaUtils.checkNullVal(client[6])?"":client[6].toString()));	
						
						clntDataJsnObj.put("strFpmsExists", FipaUtils.getObjValue(FipaUtils.checkNullVal(client[7])?"":client[7].toString()));	
						
						clntDataJsnObj.put("strFpmsCustId", FipaUtils.getObjValue(FipaUtils.checkNullVal(client[8])?"":client[8].toString()));	
						
											
						clntDataJsnArr.add(clntDataJsnObj);
						jsonSize = clntDataJsnArr.size();
						
				}
			}
			else{
				
				countryTabJsnObj.put("CLIENT_SEARCH_NOREC", "");
				
			}
			
			countryTabJsnObj.put("CLIENT_SEARCH", clntDataJsnArr);
	
			retValues.add(countryTabJsnObj);
			 
			
			
		}catch(Exception ex){
		ex.printStackTrace();	
		}
		
		return retValues;
		
	}
	
	
	
	public JSONArray openClientProfileList(HttpServletRequest request){
		 
		
		JSONArray retValues = new JSONArray();
		JSONObject objAnalysFr =new JSONObject();
		JSONObject objPurpose =new JSONObject();
		JSONObject clntDataJsnObj = new JSONObject();
		JSONObject jsnObjTab =  new JSONObject();
		JSONArray clntDataJsnArr = new JSONArray();	
			
		ClientService serv=new ClientService(); 
		
		try{
		
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");				
			 
			String strCustId = FipaUtils.getParamValue(request, "strCustId");
			String strCustName = FipaUtils.getParamValue(request, "strClientName");
			
			String strFNAId = FipaUtils.getParamValue(request, "strFNAId");
			
			strCustName = java.net.URLDecoder.decode(strCustName,"UTF-8");
			strCustName= strCustName.replace("\'", "\''");
			
			String strCustNric = FipaUtils.getParamValue(request, "strClientNRIC");
			strCustNric = java.net.URLDecoder.decode(strCustNric,"UTF-8");
			strCustNric= strCustNric.replace("\'", "\''");
			
			StringBuffer strBufQryParam = new StringBuffer();
			
			if(!FipaUtils.nullOrBlank(strCustName)){
				strBufQryParam.append(" and ss.DF_SELF_NAME = '"+strCustName+"'");
			} 
			if(!FipaUtils.nullOrBlank(strCustNric)){
				strBufQryParam.append(" and ss.DF_SELF_NRIC = '"+strCustNric+"'");
			}  
			if(!FipaUtils.nullOrBlank(strCustId)){
                strBufQryParam.append(" and ss.FPMS_CUSTID = '"+strCustId+"'");
            }
 
			
			
			List clientTabDetsList = new ArrayList();
			clientTabDetsList = serv.openClientProfileList(dao,strBufQryParam.toString());
				
			int clientTabSize = clientTabDetsList.size();
			
			if(clientTabSize > 0){
				Iterator it = clientTabDetsList.iterator();
				while(it.hasNext()){
					
					String strApplicants = "";
					Object[] objs = (Object[]) it.next();
					 
 	
					clntDataJsnObj.put("strFnaId",FipaUtils.checkNullVal(objs[0]) ? "" : objs[0].toString());
					clntDataJsnObj.put("strFnaCrtdBy",FipaUtils.checkNullVal(objs[1]) ? "" : objs[1].toString());					
					clntDataJsnObj.put("strFnaCrtdDate",FipaUtils.checkNullVal(objs[2]) ? "" :  FipaUtils.getObjValue((objs[2])));
 

					String strAnalysisFor= FipaUtils.checkNullVal(objs[3]) ? "{}" : objs[3].toString();
					strAnalysisFor = (strAnalysisFor.equalsIgnoreCase("\"\"")) ? "{}":strAnalysisFor;
					if(!FipaUtils.nullOrBlank(strAnalysisFor))
					{
						objAnalysFr =JSONObject.fromObject(strAnalysisFor);
					}
					
					
					String strPurpose= FipaUtils.checkNullVal(objs[4]) ? "{}" : objs[4].toString();					
					strPurpose = (strPurpose.equalsIgnoreCase("\"\"")) ? "{}":strPurpose;
					if(!FipaUtils.nullOrBlank(strPurpose))
					{
						objPurpose =JSONObject.fromObject(strPurpose);
					}
					
					 
					
					String strSelf = FipaUtils.checkNullVal(objAnalysFr.get("ANALYS_SLF")) ? "" : objAnalysFr.get("ANALYS_SLF").toString();
					String strSpouse = FipaUtils.checkNullVal(objAnalysFr.get("ANALYS_SPS")) ? "" : objAnalysFr.get("ANALYS_SPS").toString();
					String strFamily = FipaUtils.checkNullVal(objAnalysFr.get("ANALYS_FAM")) ? "" : objAnalysFr.get("ANALYS_FAM").toString();
					
					
					
					String strRepl = FipaUtils.checkNullVal(objs[6]) ? "" : objs[6].toString(); 
					
					if(strSelf.equalsIgnoreCase("Y")){strApplicants +="Self"+","; }
					
					if(strSpouse.equalsIgnoreCase("Y")){ strApplicants +="Spouse"+","; }
					
					if(strFamily.equalsIgnoreCase("Y")){ strApplicants +="Family"+","; }
					 
					clntDataJsnObj.put("strFnaApplicants",strApplicants.replaceAll(",", "<br/>")); 
					clntDataJsnObj.put("strFnaAnalysisList",FipaUtils.checkNullVal(objs[7]) ? "" :( "<li>"+ objs[7].toString().replaceAll(",", "</li><li>")));
					clntDataJsnObj.put("strFnaCustId",FipaUtils.checkNullVal(objs[8]) ? "" : objs[8].toString());
					clntDataJsnObj.put("strFnaCustName",FipaUtils.checkNullVal(objs[9]) ? "" : objs[9].toString());
					clntDataJsnObj.put("strFnaCustNRIC",FipaUtils.checkNullVal(objs[10]) ? "" : objs[10].toString());
					clntDataJsnObj.put("strFnaType",FipaUtils.checkNullVal(objs[11]) ? "" : objs[11].toString());
					clntDataJsnObj.put("strFnaProfRemarks",FipaUtils.checkNullVal(objs[12]) ? "" : objs[12].toString());
					
					clntDataJsnArr.add(clntDataJsnObj);	
					
				}
				
				jsnObjTab.put("CLIENT_PROFILE_LIST", clntDataJsnArr); 
			}else{
				jsnObjTab.put("NO_CLIENT_PROFILE_LIST", FipaConstant.GLBL_NO_RECORD);
			}
			
			
	
			retValues.add(jsnObjTab); 
			 
			
			
		}catch(Exception ex){
			ex.printStackTrace();	
		}
		
		return retValues;
		
	}
	
	public JSONArray openClientProfile(HttpServletRequest request){
		
		 
		
		JSONArray retValues = new JSONArray();	 
		JSONArray jsnFnaEstPlanArr = new JSONArray(); 
		 
		
		JSONArray jsnFnaAssetsArr = new JSONArray();
		JSONObject FnaRdIncTab = new JSONObject();
		JSONObject FnaRdIncAssTab = new JSONObject();
		JSONObject clientDetailsTab =  new JSONObject();
		
		
		JSONObject childDetailsTab = new JSONObject();
		JSONObject FinGoalsDetailsTab = new JSONObject();
		
		JSONObject depntDetailsTab = new JSONObject();
		JSONObject savingsInvDetailsTab = new JSONObject(); 
		
		JSONObject FnaAssetsDetailsTab = new JSONObject();
		JSONObject FnaPersAssetsDetailsTab = new JSONObject();
		JSONObject OthAreaCrnDetailsTab = new JSONObject();
		JSONObject ReasonsDetailsTab = new JSONObject();


		JSONObject PropOwnCPFDetailsTab = new JSONObject(); 
		
		JSONObject cpfBalanceDetsTab = new JSONObject();
		JSONObject cpfMthCtrbDetsTab =  new JSONObject(); 
		JSONObject CADDetsTab =  new JSONObject();
		 
		JSONObject HIDetailsTab = new JSONObject(); 
		JSONObject AttachmentTab = new JSONObject(); 
		JSONObject VehOwnDetailsTab = new JSONObject(); 
		JSONObject RcmPrdDetailsTab = new JSONObject(); 
		JSONObject RcmPrdFundDetailsTab = new JSONObject();
		JSONObject SwtchPlnDetailsTab = new JSONObject();
		JSONObject SwtchFundDetailsTab = new JSONObject();
		JSONObject CashOfBankDetailsTab = new JSONObject(); 
		JSONObject OthRetDetailsTab = new JSONObject(); 
		JSONObject InputInvestMentTab = new JSONObject();
		JSONObject typesOfAppDetsTab = new JSONObject();  
		
		JSONObject advDeclareDetsTab = new JSONObject();
		JSONObject expenditureDetsTab =  new JSONObject();
		
		JSONObject contgDetsTab =  new JSONObject();  
		JSONObject perprioDetsTab =  new JSONObject();
		JSONObject srcOfincDetsTab =  new JSONObject(); 
		JSONObject finlbDetsTab =  new JSONObject();
		JSONObject curassDetsTab =  new JSONObject();
		JSONObject retireplnDetsTab =  new JSONObject();
		JSONObject invstDetsTab =  new JSONObject();
		JSONObject cashDetsTab =  new JSONObject();
		JSONObject othassDetsTab =  new JSONObject();
		JSONObject rskprefDetsTab =  new JSONObject();
		JSONObject sumanalDetsTab =  new JSONObject(); 
		JSONObject estplanTab = new JSONObject(); 
		
		JSONObject fpmsfipaPolTab = new JSONObject();
		JSONObject polDataJsnObj = new JSONObject(); 
 
		//Existing policies
		JSONObject liDataJsnObj = new JSONObject();  
		
		JSONArray polDataJsnArr = new JSONArray();
		
		
		List clientTabDetsList = new ArrayList();
		
		List childTabDetsList = new ArrayList();
		List finGoalsTabDetsList = new ArrayList();
		
		List depntTabDetsList = new ArrayList();
		List savInvTabDetsList = new ArrayList();  
		 
		List OthAreaCnDetsList = new ArrayList();
		List RecmResonList = new ArrayList(); 
		
		List cpfBalanceList = new ArrayList();
		List cpfMthCtbTabDetsList = new ArrayList();  
		List<FnaCpfDeductions>  CADTabDetsList = new ArrayList();  
		
		List HITabDetsList = new ArrayList(); 
		List AttTabDetsList = new ArrayList(); 
		
		
		List VehOwnTabDetsList = new ArrayList(); 
		List IPINVTabDetsList = new ArrayList();
		List RcmPrdTabDetsList = new ArrayList();
		List RcmPrdPlnTabDetsList = new ArrayList();
		List RcmPrdFundTabDetsList = new ArrayList();
		List SwtPlanTabDetsList = new ArrayList();
		List SwtFundTabDetsList = new ArrayList(); 
		List CashOfBankDetsList = new ArrayList(); 
		List RDOtherIncomeList = new ArrayList(); 
		List InputInvestMentList= new ArrayList();
			
		List typesOfAppDetsList = new ArrayList(); 
 		List advDeclareDetsList = new ArrayList();
		List expenditureDetsList = new ArrayList();
		
		List contgDetsList = new ArrayList();
//		List contingencyDetsList = new ArrayList();
		List perprioDetsList = new ArrayList();
		List srcOfincDetsList = new ArrayList(); 
		List finlbDetsList = new ArrayList();
		List curassDetsList = new ArrayList();
		List retireplnDetsList = new ArrayList();
		List invstDetsList = new ArrayList();
		List cashDetsList = new ArrayList();
		List othassDetsList = new ArrayList();
		List rskprefDetsList = new ArrayList();
		List sumanalDetsList = new ArrayList(); 
		List policyDetList = new ArrayList();
		
		List<FnaLifeinsuranceDets> LifeInsSearchList = new ArrayList();
 
	 
		List<FnaAssetBusiandpersdets>  fnabusiPerDetsList = new ArrayList(); 
		List<FnaRetireplanIncomeasset>  fnaRdIncomeAssList = new ArrayList(); 
		List<FnaPropownDets>  fnpropertyOwnList = new ArrayList(); 
		
		//Life Insurance Screen
		List<FnaEstatePlan>  estPlanDetsList = new ArrayList(); 
		
		 ClientService serv=new ClientService(); 
		 
		try{
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
			
			String strCustId = FipaUtils.getParamValue(request,"strCustId");
			String strFNAId = FipaUtils.getParamValue(request,"strFNAId");
			 
			String strClientName = FipaUtils.getParamValue(request,"strClientName");//Just Reuse Purpose 
			 String strClientNRIC= FipaUtils.getParamValue(request,"strClientNRIC");//Just Reuse Purpose
			 String strAdvId= FipaUtils.getParamValue(request,"strAdvId");
			 
			 StringBuffer strBufQryParamFIPALife = new StringBuffer();			  
				
				if(!FipaUtils.nullOrBlank(strClientNRIC)){
					strBufQryParamFIPALife.append(" AND UPPER(cust.dfSelfNric) = '").append(strClientNRIC.toUpperCase()).append("'");
					
				} 
				
				if(!FipaUtils.nullOrBlank(strAdvId)){
					strBufQryParamFIPALife.append(" AND UPPER(cust.advstfId) = '").append(strAdvId.toUpperCase()).append("'");
					
				}
				
				clientTabDetsList = serv.openClientProfile(dao,strFNAId);//SelfSpouse particulars
				
				int profilelen = clientTabDetsList.size();
			 

			 
			if(profilelen > 0){
				
				
				advDeclareDetsList=serv.openAdvDclProfile(dao,strFNAId);//Types of Applications,AML Declarations
				typesOfAppDetsList = serv.openClntProfAppTypes(dao, strFNAId);//Analysis Type			
 		 
							
				childTabDetsList = serv.openClntProfChild(dao, strFNAId);//Child particulars
				
				finGoalsTabDetsList = serv.openClntProfFinGoals(dao, strFNAId);//Financial Goals/ Concerns
				savInvTabDetsList=serv.openClntProfSAInvst(dao,strFNAId); //Wealth Accumulation Goals
				
				depntTabDetsList = serv.openClntProfDepnt(dao, strFNAId);//Dependant Dets Other than family members
				
				srcOfincDetsList = serv.openSrcIncProfile(dao,strFNAId);//Employment Income & Non-Employment -Inflow
				expenditureDetsList = serv.openExpProfile(dao,strFNAId); //Annual Expenditure - Outflow
				
				contgDetsList=serv.openClntContgProfile(dao,strFNAId);//Contingency Planning
				
 				LifeInsSearchList = serv.clntLifeInsList(dao,strBufQryParamFIPALife.toString());//Life Insurance - FIPA		
				
				HITabDetsList = serv.openClntProfHI(dao,strFNAId);//Information on Health Insurance Needs
				
				perprioDetsList = serv.openPerpProfile(dao,strFNAId);//Personal Priorities
				
				InputInvestMentList= serv.openInputInvestment(dao,strFNAId);//Investments
				invstDetsList = serv.openInvProfile(dao,strFNAId);//Investments - Summary
 	
				fnpropertyOwnList = serv.openClntProfPrpOwn(dao,strFNAId);//Property Ownership
				
				CashOfBankDetsList=serv.openClntProfCashAtBank(dao,strFNAId);//Cash At Banks
				
				cashDetsList = serv.openCasProfile(dao,strFNAId);//Cash Assets
				othassDetsList = serv.openOthCAProfile(dao,strFNAId);//Other Assets
				fnabusiPerDetsList  = serv.openClntProfAssets(dao,strFNAId);//Personal Assets and Business Assets
				VehOwnTabDetsList = serv.openClntProfVehOwn(dao,strFNAId);//Vehicle Ownership
				 
				 
				AttTabDetsList=serv.openClntAttachments(dao,strFNAId);//Attachments
				
				
				
				estPlanDetsList = serv.openEstPlanProfile(dao,strFNAId);//Estate Planning
				
				cpfBalanceList = serv.openClntProfCPFBalance(dao, strFNAId);//CPF Balance
				cpfMthCtbTabDetsList = serv.openClntProfCpfMCtb(dao,strFNAId);//CPF Monthly Contribution
				CADTabDetsList = serv.openClntProfCAD(dao,strFNAId);//Additions & Deductions of funds into CPF a/c
				
				finlbDetsList = serv.openFinlbProfile(dao,strFNAId);//Financial Liabilities
				curassDetsList = serv.openCrtAssProfile(dao,strFNAId);//Current Assumptions
				
				retireplnDetsList = serv.openRetProfile(dao,strFNAId);//Retirement Planning Master
				RDOtherIncomeList=serv.openRdOtherIncome(dao,strFNAId);//RP Other payment to be made during retirement
				fnaRdIncomeAssList  = serv.openClntProfRdIncomeAss(dao,strFNAId);//Income to be received during retirement and Income and assets available for retirement
				
				OthAreaCnDetsList  = serv.openClntProfArOfConcern(dao,strFNAId);//Other Areas of Concerns
				
				RcmPrdTabDetsList =serv.openClntProfRcmPrt(dao,strFNAId);//Products Recommended - FOR LIFE & HEALTH INSURANCE
 				RcmPrdFundTabDetsList=serv.openClntProfRcmFd(dao,strFNAId);//Products Recommended - For UT and ILP
				
				SwtPlanTabDetsList=serv.openClntProfSwtPln(dao,strFNAId);//SWITCHING & REPLACEMENT - FOR LIFE & HEALTH INSURANCE
				SwtFundTabDetsList=serv.openClntProfSwtFd(dao,strFNAId);//SWITCHING & REPLACEMENT - For UT and ILP
				
				rskprefDetsList = serv.openRskPrefProfile(dao,strFNAId);//Client's Risk Preference & Investment Objectives
				
				RecmResonList = serv.openClntProfRecmReasn(dao,strFNAId);//Reasons for Recommendation
				sumanalDetsList = serv.openSumAnlProfile(dao,strFNAId);//Summary of Needs Analysis Worksheet
				
				
				
				
				FPMSDataService serv1 = new FPMSDataService();
				if(!FipaUtils.nullOrBlank(strCustId)){
					policyDetList = serv1.getFPMSLifeInsuracePolDets(dao,"","", strCustId,"");
				}
				
				clientDetailsTab.put("OPEN_CUST_DETS", FipaUtils.getPropsJsonObject(clientTabDetsList, FnaSelfspouseDets.class));
				
				retValues.add(clientDetailsTab);
				
				
				int anatyperec = typesOfAppDetsList.size();
				if(anatyperec>0){
					typesOfAppDetsTab.put("APPTYPES_DETS", FipaUtils.getPropsJsonArray(typesOfAppDetsList, FnaApptypes.class));
					retValues.add(typesOfAppDetsTab); 
					 
					
				}
				
				int advdecrec = advDeclareDetsList.size();
				if(advdecrec>0){
					advDeclareDetsTab.put("ADVDCL_DETS", FipaUtils.getPropsJsonObject(advDeclareDetsList, FnaAdvDeclare.class)); 
					retValues.add(advDeclareDetsTab);
					
				}
				
				
				int childrecords =childTabDetsList.size();
				if(childrecords>0){
					childDetailsTab.put("CHILD_DETS", FipaUtils.getPropsJsonArray(childTabDetsList, FnaChilddetails.class));
					retValues.add(childDetailsTab);
					
					
				}
				
				int fingoalrecords = finGoalsTabDetsList.size();
				if(fingoalrecords>0){
					FinGoalsDetailsTab.put("FINGOALS_DETS", FipaUtils.getPropsJsonArray(finGoalsTabDetsList, FnaFingoalsconcern.class));
					retValues.add(FinGoalsDetailsTab);
					
				}
				
				int wealthrecords =savInvTabDetsList.size();
				if(wealthrecords>0){
					savingsInvDetailsTab.put("SAVINV_DETS", FipaUtils.getPropsJsonArray(savInvTabDetsList, FnaSavingsinvDets.class));
					retValues.add(savingsInvDetailsTab); 
				}
				
				int deprecords = depntTabDetsList.size();
				if(deprecords>0){
					depntDetailsTab.put("DEPENDANT_DETS", FipaUtils.getPropsJsonArray(depntTabDetsList, FnaDependantDets.class));
					retValues.add(depntDetailsTab);
					
				}
				
				int Attrecords =AttTabDetsList.size();  
				if(Attrecords>0){
					AttachmentTab.put("ATTACHMENT_DETS", FipaUtils.getPropsJsonArray(AttTabDetsList,  FnaAttachments.class)); 
					retValues.add(AttachmentTab);    
				}
				 
				
				int inflowrecords = srcOfincDetsList.size();
				if(inflowrecords>0){
					srcOfincDetsTab.put("SOI_DETS", FipaUtils.getPropsJsonObject(srcOfincDetsList,  FnaSrcofincome.class));
					retValues.add(srcOfincDetsTab);
					
				}
				int expdrecords=expenditureDetsList.size();
				if(expdrecords>0){
					expenditureDetsTab.put("EXPD_DETS", FipaUtils.getPropsJsonObject(expenditureDetsList,  FnaExpenditureDets.class));
					retValues.add(expenditureDetsTab);
					
				}
				int contgrecords =contgDetsList.size();
				if(contgrecords>0){
					contgDetsTab.put("CONTG_DETS", FipaUtils.getPropsJsonObject(contgDetsList,  FnaContingencyDets.class)); 
					retValues.add(contgDetsTab);

					
					
				} 
				int lifeInsTabSize = LifeInsSearchList.size();
				if(lifeInsTabSize >0){ 
					
					Iterator iter = LifeInsSearchList.iterator();
					
					while(iter.hasNext()){
						
						FnaLifeinsuranceDets lip = (FnaLifeinsuranceDets) iter.next();	   
						liDataJsnObj.put("strFipaLifeInsId", FipaUtils.getObjValue(lip.getLipId()));
					 	liDataJsnObj.put("strFnaId",FipaUtils.getObjValue(lip.getFnaSelfspouseDets().getFnaId()));
						liDataJsnObj.put("strFPMSPolPrincipal",FipaUtils.getObjValue(lip.getLipCompany()));
						liDataJsnObj.put("strFPMSPolPolNo",FipaUtils.getObjValue(lip.getLipPolicyno()));
						liDataJsnObj.put("strFPMSPolPlanName",FipaUtils.getObjValue(lip.getLipPlanname()));
						liDataJsnObj.put("strFPMSPolEffDate",FipaUtils.getObjValue(lip.getLipIncepdate()));
						liDataJsnObj.put("strFPMSPolStatus",FipaUtils.getObjValue(lip.getPolicyStatus()));
						liDataJsnObj.put("strFPMSPolSA",FipaUtils.getObjValue(lip.getLipSa()));
						liDataJsnObj.put("strFPMSPolPremium","0");
						liDataJsnObj.put("strFPMSPolLOBMain","NIL");
						liDataJsnObj.put("strFPMSPolLOBSub","NIL");
						liDataJsnObj.put("strFPMSPolApplnName","FIPA");
						liDataJsnObj.put("strCrtdBy",FipaUtils.getObjValue(lip.getLipCreatedBy()));
						liDataJsnObj.put("strCrtdDate",FipaUtils.getObjValue(lip.getLipCreatedDate()));
						liDataJsnObj.put("strFPMSPolPrincipalName",FipaUtils.getObjValue(lip.getLipCompany()));
						liDataJsnObj.put("strFPMSPolAppId","NA");
					 
						polDataJsnArr.add(liDataJsnObj); 
						 
					}
					 
	 
					
				}
				
				int polTabSize = policyDetList.size();
				
				if(!FipaUtils.nullOrBlank(strCustId) && polTabSize >0){  
						if(polTabSize >0){
							Iterator it = policyDetList.iterator(); 
							while(it.hasNext()){
								Object[] polObjs = (Object[]) it.next(); 
								polDataJsnObj.put("strFipaLifeInsId","");
								polDataJsnObj.put("strFnaId",strFNAId);
								polDataJsnObj.put("strFPMSPolCustName",FipaUtils.checkNullVal(polObjs[2])?"":polObjs[2].toString());
								polDataJsnObj.put("strFPMSPolPrincipalName",(FipaUtils.checkNullVal(polObjs[6])?"":polObjs[6].toString()));
								polDataJsnObj.put("strFPMSPolPrincipal",(FipaUtils.checkNullVal(polObjs[19])?"":polObjs[19].toString()));
								polDataJsnObj.put("strFPMSPolPolNo",(FipaUtils.checkNullVal(polObjs[5])?"":polObjs[5].toString()));
								polDataJsnObj.put("strFPMSPolPlanName",(FipaUtils.checkNullVal(polObjs[4])?"":polObjs[4].toString()));
								polDataJsnObj.put("strFPMSPolEffDate",(FipaUtils.checkNullVal(polObjs[12])?"":polObjs[12].toString()));
								polDataJsnObj.put("strFPMSPolStatus",(FipaUtils.checkNullVal(polObjs[15])?"":polObjs[15].toString()));
								polDataJsnObj.put("strFPMSPolSA",(FipaUtils.checkNullVal(polObjs[9])?"":polObjs[9].toString()));
								polDataJsnObj.put("strFPMSPolPremium",(FipaUtils.checkNullVal(polObjs[8])?"":polObjs[8].toString()));
								polDataJsnObj.put("strFPMSPolLOBMain",(FipaUtils.checkNullVal(polObjs[16])?"":polObjs[16].toString()));
								polDataJsnObj.put("strFPMSPolLOBSub",(FipaUtils.checkNullVal(polObjs[17])?"":polObjs[17].toString()));
								polDataJsnObj.put("strFPMSPolApplnName","FPMSNL");
								polDataJsnObj.put("strFPMSPolAppId",(FipaUtils.checkNullVal(polObjs[18])?"":polObjs[18].toString()));
								polDataJsnArr.add(polDataJsnObj);
								
							}   
						}  
				}
				
				int fipafpmspol = polDataJsnArr.size();
				if(fipafpmspol>0){
					fpmsfipaPolTab.put("FPMS_POLICY_DETS", polDataJsnArr);
					
					retValues.add(fpmsfipaPolTab);
					
				}
				
				int healthinsrecords =HITabDetsList.size();
				if(healthinsrecords>0){
					HIDetailsTab.put("HEALTHINS_DETS",FipaUtils.getPropsJsonArray(HITabDetsList, FnaHealthinsInfo.class));
					retValues.add(HIDetailsTab);
					
				}
				
				int presprirecords =perprioDetsList.size();
				if(presprirecords>0){
					perprioDetsTab.put("PERP_DETS", FipaUtils.getPropsJsonObject(perprioDetsList,  FnaPersprio.class));
					retValues.add(perprioDetsTab);
					
				}
				
				int investrecords =InputInvestMentList.size();
				if(investrecords>0){
					InputInvestMentTab.put("INPUTINVESTMENT_DETS", FipaUtils.getPropsJsonArray(InputInvestMentList, FnaInputinvestmentsDets.class));
					retValues.add(InputInvestMentTab);
					
				}
				
				int invsummaryrecords = invstDetsList.size();
				if(invsummaryrecords>0){
					invstDetsTab.put("INV_DETS", FipaUtils.getPropsJsonObject(invstDetsList,  FnaInvsetmentSummary.class));
					retValues.add(invstDetsTab);

				}
				
				int proprecords =fnpropertyOwnList.size();
				if(proprecords>0){   
					PropOwnCPFDetailsTab.put("PROPOWNCPF_DETS",FipaUtils.getPropsJsonArray(fnpropertyOwnList,FnaPropownDets.class)); 
					retValues.add(PropOwnCPFDetailsTab);  
				}
				
				int bankcashrecords = CashOfBankDetsList.size();
				if(bankcashrecords>0){
					CashOfBankDetailsTab.put("CASHATBANKS_DETS", FipaUtils.getPropsJsonArray(CashOfBankDetsList, FnaCashAtBank.class));
					retValues.add(CashOfBankDetailsTab);
					
				}
				
				int cashassetrec = cashDetsList.size();
				if(cashassetrec>0){
					cashDetsTab.put("CAS_DETS", FipaUtils.getPropsJsonObject(cashDetsList,  FnaAssetCashdets.class));
					retValues.add(cashDetsTab);
					
				}
				
				int othassetrec = othassDetsList.size();
				if(othassetrec>0){
					othassDetsTab.put("OTH_DETS", FipaUtils.getPropsJsonObject(othassDetsList,  FnaAssetOtherdets.class));
					retValues.add(othassDetsTab);
					
				}
				
				int persbusiassetrec = fnabusiPerDetsList.size();
				if(persbusiassetrec>0){
					
					JSONObject jsnBusperDetailsDataObj = new JSONObject();
					JSONObject jsnPersDetailsDataObj = new JSONObject(); 
					JSONArray persjsnArr = new JSONArray();
					for(FnaAssetBusiandpersdets fnabusper : fnabusiPerDetsList){
						
						String strCatg=fnabusper.getAssetCateg();
						
						if(!FipaUtils.nullOrBlank(strCatg)){ 
							if(strCatg.equalsIgnoreCase("PERSONAL")){ 
								jsnPersDetailsDataObj.put("fnaId", !FipaUtils.nullObj(fnabusper.getFnaSelfspouseDets().getFnaId()) ? fnabusper.getFnaSelfspouseDets().getFnaId() : "");
								jsnPersDetailsDataObj.put("txtFldPerBusiPersId", !FipaUtils.nullObj(fnabusper.getBusipersId()) ? fnabusper.getBusipersId() : "");
								jsnPersDetailsDataObj.put("txtFldPerAcctCategory", !FipaUtils.nullObj(fnabusper.getAssetCateg()) ? fnabusper.getAssetCateg() : "");
								jsnPersDetailsDataObj.put("txtFldPerAcctHolder", !FipaUtils.nullObj(fnabusper.getAcctHolder()) ? fnabusper.getAcctHolder() : "");
								jsnPersDetailsDataObj.put("txtFldPerEstApprValue", !FipaUtils.nullObj((fnabusper.getEstApprValue())) ? fnabusper.getEstApprValue() : "");
								jsnPersDetailsDataObj.put("txtFldPerTypeOfAsset", !FipaUtils.nullObj(fnabusper.getTypeOfAsset()) ? fnabusper.getTypeOfAsset() : "");
								jsnPersDetailsDataObj.put("txtFldPerYrs2keep", !FipaUtils.nullObj(fnabusper.getYrs2keep()) ? fnabusper.getYrs2keep() : "");
								jsnPersDetailsDataObj.put("txtFldPerNameOfAsset", !FipaUtils.nullObj(fnabusper.getNameOfAsset()) ? fnabusper.getNameOfAsset() : "");
								jsnPersDetailsDataObj.put("txtFldPerChildEdnPrcnt", !FipaUtils.nullObj(fnabusper.getChildEdnPrcnt()) ? fnabusper.getChildEdnPrcnt() : "");
								jsnPersDetailsDataObj.put("txtFldPerPurInvValue", !FipaUtils.nullObj(fnabusper.getPurInvValue()) ? fnabusper.getPurInvValue() : "");
								jsnPersDetailsDataObj.put("txtFldPerRetPlanPrcnt", !FipaUtils.nullObj(fnabusper.getRetPlanPrcnt()) ? fnabusper.getRetPlanPrcnt() : "");
								jsnPersDetailsDataObj.put("txtFldPerCurrValue", !FipaUtils.nullObj(fnabusper.getCurrValue()) ? fnabusper.getCurrValue() : "");
								jsnPersDetailsDataObj.put("txtFldPerRemarks", !FipaUtils.nullObj(fnabusper.getRemarks()) ? fnabusper.getRemarks() : "");
								jsnPersDetailsDataObj.put("txtFldPerOsValue", !FipaUtils.nullObj(fnabusper.getOsValue()) ? fnabusper.getOsValue() : ""); 
								persjsnArr.add(jsnPersDetailsDataObj); 
							
							}
						
							if(strCatg.equalsIgnoreCase("BUSINESS")){						
								jsnBusperDetailsDataObj.put("fnaId", !FipaUtils.nullObj(fnabusper.getFnaSelfspouseDets().getFnaId()) ? fnabusper.getFnaSelfspouseDets().getFnaId() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisBusiPersId", !FipaUtils.nullObj(fnabusper.getBusipersId()) ? fnabusper.getBusipersId() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisAcctCategory", !FipaUtils.nullObj(fnabusper.getAssetCateg()) ? fnabusper.getAssetCateg() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisAcctHolder", !FipaUtils.nullObj(fnabusper.getAcctHolder()) ? fnabusper.getAcctHolder() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisEstApprValue", !FipaUtils.nullObj((fnabusper.getEstApprValue())) ? fnabusper.getEstApprValue() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisTypeOfAsset", !FipaUtils.nullObj(fnabusper.getTypeOfAsset()) ? fnabusper.getTypeOfAsset() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisYrs2keep", !FipaUtils.nullObj(fnabusper.getYrs2keep()) ? fnabusper.getYrs2keep() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisNameOfAsset", !FipaUtils.nullObj(fnabusper.getNameOfAsset()) ? fnabusper.getNameOfAsset() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisChildEdnPrcnt", !FipaUtils.nullObj(fnabusper.getChildEdnPrcnt()) ? fnabusper.getChildEdnPrcnt() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisPurInvValue", !FipaUtils.nullObj(fnabusper.getPurInvValue()) ? fnabusper.getPurInvValue() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisRetPlanPrcnt", !FipaUtils.nullObj(fnabusper.getRetPlanPrcnt()) ? fnabusper.getRetPlanPrcnt() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisCurrValue", !FipaUtils.nullObj(fnabusper.getCurrValue()) ? fnabusper.getCurrValue() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisRemarks", !FipaUtils.nullObj(fnabusper.getRemarks()) ? fnabusper.getRemarks() : "");
								jsnBusperDetailsDataObj.put("txtFldBuisOsValue", !FipaUtils.nullObj(fnabusper.getOsValue()) ? fnabusper.getOsValue() : ""); 
								jsnFnaAssetsArr.add(jsnBusperDetailsDataObj); 
								
						 }
				    }  
				}
				FnaPersAssetsDetailsTab.put("PERASSET_DETS",persjsnArr);
				FnaAssetsDetailsTab.put("BUSASSET_DETS",jsnFnaAssetsArr); 
				
				retValues.add(FnaPersAssetsDetailsTab);//Personal
				retValues.add(FnaAssetsDetailsTab);//Business
				
			}
				
				int vehirec = VehOwnTabDetsList.size();
				if(vehirec>0){
					VehOwnDetailsTab.put("VEHOWN_DETS", FipaUtils.getPropsJsonArray(VehOwnTabDetsList, FnaVehicleownDets.class));
					retValues.add(VehOwnDetailsTab);
					
				}
				
				
				int estaterec = estPlanDetsList.size();
				if(estaterec>0){ 

					JSONObject jsnDetailsEstDataObj = new JSONObject();

					for(FnaEstatePlan fna  : estPlanDetsList){
						String strEstDesc = fna.getEstPlanDesc();


						if(!FipaUtils.nullOrBlank(strEstDesc)){
						if(strEstDesc.equalsIgnoreCase("Have any Will or Trust been set up?")){ 
							jsnDetailsEstDataObj.put("fnaId",!FipaUtils.nullObj(fna.getFnaSelfspouseDets().getFnaId()) ? fna.getFnaSelfspouseDets().getFnaId() : "");
							jsnDetailsEstDataObj.put("txtFldEstTrstDesc",!FipaUtils.nullOrBlank(fna.getEstPlanDesc()) ? fna.getEstPlanDesc() : "");
							jsnDetailsEstDataObj.put("txtFldEstSlfTrstFlg",!FipaUtils.nullOrBlank(fna.getEstSelfPlanFlg()) ? fna.getEstSelfPlanFlg() : "");
							jsnDetailsEstDataObj.put("txtFldEstSpsTrstFlg",!FipaUtils.nullOrBlank(fna.getEstSpsPlanFlg()) ? fna.getEstSpsPlanFlg() : "");
							jsnDetailsEstDataObj.put("txtFldEstTrstRmrks",!FipaUtils.nullOrBlank(fna.getEstPlanRemarks()) ? fna.getEstPlanRemarks() : "");
						  
							jsnFnaEstPlanArr.add(jsnDetailsEstDataObj);
						}
						
						
						if(strEstDesc.equalsIgnoreCase("Have any LPOA been set up?")){ 
							jsnDetailsEstDataObj.put("fnaId",!FipaUtils.nullObj(fna.getFnaSelfspouseDets().getFnaId()) ? fna.getFnaSelfspouseDets().getFnaId() : "");
							jsnDetailsEstDataObj.put("txtFldEstLPOADesc",!FipaUtils.nullOrBlank(fna.getEstPlanDesc()) ? fna.getEstPlanDesc() : "");
							jsnDetailsEstDataObj.put("txtFldEstSlfLPOAFlg",!FipaUtils.nullOrBlank(fna.getEstSelfPlanFlg()) ? fna.getEstSelfPlanFlg() : "");
							jsnDetailsEstDataObj.put("txtFldEstSpsLPOAFlg",!FipaUtils.nullOrBlank(fna.getEstSpsPlanFlg()) ? fna.getEstSpsPlanFlg() : "");
							jsnDetailsEstDataObj.put("txtFldEstLPOARmrks",!FipaUtils.nullOrBlank(fna.getEstPlanRemarks()) ? fna.getEstPlanRemarks() : "");
						  
							jsnFnaEstPlanArr.add(jsnDetailsEstDataObj);
						}
						
						if(strEstDesc.equalsIgnoreCase("Do you intend to provide gift to charity")){ 
							jsnDetailsEstDataObj.put("fnaId",!FipaUtils.nullObj(fna.getFnaSelfspouseDets().getFnaId()) ? fna.getFnaSelfspouseDets().getFnaId() : "");
							jsnDetailsEstDataObj.put("txtFldEstCharityDesc",!FipaUtils.nullOrBlank(fna.getEstPlanDesc()) ? fna.getEstPlanDesc() : "");
							jsnDetailsEstDataObj.put("txtFldEstSlfCharityFlg",!FipaUtils.nullOrBlank(fna.getEstSelfPlanFlg()) ? fna.getEstSelfPlanFlg() : "");
							jsnDetailsEstDataObj.put("txtFldEstSpsCharityFlg",!FipaUtils.nullOrBlank(fna.getEstSpsPlanFlg()) ? fna.getEstSpsPlanFlg() : "");
							jsnDetailsEstDataObj.put("txtFldEstCharityRmrks",!FipaUtils.nullOrBlank(fna.getEstPlanRemarks()) ? fna.getEstPlanRemarks() : "");
						  
							jsnFnaEstPlanArr.add(jsnDetailsEstDataObj);
						}
						
						if(strEstDesc.equalsIgnoreCase("Do you have any assets overseas")){ 
							jsnDetailsEstDataObj.put("fnaId",!FipaUtils.nullObj(fna.getFnaSelfspouseDets().getFnaId()) ? fna.getFnaSelfspouseDets().getFnaId() : "");
							jsnDetailsEstDataObj.put("txtFldEstOverseasDesc",!FipaUtils.nullOrBlank(fna.getEstPlanDesc()) ? fna.getEstPlanDesc() : "");
							jsnDetailsEstDataObj.put("txtFldEstSlfOverseasFlg",!FipaUtils.nullOrBlank(fna.getEstSelfPlanFlg()) ? fna.getEstSelfPlanFlg() : "");
							jsnDetailsEstDataObj.put("txtFldEstSpsOverseasFlg",!FipaUtils.nullOrBlank(fna.getEstSpsPlanFlg()) ? fna.getEstSpsPlanFlg() : "");
							jsnDetailsEstDataObj.put("txtFldEstOverseasRmrks",!FipaUtils.nullOrBlank(fna.getEstPlanRemarks()) ? fna.getEstPlanRemarks() : "");
						  
							jsnFnaEstPlanArr.add(jsnDetailsEstDataObj);
						}
					}
						
					}
					
					estplanTab.put("ESTPLAN_DETS", jsnFnaEstPlanArr);
					
					retValues.add(estplanTab);
					
					
				}
				
 				int cpfBalSize = cpfBalanceList.size();
 				if(cpfBalSize>0){
					JSONObject jsnData = new JSONObject();
					
					Iterator ite = cpfBalanceList.iterator();
					while(ite.hasNext()){
						FnaCpfBalanceDets cpfBal = (FnaCpfBalanceDets)ite.next();
						
						String strAccType = FipaUtils.getObjValue(cpfBal.getMasterCpfAcctype().getAccType());
						String strSelfORSpouse = FipaUtils.getObjValue(cpfBal.getCpfSelfOrSps());
						
						if(strSelfORSpouse.equalsIgnoreCase("SELF")){
							jsnData.put("hTxtFldSlfAccType"+strAccType,FipaUtils.getObjValue(cpfBal.getMasterCpfAcctype().getCpfAcId()));
							jsnData.put("txtFldCpfSlf"+strAccType,FipaUtils.getObjValue(cpfBal.getCpfSelfBalance()));
						}else if (strSelfORSpouse.equalsIgnoreCase("SPOUSE")){
							jsnData.put("hTxtFldSpsAccType"+strAccType,FipaUtils.getObjValue(cpfBal.getMasterCpfAcctype().getCpfAcId()));
							jsnData.put("txtFldCpfSps"+strAccType,FipaUtils.getObjValue(cpfBal.getCpfSelfBalance()));
						}						
					}
					
				 cpfBalanceDetsTab.put("CPF_BALANCE_DETS",jsnData);
				 retValues.add(cpfBalanceDetsTab);
					
					
				}
 				
 				int cpfcontrrec = cpfMthCtbTabDetsList.size();
				if(cpfcontrrec>0){
					cpfMthCtrbDetsTab.put("CPFMTHCTRB_DETS", FipaUtils.getPropsJsonArray(cpfMthCtbTabDetsList, FnaCpfMonthcontDets.class));
					retValues.add(cpfMthCtrbDetsTab);

					
				}
				
				int cpfadddedrec = CADTabDetsList.size();
				if(cpfadddedrec>0){ 
					CADDetsTab.put("CPF_ADD_DED_DETS", FipaUtils.getPropsJsonArray(CADTabDetsList, FnaCpfDeductions.class)); 
					retValues.add(CADDetsTab); 
					
				} 
				int finliabrec = finlbDetsList.size();
				if(finliabrec>0){
					finlbDetsTab.put("FLB_DETS", FipaUtils.getPropsJsonObject(finlbDetsList,  FnaFinLiability.class));
					retValues.add(finlbDetsTab);
					
				}
				
				int curassrec = curassDetsList.size();
				if(curassrec>0){
					curassDetsTab.put("CURASS_DETS", FipaUtils.getPropsJsonObject(curassDetsList,  FnaCurassDets.class));
					retValues.add(curassDetsTab);
					
					
				}
				int rprec = retireplnDetsList.size();
				if(rprec>0){
					retireplnDetsTab.put("RETP_DETS", FipaUtils.getPropsJsonObject(retireplnDetsList,  FnaRetireplanDets.class));
					retValues.add(retireplnDetsTab);
					
				}
				
				int rpothpayrec  = RDOtherIncomeList.size();
				if(rpothpayrec>0){
					OthRetDetailsTab.put("RDOTHER_PAY", FipaUtils.getPropsJsonArray(RDOtherIncomeList, FnaRetireplanOthpayment.class));
					retValues.add(OthRetDetailsTab);  
					
				}
				
				
				int rpincassrec = fnaRdIncomeAssList.size();
				if(rpincassrec>0){
					
					JSONObject jsnIncDetailsDataObj = new JSONObject();
					JSONObject jsnAssDetailsDataObj = new JSONObject(); 
					JSONArray incjsnArr = new JSONArray();
					JSONArray incassjsnArr = new JSONArray();
					for(FnaRetireplanIncomeasset fnaIncAss : fnaRdIncomeAssList){
						
						String strRpType = fnaIncAss.getRetIaType();
						
						if(!FipaUtils.nullOrBlank(strRpType)){ 
							
							if(strRpType.equalsIgnoreCase("RETINCOME")){ 
								jsnIncDetailsDataObj.put("fnaId", !FipaUtils.nullObj(fnaIncAss.getFnaSelfspouseDets().getFnaId()) ? fnaIncAss.getFnaSelfspouseDets().getFnaId() : "");
								jsnIncDetailsDataObj.put("txtFldIRId", !FipaUtils.nullOrBlank(fnaIncAss.getIaId()) ? fnaIncAss.getIaId() : "");
								jsnIncDetailsDataObj.put("txtFldIRClsfy", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaClass()) ? fnaIncAss.getRetIaClass() : "");
								jsnIncDetailsDataObj.put("txtFldIRDesc", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaDesc()) ? fnaIncAss.getRetIaDesc() : "");
								jsnIncDetailsDataObj.put("selIRFreq", !FipaUtils.nullOrBlank((fnaIncAss.getRetIaFrequency())) ? fnaIncAss.getRetIaFrequency() : "");
								jsnIncDetailsDataObj.put("txtFldIRAmtofInc", !FipaUtils.nullObj(fnaIncAss.getRetIaAmout()) ? fnaIncAss.getRetIaAmout() : "");
								jsnIncDetailsDataObj.put("txtFldIREslrate", !FipaUtils.nullObj(fnaIncAss.getRetIaEscrate()) ? fnaIncAss.getRetIaEscrate() : "");
								jsnIncDetailsDataObj.put("txtFldIRRoi", !FipaUtils.nullObj(fnaIncAss.getRetIaRoi()) ? fnaIncAss.getRetIaRoi() : "");
								jsnIncDetailsDataObj.put("selIRAgeBsOn", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaAgebasedon()) ? fnaIncAss.getRetIaAgebasedon() : "");
								jsnIncDetailsDataObj.put("txtFldIRAgePaySts", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaAgestart()) ? fnaIncAss.getRetIaAgestart() : "");
								jsnIncDetailsDataObj.put("txtFldIRAgePayends", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaAgeend()) ? fnaIncAss.getRetIaAgeend() : "");
							 	incjsnArr.add(jsnIncDetailsDataObj); 
							
							}
						
							if(strRpType.equalsIgnoreCase("RETINCOMEASS")){ 				
								jsnAssDetailsDataObj.put("fnaId",  !FipaUtils.nullObj(fnaIncAss.getFnaSelfspouseDets().getFnaId()) ? fnaIncAss.getFnaSelfspouseDets().getFnaId() : "");
								jsnAssDetailsDataObj.put("txtFldIncAssId", !FipaUtils.nullOrBlank(fnaIncAss.getIaId()) ? fnaIncAss.getIaId() : "");
								jsnAssDetailsDataObj.put("txtFldIncAssClsfy", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaClass()) ? fnaIncAss.getRetIaClass() : "");
								jsnAssDetailsDataObj.put("txtFldIncAssDesc", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaDesc()) ? fnaIncAss.getRetIaDesc() : "");
								jsnAssDetailsDataObj.put("selIncAssFreq",  !FipaUtils.nullOrBlank((fnaIncAss.getRetIaFrequency())) ? fnaIncAss.getRetIaFrequency() : "");
								jsnAssDetailsDataObj.put("txtFldIncAssAmtofInc", !FipaUtils.nullObj(fnaIncAss.getRetIaAmout()) ? fnaIncAss.getRetIaAmout() : "");
								jsnAssDetailsDataObj.put("txtFldIncAssEslrate", !FipaUtils.nullObj(fnaIncAss.getRetIaEscrate()) ? fnaIncAss.getRetIaEscrate() : "");
								jsnAssDetailsDataObj.put("txtFldIncAssRoi",!FipaUtils.nullObj(fnaIncAss.getRetIaRoi()) ? fnaIncAss.getRetIaRoi() : "");
								jsnAssDetailsDataObj.put("selIncAssAgeBsOn", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaAgebasedon()) ? fnaIncAss.getRetIaAgebasedon() : "");
								jsnAssDetailsDataObj.put("txtFldIncAssAgePaySts", !FipaUtils.nullOrBlank(fnaIncAss.getRetIaAgestart()) ? fnaIncAss.getRetIaAgestart() : "");
								jsnAssDetailsDataObj.put("txtFldIncAssAgePayends",!FipaUtils.nullOrBlank(fnaIncAss.getRetIaAgeend()) ? fnaIncAss.getRetIaAgeend() : "");
							 	incassjsnArr.add(jsnAssDetailsDataObj); 
								
						 }
				    }  
				}	
					
				FnaRdIncTab.put("RDINCOME_DETS",incjsnArr);
				FnaRdIncAssTab.put("RDINCASS_DETS",incassjsnArr); 
				
				retValues.add(FnaRdIncTab); 
				retValues.add(FnaRdIncAssTab);			

				
			}
				
				int otharearec = OthAreaCnDetsList.size();
				if(otharearec>0){
					OthAreaCrnDetailsTab.put("OTHAREA_DETS",FipaUtils.getPropsJsonArray(OthAreaCnDetsList, FnaOthareaconcern.class));
					retValues.add(OthAreaCrnDetailsTab);
					
					
				}
				
				int newplanrec = RcmPrdTabDetsList.size();
				if(newplanrec>0){
					RcmPrdDetailsTab.put("RCMPRO_DETS", FipaUtils.getPropsJsonArray(RcmPrdTabDetsList, FnaRecomPrdtplanDet.class)); 
					retValues.add(RcmPrdDetailsTab);

					
				}
				int newfundrec = RcmPrdFundTabDetsList.size();
				if(newfundrec>0){
					RcmPrdFundDetailsTab.put("RCMFUND_DETS", FipaUtils.getPropsJsonArray(RcmPrdFundTabDetsList, FnaRecomFundDet.class));
					retValues.add(RcmPrdFundDetailsTab);
					
				}
				
				int swplanrec = SwtPlanTabDetsList.size();
				if(swplanrec>0){
					SwtchPlnDetailsTab.put("SWTHPLAN_DETS", FipaUtils.getPropsJsonArray(SwtPlanTabDetsList, FnaSwtchrepPlanDet.class));
					
					retValues.add(SwtchPlnDetailsTab);
					
				}
				
				int swfundrec = SwtFundTabDetsList.size();
				if(swfundrec>0){
					SwtchFundDetailsTab.put("SWTHFUND_DETS", FipaUtils.getPropsJsonArray(SwtFundTabDetsList, FnaSwtchrepFundDet.class));
					retValues.add(SwtchFundDetailsTab);
					
					
				}
				int riskprerec = rskprefDetsList.size();						
				if(riskprerec>0){
					rskprefDetsTab.put("RSKPREF_DETS", FipaUtils.getPropsJsonObject(rskprefDetsList,  FnaRiskprefDets.class));
					retValues.add(rskprefDetsTab);			
					
				}
				
				int recomrec = RecmResonList.size();
				if(recomrec>0){
					ReasonsDetailsTab.put("RCMRSN",FipaUtils.getPropsJsonArray(RecmResonList, FnaRecomReasons.class));
					retValues.add(ReasonsDetailsTab); 
					
				}
				
				int sumanarec = sumanalDetsList.size();
				if(sumanarec>0){
					sumanalDetsTab.put("SUMANAL_DETS", FipaUtils.getPropsJsonObject(sumanalDetsList,  FnaSummaryAnalysis.class));
					retValues.add(sumanalDetsTab);
				}		
				
				
			}
			
 
			 
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error(ex.getLocalizedMessage());
		}
 		
		return retValues;
 		
	}
	
	
	
	public JSONArray getCustomerDetsFromFPMS(HttpServletRequest request){
		 
		
		JSONArray retValues = new JSONArray();
		
		JSONObject clntDataJsnObj = new JSONObject();
		
		JSONObject jsnObjTab =  new JSONObject();
		
		JSONArray clntDataJsnArr = new JSONArray();
			
			
		FPMSDataService serv=new FPMSDataService(); 
		
		try{
		
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();			
			DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");				
			
			String strCustName = FipaUtils.getParamValue(request, "strClientName");
			strCustName = java.net.URLDecoder.decode(strCustName,"UTF-8");
			
			String strCustNric = FipaUtils.getParamValue(request, "strClientNRIC");
			strCustNric = java.net.URLDecoder.decode(strCustNric,"UTF-8");
			
			String strCustId = FipaUtils.getParamValue(request, "strCustId");
			
			List clientTabDetsList = new ArrayList();
			clientTabDetsList = serv.getCustomerDetsFromFPMS(dao,strCustName,strCustNric,strCustId);
			
			
				
			int clientTabSize = clientTabDetsList.size();
			
			
			
			if(clientTabSize > 0){
				Iterator it = clientTabDetsList.iterator();
				while(it.hasNext()){
					
					Object[] objs = (Object[]) it.next();
					
					clntDataJsnObj.put("fpmsCustid",FipaUtils.getObjValue(objs[0]));
					clntDataJsnObj.put("dfSelfName",FipaUtils.getObjValue(objs[2]));
					clntDataJsnObj.put("dfSelfNric",FipaUtils.getObjValue(objs[4]));
					clntDataJsnObj.put("advstfId",FipaUtils.getObjValue(objs[7]));
					clntDataJsnObj.put("dfSelfCompname",FipaUtils.getObjValue(objs[9]));
					clntDataJsnObj.put("dfSelfOccpn",FipaUtils.getObjValue(objs[11]));
					
					String strHomeAdd1 = FipaUtils.getObjValue(objs[13]),
							strHomeAdd2 = FipaUtils.getObjValue(objs[14]),
							strCountry = FipaUtils.getObjValue(objs[18]),
							strPostal = FipaUtils.getObjValue(objs[19]);
					
					clntDataJsnObj.put("dfSelfHomeaddr",strHomeAdd1);					
					clntDataJsnObj.put("dfSelfHomeaddr2",strHomeAdd2);
					clntDataJsnObj.put("dfSelfHomeaddr3",FipaUtils.getObjValue(objs[15]));
					clntDataJsnObj.put("dfSelfHomeCity",FipaUtils.getObjValue(objs[16]));
					clntDataJsnObj.put("dfSelfHomeState",FipaUtils.getObjValue(objs[17]));
					clntDataJsnObj.put("dfSelfHomecntry",strCountry);
					clntDataJsnObj.put("dfSelfHomepostal",strPostal);	
					
					clntDataJsnObj.put("dfSelfFax",FipaUtils.getObjValue(objs[20]));
					clntDataJsnObj.put("dfSelfHome",FipaUtils.getObjValue(objs[21]));
					clntDataJsnObj.put("dfSelfMobile",FipaUtils.getObjValue(objs[22]));
					
					String strMailAdd1 = FipaUtils.getObjValue(objs[33]),
							strMailAdd2 = FipaUtils.getObjValue(objs[34]),
							strMailContry = FipaUtils.getObjValue(objs[38]),
							strMailPostal = FipaUtils.getObjValue(objs[39]);
					
					clntDataJsnObj.put("dfSelfMailaddr",strMailAdd1);				
					clntDataJsnObj.put("dfSelfMailaddr2",strMailAdd2);
					clntDataJsnObj.put("dfSelfMailaddr3",FipaUtils.getObjValue(objs[35]));
					clntDataJsnObj.put("dfSelfMailCity",FipaUtils.getObjValue(objs[36]));
					clntDataJsnObj.put("dfSelfMailState",FipaUtils.getObjValue(objs[37]));
					clntDataJsnObj.put("dfSelfMailcntry",strMailContry);
					clntDataJsnObj.put("dfSelfMailpostal",strMailPostal);					
					
					clntDataJsnObj.put("dfSelfDob",FipaDateUtils.formatDate((Date)objs[41]));
					clntDataJsnObj.put("dfSelfMartsts",FipaUtils.getObjValue(objs[42]));
					clntDataJsnObj.put("dfSelfGender",FipaUtils.getObjValue(objs[43]));
					
					clntDataJsnObj.put("dfSelfPersemail",FipaUtils.getObjValue(objs[44]));
					clntDataJsnObj.put("dfSelfSmoking",FipaUtils.getObjValue(objs[46]));
					clntDataJsnObj.put("dfSelfNationality",FipaUtils.getObjValue(objs[48]));	
					clntDataJsnObj.put("dfSelfAnnlincome",FipaUtils.getObjValue(objs[53]));				
					
					
					if(strHomeAdd1.equalsIgnoreCase(strMailAdd1) &&  strHomeAdd2.equalsIgnoreCase(strMailAdd2) &&
							strCountry.equalsIgnoreCase(strMailContry) && strPostal.equalsIgnoreCase(strMailPostal)) {
						clntDataJsnObj.put("dfSelfRegmailaddrSame","Y");		
					}else {
						clntDataJsnObj.put("dfSelfRegmailaddrSame","N");
					} 
					
					clntDataJsnObj.put("dfSpsNric",FipaUtils.getObjValue(objs[56]));			
					clntDataJsnObj.put("dfSpsName",FipaUtils.getObjValue(objs[57]));			
					clntDataJsnObj.put("dfSpsAge",FipaUtils.getObjValue(objs[60]));			
					clntDataJsnObj.put("dfSpsGender",FipaUtils.getObjValue(objs[62]));			
					clntDataJsnObj.put("dfSpsDob",FipaDateUtils.formatDate((Date)objs[64]));			
//					clntDataJsnObj.put("dfSpsMartsts",FipaUtils.getObjValue(objs[65]));			
					clntDataJsnObj.put("dfSpsAnnlincome",FipaUtils.getObjValue(objs[66]));			
					  
					clntDataJsnArr.add(clntDataJsnObj);	
					
				}
				
				jsnObjTab.put("FPMS_CUSTOMER_DETAILS", clntDataJsnArr);
			}
			
			JSONObject polJsnObj = getFPMSPolDets(dao, strCustName, strCustNric,strCustId);
			
			retValues.add(jsnObjTab);
			retValues.add(polJsnObj);  
//			System.out.println(retValues);
			
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error(ex.getMessage());
		}
		
		return retValues;
		
	}
	
	 
	 public JSONArray checkExistingNRIC(HttpServletRequest request){
		 
		JSONArray retValues = new JSONArray();
		
		JSONObject nricDataJsnObj = new JSONObject();
		JSONObject nricTabJsnObj =  new JSONObject();
		JSONArray nricDataJsnArr = new JSONArray();
		
		List clientSearchList = new ArrayList();		
		ClientService serv=new ClientService(); 

		
		try{
		
			ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
			
			DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
			
				 
			String strCustNric = FipaUtils.getParamValue(request, "strSrchClntNric");
			strCustNric = java.net.URLDecoder.decode(strCustNric,"UTF-8");
			strCustNric= strCustNric.replace("\'", "\''");
			
			
			String strCustNricType =  FipaUtils.getParamValue(request, "strSrchClntNricType");
			strCustNricType = java.net.URLDecoder.decode(strCustNricType,"UTF-8");
			
			
			
			
			StringBuffer strBufQryParam = new StringBuffer();
		 
			
			if(!FipaUtils.nullOrBlank(strCustNric)){
				strBufQryParam.append(" and UPPER(cust.DF_SELF_NRIC) = '").append(strCustNric.toUpperCase()).append("'");
				
			} 
			if(!FipaUtils.nullOrBlank(strCustNricType)){
				strBufQryParam.append(" and UPPER(cust.DF_SELF_IDTYPE) = '").append(strCustNricType.toUpperCase()).append("'");
				
			}
			  
			
			clientSearchList = serv.clientNRICSearch(dao,strBufQryParam.toString());
			
			if(clientSearchList.size() > 0){
				
				Iterator it = clientSearchList.iterator();
				
				String strContDets  = "";
//				int jsonSize=0;
				
				int sino=0;
				while(it.hasNext()){
					
					Object[] client = (Object[]) it.next();					
					
					nricDataJsnObj.put("dfSelfNricName", FipaUtils.getObjValue(client[0]));
					nricDataJsnObj.put("dfSelfNric", FipaUtils.getObjValue(client[1]));
						 
											
					nricDataJsnArr.add(nricDataJsnObj);
//						jsonSize = nricDataJsnArr.size();
						
				}
				
				nricTabJsnObj.put("CLIENT_NRIC_SRCH", nricDataJsnArr);
			}
			else{
				
				nricTabJsnObj.put("CLIENT_NRIC_SRCH_NOREC", "");
				
			}
			
			
	
			retValues.add(nricTabJsnObj);
			 
			
			
		}catch(Exception ex){
		ex.printStackTrace();	
		}
		
		return retValues;
		
	}
	
	 
	 
	 public JSONArray getLifeInsuranceDets(HttpServletRequest request){
			
//			logger.info(" ------> Inside getLifeInsuranceDets"); 
			
			JSONArray retValues = new JSONArray();
			
			JSONObject lifeDataJsnObj = new JSONObject();
			JSONObject lifeTabJsnObj =  new JSONObject();
			JSONArray lifeDataJsnArr = new JSONArray();
			
			

			List<FnaLifeinsuranceDets> LifeInsSearchList = new ArrayList();	 
			List<FnaLifeinsuranceCoverages> LifeCovSearchList = new ArrayList();
			
			/*Death Benf*/ 
			JSONObject lifeDfJsnObj = new JSONObject();
			JSONObject lifeDfTabJsnObj =  new JSONObject();
			JSONArray lifeDfJsnArr = new JSONArray();
			
			/*Critical illness*/ 
			JSONObject lifeClJsnObj = new JSONObject();
			JSONObject lifeClTabJsnObj =  new JSONObject();
			JSONArray lifeClJsnArr = new JSONArray();
			
			/*Hospitality*/ 
			JSONObject lifeHpJsnObj = new JSONObject();
			JSONObject lifeHpTabJsnObj =  new JSONObject();
			JSONArray lifeHpJsnArr = new JSONArray();
			
			
			/*Life Plan PRo Dets*/
			List LifePlanSearchList = new ArrayList(); 
			JSONObject lifePlnJsnObj = new JSONObject();
			JSONObject lifePlnTabJsnObj =  new JSONObject();
			JSONArray lifePlnDataJsnArr = new JSONArray();
			
			
			/*Life Benefits Dets*/
			
			JSONObject lifeBenfDataJsnObj = new JSONObject();
			JSONObject lifeBenfTabJsnObj =  new JSONObject();
			JSONArray lifeBenfDataJsnArr = new JSONArray();
			
			List LifeBenfSearchList = new ArrayList();
			/*Life Child Education Dets*/
			JSONObject lifeChldEduDataJsnObj = new JSONObject();
			JSONObject lifeChldEduTabJsnObj =  new JSONObject();
			JSONArray lifeChldEduDataJsnArr = new JSONArray();
			JSONObject liChldEduDetsTab = new JSONObject();
			List LifeChldEduSearchList = new ArrayList(); 
			/*Life MV Retirement Dets*/
			JSONObject lifeMVDataJsnObj = new JSONObject();
			JSONObject lifeMVTabJsnObj =  new JSONObject();
			JSONArray lifeMVDataJsnArr = new JSONArray();
			
			List LifeMVSearchList = new ArrayList();
			/*Life Nominees Dets*/
			JSONObject lifeNomDataJsnObj = new JSONObject();
			JSONObject lifeNomTabJsnObj =  new JSONObject();
			JSONArray lifeNomDataJsnArr = new JSONArray();
			
			List LifeNomSearchList = new ArrayList();
			
			ClientService serv=new ClientService(); 

			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				
					 
				String strSrchlifeInsId = FipaUtils.getParamValue(request, "strSrchlifeInsId");
				strSrchlifeInsId = java.net.URLDecoder.decode(strSrchlifeInsId,"UTF-8");
				 
				
//				StringBuffer strBufQryParam = new StringBuffer();
			 
				
//				if(!FipaUtils.nullOrBlank(strSrchlifeInsId)){
//					strBufQryParam.append(" and UPPER(life.LIP_ID) = '").append(strSrchlifeInsId.toUpperCase()).append("'");
					
//				} 
				  
				LifeInsSearchList = serv.clntLifeInsSearch(dao,strSrchlifeInsId);//LI 
				LifeCovSearchList = serv.clntLifeCovSearch(dao,strSrchlifeInsId);//COV (DEATH BENEFIT~CRITICAL ILLNESS~HOSPITALITY) 
				LifePlanSearchList = serv.clntLifePlanDetsSearch(dao,strSrchlifeInsId);//PLAN DETS 
				LifeBenfSearchList = serv.clntLifeBenfSearch(dao,strSrchlifeInsId);//DISBILTY
				LifeChldEduSearchList = serv.clntLifeChldEduSearch(dao,strSrchlifeInsId);//EDucation
				LifeMVSearchList = serv.clntLifeMVSearch(dao,strSrchlifeInsId);//Retirement Plg
				LifeNomSearchList = serv.clntLifeNomSearch(dao,strSrchlifeInsId);//Nomination
				
				if(LifeInsSearchList.size() > 0){ 
					Iterator it = LifeInsSearchList.iterator();
					 
					while(it.hasNext()){
						
						FnaLifeinsuranceDets lifeins = (FnaLifeinsuranceDets) it.next();
						lifeDataJsnObj.put("lipId",  FipaUtils.getObjValue(lifeins.getLipId()));
						lifeDataJsnObj.put("lipOwner",  FipaUtils.getObjValue(lifeins.getLipOwner()));
						lifeDataJsnObj.put("lipAssured",  FipaUtils.getObjValue(lifeins.getLipAssured()));
						lifeDataJsnObj.put("lipCompany",  FipaUtils.getObjValue(lifeins.getLipCompany()));
						lifeDataJsnObj.put("lipPolicyno",  FipaUtils.getObjValue(lifeins.getLipPolicyno()));
						lifeDataJsnObj.put("lipPlantype",  FipaUtils.getObjValue(lifeins.getLipPlantype()));
						lifeDataJsnObj.put("lipPaymentfreq",  FipaUtils.getObjValue(lifeins.getLipPaymentfreq()));
						lifeDataJsnObj.put("lipPaymentmethod",  FipaUtils.getObjValue(lifeins.getLipPaymentmethod()));
						lifeDataJsnObj.put("lipPremiumsrc",  FipaUtils.getObjValue(lifeins.getLipPremiumsrc())); 
						lifeDataJsnObj.put("lipIncepdate", FipaUtils.getObjValue(lifeins.getLipIncepdate()));
						lifeDataJsnObj.put("lipSa",  FipaUtils.getObjValue(lifeins.getLipSa()));
						lifeDataJsnObj.put("policyStatus",  FipaUtils.getObjValue(lifeins.getPolicyStatus()));
						lifeDataJsnObj.put("lipPlanname",   FipaUtils.getObjValue(lifeins.getLipPlanname()));
						lifeDataJsnObj.put("lipCoveragetype",  FipaUtils.getObjValue(lifeins.getLipCoveragetype()));
						lifeDataJsnObj.put("lipIsnurObject",  FipaUtils.getObjValue(lifeins.getLipIsnurObject()));
						lifeDataJsnObj.put("lipCurrBonusAcc",  FipaUtils.getObjValue(lifeins.getLipCurrBonusAcc()));
						lifeDataJsnObj.put("lipCurrCashVal",  FipaUtils.getObjValue(lifeins.getLipCurrCashVal()));
						lifeDataJsnObj.put("lipMaturityVal",  FipaUtils.getObjValue(lifeins.getLipMaturityVal()));
						lifeDataJsnObj.put("lipMaturityDate",  FipaUtils.getObjValue(lifeins.getLipMaturityDate()));
						lifeDataJsnObj.put("osLoan",  FipaUtils.getObjValue(lifeins.getOsLoan()));
						lifeDataJsnObj.put("nominationType",  FipaUtils.getObjValue(lifeins.getNominationType()));
						lifeDataJsnObj.put("thirdpartyName",  FipaUtils.getObjValue(lifeins.getThirdpartyName()));
						lifeDataJsnObj.put("lfretYrstoret",  FipaUtils.getObjValue(lifeins.getLfretYrstoret()));
						lifeDataJsnObj.put("retSelfretage",  FipaUtils.getObjValue(lifeins.getRetSelfretage()));
						lifeDataJsnObj.put("retSpouseretage",  FipaUtils.getObjValue(lifeins.getRetSpouseretage()));
						lifeDataJsnObj.put("retMultionret",  FipaUtils.getObjValue(lifeins.getRetMultionret()));
						lifeDataJsnObj.put("retCashvalonret",  FipaUtils.getObjValue(lifeins.getRetCashvalonret()));
						lifeDataJsnObj.put("retIntrateused",  FipaUtils.getObjValue(lifeins.getRetIntrateused()));
						lifeDataJsnObj.put("retPrcnttoused", FipaUtils.getObjValue(lifeins.getRetPrcnttoused())); 
						lifeDataJsnObj.put("lipRemarks",  FipaUtils.getObjValue(lifeins.getLipRemarks()));
						lifeDataJsnObj.put("lipCreatedBy",  FipaUtils.getObjValue(lifeins.getLipCreatedBy()));
						lifeDataJsnObj.put("lipCreatedDate", FipaUtils.getObjValue(lifeins.getLipCreatedDate()));
						
						lifeDataJsnArr.add(lifeDataJsnObj); 
					}
					
					lifeTabJsnObj.put("CLIENT_LIFEDATA_SRCH", lifeDataJsnArr);
				}else{
					
					lifeTabJsnObj.put("CLIENT_LIFEDATA_SRCH_NOREC", "");
					
				}
				 
				
				/*Life Coverage Dets*/
				if(LifeCovSearchList.size() > 0){ 
				Iterator it = LifeCovSearchList.iterator();
				 
				while(it.hasNext()){
					
					FnaLifeinsuranceCoverages cltliCov = (FnaLifeinsuranceCoverages) it.next();
					
					String CoverName=FipaUtils.getObjValue(FipaUtils.nullOrBlank(cltliCov.getCoverName())?"":cltliCov.getCoverName());
					 
					
					if(CoverName.equalsIgnoreCase("DEATH BENEFIT")){
						

						lifeDfJsnObj.put("coverId", FipaUtils.getObjValue(cltliCov.getCoverId()));
						lifeDfJsnObj.put("coverPlanname", FipaUtils.getObjValue(cltliCov.getCoverPlanname()));
						lifeDfJsnObj.put("effDate",FipaUtils.getObjValue(cltliCov.getEffDate()));
						lifeDfJsnObj.put("expiryDate", FipaUtils.getObjValue(cltliCov.getExpiryDate()));
						lifeDfJsnObj.put("coverageTerm", FipaUtils.getObjValue(cltliCov.getCoverageTerm()));
						lifeDfJsnObj.put("coverSumAssured", FipaUtils.getObjValue(cltliCov.getCoverSumAssured()));
						lifeDfJsnObj.put("coverCreatedBy",FipaUtils.getObjValue(cltliCov.getCoverCreatedBy()));
						lifeDfJsnObj.put("coverCreatedDate", FipaUtils.getObjValue(cltliCov.getCoverCreatedDate()));
						
						lifeDfJsnArr.add(lifeDfJsnObj); 
					}
					
					
					if(CoverName.equalsIgnoreCase("CRITICAL ILLNESS")){
						
						lifeClJsnObj.put("coverId", FipaUtils.getObjValue(cltliCov.getCoverId()));
						lifeClJsnObj.put("coverLevelortype", FipaUtils.getObjValue(cltliCov.getCoverLevelortype()));
						lifeClJsnObj.put("expiryDate", FipaUtils.getObjValue(cltliCov.getExpiryDate()));
						lifeClJsnObj.put("coverSumAssured", FipaUtils.getObjValue(cltliCov.getCoverSumAssured()));
						lifeClJsnObj.put("coverageTerm", FipaUtils.getObjValue(cltliCov.getCoverageTerm()));
						lifeClJsnObj.put("coverRemarks", FipaUtils.getObjValue(cltliCov.getCoverRemarks()));
						lifeClJsnObj.put("coverCreatedBy", FipaUtils.getObjValue(cltliCov.getCoverCreatedBy()));
						lifeClJsnObj.put("coverCreatedDate", FipaUtils.getObjValue(cltliCov.getCoverCreatedDate()));
						
						lifeClJsnArr.add(lifeClJsnObj); 
											
											
					}
					
					if(CoverName.equalsIgnoreCase("HOSPITALITY")){
						lifeHpJsnObj.put("coverId", FipaUtils.getObjValue(cltliCov.getCoverId()));
						lifeHpJsnObj.put("coverBasorrid", FipaUtils.getObjValue(cltliCov.getCoverBasorrid()));
						lifeHpJsnObj.put("coverageTerm", FipaUtils.getObjValue(cltliCov.getCoverageTerm()));
						lifeHpJsnObj.put("coverDeductable", FipaUtils.getObjValue(cltliCov.getCoverDeductable()));
						lifeHpJsnObj.put("coInsurance", FipaUtils.getObjValue(cltliCov.getCoInsurance()));
						lifeHpJsnObj.put("coverCreatedBy",FipaUtils.getObjValue(cltliCov.getCoverCreatedBy()));
						lifeHpJsnObj.put("coverCreatedDate",FipaUtils.getObjValue(cltliCov.getCoverCreatedDate()));
					 
						lifeHpJsnArr.add(lifeHpJsnObj); 
						
							
						
					}
					
				}
				
				
				lifeDfTabJsnObj.put("CLIENT_DEATHBENF_SRCH", lifeDfJsnArr);
				lifeClTabJsnObj.put("CLIENT_CRITICAL_SRCH",lifeClJsnArr);
				lifeHpTabJsnObj.put("CLIENT_HOSP_SRCH", lifeHpJsnArr);
				
				
				
				
				} 
				
				/*Plan Pro*/
				lifePlnTabJsnObj.put("CLIENT_PLANPRO_SRCH", FipaUtils.getPropsJsonArray(LifePlanSearchList, FnaLifeinsuranceBasicriders.class));
				
				
			
				/*Life Benefits Dets*/
				lifeBenfTabJsnObj.put("CLIENT_BENEFDATA_SRCH", FipaUtils.getPropsJsonArray(LifeBenfSearchList, FnaLifeinsuranceDisablebenfs.class));
				  
				 
				/*Life Child Education Dets*/
				lifeChldEduTabJsnObj.put("CLIENT_CHLDEDUDATA_SRCH", FipaUtils.getPropsJsonArray(LifeChldEduSearchList, FnaLifeinsuranceChildedc.class));
				
				  
				/*Life MV Retirement Dets*/
				lifeMVTabJsnObj.put("CLIENT_MVDATA_SRCH", FipaUtils.getPropsJsonArray(LifeMVSearchList, FnaLifeinsuranceMvRet.class));
				 
				
				/*Life Nominees Dets*/
				lifeNomTabJsnObj.put("CLIENT_NOMDATA_SRCH", FipaUtils.getPropsJsonArray(LifeNomSearchList, FnaLifeinsuranceNominees.class));
				
				 
				
				
				retValues.add(lifeTabJsnObj);//life insurance
				retValues.add(lifeDfTabJsnObj); //death benefit
				retValues.add(lifeClTabJsnObj); //critical illness
				retValues.add(lifeHpTabJsnObj); //hospitality
				retValues.add(lifeBenfTabJsnObj);//Disablity benefits
				retValues.add(lifeChldEduTabJsnObj); //Education Plg
				retValues.add(lifeMVTabJsnObj);//Retirement Plg
				retValues.add(lifeNomTabJsnObj);//Nomination
				retValues.add(lifePlnTabJsnObj);
				 
			}catch(Exception ex){
				ex.printStackTrace();	
			}
			
			return retValues;
			
		}
	 
	 public JSONArray deleteLifeInsuranceDets(HttpServletRequest request){
			 
			
			JSONArray retValues = new JSONArray(); 
			JSONObject DataJsnObj = new JSONObject();
			ClientDB clientDB=new ClientDB(); 

			 Map<String,Object> objMapping  = new HashMap();
			 objMapping = FipaUtils.getRequestMapping(request);
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				
					 
				String strLICId = FipaUtils.getParamValue(request, "strlifeInsId");
				strLICId = java.net.URLDecoder.decode(strLICId,"UTF-8");
				
				
				String strClientId = FipaUtils.getParamValue(request, "strlifeFnaId");
				strClientId = java.net.URLDecoder.decode(strClientId,"UTF-8");
				 
				/*Plan Details*/ 
				clientDB.deletePlnProdetails(strLICId); 
				
				/*Nominees Details*/ 
				clientDB.deleteNomineeNamedetails(strLICId); 
				
				
				/*Disability Details*/ 
				clientDB.deleteBenefdetails(strLICId); 
				
				 
				/*Retirement Details*/ 
				clientDB.deleteRetPlgdetails(strLICId); 
				
				
				/*Coverages Details*/ 
				clientDB.deleteCoveragesdetails(strLICId); 
				
				/*Education Details*/ 
				clientDB.deleteEduPlgdetails(strLICId);  
				
				/*Life Insurance Details*/
				clientDB.deleteLifeInsurceDetails(strClientId,strLICId);
				 
				DataJsnObj.put("TARGET", "Delete completed");
				retValues.add(DataJsnObj);
				 
			}catch(Exception ex){
				ex.printStackTrace();	
			}
			
			return retValues;
			
		}
	 
	 public JSONArray getFPMSlifeDets(HttpServletRequest request){
			 
			JSONArray retValues = new JSONArray();
			
			JSONObject lifeDataJsnObj = new JSONObject();
			JSONObject lifeTabJsnObj =  new JSONObject();
			JSONArray lifeDataJsnArr = new JSONArray(); 
			
			
			JSONObject polDataJsnObj = new JSONObject();
			 JSONObject polPlanDataJsnObj = new JSONObject();
				JSONObject jsnObjPolTab =  new JSONObject();
				JSONArray polDataJsnArr = new JSONArray();
				JSONArray polPlanDataJsnArr = new JSONArray();
				JSONObject jsnObjPolPlanTab =  new JSONObject();
				
			List  policyPlanDetList = new ArrayList();	 
			 List policyDetList =new ArrayList();
			 
			 FPMSDataService serv = new FPMSDataService();
			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				 
				String strSrchAppId = FipaUtils.getParamValue(request, "strSrchAppId");
				strSrchAppId = java.net.URLDecoder.decode(strSrchAppId,"UTF-8");
				
				
				StringBuffer strBufQryParam = new StringBuffer();
			 
				 
				if(!FipaUtils.nullOrBlank(strSrchAppId)){
					strBufQryParam.append(" and UPPER(life.APPID) = '").append(strSrchAppId.toUpperCase()).append("'");
					
				} 

			
				policyDetList = serv.getFPMSLifeInsuracePolDets(dao, "","","",strSrchAppId);
				policyPlanDetList = serv.getLifeInsuracePlanDets(dao, "","","",strSrchAppId);
				
				int polCnt = policyDetList.size();
				int polPlanCnt = policyPlanDetList.size();
			 
				if(polCnt > 0){
					
					

					Iterator it = policyDetList.iterator();
					while(it.hasNext()){
						Object[] polObjs = (Object[]) it.next();
						
						polDataJsnObj.put("strFPMSPolOwner",(FipaUtils.checkNullVal(polObjs[2])?"":polObjs[2].toString()));
						polDataJsnObj.put("strFPMSPolOwnerNRIC",(FipaUtils.checkNullVal(polObjs[3])?"":polObjs[3].toString()));
						polDataJsnObj.put("strFPMSPolPlanName",(FipaUtils.checkNullVal(polObjs[4])?"":polObjs[4].toString()));
						polDataJsnObj.put("strFPMSPolPolNo",(FipaUtils.checkNullVal(polObjs[5])?"":polObjs[5].toString()));
						polDataJsnObj.put("strFPMSPolPrincipal",(FipaUtils.checkNullVal(polObjs[6])?"":polObjs[6].toString()));
						polDataJsnObj.put("strFPMSPolPremiumType",(FipaUtils.checkNullVal(polObjs[7])?"":polObjs[7].toString()));
						polDataJsnObj.put("strFPMSPolPremium",(FipaUtils.checkNullVal(polObjs[8])?"":polObjs[8].toString()));
						polDataJsnObj.put("strFPMSPolSA",(FipaUtils.checkNullVal(polObjs[9])?"":polObjs[9].toString()));
						polDataJsnObj.put("strFPMSPolPaymentMode",(FipaUtils.checkNullVal(polObjs[10])?"":polObjs[10].toString()));
						polDataJsnObj.put("strFPMSPolPaymentMeth",(FipaUtils.checkNullVal(polObjs[11])?"":polObjs[11].toString()));
						polDataJsnObj.put("strFPMSPolEffDate",(FipaUtils.checkNullVal(polObjs[12])?"":polObjs[12].toString()));
						polDataJsnObj.put("strFPMSPolRenDate",(FipaUtils.checkNullVal(polObjs[13])?"":polObjs[13].toString()));
						polDataJsnObj.put("strFPMSPolStatus",(FipaUtils.checkNullVal(polObjs[15])?"":polObjs[15].toString()));
						polDataJsnObj.put("strFPMSPolLOBMain",(FipaUtils.checkNullVal(polObjs[16])?"":polObjs[16].toString()));
						polDataJsnObj.put("strFPMSPolLOBSub",(FipaUtils.checkNullVal(polObjs[17])?"":polObjs[17].toString()));						
						polDataJsnObj.put("strFPMSPolAppId",(FipaUtils.checkNullVal(polObjs[18])?"":polObjs[18].toString()));
						polDataJsnObj.put("strFPMSPolPrincipalId",(FipaUtils.checkNullVal(polObjs[19])?"":polObjs[19].toString()));
						polDataJsnObj.put("strFPMSPolApplnName","FPMSNL");
						polDataJsnArr.add(polDataJsnObj);
					}
					jsnObjPolTab.put("FPMS_POLICY_DETS", polDataJsnArr);				
					
				}
				
				if(polPlanCnt >0){

					Iterator planite = policyPlanDetList.iterator();
					 
					while(planite.hasNext()){
						Object[] polObjs = (Object[]) planite.next();
						
						polPlanDataJsnObj.put("strFPMSPolOwner",(FipaUtils.checkNullVal(polObjs[2])?"":polObjs[2].toString()));
						polPlanDataJsnObj.put("strFPMSPolOwnerNRIC",(FipaUtils.checkNullVal(polObjs[3])?"":polObjs[3].toString()));
						polPlanDataJsnObj.put("strFPMSPolPlanName",(FipaUtils.checkNullVal(polObjs[4])?"":polObjs[4].toString()));
						polPlanDataJsnObj.put("strFPMSPolPolNo",(FipaUtils.checkNullVal(polObjs[5])?"":polObjs[5].toString()));						
						polPlanDataJsnObj.put("strFPMSPolPrincipal",(FipaUtils.checkNullVal(polObjs[6])?"":polObjs[6].toString()));
						polPlanDataJsnObj.put("strFPMSPolPremiumType",(FipaUtils.checkNullVal(polObjs[7])?"":polObjs[7].toString()));
						polPlanDataJsnObj.put("strFPMSPolPremium",(FipaUtils.checkNullVal(polObjs[8])?"":polObjs[8].toString()));
						polPlanDataJsnObj.put("strFPMSPolSA",(FipaUtils.checkNullVal(polObjs[9])?"":polObjs[9].toString()));  
						polPlanDataJsnObj.put("strFPMSPolPaymentMode",(FipaUtils.checkNullVal(polObjs[10])?"":polObjs[10].toString()));
						polPlanDataJsnObj.put("strFPMSPolPaymentMeth",(FipaUtils.checkNullVal(polObjs[11])?"":polObjs[11].toString()));						
						polPlanDataJsnObj.put("strFPMSPolEffDate",(FipaUtils.checkNullVal(polObjs[12])?"":polObjs[12].toString()));
						polPlanDataJsnObj.put("strFPMSPolRenDate",(FipaUtils.checkNullVal(polObjs[13])?"":polObjs[13].toString()));
						polPlanDataJsnObj.put("strFPMSPolPrdtType",(FipaUtils.checkNullVal(polObjs[14])?"":polObjs[14].toString()));
						polPlanDataJsnObj.put("strFPMSPolStatus",(FipaUtils.checkNullVal(polObjs[15])?"":polObjs[15].toString()));
						polPlanDataJsnObj.put("strFPMSPolLOBMain",(FipaUtils.checkNullVal(polObjs[16])?"":polObjs[16].toString()));
						polPlanDataJsnObj.put("strFPMSPolLOBSub",(FipaUtils.checkNullVal(polObjs[17])?"":polObjs[17].toString()));						
						polPlanDataJsnObj.put("strFPMSPolAppId",(FipaUtils.checkNullVal(polObjs[18])?"":polObjs[18].toString()));
						polPlanDataJsnObj.put("strFPMSPolPremTerm",(FipaUtils.checkNullVal(polObjs[19])?"":polObjs[19].toString()));
						polPlanDataJsnObj.put("strFPMSPolRemarks",(FipaUtils.checkNullVal(polObjs[20])?"":polObjs[20].toString()));
						polPlanDataJsnObj.put("strFPMSPolApplnName","FPMSNL");
						polPlanDataJsnArr.add(polPlanDataJsnObj);
						
					}
					
					jsnObjPolPlanTab.put("FPMS_POLICYPLAN_DETS", polPlanDataJsnArr);
				}
				 
				
				retValues.add(jsnObjPolTab);
				retValues.add(jsnObjPolPlanTab); 
				 
			}catch(Exception ex){
				ex.printStackTrace();
				logger.error(ex.getMessage());
			}
			
			return retValues;
			
		}
	 
 
	 
	 public JSONArray getRecomProductName(HttpServletRequest request){
			
//			logger.info(" ------> Inside getRecomProductName Method "); 
			
			JSONArray retValues = new JSONArray();
			
			JSONObject cpfDataJsnObj = new JSONObject();
			JSONObject cpfTabJsnObj =  new JSONObject();
			JSONArray cpfDataJsnArr = new JSONArray();
			
			List cpfSearchList = new ArrayList();		
			ClientService cpfServ=new ClientService(); 

			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				  
				 
				String strRecomProdId = FipaUtils.getParamValue(request, "strSrchRecomProdId");
				strRecomProdId = java.net.URLDecoder.decode(strRecomProdId,"UTF-8");
				 
				
				StringBuffer strCpfBufQryParam = new StringBuffer();
			 
				
				if(!FipaUtils.nullOrBlank(strRecomProdId)){
					strCpfBufQryParam.append(" and rcmPrdt.PRIN_ID = '").append(strRecomProdId).append("'");
					
				}
				
				 
	  
				
				cpfSearchList = cpfServ.rcmPrdtSearch(dao,strCpfBufQryParam.toString());

				if(cpfSearchList.size() > 0){
					
					Iterator it = cpfSearchList.iterator();
					
					String strContDets  = "";
					int jsonSize=0;
					
					int sino=0;
					while(it.hasNext()){
						
						Object[] client = (Object[]) it.next();					
						 
							cpfDataJsnObj.put("txtfldProductid",FipaUtils.getObjValue(client[0]));				
							 
							cpfDataJsnArr.add(cpfDataJsnObj);
							jsonSize = cpfDataJsnArr.size(); 
					}
				}
				else{
					
					cpfTabJsnObj.put("NOREC", "");
					
				}
				
				cpfTabJsnObj.put("PRODUCT_NAME_LIST", cpfDataJsnArr);
		
				retValues.add(cpfTabJsnObj);
//				
//				logger.info("  retValues ------>"+retValues); 
//				
				
			}catch(Exception ex){
			ex.printStackTrace();	
			}
			
			return retValues;
			
		}
	 
	 
	 public JSONArray cpfSearchDetails(HttpServletRequest request){
			
//			logger.info(" ------> Inside cpfSearchDetails Method "); 
			
			JSONArray retValues = new JSONArray();
			
			JSONObject cpfDataJsnObj = new JSONObject();
			JSONObject cpfTabJsnObj =  new JSONObject();
			JSONArray cpfDataJsnArr = new JSONArray();
			
			List cpfSearchList = new ArrayList();		
			MasterCpfService cpfServ=new MasterCpfService(); 

			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				
					
				
				String strCpfAc = FipaUtils.getParamValue(request, "strSrchCpfAccount");
				strCpfAc = java.net.URLDecoder.decode(strCpfAc,"UTF-8");
				
				String strCpfIntMth = FipaUtils.getParamValue(request, "strSrchCpfIntMth");
				strCpfIntMth = java.net.URLDecoder.decode(strCpfIntMth,"UTF-8");
				
				
				StringBuffer strCpfBufQryParam = new StringBuffer();
			 
				
				if(!FipaUtils.nullOrBlank(strCpfAc)){
					strCpfBufQryParam.append(" and cpf.CPF_ACCOUNT = '").append(strCpfAc).append("'");
					
				}
				
				if(!FipaUtils.nullOrBlank(strCpfIntMth)){
					strCpfBufQryParam.append(" and cpf.CPF_INT_MONTH = '").append(strCpfIntMth).append("'");
				}
	 

			  
				
				cpfSearchList = cpfServ.cpfSearch(dao,strCpfBufQryParam.toString());

				if(cpfSearchList.size() > 0){
					
					Iterator it = cpfSearchList.iterator();
					
					String strContDets  = "";
					int jsonSize=0;
					
					int sino=0;
					while(it.hasNext()){
						
						Object[] client = (Object[]) it.next();					
						

							cpfDataJsnObj.put("sino",++sino);
							 
							cpfDataJsnObj.put("txtFldCpfIntId",FipaUtils.getObjValue(client[0]));				
							
							cpfDataJsnObj.put("selCpfAccount", FipaUtils.getObjValue(client[1]));
												
							cpfDataJsnObj.put("txtFldCpfIntRate", FipaUtils.getObjValue(client[2]));
							
							cpfDataJsnObj.put("txtFldCpfIntMonth", FipaUtils.getObjValue(client[3]));
							
							cpfDataJsnObj.put("txtFldCpfCreatedBy", FipaUtils.getObjValue(client[4]));
							
							cpfDataJsnObj.put("txtFldCpfCreatedDate", FipaUtils.getObjValue(client[5]));
							
							  	
							cpfDataJsnArr.add(cpfDataJsnObj);
							jsonSize = cpfDataJsnArr.size(); 
					}
				}
				else{
					
					cpfTabJsnObj.put("CPF_SEARCH_NOREC", "");
					
				}
				
				cpfTabJsnObj.put("CPF_SEARCH", cpfDataJsnArr);
		
				retValues.add(cpfTabJsnObj);
				
//				logger.info("  retValues ------>"+retValues); 
				
				
			}catch(Exception ex){
			ex.printStackTrace();	
			}
			
			return retValues;
			
		}
		
	 
	 
	 
	 
	 
	 
	 
	 public JSONArray cpfCheckExisting(HttpServletRequest request){
			
//			logger.info(" ------> Inside cpfCheckExisting Method "); 
			
			JSONArray retValues = new JSONArray();
			
			JSONObject cpfDataJsnObj = new JSONObject();
			JSONObject cpfTabJsnObj =  new JSONObject();
			JSONArray cpfDataJsnArr = new JSONArray();
			
			List cpfSearchList = new ArrayList();		
			MasterCpfService cpfServ=new MasterCpfService(); 

			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				
					
				
				String strCpfAc = FipaUtils.getParamValue(request, "strSrchCpfAccount");
				strCpfAc = java.net.URLDecoder.decode(strCpfAc,"UTF-8");
				
				String strCpfIntMth = FipaUtils.getParamValue(request, "strSrchCpfIntMth");
				strCpfIntMth = java.net.URLDecoder.decode(strCpfIntMth,"UTF-8");
				
				
				StringBuffer strCpfBufQryParam = new StringBuffer();
			 
				
				if(!FipaUtils.nullOrBlank(strCpfAc)){
					strCpfBufQryParam.append(" and cpf.CPF_ACCOUNT = '").append(strCpfAc).append("'");
					
				}
				
				if(!FipaUtils.nullOrBlank(strCpfIntMth)){
					strCpfBufQryParam.append(" and cpf.CPF_INT_MONTH = '").append(strCpfIntMth).append("'");
				}
	 

			  
				
				cpfSearchList = cpfServ.cpfSrchExisting(dao,strCpfBufQryParam.toString());

				if(cpfSearchList.size() > 0){
					
					Iterator it = cpfSearchList.iterator();
					
					String strContDets  = "";
					int jsonSize=0;
					
					int sino=0;
					while(it.hasNext()){
						
						Object[] client = (Object[]) it.next();					
						

							cpfDataJsnObj.put("sino",++sino);
							 
							cpfDataJsnObj.put("txtFldCpfIntId", FipaUtils.getObjValue(client[0]));				
							
							cpfDataJsnObj.put("selCpfAccount", FipaUtils.getObjValue(client[1]));
												
							cpfDataJsnObj.put("txtFldCpfIntRate", FipaUtils.getObjValue(client[2]));
							
							cpfDataJsnObj.put("txtFldCpfIntMonth", FipaUtils.getObjValue(client[3]));
							
							cpfDataJsnObj.put("txtFldCpfCreatedBy", FipaUtils.getObjValue(client[4]));
							
							cpfDataJsnObj.put("txtFldCpfCreatedDate", FipaUtils.getObjValue(client[5]));
							
							  	
							cpfDataJsnArr.add(cpfDataJsnObj);
							jsonSize = cpfDataJsnArr.size(); 
					}
				}
				else{
					
					cpfTabJsnObj.put("NOREC_FOUND", "");
					
				}
				
				cpfTabJsnObj.put("CPF_ACCOUNT_EXISTED", cpfDataJsnArr);
		
				retValues.add(cpfTabJsnObj);
				
//				logger.info("  retValues ------>"+retValues); 
				
				
			}catch(Exception ex){
			ex.printStackTrace();	
			}
			
			return retValues;
			
		}

	 
	 
	 
	 
	
	 
	 
	 public JSONArray cpfAllocSearchDetails(HttpServletRequest request){
			
//			logger.info(" ------> Inside cpfAllocSearchDetails Method "); 
			
			JSONArray retValues = new JSONArray();
			
			JSONObject cpfAlRateDataJsnObj = new JSONObject();
			JSONObject cpfAlRateTabJsnObj =  new JSONObject();
			JSONArray cpfAlRateDataJsnArr = new JSONArray();
			
			List cpfAlRateSearchList = new ArrayList();		
			MasterCpfService cpfAlRateServ=new MasterCpfService(); 

			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				
					
				
				String strCpfAllocAcType = FipaUtils.getParamValue(request, "strSrchCpfAllocAcType");
				strCpfAllocAcType = java.net.URLDecoder.decode(strCpfAllocAcType,"UTF-8");
				
				String strCpfAllocEffFrm = FipaUtils.getParamValue(request, "strSrchCpfAllocEffFrom");
				strCpfAllocEffFrm = java.net.URLDecoder.decode(strCpfAllocEffFrm,"UTF-8");
				
				
				String strCpfAllocAgeGroup = FipaUtils.getParamValue(request, "strSrchCpfAllocAgeGroup");
				strCpfAllocAgeGroup = java.net.URLDecoder.decode(strCpfAllocAgeGroup,"UTF-8");
				
				 
				
				
				StringBuffer strCpfBufQryParam = new StringBuffer();
			 
				
				if(!FipaUtils.nullOrBlank(strCpfAllocAcType)){
					strCpfBufQryParam.append(" and cpf.ACC_TYPE = '").append(strCpfAllocAcType).append("'"); 
				}
				
				if(!FipaUtils.nullOrBlank(strCpfAllocEffFrm)){
					strCpfBufQryParam.append(" and cpf.EFF_FROM = '").append(strCpfAllocEffFrm).append("'");
				}
	 

				if(!FipaUtils.nullOrBlank(strCpfAllocAgeGroup)){
					strCpfBufQryParam.append(" and cpf.AGE_GRP = '").append(strCpfAllocAgeGroup).append("'");
				}
				 
				
				cpfAlRateSearchList = cpfAlRateServ.cpfAllocRateSearch(dao,strCpfBufQryParam.toString());

				if(cpfAlRateSearchList.size() > 0){
					
					Iterator it = cpfAlRateSearchList.iterator();
					
					String strContDets  = "";
					int jsonSize=0;
					
					int sino=0;
				 
					while(it.hasNext()){
						 
							Object[] client = (Object[]) it.next();					
						
						

							cpfAlRateDataJsnObj.put("sino",++sino);
							 
							cpfAlRateDataJsnObj.put("txtFldCPFAllocId",FipaUtils.getObjValue(client[0]));				
							
							cpfAlRateDataJsnObj.put("txtFldCPFAllocEffFrom", FipaUtils.getObjValue(client[1]));
												
							cpfAlRateDataJsnObj.put("selCPFAllocAgeGrp", FipaUtils.getObjValue(client[2]));
							
							cpfAlRateDataJsnObj.put("selCPFAllocAccType", FipaUtils.getObjValue(client[3]));
							
							cpfAlRateDataJsnObj.put("txtFldCPFAllocRate", FipaUtils.getObjValue(client[4]));
							
							cpfAlRateDataJsnObj.put("txtFldCPFAllocRemarks", FipaUtils.getObjValue(client[5]));
							
							cpfAlRateDataJsnObj.put("txtFldCPFCreatedBy", FipaUtils.getObjValue(client[6]));
							
							cpfAlRateDataJsnObj.put("txtFldCPFCreatedDate", FipaUtils.getObjValue(client[7]));
							  	
							cpfAlRateDataJsnArr.add(cpfAlRateDataJsnObj);
							jsonSize = cpfAlRateDataJsnArr.size(); 
							 
					}
				}
				else{
					
					cpfAlRateTabJsnObj.put("CPF_ALLOC_SEARCH_NOREC", "");
					
				}
				
				cpfAlRateTabJsnObj.put("CPF_ALLOC_SEARCH", cpfAlRateDataJsnArr);
		
				retValues.add(cpfAlRateTabJsnObj);
				
//				logger.info("  retValues ------>"+retValues); 
				
				
			}catch(Exception ex){
			ex.printStackTrace();	
			}
			
			return retValues;
			
		}
	 
	 public JSONArray cpfAllocCheckExisting(HttpServletRequest request){
			
//			logger.info(" ------> Inside cpfAllocCheckExisting Method "); 
			
			JSONArray retValues = new JSONArray();
			
			JSONObject cpfAllcChkDataJsnObj = new JSONObject();
			JSONObject cpfAllcChkTabJsnObj =  new JSONObject();
			JSONArray cpfAllcChkDataJsnArr = new JSONArray();
			
			List cpfAllcChkSearchList = new ArrayList();		
			MasterCpfService cpfAllcChkServ=new MasterCpfService(); 

			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				
					
				
				String strCpfAllocEFrm = FipaUtils.getParamValue(request, "strSrchCpfAllocEFrm");
				strCpfAllocEFrm = java.net.URLDecoder.decode(strCpfAllocEFrm,"UTF-8");
				
				String strCpfAllocAgeGrp = FipaUtils.getParamValue(request, "strSrchCpfAllocAgeGrp");
				strCpfAllocAgeGrp = java.net.URLDecoder.decode(strCpfAllocAgeGrp,"UTF-8");
				
				
				String strCpfAllocAccType = FipaUtils.getParamValue(request, "strSrchCpfAllocAcType");
				strCpfAllocAccType = java.net.URLDecoder.decode(strCpfAllocAccType,"UTF-8");
				
				 
				
				StringBuffer strCpfBufQryParam = new StringBuffer();
			 
				
				if(!FipaUtils.nullOrBlank(strCpfAllocEFrm)){
					strCpfBufQryParam.append(" and cpf.EFF_FROM = '").append(strCpfAllocEFrm).append("'");
					
				}
				
				if(!FipaUtils.nullOrBlank(strCpfAllocAgeGrp)){
					strCpfBufQryParam.append(" and cpf.AGE_GRP = '").append(strCpfAllocAgeGrp).append("'");
				}
	 

				if(!FipaUtils.nullOrBlank(strCpfAllocAccType)){
					strCpfBufQryParam.append(" and cpf.ACC_TYPE = '").append(strCpfAllocAccType).append("'");
				}
				 
				
				cpfAllcChkSearchList = cpfAllcChkServ.cpfAllocSrchExisting(dao,strCpfBufQryParam.toString());

				if(cpfAllcChkSearchList.size() > 0){
					
					Iterator it = cpfAllcChkSearchList.iterator();
					
					String strContDets  = "";
					int jsonSize=0;
					
					int sino=0;
					while(it.hasNext()){
						
						Object[] client = (Object[]) it.next();					
						

						cpfAllcChkDataJsnObj.put("sino",++sino);
						 
						cpfAllcChkDataJsnObj.put("txtFldCPFAllocId",FipaUtils.getObjValue(client[0]));				
						
						cpfAllcChkDataJsnObj.put("txtFldCPFAllocEffFrom", FipaUtils.getObjValue(client[1]));
											
						cpfAllcChkDataJsnObj.put("selCPFAllocAgeGrp", FipaUtils.getObjValue(client[2]));
						
						cpfAllcChkDataJsnObj.put("selCPFAllocAccType", FipaUtils.getObjValue(client[3]));
						
						cpfAllcChkDataJsnObj.put("txtFldCPFAllocRate", FipaUtils.getObjValue(client[4]));
						
						cpfAllcChkDataJsnObj.put("txtFldCPFAllocRemarks", FipaUtils.getObjValue(client[5]));
						
						cpfAllcChkDataJsnObj.put("txtFldCPFCreatedBy", FipaUtils.getObjValue(client[6]));
						
						cpfAllcChkDataJsnObj.put("txtFldCPFCreatedDate", FipaUtils.getObjValue(client[7]));
							
							  	
							cpfAllcChkDataJsnArr.add(cpfAllcChkDataJsnObj);
							jsonSize = cpfAllcChkDataJsnArr.size(); 
					}
				}
				else{
					
					cpfAllcChkTabJsnObj.put("NOREC_FOUND", "");
					
				}
				
				cpfAllcChkTabJsnObj.put("CPF_ALLOC_AC_EXIST", cpfAllcChkDataJsnArr); 
				retValues.add(cpfAllcChkTabJsnObj); 
//				logger.info("  retValues ------>"+retValues); 
				
				
			}catch(Exception ex){
			ex.printStackTrace();	
			}
			
			return retValues;
			
		}
	 
	 public JSONObject getFPMSPolDets(DBInterface dao,String strCustName,String strCustNric,String strCustId){
		 
		 
		 FPMSDataService serv = new FPMSDataService();
		 JSONObject polDataJsnObj = new JSONObject();
			JSONObject jsnObjPolTab =  new JSONObject();
			JSONArray polDataJsnArr = new JSONArray();
			
		 List policyDetList = new ArrayList();
		 List policyDetPlanList = new ArrayList();
//		 if(!FipaUtils.nullOrBlank(strCustNric)){
			 policyDetList = serv.getFPMSLifeInsuracePolDets(dao, strCustName,strCustNric,strCustId,"");
//			 UNWANTED QUERY EXECUTING
//			 policyDetPlanList = serv.getLifeInsuracePlanDets(dao, strCustName,strCustNric,strCustId,"");
			 
			 
			 
//		 }else{
//			 policyDetList = serv.getLifeInsuraceDets(dao, strCustName);
//		 }
		 
		 int polTabSize = policyDetList.size();
		 
			if(polTabSize >0){
				Iterator it = policyDetList.iterator();
				while(it.hasNext()){
					Object[] polObjs = (Object[]) it.next();
					
					polDataJsnObj.put("strFPMSPolPrincipal",(FipaUtils.checkNullVal(polObjs[6])?"":polObjs[6].toString()));
					polDataJsnObj.put("strFPMSPolPolNo",(FipaUtils.checkNullVal(polObjs[5])?"":polObjs[5].toString()));
					polDataJsnObj.put("strFPMSPolPlanName",(FipaUtils.checkNullVal(polObjs[4])?"":polObjs[4].toString()));
					polDataJsnObj.put("strFPMSPolEffDate",(FipaUtils.checkNullVal(polObjs[12])?"":polObjs[12].toString()));
					polDataJsnObj.put("strFPMSPolStatus",(FipaUtils.checkNullVal(polObjs[15])?"":polObjs[15].toString()));
					polDataJsnObj.put("strFPMSPolSA",(FipaUtils.checkNullVal(polObjs[9])?"":polObjs[9].toString()));  
					polDataJsnObj.put("strFPMSPolPremium",(FipaUtils.checkNullVal(polObjs[8])?"":polObjs[8].toString())); 
					polDataJsnObj.put("strFPMSPolLOBMain",(FipaUtils.checkNullVal(polObjs[16])?"":polObjs[16].toString()));
					polDataJsnObj.put("strFPMSPolLOBSub",(FipaUtils.checkNullVal(polObjs[17])?"":polObjs[17].toString()));
					polDataJsnObj.put("strFPMSPolApplnName","FPMSNL");
					polDataJsnObj.put("strFPMSPolAppId",(FipaUtils.checkNullVal(polObjs[18])?"":polObjs[18].toString()));
					polDataJsnArr.add(polDataJsnObj);
				}
				jsnObjPolTab.put("FPMS_POLICY_DETS", polDataJsnArr);
			} else{
				
				jsnObjPolTab.put("NORECORDS_FPMS_POLICY_DETS", "");
				
			}
			
			return jsnObjPolTab;
	 }
	 
	 public JSONArray cpfAccountTypeSearch(HttpServletRequest request){
			
//			logger.info(" ------> Inside cpfAccountTypeSearch Method "); 
			
			JSONArray retValues = new JSONArray();
			
			JSONObject cpfAccTypeDataJsnObj = new JSONObject();
			JSONObject cpfAccTypeTabJsnObj =  new JSONObject();
			JSONArray cpfAccTypeDataJsnArr = new JSONArray();
			
			List cpfAccTypeSearchList = new ArrayList();		
			MasterCpfService cpfAccTypeServ=new MasterCpfService(); 

			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext(); 
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				
					 

				String strsrchcpfacctype= FipaUtils.getParamValue(request, "selSrchCpfAcctype");
				strsrchcpfacctype = java.net.URLDecoder.decode(strsrchcpfacctype,"UTF-8");
				

				
				 
				StringBuffer strCpfBufQryParam = new StringBuffer();
			 
				
				if(!FipaUtils.nullOrBlank(strsrchcpfacctype)){
					strCpfBufQryParam.append(" AND cpf.cpfAcId  = '").append(strsrchcpfacctype).append("'");
				 
				}
			 
				cpfAccTypeSearchList = cpfAccTypeServ.cpfAccTypeSearch(dao,strCpfBufQryParam.toString());

				cpfAccTypeTabJsnObj.put("CPFACCTYPE_SEARCH", FipaUtils.getPropsJsonArray(cpfAccTypeSearchList, MasterCpfAcctype.class));
				
				retValues.add(cpfAccTypeTabJsnObj); 
				 
				
			}catch(Exception ex){
			ex.printStackTrace();	
			}
			
			return retValues;
			
		}
	 public JSONArray QuotesSearch(HttpServletRequest request){
		 
			JSONArray retValues = new JSONArray();
			
			JSONObject quotesDataJsnObj = new JSONObject();
			JSONObject quotesTabJsnObj =  new JSONObject();
			JSONArray quotesDataJsnArr = new JSONArray();
			
			List quotesList = new ArrayList();		
			ClientService serv=new ClientService(); 

			
			try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				 
				quotesList = serv.searchQuotes(dao);
				 
				
				if(quotesList.size() > 0){
					
					Iterator it = quotesList.iterator();
					 
//					int jsonSize=0;
					
					int sino=0;
					while(it.hasNext()){
						
						Object[] quotesObj = (Object[]) it.next();					
						
	 
						quotesDataJsnObj.put("txtFldQuotesId", FipaUtils.getObjValue(FipaUtils.checkNullVal(quotesObj[0])?"":quotesObj[0].toString()));
						quotesDataJsnObj.put("txtFldAuthor", FipaUtils.getObjValue(FipaUtils.checkNullVal(quotesObj[2])?"":quotesObj[2].toString()));
						quotesDataJsnObj.put("txtFldLogMsg",FipaUtils.getObjValue(FipaUtils.checkNullVal(quotesObj[1])?"":quotesObj[1].toString()));
						quotesDataJsnObj.put("selWeekQte", FipaUtils.getObjValue(FipaUtils.checkNullVal(quotesObj[5])?"":quotesObj[5].toString()));
						quotesDataJsnObj.put("txtFldQuotesFrom",FipaUtils.getObjValue(FipaUtils.checkNullVal(quotesObj[3])?"":quotesObj[3].toString()));
						quotesDataJsnObj.put("txtFldQuotesTo", FipaUtils.getObjValue(FipaUtils.checkNullVal(quotesObj[4])?"":quotesObj[4].toString()));
							 
												
						quotesDataJsnArr.add(quotesDataJsnObj);
//							jsonSize = nricDataJsnArr.size();
							
					}
					quotesTabJsnObj.put("ALL_QUOTES", quotesDataJsnArr);
				
				}
				else{
					
					quotesTabJsnObj.put("QUOTES_NOREC", "");
					
				}
			
				
		
				
				retValues.add(quotesTabJsnObj);
				 
				
				
			}catch(Exception ex){
			ex.printStackTrace();	
			}
			
			return retValues;
			
		}

	 public JSONArray propertyInsert(HttpServletRequest request){
		  
		 JSONArray retval=new JSONArray();

		  	JSONObject propDataJsnObj = new JSONObject();
			JSONObject propTabJsnObj =  new JSONObject(); 
			
			
		 String strValue = FipaUtils.getParamValue(request, "strNewValue");
		 String strRemarks = FipaUtils.getParamValue(request, "strRemarks");
		 String strStatus = FipaUtils.getParamValue(request, "strStatus");
		 String strKey = FipaUtils.getParamValue(request, "strKey");
		 
//		 System.out.println(strValue);
		 
			
		 MasterService mastServ=new MasterService();
		 HttpSession session  = request.getSession(false);
		 Map<String,String> sessMap    = new HashMap<String,String>();
		 sessMap = (HashMap<String, String>)session.getAttribute(FipaConstant.LOGGED_USER_INFO);
		 String strCrtdUser = (String)sessMap.get(FipaConstant.LOGGED_USER_ID);
		 try{
			
				ApplicationContext appCtx = ApplicationContextUtils.getApplicationContext();
				
				DBInterfaceImpl dao = (DBInterfaceImpl)appCtx.getBean("dbImplBean");
				  
				MasterPropertykv mastPropkv=new MasterPropertykv(); 
				   
				
				if(strKey.equalsIgnoreCase("FINGLS"))
				{
					mastPropkv.setPropKey(strKey);
					mastPropkv.setPropValue(strValue);
					mastPropkv.setPropRemarks(strRemarks);
					mastPropkv.setPropStatus(strStatus);
					mastPropkv.setPropCrtdBy(strCrtdUser);
					mastPropkv.setPropCrtdDate(new Date());
					mastServ.insMasterKeys(mastPropkv);
					propTabJsnObj.put("FINGLS",strValue);
				}
				
				 retval.add(propTabJsnObj); 
				 
			}catch(Exception ex){
			ex.printStackTrace();	
			} 
		 
//		 System.out.println(retval);
		
		 
		return retval;
			 
		}
	 
}
