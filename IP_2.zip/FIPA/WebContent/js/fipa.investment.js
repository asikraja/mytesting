
 /**
 * Investment
 * 
 */
  

$("a.addInflwOutflw").on("click",function(){ 
	calcTotalInvestAmts();
	if($("#InvestARow").hasClass("blinking")){
		$("#InvestARow").removeClass("blinking");
	} 
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(5)").find("a").click();	
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#InvestARow").addClass("blinking"); 
//	$("#InvestARow").focus();
	
});

function openBackToCOB(){
	if($("#CobARow").hasClass("blinking")){
		$("#CobARow").removeClass("blinking");
	} 
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(7)").find("a").click();	
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#CobARow").addClass("blinking"); 
}

/*Datatable Initialisation*/
var fnaInvestmentTbl = $('#fnaInvestmentTbl').DataTable({
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


/*Add Row Click */
$("#InvestARow").on("click",function(){
	$("#invNameofChilddiv").css("display","none");
	$("#invChildYrtoterdiv").css("display","none");    
	$("#invAnlDivid").css("display","none");
	$("#invDividPaymode").css("display","none");
	
	$("#txtFldDlgInvDesc").html("");
	$("#txtFldDlgInvDesc").html('<option value="">--SELECT--</option>'); 
			investClearFlds();
			$("#Investment_Dialog #txtFldDlgInvFABrokerName").val(DEFAULT_FA_AVALLIS);  
			activeInvAmt($("#txtFldDlgAnyRegInvPlan"),$("#selDlgInvFreq"),$("#txtFldDlgAnyRegInvPlanAmt"),$("#txtFldDlgNoOfYrsRegInv"),$("#txtFldDlgTotNoOfYrsStayInv"));
			showFIPAModel('Investment_Dialog','Investment Details');   
			$('#Investment_Dialog').on('shown.bs.modal', function () {
				$("#Investment_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#Investment_Dialog").find("select[id=selDlgInvOwnership]").focus();
				$("#Investment_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validateinvestDetails())return; 
						if(!validateRegInvPlan())return; 
					   	investRdlyflds(INS_MODE); 
					   	getInptInvstRows(null); 
					   	$('#Investment_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getInptInvstRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldinvestMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldOwnInvstId"><input type="hidden" name="txtFldOwnInvRefId">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radinvestSelect"/><label>&nbsp;</label></div>'; 

var cell2 = '<select  name="selInvOwner" class="form-control editable" onmouseover="fipaTooltip(this);" ></select>';

var cell3 = '<select name="selInvType" class="form-control editable" onmouseover="fipaTooltip(this);" ></select>'; 

var cell4 = '<input type="text" name="txtFldInvFa" class="form-control editable" onmouseover="fipaTooltip(this);" maxlength="60"/>';

var cell5 = '<select name="txtFldInvAnnlPortfolio" class="form-control editable"onmouseover="fipaTooltip(this);" ></select>'; 

var cell6 = '<select name="txtFldInvInstname" class="form-control editable"onmouseover="fipaTooltip(this);" ></select>'; 

var cell7 = '<select name="txtFldInvDesc" class="form-control editable" onmouseover="fipaTooltip(this);"></select>';

var cell8 = '<input type="text" name="txtFldInvEstrate" class="form-control editable"   onmouseover="fipaTooltip(this);"  />';

var cell9 = '<input type="text" name="txtFldInvAmount" class="form-control editable"   onmouseover="fipaTooltip(this);"  />';

var cell10 = '<select  name="selInvPaymethod" class="form-control editable" onmouseover="fipaTooltip(this);" ></select>';

var cell11 = '<input type="text" name="txtFldInvAnnlDivid" class="form-control editable"   onmouseover="fipaTooltip(this);" />'; 

var cell12 = '<select  name="selInvDividPaymode" class="form-control editable" disabled="true" onmouseover="fipaTooltip(this);" >';

var cell13 = '<input type="text" name="txtFldInvDate" class="form-control editable"   maxlength="10" onmouseover="fipaTooltip(this);" />';

var cell14 = '<div class="inputnoborder" style="border:none important!;"><input type="text" name="txtFldInvCurrbid" class="form-control editable"   onmouseover="fipaTooltip(this);" /></div>'+
'<div class="inputnoborder"><a class="btn btn-default genNavicon" id="tblgenNavicon" style="margin-left: 3px;" onmouseover="dhtmltooltip(this,&quot;Fetch NAV&quot;);"/></a></div>';
//one more added check it after discussion

var cell15 = '<input type="text" name="txtFldInvUnitsAlloc" class="form-control editable"   onmouseover="fipaTooltip(this);"  />';

var cell16 = '<input type="text" name="txtFldinvCurrNAV" class="form-control editable"   onmouseover="fipaTooltip(this);"  />';

var cell17 = '<select  name="txtFldInvAnyRegPlan" class="form-control editable" onmouseover="fipaTooltip(this);" ></select>';

var cell18 = '<select  name="selInvRegPlanFreq" class="form-control editable" disabled="true" onmouseover="fipaTooltip(this);" ></select>'+
'<input type="hidden" name="txtInvRegPlanAmout"/>';

var cell19 = '<input type="text" name="txtFldInvRegPlanFromYrs" disabled="true" class="form-control editable"   onmouseover="fipaTooltip(this);"  />';

var cell20 = '<input type="text" name="txtFldInvRegPlanToYrs" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

var cell21 = '<select name="selInvObjective" class="form-control editable" onmouseover="fipaTooltip(this);" ></select>';

var cell22 = '<input type="text" name="selInvYrsToRet" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

var cell23 = '<select  name="txtFldInvChildname" class="form-control editable"   onmouseover="fipaTooltip(this);" ></select>';

var cell24 = '<input type="text" name="txtFldInvAccPrcnt" class="form-control editable"   onmouseover="fipaTooltip(this);" />';

var cell25 = '<input type="text" name="txtFldInvRemarks" class="form-control editable"   onmouseover="fipaTooltip(this);" maxlength="300"/>'+
'<input type="hidden" name="invCreatedBy"/><input type="hidden" name="invCreatedDate"/>';
 
fnaInvestmentTbl.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10,cell11,cell12,cell13,cell14,cell15,cell16,cell17,cell18,cell19,cell20,cell21,cell22,cell23,cell24,cell25] ).draw( false );


var rowCount = $('#fnaInvestmentTbl tbody tr').length;	
var $lastRow = $("#fnaInvestmentTbl tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radinvest"+$lastRow.index())
.parent().find('label').attr('for',"radinvest"+$lastRow.index());

/**********/

var ownership = $("#selDlgInvOwnership > option").clone();
$lastRow.find("td:eq(2)").find('select:eq(0)').append(ownership);
$lastRow.find("td:eq(2)").find('select:eq(0)').val($("#selDlgInvOwnership").val());
$lastRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){ 
	calcTotalInvestAmts();
	calInvSumryRow();  
//	SyncWithInvtoCpfAddDed();	
//	syncInvestCobTblRow(); 
	newRowInvestCpfEditTbl($lastRow);
	newRowInvestCobEditTbl($lastRow);
	if(!checkOwnerForPayment( $(this),$lastRow.find("td:eq(9)").find('select:eq(0)')))return;  
	syncInvestTblEditRow($lastRow); 
	return;
});
/**********/
var typeofInvst = $("#selDlgInvTypesOfInvst > option").clone();
$lastRow.find("td:eq(3)").find('select:eq(0)').append(typeofInvst);
$lastRow.find("td:eq(3)").find('select:eq(0)').val($("#selDlgInvTypesOfInvst").val()); 
$lastRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
	calInvSumryRow();  
		return;
});
/**********/
$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgInvFABrokerName").val());
/**********/

var analyportflo = $("#txtFldDlgAnalsByPortfolio > option").clone();
$lastRow.find("td:eq(5)").find('select:eq(0)').append(analyportflo);
$lastRow.find("td:eq(5)").find('select:eq(0)').val($("#txtFldDlgAnalsByPortfolio").val());
$lastRow.find("td:eq(5)").find('select:eq(0)').on("change",function(){
	invcloneportflio($lastRow.find("td:eq(6)").find('select:eq(0)'),$lastRow.find("td:eq(5)").find('select:eq(0)'),$lastRow.find("td:eq(7)").find('select:eq(0)'));  
 
		return;
});
/**********/
var tblinvclearnavprev,tblinvclearnavid;
var invstins =  $("#txtFldDlgInvInstitution > option").clone();
$lastRow.find("td:eq(6)").find('select:eq(0)').append(invstins);
$lastRow.find("td:eq(6)").find('select:eq(0)').val($("#txtFldDlgInvInstitution").val()); 
$lastRow.find("td:eq(6)").find('select:eq(0)').on("change",function(){
	removeTooltip($(this));
	invcloneportflio($lastRow.find("td:eq(6)").find('select:eq(0)'),$lastRow.find("td:eq(5)").find('select:eq(0)'),$lastRow.find("td:eq(7)").find('select:eq(0)'));  
 
	return;
}); 
$lastRow.find("td:eq(6)").find('select:eq(0)').on("focus",function(){ 
	tblinvclearnavid=$(this).attr("id");
	tblinvclearnavprev=$(this).val();
	
}).change(function(){
	clearCurrentBidPriceAlert($(this),tblinvclearnavid,tblinvclearnavprev,$lastRow.find("td:eq(14)").find('input:eq(0)'),$lastRow);
	
});

/**********/



var sell =  $("#txtFldDlgInvDesc > option").clone();
$lastRow.find("td:eq(7)").find('select:eq(0)').append(sell);
invcloneportflio($lastRow.find("td:eq(6)").find('select:eq(0)'),$lastRow.find("td:eq(5)").find('select:eq(0)'),$lastRow.find("td:eq(7)").find('select:eq(0)'));  
$lastRow.find("td:eq(7)").find('select:eq(0)').val($("#txtFldDlgInvDesc").val()); 
$lastRow.find("td:eq(7)").find('select:eq(0)').on("change",function(){ 
	removeTooltip($(this));
    syncInvestTblEditRow($lastRow); 
    return;
});
$lastRow.find("td:eq(7)").find('select:eq(0)').on("focus",function(){ 
	tblinvclearnavid=$(this).attr("id");
	tblinvclearnavprev=$(this).val();
	
}).change(function(){
	clearCurrentBidPriceAlert($(this),tblinvclearnavid,tblinvclearnavprev,$lastRow.find("td:eq(14)").find('input:eq(0)'),$lastRow);
	
});

/**********/

$lastRow.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgInvEstInvRate").val());
$lastRow.find("td:eq(8)").find('input:eq(0)').addClass("applyEvntpCent3");
$lastRow.find("td:eq(8)").find('input:eq(0)').on("change",function(){
	calcTotalInvestAmts(); 
		return;
});
/**********/

$lastRow.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgInvAmt").val());
$lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
	calcTotalInvestAmts();
//	SyncWithInvtoCpfAddDed(); 
	newRowInvestCpfEditTbl($lastRow);
		syncInvestTblEditRow($lastRow); 
		return;
});
/**********/

var invstsource =  $("#txtFldDlgInvSource > option").clone();
$lastRow.find("td:eq(10)").find('select:eq(0)').append(invstsource); 
$lastRow.find("td:eq(10)").find('select:eq(0)').val($("#txtFldDlgInvSource").val());
$lastRow.find("td:eq(10)").find('select:eq(0)').on("change",function(){ 
	if(!checkPaymentInvObj($(this),$lastRow.find("td:eq(21)").find('select:eq(0)')))return;
	if(!checkOwnerForPayment($lastRow.find("td:eq(2)").find('select:eq(0)'), $(this)))return;
	if(!checkPaymentWithObj($(this),$lastRow.find("td:eq(21)").find('select:eq(0)')))return;
	invpaymentmtd($(this),$lastRow.find("td:eq(11)").find('input:eq(0)'),$lastRow.find("td:eq(12)").find('select:eq(0)'));
//	SyncWithInvtoCpfAddDed();
//	syncInvestCobTblRow();  
	newRowInvestCpfEditTbl($lastRow);
	newRowInvestCobEditTbl($lastRow);
	return;
});



/**********/
$lastRow.find("td:eq(11)").find('input:eq(0)').val($("#txtFldDlgAnlDivd").val());
$lastRow.find("td:eq(11)").find('input:eq(0)').addClass("applyEvntpCent");
$lastRow.find("td:eq(11)").find('input:eq(0)').on("change",function(){  
	syncInvestTblEditRow($lastRow); 
		return;
}); 

/**********/
var invstpaymode =  $("#selDlgDivdPaymode > option").clone();
$lastRow.find("td:eq(12)").find('select:eq(0)').append(invstpaymode);
$lastRow.find("td:eq(12)").find('select:eq(0)').val($("#selDlgDivdPaymode").val());

/**********/


$lastRow.find("td:eq(13)").find('input:eq(0)').val($("#txtFldDlgInvDateInvst").val()); 
$lastRow.find("td:eq(13)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
	removeTooltip($(this));
	 checkDateFormat($(this));    
			return;
}); 
$lastRow.find("td:eq(13)").find('input:eq(0)').on("focus",function(){ 
	tblinvclearnavid=$(this).attr("id");
	tblinvclearnavprev=$(this).val();
	
}).change(function(){
	clearCurrentBidPriceAlert($(this),tblinvclearnavid,tblinvclearnavprev,$lastRow.find("td:eq(14)").find('input:eq(0)'),$lastRow);
 
});
/***********/
$lastRow.find("td:eq(14)").find('input:eq(0)').val($("#txtFldDlgInvCurBid").val());
$lastRow.find("td:eq(14)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(14)").find('input:eq(0)').on("change",function(){
	currentNavcalc($lastRow); 
		return;
}); 

$lastRow.find("td:eq(14)").find('a').on("click",function(){
//	if(!validateNavDetails())return; 
	if(!validateInvstNavDetails($lastRow))return; 
	fetchCurentNAV($lastRow.find("td:eq(5)").find('select:eq(0)'),$lastRow.find("td:eq(7)").find('select:eq(0)'),$lastRow.find("td:eq(13)").find('input:eq(0)'),$lastRow.find("td:eq(14)").find('input:eq(0)'));
	currentNavcalc($lastRow); 
});
/**********/
$lastRow.find("td:eq(15)").find('input:eq(0)').val($("#txtFldDlgInvNoOfUnits").val());
$lastRow.find("td:eq(15)").find('input:eq(0)').addClass("applyEvntUsd");
$lastRow.find("td:eq(15)").find('input:eq(0)').on("change",function(){
	currentNavcalc($lastRow); 
		return;
});
/**********/
$lastRow.find("td:eq(16)").find('input:eq(0)').val($("#txtFldDlgInvNAV").val());
$lastRow.find("td:eq(16)").find('input:eq(0)').addClass("applyEvntUsd"); 
$lastRow.find("td:eq(16)").find('input:eq(0)').on("change",function(){  
		return;
});
/**********/

var invstplan =  $("#txtFldDlgAnyRegInvPlan > option").clone();
$lastRow.find("td:eq(17)").find('select:eq(0)').append(invstplan); 
$lastRow.find("td:eq(17)").find('select:eq(0)').val($("#txtFldDlgAnyRegInvPlan").val());
$lastRow.find("td:eq(17)").find('select:eq(0)').on("change",function(){ 
	activeInvAmt($(this),$lastRow.find("td:eq(18)").find('select:eq(0)'),$lastRow.find("td:eq(18)").find('input:eq(0)'),$lastRow.find("td:eq(19)").find('input:eq(0)'),$lastRow.find("td:eq(20)").find('input:eq(0)')); 
 
		return;
	
});

/**********/
var invstfreq =  $("#selDlgInvFreq > option").clone();
$lastRow.find("td:eq(18)").find('select:eq(0)').append(invstfreq);
$lastRow.find("td:eq(18)").find('select:eq(0)').val($("#selDlgInvFreq").val());
$lastRow.find("td:eq(18)").find('select:eq(0)').on("change",function(){ 
	calInvSumryRow();  
//	syncInvestCobTblRow();  
	newRowInvestCobEditTbl($lastRow);
		return;
});
/**********/

$lastRow.find("td:eq(18)").find('input:eq(0)').val($("#txtFldDlgAnyRegInvPlanAmt").val());
$lastRow.find("td:eq(18)").find('input:eq(0)').prop("disabled",false);
$lastRow.find("td:eq(18)").find('input:eq(0)').on("change",function(){  
//	syncInvestCobTblRow();  
	newRowInvestCobEditTbl($lastRow);
		return;
});

/**********/
$lastRow.find("td:eq(19)").find('input:eq(0)').val($("#txtFldDlgNoOfYrsRegInv").val());
$lastRow.find("td:eq(19)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(19)").find('input:eq(0)').on("change",function(){
	if(!validatenoofyrs($lastRow))return;  
		return;
});

/**********/
$lastRow.find("td:eq(20)").find('input:eq(0)').val($("#txtFldDlgTotNoOfYrsStayInv").val());
$lastRow.find("td:eq(20)").find('input:eq(0)').addClass("applyEvntYrs");
$lastRow.find("td:eq(20)").find('input:eq(0)').on("change",function(){
	if(!validatenoofyrs($lastRow))return; 
		return;
});
/**********/

var invstObj =  $("#selDlgInvObjInvst > option").clone();
$lastRow.find("td:eq(21)").find('select:eq(0)').append(invstObj);
$lastRow.find("td:eq(21)").find('select:eq(0)').val($("#selDlgInvObjInvst").val());
$lastRow.find("td:eq(21)").find('select:eq(0)').on("change",function(){ 
	 if($(this).val() == "Retirement Planning"){
		 if(!validationRetirementScreen())return; 
	 }
	if(!checkPaymentInvObj($(this),$lastRow.find("td:eq(10)").find('select:eq(0)')))return;
	if(!checkPaymentWithObj($lastRow.find("td:eq(10)").find('select:eq(0)'),$(this)))return;
	checkInvObjDets($(this),$lastRow.find("td:eq(23)").find('select:eq(0)'),$lastRow.find("td:eq(22)").find('input:eq(0)'));
//	syncInvestCobTblRow(); 
	newRowInvestCobEditTbl($lastRow);
	syncInvestTblEditRow($lastRow); 
	return;
	
});

/**********/
$lastRow.find("td:eq(22)").find('input:eq(0)').val($("#selDlgInvYrToRet").val());
$lastRow.find("td:eq(22)").find('input:eq(0)').addClass("applyEvntYrs"); 
$lastRow.find("td:eq(22)").find('input:eq(0)').on("change",function(){  
//	syncInvestCobTblRow();
	newRowInvestCobEditTbl($lastRow);
		return;
});
/**********/
var Nameofchild =  $("#selDlgInvNameOfChild > option").clone();
$lastRow.find("td:eq(23)").find('select:eq(0)').append(Nameofchild);
$lastRow.find("td:eq(23)").find('select:eq(0)').val($("#selDlgInvNameOfChild").val());
$lastRow.find("td:eq(23)").find('select:eq(0)').on("change",function(){ 
	getChildYrtoTerEduc($(this),$lastRow.find("td:eq(22)").find('input:eq(0)')); 
//	syncInvestCobTblRow(); 
	newRowInvestCobEditTbl($lastRow);
		return;
});
/**********/
$lastRow.find("td:eq(24)").find('input:eq(0)').val($("#selDlgInvPercntAcc").val());
$lastRow.find("td:eq(24)").find('input:eq(0)').addClass("symbolprCent"); 
/**********/
$lastRow.find("td:eq(25)").find('input:eq(0)').val($("#selDlgInvRemarks").val());
 
/**********/
/*get sync investment rows*/
//if($lastRow.find("td:eq(18)").find('select:eq(0)').val() == "Retirement Planning" ){
// syncInvestTblRow();
//}

/*end*/

//checkInvObjTblDets($(this),$lastRow.find("td:eq(19)").find('input:eq(0)'),$lastRow.find("td:eq(20)").find('select:eq(0)'));

applyEventHandlers();


if(dataset != null){

	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	var investDes;
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
		case "owninvstId": 
			$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
			break;
		
		case "invReferenceId": 
			$lastRow.find("td:eq(0)").find('input:eq(2)').val(col);
			if(!isEmpty(col)){$lastRow.attr("rowref",col);}
			
			break;
			
		case "invOwner": 
			selectNullvalChk($lastRow.find("td:eq(2)"),col); 
			break;
			
		case "invType": 
			selectNullvalChk($lastRow.find("td:eq(3)"),col); 
			break;
		 
		case "invFa": 
			$lastRow.find("td:eq(4)").find('input:eq(0)').val(col); 
			break;
		 
		case "invAnlysByPtflio": 
			selectNullvalChk($lastRow.find("td:eq(5)"),col); 
			break;
		
			
		case "invInstname":  
			selectNullvalChk($lastRow.find("td:eq(6)"),col);
			invcloneportflio($lastRow.find("td:eq(6)").find('select:eq(0)'),$lastRow.find("td:eq(5)").find('select:eq(0)'),$lastRow.find("td:eq(7)").find('select:eq(0)'));  
			$lastRow.find("td:eq(7)").find("select:eq(0)").val(investDes);
			break; 
			
		case "invDesc":		
			investDes=col;
			$lastRow.find("td:eq(7)").find("select:eq(0)").val(col);
			break;
			
			
		case "invEstrate": 
			$lastRow.find("td:eq(8)").find('input:eq(0)').val(col); 
			break;
		
		case "invAmount": 
			$lastRow.find("td:eq(9)").find('input:eq(0)').val(col); 
			break;
			
		case "invPaymethod":
			selectNullvalChk($lastRow.find("td:eq(10)"),col); 		
			break;
			
		case "invAnnlDividPrct":
			$lastRow.find("td:eq(11)").find('input:eq(0)').val(col); 
			break;
			
		case "invDividPaymode":
			$lastRow.find("td:eq(12)").find('select:eq(0)').val(col); 
			break;
			
		case "invDate":
			$lastRow.find("td:eq(13)").find('input:eq(0)').val(col); 
			break; 
			
		case "invCurrbid":
			$lastRow.find("td:eq(14)").find('input:eq(0)').val(col); 
			break;
				
		case "invUnitsalloc":
			$lastRow.find("td:eq(15)").find('input:eq(0)').val(col); 
			break;
			
		case "invCurrentNAV":
			$lastRow.find("td:eq(16)").find('input:eq(0)').val(col); 
			break;
			
		case "invAnyregplan":
			selectNullvalChk($lastRow.find("td:eq(17)"),col); 		
			break;
			
		case "invRegplanFreq":
			selectNullvalChk($lastRow.find("td:eq(18)"),col); 	
			
			break;
			
		case "invRegplanAmount":
			$lastRow.find("td:eq(18)").find('input:eq(0)').val(col);  
			break;
			

		case "invRegplanFromyrs":
			$lastRow.find("td:eq(19)").find('input:eq(0)').val(col); 
			break;
			
		case "invRegplanToyrs":
			$lastRow.find("td:eq(20)").find('input:eq(0)').val(col); 
			break;
			
		case "invObjective":
			selectNullvalChk($lastRow.find("td:eq(21)"),col); 	 
			break;
			
		case "invYrstoret": 
			$lastRow.find("td:eq(22)").find('input:eq(0)').val(col); 
			break;
			
		case "invChildname":
			selectNullvalChk($lastRow.find("td:eq(23)"),col); 		
			break;
			
		case "invAccprcnt":
			$lastRow.find("td:eq(24)").find('input:eq(0)').val(col); 
			break;
			
		case "invRemarks":
			$lastRow.find("td:eq(25)").find('input:eq(0)').val(col); 
			break;
				
		case "invCreatedBy": 
			$lastRow.find("td:eq(25)").find('input:eq(1)').val(col);
			infoDetsArr.push(col);				
			break;
			
		case "invCreatedDate":
			$lastRow.find("td:eq(25)").find('input:eq(2)').val(col);
			infoDetsArr.push(col);
			break;
			
		case "invModifiedBy":
			infoDetsArr.push(col);
			break;
			
		case "invModifiedDate":
			infoDetsArr.push(col);
			break;	
			
	
			
		}		
		
		
		
		 
	}
	}

invpaymentmtd($lastRow.find("td:eq(10)").find('select:eq(0)'),$lastRow.find("td:eq(11)").find('input:eq(0)'),$lastRow.find("td:eq(12)").find('select:eq(0)'));
calInvSumryRow();
activeInvAmt($lastRow.find("td:eq(17)").find('select:eq(0)'),$lastRow.find("td:eq(18)").find('select:eq(0)'),$lastRow.find("td:eq(18)").find('input:eq(0)'),$lastRow.find("td:eq(19)").find('input:eq(0)'),$lastRow.find("td:eq(20)").find('input:eq(0)'));
if(dataset == null){
if($lastRow.find("td:eq(21)").find('select:eq(0)').val() == "Retirement Planning" ){
	if(!($lastRow.find("td:eq(2)").find('select:eq(0)').val() == "Joint")){
		syncInvestTblRow();
	}  
}

calcTotalInvestAmts();
//syncInvestCobTblRow(); 
if($lastRow.find("td:eq(10)").find('select:eq(0)').val() ==  "Cash" ){
	newRowInvestCobTbl($lastRow);
}
if($lastRow.find("td:eq(10)").find('select:eq(0)').val()  == "CPFOA" || $lastRow.find("td:eq(10)").find('select:eq(0)').val()  == "CPFSA" || 
		$lastRow.find("td:eq(10)").find('select:eq(0)').val()  == "CPFMA" || $lastRow.find("td:eq(10)").find('select:eq(0)').val()  == "CPFRA"){
	newRowInvestCpfTbl($lastRow);
}
}
checkInvObjDetsRem($lastRow.find("td:eq(21)").find('select:eq(0)'),$lastRow.find("td:eq(23)").find('select:eq(0)'),$lastRow.find("td:eq(22)").find('input:eq(0)'));
investClearFlds();
}


function validateInvstNavDetails($lastRow){ 
	 
 
	if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(6)").find('select:eq(0)'),  IPINVST_INSNAME))) return;
	if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(7)").find('select:eq(0)'), IPINVST_FUNDCODE))) return;  
	if(!(validateFocusDhtmlFlds($lastRow.find("td:eq(13)").find('input:eq(0)'), IPINST_DATEINV))) return;   
	
  return true; 
}







/*Mandatory Fields Tooltip*/ 
$("#selDlgInvOwnership,#selDlgInvTypesOfInvst,#txtFldDlgInvDateInvst").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});

/*Edit Row Click */
$("#InvestERow").on("click",function(){ 
	$("#InvestVRow").click(); 
});


/*View Row Click */
$("#InvestVRow").on("click",function(){

	activeInvAmt($("#txtFldDlgAnyRegInvPlan"),$("#selDlgInvFreq"),$("#txtFldDlgAnyRegInvPlanAmt"),$("#txtFldDlgNoOfYrsRegInv"),$("#txtFldDlgTotNoOfYrsStayInv"));
	var isOneRowSelected=0;
	var $rowCount = $('#fnaInvestmentTbl tbody tr').length;	
	var $lastRow = $("#fnaInvestmentTbl tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	
	
	$("#fnaInvestmentTbl tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
		
			
	});
	
	
	
	$("#fnaInvestmentTbl tbody").find('input[name="radinvestSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#fnaInvestmentTbl tbody").find('input[name="radinvestSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode);  
				 $(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
						$(this).attr("disabled",false); 
						$row.removeClass('selected');  
						$(this).parent().css({border:'1px solid green'});
						$row.css({border:'1px solid green'});
						$row.find("td").css({border:'1px solid green'});
					});  
				 
				 	investRdlyflds($mode);
					investfilldlgval($row);
					checkInvObjDetsRem($("#selDlgInvObjInvst"),$("#selDlgInvNameOfChild"),$("#selDlgInvYrToRet"));
					
					yrtoretirementChk($("#selDlgInvYrToRet"));
					activeInvAmt($("#txtFldDlgAnyRegInvPlan"),$("#selDlgInvFreq"),$("#txtFldDlgAnyRegInvPlanAmt"),$("#txtFldDlgNoOfYrsRegInv"),$("#txtFldDlgTotNoOfYrsStayInv"));
					 
					invpaymentmtd($("#txtFldDlgInvSource"),$("#txtFldDlgAnlDivd"),$("#selDlgDivdPaymode"));
					showFIPAModel('Investment_Dialog','Investment Details');  
					$('#Investment_Dialog').on('shown.bs.modal', function () {
						$("#Investment_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#Investment_Dialog").find("select[id=selDlgInvOwnership]").focus();
						$("#Investment_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validateinvestDetails())return; 
							 if(!validateRegInvPlan())return
							
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			investfilldomval($RowId,$row); 
					     		}  
							 
							 
							 var $rowref=$row.attr("rowref");
						 		if(isValidObject($rowref)){ 
							 			syncInvestTblEditRow($row);
							 		
						 		}     
						 		if($row.find("td:eq(10)").find('select:eq(0)').val() ==  "Cash" ){
						 			 newRowInvestCobEditTbl($row);
						 		}  
						 		
						 		checkInvObjDetsRem($row.find("td:eq(21)").find('select:eq(0)'),$row.find("td:eq(23)").find('select:eq(0)'),$row.find("td:eq(22)").find('input:eq(0)'));
						 		
						 	 	newRowInvestCpfEditTbl($row);
						 		 
						 		
							 	calcTotalInvestAmts(); 
							 	calInvSumryRow(); 
								$('#Investment_Dialog').modal('hide'); 
								investClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#InvestDRow").on("click",function(){  
	var rowCount = $('#fnaInvestmentTbl tbody tr').length;	 
	if(rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	}
	var isOneRowSelected=false;
	$('#fnaInvestmentTbl tbody').find('input[type=checkbox]').each(function(){
		if($(this).is(":checked")){  
			var row = $(this).parents("tr");                                    
			var mode = $(this).parents("tr").find("td:first").find('input:eq(0)').val();
			
			var refId=$(this).parents("tr").attr("rowref");//Retirement Reference 
			
			if(isValidObject($(this).parents("tr").attr("rowref"))){
		
				var refTbl=refId.split("-")[0];  
				var messge;
				
				$("#IncAssRetPlgtbl tr[rowref='"+refId+"']").each(function(){
					messge=true;
					IncAssRetPlgtbl.row($(this)).remove().draw();
				});	
				 
				$("#cpfAccAddDedTable tr[rowref='"+refId+"']").each(function(){
					messge=true;
				 	cpfAccAddDedTable.row($(this)).remove().draw();
				});	
				
				
				$("#cashOfBanksTable tr[rowref='"+refId+"']").each(function(){ 
					messge=true;
					cashOfBanksTable.row($(this)).remove().draw();
				});	
				
				$("#fnaInvestmentTbl tr[rowref='"+refId+"']").each(function(){
					if(messge){
						showAlert("The Existing Reference Record will also be deleted");
					}
					fnaInvestmentTbl.row($(this)).remove().draw();
				}); 
				  
			}
			
			//Normal without reference Delete function
			if(!isValidObject($(this).parents("tr").attr("rowref"))){
				
				fnaInvestmentTbl.row($(this).parent().parent()).remove().draw();
			 
			}
				
			
			$(this).attr("checked",false);
			isOneRowSelected=true; 
		}
	});
	if(rowCount==1){
		fnaInvestmentTbl.clear().draw();
	}

	
	if(!isOneRowSelected){
		showAlert("No Rows Selected");
	} 
	
	
	reorderSino("IncAssRetPlgtbl"); 
	reorderSino("cashOfBanksTable"); 
	reorderSino("cpfAccAddDedTable");
	reorderSino("fnaInvestmentTbl"); 
	calInvSumryRow();  
	calcTotalInvestAmts();

});

/*Clear Fields */
function investClearFlds(){
	$("#Investment_Dialog").find("input[type=text]").val("");
	$("#Investment_Dialog").find("textarea").val("");
	$("#Investment_Dialog").find("select").val("");
	$("#Investment_Dialog #txtFldDlgInvDesc option").remove(0);
	$('#Investment_Dialog #txtFldDlgInvDesc').append( '<option value="">--SELECT--</option>' ); 
}

/*Disabled/Readonly Fields */
function investRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#Investment_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#Investment_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validateinvestDetails(){
	 
	if(!(validateFocusFlds('Investment_Dialog','selDlgInvOwnership', IPINVST_OWNNAME))) return;
	if(!(validateFocusFlds('Investment_Dialog','selDlgInvTypesOfInvst',IPINVST_TYPE))) return;
	if(!(validateFocusFlds('Investment_Dialog','txtFldDlgInvDateInvst', IPINST_DATEINV))) return; 
	
	  return true; 
}
 

/*Mandatory Fields Tooltip*/ 
$("#selDlgInvOwnership,#selDlgInvTypesOfInvst,#txtFldDlgInvDateInvst").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


/* Filling Model Fields*/
function investfilldlgval($lastRow){
	  
	  $('#Investment_Dialog #txtFldDlgInvtmntId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#Investment_Dialog #txtFldDlgInvtmntRefId').val($lastRow.find("td:eq(0)").find('input:eq(2)').val());
	  $('#Investment_Dialog #selDlgInvOwnership').val($lastRow.find("td:eq(2)").find('select:eq(0)').val());
	  $('#Investment_Dialog #selDlgInvTypesOfInvst').val($lastRow.find("td:eq(3)").find('select:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvFABrokerName').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgAnalsByPortfolio').val($lastRow.find("td:eq(5)").find('select:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvInstitution').val($lastRow.find("td:eq(6)").find('select:eq(0)').val());
	  

	  /**/
	  invcloneportflio($('#Investment_Dialog #txtFldDlgInvInstitution'),$('#Investment_Dialog #txtFldDlgAnalsByPortfolio'),$('#Investment_Dialog #txtFldDlgInvDesc'));  
		
	   /**/
		 
	  
	  $('#Investment_Dialog #txtFldDlgInvDesc').val($lastRow.find("td:eq(7)").find('select:eq(0)').val()); 
	  $('#Investment_Dialog #txtFldDlgInvEsrowRefIDtInvRate').val($lastRow.find("td:eq(8)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvAmt').val($lastRow.find("td:eq(9)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvSource').val($lastRow.find("td:eq(10)").find('select:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgAnlDivd').val($lastRow.find("td:eq(11)").find('input:eq(0)').val());
	  $('#Investment_Dialog #selDlgDivdPaymode').val($lastRow.find("td:eq(12)").find('select:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvDateInvst').val($lastRow.find("td:eq(13)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvCurBid').val($lastRow.find("td:eq(14)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvNoOfUnits').val($lastRow.find("td:eq(15)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvNAV').val($lastRow.find("td:eq(16)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgAnyRegInvPlan').val($lastRow.find("td:eq(17)").find('select:eq(0)').val());
	  $('#Investment_Dialog #selDlgInvFreq').val($lastRow.find("td:eq(18)").find('select:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgAnyRegInvPlanAmt').val($lastRow.find("td:eq(18)").find('input:eq(0)').val()); 
	  $('#Investment_Dialog #txtFldDlgNoOfYrsRegInv').val($lastRow.find("td:eq(19)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgTotNoOfYrsStayInv').val($lastRow.find("td:eq(20)").find('input:eq(0)').val());
	  $('#Investment_Dialog #selDlgInvObjInvst').val($lastRow.find("td:eq(21)").find('select:eq(0)').val());
	  $('#Investment_Dialog #selDlgInvYrToRet').val($lastRow.find("td:eq(22)").find('input:eq(0)').val());
	  $('#Investment_Dialog #selDlgInvNameOfChild').val($lastRow.find("td:eq(23)").find('select:eq(0)').val());
	  $('#Investment_Dialog #selDlgInvPercntAcc').val($lastRow.find("td:eq(24)").find('input:eq(0)').val());
	  $('#Investment_Dialog #selDlgInvRemarks').val($lastRow.find("td:eq(25)").find('input:eq(0)').val());
	  $('#Investment_Dialog #txtFldDlgInvtmntCrtdBy').val($lastRow.find("td:eq(25)").find('input:eq(1)').val());
	  $('#Investment_Dialog #txtFldDlgInvtmntCrtdDate').val($lastRow.find("td:eq(25)").find('input:eq(2)').val());
	
}

/* Filling Table Fields*/
function investfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('select:eq(0)').val($("#selDlgInvOwnership").val()); 
	$row.find("td:eq(3)").find('select:eq(0)').val($("#selDlgInvTypesOfInvst").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgInvFABrokerName").val()); 
	$row.find("td:eq(5)").find('select:eq(0)').val($("#txtFldDlgAnalsByPortfolio").val()); 
	
	$row.find("td:eq(6)").find('select:eq(0)').val($("#txtFldDlgInvInstitution").val()); 
	
	invcloneportflio($row.find("td:eq(6)").find('select:eq(0)'),$row.find("td:eq(5)").find('select:eq(0)'),$row.find("td:eq(7)").find('select:eq(0)'));  

	$row.find("td:eq(7)").find('select:eq(0)').val($("#txtFldDlgInvDesc").val()); 
	$row.find("td:eq(8)").find('input:eq(0)').val($("#txtFldDlgInvEstInvRate").val()); 
	$row.find("td:eq(9)").find('input:eq(0)').val($("#txtFldDlgInvAmt").val()); 
	$row.find("td:eq(10)").find('select:eq(0)').val($("#txtFldDlgInvSource").val()); 
	$row.find("td:eq(11)").find('input:eq(0)').val($("#txtFldDlgAnlDivd").val()); 
	$row.find("td:eq(12)").find('select:eq(0)').val($("#selDlgDivdPaymode").val());  
	$row.find("td:eq(13)").find('input:eq(0)').val($("#txtFldDlgInvDateInvst").val()); 
	$row.find("td:eq(14)").find('input:eq(0)').val($("#txtFldDlgInvCurBid").val());
	$row.find("td:eq(15)").find('input:eq(0)').val($("#txtFldDlgInvNoOfUnits").val()); 
	$row.find("td:eq(16)").find('input:eq(0)').val($("#txtFldDlgInvNAV").val());
	$row.find("td:eq(17)").find('select:eq(0)').val($("#txtFldDlgAnyRegInvPlan").val()); 
	$row.find("td:eq(18)").find('select:eq(0)').val($("#selDlgInvFreq").val()); 
	$row.find("td:eq(18)").find('input:eq(0)').val($("#txtFldDlgAnyRegInvPlanAmt").val());  
	$row.find("td:eq(19)").find('input:eq(0)').val($("#txtFldDlgNoOfYrsRegInv").val()); 
	$row.find("td:eq(20)").find('input:eq(0)').val($("#txtFldDlgTotNoOfYrsStayInv").val()); 
	$row.find("td:eq(21)").find('select:eq(0)').val($("#selDlgInvObjInvst").val()); 
	$row.find("td:eq(22)").find('input:eq(0)').val($("#selDlgInvYrToRet").val()); 
	$row.find("td:eq(23)").find('select:eq(0)').val($("#selDlgInvNameOfChild").val()); 
	$row.find("td:eq(24)").find('input:eq(0)').val($("#selDlgInvPercntAcc").val()); 
	$row.find("td:eq(25)").find('input:eq(0)').val($("#selDlgInvRemarks").val());  
}

/*###########################################################################################################################################################*/


$("#txtFldDlgInvCurBid,#txtFldDlgInvNoOfUnits").on("change",function(){
	currentNavcalc(null);
});
$("#txtFldDlgNoOfYrsRegInv,#txtFldDlgTotNoOfYrsStayInv").on("change blur",function(){
	if(!validatenoofyrs(null))return;
});

function currentNavcalc($lastRow){
	var curbidprice=(isEmpty($("#txtFldDlgInvCurBid").val())) ? Number(0) : Number($("#txtFldDlgInvCurBid").val()); 
	var noofunits=(isEmpty($("#txtFldDlgInvNoOfUnits").val())) ? Number(0) : Number($("#txtFldDlgInvNoOfUnits").val());
		  
	var currentNav=curbidprice*noofunits;
	$("#txtFldDlgInvNAV").val(remPriceAfDec(currentNav));
	
	
	if($lastRow){
		var curbidpricerow=(isEmpty($lastRow.find("td:eq(14)").find('input:eq(0)').val())) ? Number(0) : Number($lastRow.find("td:eq(14)").find('input:eq(0)').val()); 
		var noofunitsrow=(isEmpty($lastRow.find("td:eq(15)").find('input:eq(0)').val())) ? Number(0) : Number($lastRow.find("td:eq(15)").find('input:eq(0)').val());
			  
		var currentNavrow=curbidpricerow*noofunitsrow;
	$lastRow.find("td:eq(16)").find('input:eq(0)').val(remPriceAfDec(currentNavrow));
	} 
}


function validatenoofyrs($lastRow){
	var noofyrs=$("#txtFldDlgNoOfYrsRegInv").val(); 
	var totnoyrs=$("#txtFldDlgTotNoOfYrsStayInv").val();
		    
	if(!isEmpty(noofyrs) ){
		if(!isEmpty(totnoyrs)){
		if(Number(totnoyrs) < Number(noofyrs)){
			showAlert("Tot no. of yrs to stay invested should be greater than No of yrs of reg. inv",$("#txtFldDlgTotNoOfYrsStayInv"));
			$("#txtFldDlgTotNoOfYrsStayInv").val("");
			return false;
		}
		}
	}
	
	if($lastRow){
		var noofyrsrow=$lastRow.find("td:eq(19)").find('input:eq(0)').val(); 
		var totnoyrsrow=$lastRow.find("td:eq(20)").find('input:eq(0)').val();
		if(!isEmpty(noofyrsrow) ){
			if(!isEmpty(totnoyrsrow)){
			if(Number(totnoyrsrow) < Number(noofyrsrow)){
				showAlert("Tot no. of yrs to stay invested should be greater than No of yrs of reg. inv",$lastRow.find("td:eq(20)").find('input:eq(0)'));
				$lastRow.find("td:eq(20)").find('input:eq(0)').val("");
				return false;
			}
			}
		}
	} 
	
	return true;
}


function totInsuranceCalcRow(){
	
	
	 var sum1=0,sum2=0,sum3=0,sum4=0,sum5=0,sum6=0,sum7=0;
	 var tbl = document.getElementById('fnaInvestmentTbl'),
	 tblBody = tbl.tBodies[0],
	 len = tblBody.rows.length;
 	
	 for(var edit=0;edit<len;edit++){
		 if(document.getElementsByName("txtFldLipDthchBenf")[edit]){
			 sum1 +=Number(document.getElementsByName("txtFldLipDthchBenf")[edit].value);
		 }
		 if(document.getElementsByName("txtFldLipMiCoverage")[edit]){
			 sum2 +=Number(document.getElementsByName("txtFldLipMiCoverage")[edit].value);
		 }
		 if(document.getElementsByName("txtFldLipCashValue")[edit]){
			 sum3 +=Number(document.getElementsByName("txtFldLipCashValue")[edit].value);
		 } 
		 if(document.getElementsByName("txtFldLipOsValue")[edit]){
			 sum4 +=Number(document.getElementsByName("txtFldLipOsValue")[edit].value);
		 }
		 if(document.getElementsByName("txtFldLipRpValue")[edit]){
			 sum5 +=Number(document.getElementsByName("txtFldLipRpValue")[edit].value);
		 }
		 if(document.getElementsByName("txtFldLipAnnlPrem")[edit]){
			 sum6 +=Number(document.getElementsByName("txtFldLipAnnlPrem")[edit].value);
		 }
		 if(document.getElementsByName("txtFldLipComputedtpd")[edit]){
			 sum7 +=Number(document.getElementsByName("txtFldLipComputedtpd")[edit].value);
		 }
	 } 
	 
	 if(!(sum1 == 0 && sum2 == 0 && sum3 == 0 && sum4 == 0 && sum5 == 0 && sum6 == 0 && sum7 == 0)){ 
	 $("#fnaInvestmentTblfooter #tottxtFldDeathBenf").val(remPriceAfDec(sum1));  
	 $("#fnaInvestmentTblfooter #tottxtFldMICoverage").val(remPriceAfDec(sum2));  
	 $("#fnaInvestmentTblfooter #tottxtFldCashValue").val(remPriceAfDec(sum3));  
	 $("#fnaInvestmentTblfooter #tottxtFldOutsgLoan").val(remPriceAfDec(sum4));  
	 $("#fnaInvestmentTblfooter #tottxtFldValRPCash").val(remPriceAfDec(sum5));  
	 $("#fnaInvestmentTblfooter #tottxtFldAnlPrem").val(remPriceAfDec(sum6));  
	 $("#fnaInvestmentTblfooter #tottxtFldCompTPD").val(remPriceAfDec(sum7)); 
	 }
	 
	 if(sum1 == 0){$('#tottxtFldDeathBenf').val("0");}
	 if(sum2 == 0){$('#tottxtFldMICoverage').val("0");}
	 if(sum3 == 0){$('#tottxtFldCashValue').val("0");}
	 if(sum4 == 0){$('#tottxtFldOutsgLoan').val("0");}
	 if(sum5 == 0){$('#tottxtFldValRPCash').val("0");}
	 if(sum6 == 0){$('#tottxtFldAnlPrem').val("0");}
	 if(sum7 == 0){ $('#tottxtFldCompTPD').val("0");}
	 
	  
	   
}

function UpdInvstmntChildName(existingName,newchildname){
 
	
	var table = document.getElementById("fnaInvestmentTbl"); 
	var tbody = table.tBodies[0];
	var rowCount = tbody.rows.length;
	var editFlag = 0;
	 
	
	var Insrnceindex = fnaInvestmentTbl.row().count();
	 
 
		if(Insrnceindex>0){
	for(var editrow=0;editrow<rowCount;editrow++){ 
			 var editCurRow = tbody.rows[editrow];   
			 if( existingName == editCurRow.cells[23].childNodes[0].value ){  
				 var RowId=editCurRow.rowIndex; 
				 table.rows[RowId].cells[23].childNodes[0].value = newchildname;  
			 } 
		}
	}
		return true;	
}


 
//$("#txtFldDlgAnyRegInvPlan").on("change",function(){
function activeInvAmt(elmid,freq,amt,noofyrs,stayinv) {
	var option = elmid.val();
		if (!isEmpty(option)) {
			if (option == "Y") {  
				$("#txtFldDlgAnyRegInvPlanAmt").prop("disabled", false);
				freq.prop("disabled", false);
				noofyrs.prop("disabled", false);
				stayinv.prop("disabled", false);
			} else if (option == "N") {  
				$("#txtFldDlgAnyRegInvPlanAmt").prop("disabled", true);
				$("#txtFldDlgAnyRegInvPlanAmt").val("");
				freq.prop("disabled", true);
				freq.val("");
				noofyrs.prop("disabled", true);
				noofyrs.val("");
				stayinv.prop("disabled", true);
				stayinv.val("");
			}
		} else {  
			$("#txtFldDlgAnyRegInvPlanAmt").prop("disabled", true);
			$("#txtFldDlgAnyRegInvPlanAmt").val("");
			freq.prop("disabled", true);
			freq.val("");
			noofyrs.prop("disabled", true);
			noofyrs.val("");
			stayinv.prop("disabled", true);
			stayinv.val("");

		}
		
		return true;
}
 
	
$("#txtFldDlgAnyRegInvPlan").on("change blur",function(){
	activeInvAmt($(this),$("#selDlgInvFreq"),$("#txtFldDlgAnyRegInvPlanAmt"),$("#txtFldDlgNoOfYrsRegInv"),$("#txtFldDlgTotNoOfYrsStayInv")); 
});

	
$("#selDlgInvObjInvst").on("change",function(){
	 if($(this).val() == "Retirement Planning"){
		 if(!validationRetirementScreen())return; 
	 }
	if(!checkPaymentInvObj($("#txtFldDlgInvSource"),$("#selDlgInvObjInvst")))return;
	checkInvObjDets($("#selDlgInvObjInvst"),$("#selDlgInvNameOfChild"),$("#selDlgInvYrToRet"));
	if(!checkPaymentWithObj($("#txtFldDlgInvSource"),$("#selDlgInvObjInvst")))return;
	
});

$("#txtFldDlgInvSource").on("change blur",function(){
	if(!checkOwnerForPayment( $("#selDlgInvOwnership"),$("#txtFldDlgInvSource")))return;
	if(!checkPaymentInvObj($("#txtFldDlgInvSource"),$("#selDlgInvObjInvst")))return;
	if(!checkPaymentWithObj($("#txtFldDlgInvSource"),$("#selDlgInvObjInvst")))return;
});

$("#selDlgInvOwnership").on("change blur",function(){
	if(!checkOwnerForPayment( $("#selDlgInvOwnership"),$("#txtFldDlgInvSource")))return;
});



function  checkOwnerForPayment(owner,source){
	var ownership = owner.val();
	var paymentmeth = source.val();
	if(!(ownership==null) && !(paymentmeth == null)){
	if(!isEmpty(ownership) && !isEmpty(paymentmeth) ){
	if( ownership  == "Joint" && (paymentmeth.toUpperCase() != "CASH")){
		showAlert("Joint ownership will not accept any CPFOA, CPFSA or SRS as investment source", '');
		source.val("");
		return false;
	  }
	}
	}
	return true;
}

function  checkPaymentWithObj(paymtd,obj){
	var paymtd = paymtd.val();
	var objv = obj.val();
	 
	if(!isEmpty(paymtd) && !isEmpty(paymtd) ){
	if((paymtd  == "SRS" || paymtd  == "CPFSA") && (objv == "Education Planning")){
		showAlert("Payment Methods SRS and CPFSA will not accept Education Planning", '');
		obj.val("");
		return false;
	  }
	}
	 
	return true;
}


function checkPaymentInvObj(source,invobj){
	var paymentmeth = source.val();
	var invobjective = invobj.val();
	if(!(paymentmeth==null) && !(invobjective == null)){
if(!isEmpty(paymentmeth) && !isEmpty(invobjective) ){

	paymentmeth = paymentmeth.toUpperCase();
	invobjective = invobjective.toUpperCase();
	
	if( (paymentmeth == "CPFSA" || paymentmeth == "SRS")  
			&& (invobjective == "Education Planning")){
		showAlert("For SRS and CPFSA, investment objective cannot be Education Planning", '');
		invobj.val("");
		return false;
	}
}
	
}
	return true;
}

function checkInvObjDets(elmid,child,ret){
	var invobj = elmid.val(); 
		if(!(isEmpty(invobj))){ 
	if(invobj == "Education Planning"){
		$("#invNameofChilddiv").css("display","block");
		$("#invChildYrtoterdiv").css("display","block"); 
		$("#invChildYrtoterdiv").find("label[id=objofinvlabelchange]").text("Yrs in Tertiary Education");
		child.val("");
		ret.val("");
		ret.prop("disabled",false);
		child.prop("disabled",false);
	}else if(invobj == "Retirement Planning"){ 
		$("#invNameofChilddiv").css("display","none");
		$("#invChildYrtoterdiv").css("display","block"); 
		$("#invChildYrtoterdiv").find("label[id=objofinvlabelchange]").text("Yr to Retirement");   
		ret.prop("disabled",true); 
		child.val("");
		ret.val($("#retYrstoret").val());
		child.prop("disabled",true);
	}else if(invobj == "No plans"){
		$("#invNameofChilddiv").css("display","none");
		$("#invChildYrtoterdiv").css("display","none"); 
		child.val("");
		ret.val("");
		ret.prop("disabled",true);  
		child.prop("disabled",true);
	}  
		}else{
			$("#invNameofChilddiv").css("display","none");
			$("#invChildYrtoterdiv").css("display","none"); 
			child.val("");
			ret.val("");
			ret.prop("disabled",true);  
			child.prop("disabled",true);
		}
//	}
	return true;
	
}

function checkInvObjDetsRem(elmid,child,ret){
	var invobj = elmid.val(); 
	if(!(isEmpty(invobj))){ 
if(invobj == "Education Planning"){
	$("#invNameofChilddiv").css("display","block");
	$("#invChildYrtoterdiv").css("display","block"); 
	$("#invChildYrtoterdiv").find("label[id=objofinvlabelchange]").text("Yrs in Tertiary Education");
	ret.prop("disabled",false);
	child.prop("disabled",false);
}else if(invobj == "Retirement Planning"){  
	$("#invNameofChilddiv").css("display","none");
	$("#invChildYrtoterdiv").css("display","block"); 
	$("#invChildYrtoterdiv").find("label[id=objofinvlabelchange]").text("Yr to Retirement");   
	 
	ret.prop("disabled",true); 
	child.prop("disabled",true);
}else if(invobj == "No plans"){ 
	$("#invNameofChilddiv").css("display","none");
	$("#invChildYrtoterdiv").css("display","none"); 
	ret.prop("disabled",true);  
	child.prop("disabled",true);
}  
	}else{ 
		$("#invNameofChilddiv").css("display","none");
		$("#invChildYrtoterdiv").css("display","none"); 
		ret.prop("disabled",true);  
		child.prop("disabled",true);
	}
//}
return true;

}
 
function validateRegInvPlan(){
	
	if($("#txtFldDlgAnyRegInvPlan").val() == "Y"){  
		if(!(validateFocusFlds('Investment_Dialog','txtFldDlgAnyRegInvPlanAmt', IPINVST_AMT))) return;
		if(!(validateFocusFlds('Investment_Dialog','selDlgInvFreq',IPINVST_FREQ))) return;
		if(!(validateFocusFlds('Investment_Dialog','txtFldDlgNoOfYrsRegInv', IPINST_NOOFYRS))) return;
		if(!(validateFocusFlds('Investment_Dialog','txtFldDlgTotNoOfYrsStayInv', IPINST_YRSTOSTAY))) return;
	}
	return true;
}

/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgAnyRegInvPlanAmt,#selDlgInvFreq,#txtFldDlgNoOfYrsRegInv,#txtFldDlgTotNoOfYrsStayInv").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});
  


function calInvSumryRow(){
	
	 
	
	 var catg; 
	
	 var selfcur1=0,spousecur1=0,jointcur1=0;//Bonds
	 var selfreg1=0,spousereg1=0,jointreg1=0;
	 
	 var selfcur2=0,spousecur2=0,jointcur2=0;//UT&ILP
	 var selfreg2=0,spousereg2=0,jointreg2=0;
	 
	 var selfcur3=0,spousecur3=0,jointcur3=0;//Shares
	 var selfreg3=0,spousereg3=0,jointreg3=0;

	 var selfcur4=0,spousecur4=0,jointcur4=0;//Others
	 var selfreg4=0,spousereg4=0,jointreg4=0;
	 
	 var selfcur5=0,spousecur5=0,jointcur5=0;//Dividends
	 var selfreg5=0,spousereg5=0,jointreg5=0;
	 
	 
  
	 var $rowCount = fnaInvestmentTbl.rows().count();			
	 var $lastRow = $("#fnaInvestmentTbl tbody tr:last");	

	 if($rowCount == 0){
		 $("#divforInvestmentSummary").find("input").val("");
	 }
	 if($rowCount >0){
		 $("#divforInvestmentSummary").find("input").val("");
		 $("#fnaInvestmentTbl tbody tr").each(function(count,value){
			   catg=$(this).find("td:eq(3)").find("select:eq(0)").val(); 
			   var anualTopAmt= $(this).find("td:eq(18)").find("select:eq(0)").val();
			   
			 var TopUpAmt=0; 
			
			 if(!isEmpty(anualTopAmt)){
				 if(anualTopAmt == 'ANNUAL'){
						TopUpAmt=1;
					}else if(anualTopAmt == 'SEMI ANNUAL'){
						TopUpAmt=2;
					}else if(anualTopAmt == 'QUARTERLY'){
						TopUpAmt=4;
					}else if(anualTopAmt == 'MONTHLY'){
						TopUpAmt=12;
					}else if(anualTopAmt == 'SINGLE'){
						TopUpAmt=0;
					}
			 }
			 
			 if(catg=='Bonds'){  
				   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Self' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
					   selfcur1 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());  
					   selfreg1 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt); 
		     	   }
				   
				   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Spouse' && $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
					   spousecur1 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());
					   spousereg1 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt); 
				   }
				   
				   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Joint' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
					   jointcur1 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val()); 
					   jointreg1 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
 
				} 
				   
				   $("#invSelfBondCurr").val(remPriceAfDec(selfcur1));
					 $("#invSelfBondCurr").attr("data-attr",remPriceAfDec(selfcur1)); 
					 
					 $("#invSpsBondCurr").val(remPriceAfDec(spousecur1));
					 $("#invSpsBondCurr").attr("data-attr",remPriceAfDec(spousecur1)); 
					 
					 $("#invFamBondCurr").val(remPriceAfDec(jointcur1)); 
					 $("#invFamBondCurr").attr("data-attr",remPriceAfDec(jointcur1)); 
					 
					  
					 $("#invSelfBondReg").val(remPriceAfDec(selfreg1));
					 $("#invSelfBondReg").attr("data-attr",remPriceAfDec(selfreg1)); 
					 
					 
					 $("#invSpsBondReg").val(remPriceAfDec(spousereg1));
					 $("#invSpsBondReg").attr("data-attr",remPriceAfDec(spousereg1)); 
					 
					 
					 $("#invFamBondReg").val(remPriceAfDec(jointreg1)); 
					 $("#invFamBondReg").attr("data-attr",remPriceAfDec(jointreg1)); 
					 
			 }
				  
				 
				 if(catg=='UT'|| catg=='ILP'){  
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Self' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   selfcur2 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());  
						   selfreg2 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
			     	   }
					   
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Spouse' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   spousecur2 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());
						   spousereg2 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
					   }
					   
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Joint' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   jointcur2 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val()  * $(this).find("td:eq(15)").find("input:eq(0)").val()); 
						   jointreg2 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
					   }  
					   
						 $("#invSelfIlputCurr").val(remPriceAfDec(selfcur2));
						 $("#invSelfIlputCurr").attr("data-attr",remPriceAfDec(selfcur2)); 
						 
						 $("#invSpsIlputCurr").val(remPriceAfDec(spousecur2));
						 $("#invSpsIlputCurr").attr("data-attr",remPriceAfDec(spousecur2)); 
						 
						 $("#invFamIlputCurr").val(remPriceAfDec(jointcur2)); 
						 $("#invFamIlputCurr").attr("data-attr",remPriceAfDec(jointcur2)); 
						  
						 $("#invSelfIlputReg").val(remPriceAfDec(selfreg2));
						 $("#invSelfIlputReg").attr("data-attr",remPriceAfDec(selfreg2)); 
						 
						 $("#invSpsIlputReg").val(remPriceAfDec(spousereg2));
						 $("#invSpsIlputReg").attr("data-attr",remPriceAfDec(spousereg2)); 
						 
						 $("#invFamIlputReg").val(remPriceAfDec(jointreg2));
						 $("#invFamIlputReg").attr("data-attr",remPriceAfDec(jointreg2)); 
					 }
				 
				 if(catg=='Stocks'){  
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Self' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   selfcur3 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val()  * $(this).find("td:eq(15)").find("input:eq(0)").val());  
						   selfreg3 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
			     	   }
					   
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Spouse' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   spousecur3 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());
						   spousereg3 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt); 
					   }
					   
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Joint' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   jointcur3 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val()); 
						   jointreg3 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
					   }  
					   
					   	 $("#invSelfShareCurr").val(remPriceAfDec(selfcur3));
						 $("#invSelfShareCurr").attr("data-attr",remPriceAfDec(selfcur3)); 
						 
						 $("#invSpsShareCurr").val(remPriceAfDec(spousecur3));
						 $("#invSpsShareCurr").attr("data-attr",remPriceAfDec(spousecur3)); 
						 
						 $("#invFamShareCurr").val(remPriceAfDec(jointcur3)); 
						 $("#invFamShareCurr").attr("data-attr",remPriceAfDec(jointcur3)); 
						 
						  
						 $("#invSelfShareReg").val(remPriceAfDec(selfreg3));
						 $("#invSelfShareReg").attr("data-attr",remPriceAfDec(selfreg3)); 
						 
						 $("#invSpsShareReg").val(remPriceAfDec(spousereg3));
						 $("#invSpsShareReg").attr("data-attr",remPriceAfDec(spousereg3)); 
						 
						 $("#invFamShareReg").val(remPriceAfDec(jointreg3)); 
						 $("#invFamShareReg").attr("data-attr",remPriceAfDec(jointreg3)); 
				 }
				 
				 
				 if(catg=='Others'){  
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Self' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   selfcur4 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());  
						   selfreg4 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
			     	   }
					   
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Spouse' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   spousecur4 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());
						   spousereg4 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
					   }
					   
					   if($(this).find("td:eq(2)").find("select:eq(0)").val()  == 'Joint' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() ==catg){
						   jointcur4 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val()); 
						   jointreg4 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
					   }   
					}  
				 
				 
				 $("#invSelfOthinvCurr").val(remPriceAfDec(selfcur4));
				 $("#invSelfOthinvCurr").attr("data-attr",remPriceAfDec(selfcur4)); 
				 
				 $("#invSpsOthinvCurr").val(remPriceAfDec(spousecur4));
				 $("#invSpsOthinvCurr").attr("data-attr",remPriceAfDec(spousecur4)); 
				 
				 $("#invFamOthinvCurr").val(remPriceAfDec(jointcur4)); 
				 $("#invFamOthinvCurr").attr("data-attr",remPriceAfDec(jointcur4)); 
				 
				  
				 $("#invSelfOthinvReg").val(remPriceAfDec(selfreg4));
				 $("#invSelfOthinvReg").attr("data-attr",remPriceAfDec(selfreg4)); 
				 
				 $("#invSpsOthinvReg").val(remPriceAfDec(spousereg4));
				 $("#invSpsOthinvReg").attr("data-attr",remPriceAfDec(spousereg4)); 
				 
				 $("#invFamOthinvReg").val(remPriceAfDec(jointreg4)); 
				 $("#invFamOthinvReg").attr("data-attr",remPriceAfDec(jointreg4));  
				 
				 
				 
				 
				 //Dividends
				 if(catg=='Dividend'){  
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Self' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   selfcur5 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());  
						   selfreg5 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
			     	   }
					   
					   if($(this).find("td:eq(2)").find("select:eq(0)").val() == 'Spouse' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() == catg){
						   spousecur5 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val());
						   spousereg5 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
					   }
					   
					   if($(this).find("td:eq(2)").find("select:eq(0)").val()  == 'Joint' &&  $(this).find("td:eq(3)").find("select:eq(0)").val() ==catg){
						   jointcur5 +=Number($(this).find("td:eq(14)").find("input:eq(0)").val() * $(this).find("td:eq(15)").find("input:eq(0)").val()); 
						   jointreg5 +=Number($(this).find("td:eq(18)").find("input:eq(0)").val() * TopUpAmt);
					   }   
					}  
				 
				 
				 $("#invSelfDivdCurr").val(remPriceAfDec(selfcur5));
				 $("#invSelfDivdCurr").attr("data-attr",remPriceAfDec(selfcur5));
				 
				 $("#invSpsDivdCurr").val(remPriceAfDec(spousecur5));
				 $("#invSpsDivdCurr").attr("data-attr",remPriceAfDec(spousecur5)); 
				 
				 $("#invFamDivdCurr").val(remPriceAfDec(jointcur5)); 
				 $("#invFamDivdCurr").attr("data-attr",remPriceAfDec(jointcur5)); 
				 
				  
				 $("#invSelfDivdReg").val(remPriceAfDec(selfreg5));
				 $("#invSelfDivdReg").attr("data-attr",remPriceAfDec(selfreg5)); 
				 
				 $("#invSpsDivdReg").val(remPriceAfDec(spousereg5));
				 $("#invSpsDivdReg").attr("data-attr",remPriceAfDec(spousereg5)); 
				 
				 $("#invFamDivdReg").val(remPriceAfDec(jointreg5)); 
				 $("#invFamDivdReg").attr("data-attr",remPriceAfDec(jointreg5));  
				 
			 
		 });
		  
	 }
	 
	 return true;
}


$('#invSelfBondCurr , #invSpsBondCurr ,#invFamBondCurr,#invSelfBondReg,'
		 +'#invSpsBondReg,#invFamBondReg,#invSelfIlputCurr,#invSpsIlputCurr,'
+'#invFamIlputCurr,#invSelfIlputReg,#invSpsIlputReg,#invFamIlputReg,'
+'#invSelfShareCurr,#invSpsShareCurr,#invFamShareCurr,#invSelfShareReg,'
+'#invSpsShareReg,#invFamShareReg,#invSelfOthinvCurr,#invSpsOthinvCurr,'
+'#invSpsOthinvCurr,#invSelfOthinvReg,#invSpsOthinvReg,#invFamOthinvReg,'
+'#invSelfDivdCurr,#invSpsDivdCurr,#invFamDivdCurr,#invSelfDivdReg,'
+'#invFamDivdReg,#invSpsDivdReg').on("change",function(){ 
	var chgeval=$(this).val();
	var oldval=$(this).attr("data-attr"); 
	if(!isEmpty(chgeval)){  
	  if((chgeval!=oldval)){
		  if(oldval != undefined && oldval != "0" && oldval != ""){
				$(this).css("color","#C0392B"); 
		
				$(this).isDisabled = true;
				$(this).qtip({
				 		content: {text : "Changed From "+oldval+" to "+chgeval+""},   
				         style: {
				             classes: 'qtip-green qtip-rounded qtip-shadow'
				         }, position: {
				             my: 'top left',   
				             at: 'bottom left', 
				             viewport: $(window),
				             target:$(this)  
				         }  
				     });
		  } 
				$(this).attr("data-attr",(isNaN(chgeval)) ? 0 : chgeval);
				$(this).val((isNaN(chgeval)) ? 0 : chgeval);
			 
	 }
	
	}
	
}); 

$("#txtFldDlgInvInstitution").on("change",function(){ 
	invcloneportflio($("#txtFldDlgInvInstitution"),$("#txtFldDlgAnalsByPortfolio"),$("#txtFldDlgInvDesc"));
});   
$("#txtFldDlgAnalsByPortfolio").on("change",function(){
	invcloneportflio($("#txtFldDlgInvInstitution"),$("#txtFldDlgAnalsByPortfolio"),$("#txtFldDlgInvDesc"));
});

function invcloneportflio(inselmid,porelmid,chgeid){ 
	chgeid.html("");
//	if(!isEmpty(chgeid.val())){
	chgeid.html('<option value="">--SELECT--</option>'); 
//	}
	//Portfolio
	if(porelmid.val() == "Y"){
		
		var apT1="<optgroup label='------Portfolio Category------'></optgroup>"; 
		chgeid.append(apT1);  
		$("#selhidPortfolio optgroup>option").each(function(i){   
			var portflio = $(this).val();  
			 if(!isEmpty(portflio)){
		  		 var clonevar=$(this).clone();  
		  		chgeid.find('optgroup[label="------Portfolio Category------"]').append(clonevar); 
			 } 
		});  
		if(chgeid.find(' optgroup[label="------Fund Name List------"]').length > 0){
			chgeid.find('optgroup[label="------Fund Name List------"]').remove(0);
		}
	}else{   
		
		if(chgeid.find('optgroup[label="------Portfolio Category------"]').length > 0){
			chgeid.find('optgroup[label="------Portfolio Category------"]').remove(0);
		}
		if(chgeid.find(' optgroup[label="------Fund Name List------"]').length > 0){
			chgeid.find('optgroup[label="------Fund Name List------"]').remove(0);
		}
		
		if(!isEmpty(inselmid.val())){ 
	var apT2="<optgroup label='------Fund Name List------'></optgroup>"; 
	var fdCode=inselmid;  
	chgeid.append(apT2);  
	$("#selhidFundName optgroup>option").each(function(i){   
		var fdnamesplit = $(this).val().split("^");  
	  	 if(!isEmpty($(this).val())){
	  		 var clonevar=$(this).clone(); 
	  		 if(fdnamesplit[0] == fdCode.val()){   
	  			clonevar.val(fdnamesplit[1]) 
	  			chgeid.find('optgroup[label="------Fund Name List------"]').append(clonevar);
	  		 }
	  	 } 
	});
	}
		
	}
	
	 return true;
}

/****************************Synronization with Investment To Retirement Planning **************************************************/
function syncInvestTblRow(){
	var owner=$("#selDlgInvOwnership").val().toUpperCase();    
	if(!(owner == "Joint")){
		applyToastrAlert("Investment data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen");
	    getincassrtRows(null,"N");
	 
	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	
	var $tblInvRow=$("#fnaInvestmentTbl tbody tr:last");
	var $tblRetRow=$("#IncAssRetPlgtbl tbody tr:last");
	 

	var dte=new Date();
	var rowRefID=$tblInvRow.attr("rowref");
		if(isValidObject(rowRefID)){
			rowRefID=rowRefID;
		}else{
			rowRefID="INV_"+$tblInvRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
			 dte.getSeconds()+dte.getMilliseconds();
		}

	//Reference ID
	$tblInvRow.attr("rowref",rowRefID);
	$tblRetRow.attr("rowref",rowRefID); 
	
	$tblInvRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
	$tblRetRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);

	
	
	$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Investment");//Classification
	
	//Description of Inv
	$tblRetRow.find("td:eq(3)").find('input:eq(0)').val((isEmpty($("#txtFldDlgInvDesc").val()))?"":$("#txtFldDlgInvDesc option:selected").text());//description
	
 
	//Frequency
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR");
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
		if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
	}); 
	
 	//Amount Invested
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').val(isEmpty($("#txtFldDlgInvAmt").val())?Number("0"):Number($("#txtFldDlgInvAmt").val()));//Amount of income
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	
	 
	//escalation rate
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').val(Number("0")); 
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	//roi
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').val(Number("0")); 
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	
	//ownership of investment
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner);//Age based on 
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
	}); 

	//Retirement self age
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage)); //Age Inc starts
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
	}); 

	 //pro living age
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge));//Age Ends
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//		if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
	}); 

	applyEventHandlers();
	}
	return true;
}


function syncInvestTblEditRow($lastrow){
 
	var flg=false;
	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	

		var $tblRetRow=$("#IncAssRetPlgtbl tbody tr:last"); 
		
		
	var $rowref=$lastrow.attr("rowref");
	$lastrow.attr("rowref",$rowref); 
	
	var descval,amt,owner,obj;
	 

	var chklength=$("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]").length;
	
	if(chklength >0){
		
	$("#fnaInvestmentTbl tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
		  descval=$(this).find("td:eq(7)").find('select:eq(0)').val();//description
		  desctext=$(this).find("td:eq(7)").find('option:selected').text();//desc text
		  amt=$(this).find("td:eq(9)").find('input:eq(0)').val();//amt invested
		  owner=$(this).find("td:eq(2)").find('select:eq(0)').val().toUpperCase();//ownership of investment 
		  obj=$(this).find("td:eq(21)").find('select:eq(0)').val();  //objective of investment
	});
	
	
	if(!(owner == "Joint")){
if(obj == "Retirement Planning"){
	applyToastrAlert("Investment data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
	 
	 
	$("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
		//Reference ID
		var $tblRetRow=$(this);
		$tblRetRow.attr("rowref",$rowref);  
		$tblRetRow.find("td:eq(0)").find('input:eq(2)').val($rowref);
		
		//classification
		$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Investment");
		//description
		$tblRetRow.find("td:eq(3)").find('input:eq(0)').val((isEmpty(descval))?"":desctext);
		$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR");
		$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
			if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
		}); 

		$tblRetRow.find("td:eq(5)").find('input:eq(0)').val(isEmpty(amt)?Number("0"):Number(amt));
		$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
		
		$tblRetRow.find("td:eq(6)").find('input:eq(0)').val(Number("0")); 
		$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
		
		$tblRetRow.find("td:eq(7)").find('input:eq(0)').val(Number("0"));  
		$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
		
		
		$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner);//Need to check 
		
		$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
			if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
		}); 
		
		$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage)); 
		$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
			if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
		}); 
		
		$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge));
		$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//			if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
		}); 
		
    });
	}else{
		IncAssRetPlgtbl.row($("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowref+"]")).remove().draw();
	}
	}
 }else{
		if($lastrow.find("td:eq(21)").find('select:eq(0)').val() ==  "Retirement Planning" ){
			if(!($lastrow.find("td:eq(2)").find('select:eq(0)').val() == "Joint")){
				newRowInvestTbl($lastrow);
			}
		}
}
 
	
return true;
}



function newRowInvestTbl($tblInvRow){
var owner=$tblInvRow.find("td:eq(2)").find('select:eq(0)').val().toUpperCase();   
	
	if(!(owner == "Joint")){
		
	
applyToastrAlert("Investment data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen");
	
	getincassrtRows(null,"N");
	 
	var intretslfage=isEmpty($("#txtFldRDSlfIntAge").val())? 0 :Number($("#txtFldRDSlfIntAge").val()); 
	var totAge=isEmpty($("#txtFldRDSlfProjLfe").val())? 0 :Number($("#txtFldRDSlfProjLfe").val());
	 var basedon=$("#retAgeBasedon").val().toUpperCase();
	
	var $tblInvRow=$("#fnaInvestmentTbl tbody tr:last");
	var $tblRetRow=$("#IncAssRetPlgtbl tbody tr:last");
	 

	var dte=new Date();
	
	 
	var rowRefID=$tblInvRow.attr("rowref");
		if(isValidObject(rowRefID)){
			rowRefID=rowRefID;
		}else{
			rowRefID="INV_"+$tblInvRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
			 dte.getSeconds()+dte.getMilliseconds();
		}

	$tblInvRow.attr("rowref",rowRefID);
	$tblRetRow.attr("rowref",rowRefID); 
	

	$tblInvRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
	$tblRetRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
	
	
	$tblRetRow.find("td:eq(2)").find('input:eq(0)').val("Investment");
	
	$tblRetRow.find("td:eq(3)").find('input:eq(0)').val((isEmpty($tblInvRow.find("td:eq(7)").find('select:eq(0)').val()))?"":$tblInvRow.find("td:eq(7)").find('option:selected').text());
	
 
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').val("REGULAR");
	$tblRetRow.find("td:eq(4)").find('select:eq(0)').on("change",function(){
		if(!rdFrequencyValidation($tblRetRow.find("td:eq(10)").find('input:eq(0)'),$tblRetRow.find("td:eq(6)").find('input:eq(0)'),$(this)))return;
	}); 
 	
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').val(isEmpty($tblInvRow.find("td:eq(9)").find('input:eq(0)').val())?Number("0"):Number($tblInvRow.find("td:eq(9)").find('input:eq(0)').val()));
	$tblRetRow.find("td:eq(5)").find('input:eq(0)').addClass("applyEvntUsd");
	
	
	
	
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').val(Number("0")); 
	$tblRetRow.find("td:eq(6)").find('input:eq(0)').addClass("applyEvntpCent3");
	
	
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').val(Number("0")); 
	$tblRetRow.find("td:eq(7)").find('input:eq(0)').addClass("applyEvntpCent3");
	
 
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').val(isEmpty(owner)? basedon :owner);//Need to check 
	$tblRetRow.find("td:eq(8)").find('select:eq(0)').on("change",function(){ 
		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
	}); 

	
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').val((isEmpty(intretslfage)) ? Number("0") : Number(intretslfage)); 
	$tblRetRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
		if(!rdStartAgeValidate($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$tblRetRow.find("td:eq(8)").find('select:eq(0)')))return;
	}); 

	
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').val((isEmpty(totAge)) ? Number("0") : Number(totAge)); 
	$tblRetRow.find("td:eq(10)").find('input:eq(0)').on("change",function(){
//		if(!rdFrequencyValidation($tblRetRow.find("td:eq(9)").find('input:eq(0)'),$(this)))return; 
	}); 

	applyEventHandlers();
	}
	return true;
	
}

/****************************End of Synronization with Investment To Retirement Planning **************************************************/



/**************************** Total Calculated Value from Investment To Expected Inflow Outflow(Investment/divident) ***********************/
function calcTotalInvestAmts(){  
	 var sumslfcash=0,sumspscash=0,sumfamcash=0;
	 var $fnaInvestmentTbl = fnaInvestmentTbl.rows().count();
var ownership;
 
	 if($fnaInvestmentTbl >0){
		 
		 $("#fnaInvestmentTbl tbody tr").each(function(i,row){
			 ownership=$(this).find("td:eq(2)").find('select:eq(0)').val(); 
			 var CurNavAmt	=Number($(this).find("td:eq(16)").find("input:eq(0)").val()); //Current NAV
			 var annlDivd=Number($(this).find("td:eq(11)").find("input:eq(0)").val())/100; //Annual Dividend
			 var dividPaymode=$(this).find("td:eq(12)").find("select:eq(0)").val();
			   
			 var TopUpAmt=0; 
			
			 if(!isEmpty(dividPaymode)){
				 if(dividPaymode == 'ANNUAL'){
						TopUpAmt=1;
					}else if(dividPaymode == 'SEMI ANNUAL'){
						TopUpAmt=2;
					}else if(dividPaymode == 'QUARTERLY'){
						TopUpAmt=4;
					}else if(dividPaymode == 'MONTHLY'){
						TopUpAmt=12;
					}else if(dividPaymode == 'SINGLE'){
						TopUpAmt=0;
					}
			 }
			 
			 
			 var amount = CurNavAmt * annlDivd * TopUpAmt;
			 
			 
			 if(!isEmpty(amount)){if(ownership =="Self"){sumslfcash +=Number(amount);}}
			 if(!isEmpty(amount)){if(ownership =="Spouse"){sumspscash +=Number(amount);}}
			 if(!isEmpty(amount)){if(ownership =="Joint"){sumfamcash +=Number(amount);}}
		
			   
			 
		 });
	 }
	 
	 console.log(sumslfcash);
	 console.log(sumspscash);
	 console.log(sumfamcash);
	 
	 
	 
	 if(!( sumslfcash==0 && sumspscash==0 && sumfamcash==0 )){ 
		applyToastrAlert("Investment Income,dividends, gains is calculated and Reflected to Expected fund Inflow and Outflow Screen");
		if(ownership =="Self"){$("#incsrcSelfNempDivdamt").val(remPriceAfDec(sumslfcash));}
		
		if(ownership =="Spouse"){$("#incsrcSpsNempDivdamt").val(remPriceAfDec(sumspscash));}
		
		if(ownership =="Joint"){$("#incsrcJointNempDivdamt").val(remPriceAfDec(sumfamcash));}
	 } 
	 
	 
	 if(sumslfcash==0){
		 $("#incsrcSelfNempDivdamt").val(sumslfcash);
	 }
	 if(sumspscash==0){
		 $("#incsrcSpsNempDivdamt").val(sumspscash);
	 }
	 if( sumfamcash==0 ){
		 $("#incsrcJointNempDivdamt").val(sumfamcash);
	 }
	 
	 
	 calcSum(null,SrcOF_Inc.SRCOFINCM_SLF);
	 calcSum(null,SrcOF_Inc.SRCOFINCM_SPS);
	 calcSum(null,SrcOF_Inc.SRCOFINCM_JOINT);
	 
	 return true;
}
 
/****************************Synronization with Investment To Cash At Bank**************************************************/
function newRowInvestCobEditTbl($lastrow){
 
	var flg=false;
	var $tblCobRow=$("#cashOfBanksTable tbody tr:last"); 
		
		
	var $rowref=$lastrow.attr("rowref");
	$lastrow.attr("rowref",$rowref); 
	
	var paymentmtd,ownership,amtinvested,reqfreq,reqinvamt,objofinv,yrofret,nameofchd;
	 

	var chklength=$("#cashOfBanksTable  tbody").find("tr[rowref="+$rowref+"]").length;
	
	if(chklength >0){
		
	$("#fnaInvestmentTbl tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
		paymentmtd	=$(this).find("td:eq(10)").find('select:eq(0)').val(); 
		ownership 	=$(this).find("td:eq(2)").find('select:eq(0)').val(); 
		amtinvested	=$(this).find("td:eq(9)").find('input:eq(0)').val();
		reqfreq		=$(this).find("td:eq(18)").find('select:eq(0)').val();
		reqinvamt	=$(this).find("td:eq(18)").find('input:eq(0)').val();
		objofinv	=$(this).find("td:eq(21)").find('select:eq(0)').val();
		yrofret		=$(this).find("td:eq(22)").find('input:eq(0)').val();
		nameofchd	=$(this).find("td:eq(23)").find('select:eq(0)').val();
	});

	if(!isEmpty(paymentmtd)){ 
		if(paymentmtd == "Cash" ){
			applyToastrAlert("Investment data will be reflected to Cash At Banks Details ");
	 
	$("#cashOfBanksTable  tbody").find("tr[rowref="+$rowref+"]").each(function(){ 

		var $tblCobRow=$(this);
		$tblCobRow.attr("rowref",$rowref);  
		
		 if(ownership == "Self"){
			 $tblCobRow.find("td:eq(2)").find('option:eq(1)').prop("selected","selected");
		 }else  if(ownership == "Spouse"){
			 $tblCobRow.find("td:eq(2)").find('option:eq(2)').prop("selected","selected");
		 }else{
			 $tblCobRow.find("td:eq(2)").find('option:eq(0)').prop("selected","selected");
		 } 
		 
		  
		 $tblCobRow.find("td:eq(3)").find('input:eq(0)').val(""); 
		 $tblCobRow.find("td:eq(4)").find('select:eq(0)').val("");
		  
		 $tblCobRow.find("td:eq(5)").find('select:eq(0)').val(ownership);
		 $tblCobRow.find("td:eq(5)").find('select:eq(0)').on("change",function(){
			 	 syncCashAtBankTblEditRow($tblCobRow);
				return; 
		});



		 $tblCobRow.find("td:eq(6)").find('input:eq(0)').val(""); 
		 $tblCobRow.find("td:eq(7)").find('input:eq(0)').val("");
		 
		 $tblCobRow.find("td:eq(8)").find('select:eq(0)').val("Current");
		 

		  
		 $tblCobRow.find("td:eq(9)").find('input:eq(0)').val(amtinvested);
		 $tblCobRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd26");
		 $tblCobRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){ 
				syncCashAtBankTblEditRow($tblCobRow);
				return;
		});


		 $tblCobRow.find("td:eq(10)").find('input:eq(0)').val(reqinvamt);
		 $tblCobRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntUsd26");
		 

		 $tblCobRow.find("td:eq(11)").find('select:eq(0)').val(reqfreq);
		  

		 $tblCobRow.find("td:eq(12)").find('input:eq(0)').val("");
		 $tblCobRow.find("td:eq(12)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
		 	 checkDateFormat($(this));  
		 	 if(!dhtmlChkDateValidation($tblCobRow.find("td:eq(12)").find('input:eq(0)'),$tblCobRow.find("td:eq(13)").find('input:eq(0)'),"To Date should greater than the From Date"));  
				return;
		 });

		 $tblCobRow.find("td:eq(13)").find('input:eq(0)').val("");
		 $tblCobRow.find("td:eq(13)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
		 	 checkDateFormat($(this));  
		 	 if(!dhtmlChkDateValidation($tblCobRow.find("td:eq(12)").find('input:eq(0)'),$tblCobRow.find("td:eq(13)").find('input:eq(0)'),"To Date should greater than the From Date"));  

				return;
		 });

		 var cobobj;
		 if(objofinv == "Retirement Planning"){
			 cobobj="Retirement";
		 }else if(objofinv == "Education Planning"){
			 cobobj="Child Education";
		 }else{
			 cobobj="";
		 }
			 
		 $tblCobRow.find("td:eq(14)").find('select:eq(0)').val(cobobj); 
		 $tblCobRow.find("td:eq(14)").find('select:eq(0)').on("change",function(){ 
				if($(this).val() == "Retirement"){	if(!validationRetirementScreen())return;} 
					syncCashAtBankTblEditRow($tblCobRow); 
					return;
			});

		 $tblCobRow.find("td:eq(15)").find('input:eq(0)').val(yrofret);
		 $tblCobRow.find("td:eq(15)").find('input:eq(0)').addClass("applyEvntpCent26");  
		 $tblCobRow.find("td:eq(16)").find('select:eq(0)').val(nameofchd); 
		 $tblCobRow.find("td:eq(17)").find('input:eq(0)').val($("#txtFldDlgCOBRemarks").val());  
		 applyEventHandlers();
		
    });
	}else{
		cashOfBanksTable.row($("#cashOfBanksTable  tbody").find("tr[rowref="+$rowref+"]")).remove().draw();
	}
		}else{
			cashOfBanksTable.row($("#cashOfBanksTable  tbody").find("tr[rowref="+$rowref+"]")).remove().draw();
		} 
 }else{
		if($lastrow.find("td:eq(10)").find('select:eq(0)').val() ==  "Cash" ){
			newRowInvestCobTbl($lastrow);
		}
 }
return true;
}


function newRowInvestCobTbl($tblInvRow){
	 
	
	getCobRows(null);
	  
	
	var $tblInvRow=$("#fnaInvestmentTbl tbody tr:last");
	var $tblCobRow=$("#cashOfBanksTable tbody tr:last");
	  
	var dte=new Date(); 
	var rowRefID=$tblInvRow.attr("rowref");
		if(isValidObject(rowRefID)){
			rowRefID=rowRefID;
		}else{
			rowRefID="INV_"+$tblInvRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
			 dte.getSeconds()+dte.getMilliseconds();
		}

		
	$tblInvRow.attr("rowref",rowRefID);
	$tblCobRow.attr("rowref",rowRefID);
	

	$tblInvRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
	$tblCobRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);

	var paymentmtd	=$tblInvRow.find("td:eq(10)").find('select:eq(0)').val(); 
	var ownership 	=$tblInvRow.find("td:eq(2)").find('select:eq(0)').val(); 
	var amtinvested	=$tblInvRow.find("td:eq(9)").find('input:eq(0)').val();
	var reqfreq		=$tblInvRow.find("td:eq(18)").find('select:eq(0)').val();
	var reqinvamt	=$tblInvRow.find("td:eq(18)").find('input:eq(0)').val();
	var objofinv	=$tblInvRow.find("td:eq(21)").find('select:eq(0)').val();
	var yrofret		=$tblInvRow.find("td:eq(22)").find('input:eq(0)').val();
	var nameofchd	=$tblInvRow.find("td:eq(23)").find('select:eq(0)').val();
	
	
	if(!isEmpty(paymentmtd)){ 
		if(paymentmtd == "Cash" ){
		applyToastrAlert("Investment data will be reflected to Cash At Banks Details ");  
		 if(ownership == "Self"){
			 $tblCobRow.find("td:eq(2)").find('option:eq(1)').prop("selected","selected");
		 }else  if(ownership == "Spouse"){
			 $tblCobRow.find("td:eq(2)").find('option:eq(2)').prop("selected","selected");
		 }else{
			 $tblCobRow.find("td:eq(2)").find('option:eq(0)').prop("selected","selected");
		 } 
		 
		  
		 $tblCobRow.find("td:eq(3)").find('input:eq(0)').val(""); 
		 $tblCobRow.find("td:eq(4)").find('select:eq(0)').val("");
		  
		 $tblCobRow.find("td:eq(5)").find('select:eq(0)').val(ownership);
		 $tblCobRow.find("td:eq(5)").find('select:eq(0)').on("change",function(){
			 	
				syncCashAtBankTblEditRow($tblCobRow);
				return; 
		});



		 $tblCobRow.find("td:eq(6)").find('input:eq(0)').val(""); 
		 $tblCobRow.find("td:eq(7)").find('input:eq(0)').val("");
		 
		 $tblCobRow.find("td:eq(8)").find('select:eq(0)').val("Current");
		 

		  
		 $tblCobRow.find("td:eq(9)").find('input:eq(0)').val(amtinvested);
		 $tblCobRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd26");
		 $tblCobRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){ 
				syncCashAtBankTblEditRow($tblCobRow);
				return;
		});


		 $tblCobRow.find("td:eq(10)").find('input:eq(0)').val(reqinvamt);
		 $tblCobRow.find("td:eq(10)").find('input:eq(0)').addClass("applyEvntUsd26");
		 

		 $tblCobRow.find("td:eq(11)").find('select:eq(0)').val(reqfreq);
		  

		 $tblCobRow.find("td:eq(12)").find('input:eq(0)').val("");
		 $tblCobRow.find("td:eq(12)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
		 	 checkDateFormat($(this));  
		 	 if(!dhtmlChkDateValidation($tblCobRow.find("td:eq(12)").find('input:eq(0)'),$tblCobRow.find("td:eq(13)").find('input:eq(0)'),"To Date should greater than the From Date"));  

				return;
		 });

		 $tblCobRow.find("td:eq(13)").find('input:eq(0)').val("");
		 $tblCobRow.find("td:eq(13)").find('input:eq(0)').datetimepicker(dateOptions).on("change",function(){
		 	 checkDateFormat($(this));  
		 	 if(!dhtmlChkDateValidation($tblCobRow.find("td:eq(12)").find('input:eq(0)'),$tblCobRow.find("td:eq(13)").find('input:eq(0)'),"To Date should greater than the From Date"));  

				return;
		 });

		 var cobobj;
		 if(objofinv == "Retirement Planning"){
			 cobobj="Retirement";
		 }else if(objofinv == "Education Planning"){
			 cobobj="Child Education";
		 }else{
			 cobobj="";
		 }
			 
		 $tblCobRow.find("td:eq(14)").find('select:eq(0)').val(cobobj); 
		 $tblCobRow.find("td:eq(14)").find('select:eq(0)').on("change",function(){ 
				if($(this).val() == "Retirement"){	if(!validationRetirementScreen())return;} 
					syncCashAtBankTblEditRow($tblCobRow); 
					return;
			});

		 $tblCobRow.find("td:eq(15)").find('input:eq(0)').val(yrofret);
		 $tblCobRow.find("td:eq(15)").find('input:eq(0)').addClass("applyEvntpCent26");  
		 $tblCobRow.find("td:eq(16)").find('select:eq(0)').val(nameofchd); 
		 $tblCobRow.find("td:eq(17)").find('input:eq(0)').val($("#txtFldDlgCOBRemarks").val());  
		 applyEventHandlers();
	}  
  }
	 
	return true;
}


/****************************Synronization with Investment To Cpf Addition and Deduction**************************************************/
function newRowInvestCpfEditTbl($lastrow){
 
	var flg=false;
	var $tblCpfRow=$("#cpfAccAddDedTable tbody tr:last"); 
		
		
	var $rowref=$lastrow.attr("rowref");
	$lastrow.attr("rowref",$rowref); 
	
	var paymentmtd,ownership,amtinvested;
	 

	var chklength=$("#cpfAccAddDedTable  tbody").find("tr[rowref="+$rowref+"]").length;
	
	if(chklength > 0){
		
	$("#fnaInvestmentTbl tbody").find("tr[rowref="+$rowref+"]").each(function(){ 
		paymentmtd	=$(this).find("td:eq(10)").find('select:eq(0)').val(); 
		ownership = $(this).find("td:eq(2)").find('select:eq(0)').val(); 
		amtinvested=$(this).find("td:eq(9)").find('input:eq(0)').val();
	});

	if(!isEmpty(paymentmtd)){ 
		if(paymentmtd == "CPFOA" || paymentmtd == "CPFSA" || paymentmtd == "CPFMA" || paymentmtd == "CPFRA"){ 
		applyToastrAlert("Investment data will be reflected to CPF Account - Additions & Deductions of funds into CPF A/C in Central Provident Fund Screen");
		 var cpfacc,ccid;
		 
		 if(paymentmtd == "CPFOA"){cpfacc="Ordinary";ccid="CPFACC000001";}
		 else if(paymentmtd == "CPFSA"){cpfacc="Special";ccid="CPFACC000002";}
		 else if(paymentmtd == "CPFMA"){cpfacc="Medisave";ccid="CPFACC000003";}
		 else if(paymentmtd == "CPFRA"){cpfacc="Retirement";ccid="CPFACC000003";}
		 else {cpfacc="";ccid="";}
		  
		 
		 
		 if(ownership == "Self"){
			 $tblCpfRow.find("td:eq(2)").find('option:eq(1)').prop("selected","selected");
		 }else  if(ownership == "Spouse"){
			 $tblCpfRow.find("td:eq(2)").find('option:eq(2)').prop("selected","selected");
		 }else{
			 $tblCpfRow.find("td:eq(2)").find('option:eq(0)').prop("selected","selected");
		 } 
		 $tblCpfRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
			 changeOnCADType($(this));
			 reverseCpfSync($tblCpfRow);
		});
		  
		 $tblCpfRow.find("td:eq(3)").find('select:eq(0)').val(ownership); 
		 $tblCpfRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
				reverseCpfSync($tblCpfRow);	
			});
		  
		 $tblCpfRow.find("td:eq(4)").find('select:eq(0)').val("Investment"); 


		 
		 $tblCpfRow.find("td:eq(5)").find('select:eq(0)').val("Deduction"); 
 
		 
		 
		 $tblCpfRow.find("td:eq(6)").find('input:eq(0)').val(ccid); 
		 $tblCpfRow.find("td:eq(6)").find('input:eq(1)').val(cpfacc);
		 $tblCpfRow.find("td:eq(6)").find('input:eq(1)').on("change",function(){
				reverseCpfSync($tblCpfRow);	
			});
		  
		 $tblCpfRow.find("td:eq(7)").find('input:eq(0)').val("");
		 $tblCpfRow.find("td:eq(7)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
		 	 checkDateFormat($(this));  
		 	 if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));  
		 	  
		 }); 

		 $tblCpfRow.find("td:eq(8)").find('input:eq(0)').val("");
		 $tblCpfRow.find("td:eq(8)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
		 	 checkDateFormat($(this));  
		 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
		 });

	 
		 $tblCpfRow.find("td:eq(9)").find('input:eq(0)').val(amtinvested);
		 $tblCpfRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
		 $tblCpfRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
				reverseCpfSync($tblCpfRow);	
			});
		  
		  
		 $tblCpfRow.find("td:eq(10)").find('select:eq(0)').val(""); 


		  
		 $tblCpfRow.find("td:eq(11)").find('select:eq(0)').val(""); 
		 
		 

		 applyEventHandlers();

	}  else{
		cpfAccAddDedTable.row($("#cpfAccAddDedTable  tbody").find("tr[rowref="+$rowref+"]")).remove().draw();
	}
  }else{
	  cpfAccAddDedTable.row($("#cpfAccAddDedTable  tbody").find("tr[rowref="+$rowref+"]")).remove().draw();
  }
 }else{
	 if($lastrow.find("td:eq(10)").find('select:eq(0)').val()  == "CPFOA" || $lastrow.find("td:eq(10)").find('select:eq(0)').val()  == "CPFSA" || 
			 $lastrow.find("td:eq(10)").find('select:eq(0)').val()  == "CPFMA" || $lastrow.find("td:eq(10)").find('select:eq(0)').val()  == "CPFRA"){
			newRowInvestCpfTbl($lastrow);
	}
 }
return true;
}


function newRowInvestCpfTbl($tblInvRow){
	
	 
	 getCADRows(null);
	  
	
	var $tblInvRow=$("#fnaInvestmentTbl tbody tr:last");
	var $tblCpfRow=$("#cpfAccAddDedTable tbody tr:last");
	 
 
	var dte=new Date(); 
	var rowRefID=$tblInvRow.attr("rowref");
		if(isValidObject(rowRefID)){
			rowRefID=rowRefID;
		}else{
			rowRefID="INV_"+$tblInvRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
			 dte.getSeconds()+dte.getMilliseconds();
		}

		
	$tblInvRow.attr("rowref",rowRefID);
	$tblCpfRow.attr("rowref",rowRefID);
	

	$tblInvRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
	$tblCpfRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);

	var paymentmtd	=$tblInvRow.find("td:eq(10)").find('select:eq(0)').val();//Payment method
	var ownership 	=$tblInvRow.find("td:eq(2)").find('select:eq(0)').val();//ownership
	var amtinvested	=$tblInvRow.find("td:eq(9)").find('input:eq(0)').val();//amount invested
	var reqfreq		=$tblInvRow.find("td:eq(18)").find('select:eq(0)').val();//regular frequency
	var reqinvamt	=$tblInvRow.find("td:eq(18)").find('input:eq(0)').val();//investment amount
	var objofinv	=$tblInvRow.find("td:eq(21)").find('select:eq(0)').val();//objective of investment
	var yrofret		=$tblInvRow.find("td:eq(22)").find('input:eq(0)').val();//year of retirement
	var nameofchd	=$tblInvRow.find("td:eq(23)").find('select:eq(0)').val();//name of child
	
	if(!isEmpty(paymentmtd)){ 
		if(paymentmtd == "CPFOA" || paymentmtd == "CPFSA" || paymentmtd == "CPFMA" || paymentmtd == "CPFRA"){
		applyToastrAlert("Investment data will be reflected to CPF Account - Additions & Deductions of funds into CPF A/C in Central Provident Fund Screen !");
		var cpfacc,ccid;
		 
		 if(paymentmtd == "CPFOA"){cpfacc="Ordinary";ccid="CPFACC000001";}
		 else if(paymentmtd == "CPFSA"){cpfacc="Special";ccid="CPFACC000002";}
		 else if(paymentmtd == "CPFMA"){cpfacc="Medisave";ccid="CPFACC000003";}
		 else if(paymentmtd == "CPFRA"){cpfacc="Retirement";ccid="CPFACC000003";}
		 else {cpfacc="";ccid="";}
	 
		 
		 
		 if(ownership == "Self"){
			 $tblCpfRow.find("td:eq(2)").find('option:eq(1)').prop("selected","selected");//Name of account
		 }else  if(ownership == "Spouse"){
			 $tblCpfRow.find("td:eq(2)").find('option:eq(2)').prop("selected","selected");
		 }else{
			 $tblCpfRow.find("td:eq(2)").find('option:eq(0)').prop("selected","selected");
		 } 
		 
		 
		 $tblCpfRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
			 changeOnCADType($(this));
			 reverseCpfSync($tblCpfRow);
		});
		  
		 $tblCpfRow.find("td:eq(3)").find('select:eq(0)').val(ownership); //Applicant Type
		 $tblCpfRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
				reverseCpfSync($tblCpfRow);	
		 });
		 
		  
		 $tblCpfRow.find("td:eq(4)").find('select:eq(0)').val("Investment"); //Description of Investment


		 
		 $tblCpfRow.find("td:eq(5)").find('select:eq(0)').val("Deduction"); //Types of Transaction
 
		 
		 $tblCpfRow.find("td:eq(6)").find('input:eq(0)').val(ccid);//Type of CPF Account 
		 $tblCpfRow.find("td:eq(6)").find('input:eq(1)').val(cpfacc);
		 $tblCpfRow.find("td:eq(6)").find('input:eq(1)').on("change",function(){
				reverseCpfSync($tblCpfRow);	
			});
		  
		 $tblCpfRow.find("td:eq(7)").find('input:eq(0)').val("");//Period From
		 $tblCpfRow.find("td:eq(7)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
		 	 checkDateFormat($(this));  
		 	 if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));  
		 	  
		 }); 

		 $tblCpfRow.find("td:eq(8)").find('input:eq(0)').val("");//Period To
		 $tblCpfRow.find("td:eq(8)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
		 	 checkDateFormat($(this));  
		 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
		 });

	 
		 $tblCpfRow.find("td:eq(9)").find('input:eq(0)').val(amtinvested);//Amount
		 $tblCpfRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
		 $tblCpfRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
				reverseCpfSync($tblCpfRow);	
			});
		  
		  
		 $tblCpfRow.find("td:eq(10)").find('select:eq(0)').val(""); //Frequency of Transaction


		  
		 $tblCpfRow.find("td:eq(11)").find('select:eq(0)').val(""); //Amt to be transferred
		 
		 

		 applyEventHandlers();

	}  
  }
	 
	 
	return true;
}
/**************************** Clear Current NAV on Focus and Onchange Description of Investment***********************/
var invclearnavprev,invclearnavid;
$("#txtFldDlgInvDesc,#txtFldDlgInvDateInvst,#txtFldDlgInvInstitution").on("focus",function(){ 
	invclearnavid=$(this).attr("id");
	invclearnavprev=$(this).val();
	
}).change(function(){
	clearCurrentBidPriceAlert($(this),invclearnavid,invclearnavprev,$("#txtFldDlgInvCurBid"),null);
});

function clearCurrentBidPriceAlert(elmid,invclearnavid,invclearnavprev,curbidprcid,row){
	if(!isEmpty(elmid.val())){ 
		if(!isEmpty(curbidprcid.val())){
			$("#confirmationalertmsgdiv #confalertimg").html(""); 
			$("#confirmationalertmsgdiv #confalertmsg").html("Do you want to clear Current Bid Price");
			$('#confirmationalertmsgdiv').modal({
				  backdrop: 'static',
				  keyboard: false,
				  show:true,
				}); 
			$('#confirmationalertmsgdiv').on('shown.bs.modal', function() {  
				$('#confirmationalertmsgdiv').find(".modal-title").text("FIPA - Message");
				$('#confirmationalertmsgdiv').find(".modal-footer").find("button:eq(0)").unbind(); 
				$('#confirmationalertmsgdiv').find(".modal-footer").find("button:eq(0)").click(function (){   
						curbidprcid.val("");   
						currentNavcalc(row);
						$('#confirmationalertmsgdiv').modal('hide');  
					  	
				  });
				$('#confirmationalertmsgdiv').find(".modal-footer").find("button:eq(1)").click(function (){ 
						$("#"+invclearnavid).val(invclearnavprev);
					  	currentNavcalc(row);
					  	$('#confirmationalertmsgdiv').modal('hide');  
					  	
				  });
				
			});
		
			
			
			}
		}	
}
 
/**************************** Fetch Current NAV From DB***********************/
$("a#genNavicon").on("click",function(){
	if(!validateNavDetails())return;   
	fetchCurentNAV($("#txtFldDlgAnalsByPortfolio"),$("#txtFldDlgInvDesc"),$("#txtFldDlgInvDateInvst"),$("#txtFldDlgInvCurBid")); 
});

function fetchCurentNAV(port,desc,date,curbid){
	var portofolioExist = port.val();
 
	if(portofolioExist == "N" || portofolioExist == ""){ 

	var fundcode  =desc.val();
	var dateInvest=date.val();
	showLoader(); 
	parameter = "DBCALLFOR=FETCH_NAV&strFundCode="+fundcode+"&strDateInvest="+dateInvest;
		 ajaxCall(parameter,servletName,function(Data){ 
			var retval = Data;  
			hideLoader(); 
	 		for ( var val in retval) { 
	 			var tabdets = retval[val];

	 			if (tabdets["SESSION_EXPIRY"]) {
	 				window.location = BASE_URL +  SESSION_EXP_JSP;
	 				return;
	 			}
	 			if (tabdets["DB_ERROR"]) {
	 				window.location = BASE_URL +  DB_EXP_JSP;
	 				return;
	 			} 

	 			if(tabdets["CURRENT_NAV"]){ 
	 				var navval=tabdets["CURRENT_NAV"];  
	 				curbid.val(navval);
	 				currentNavcalc(null);
				} 
	 			
	 			if(tabdets["NO_NAV"]){ 
	 				var navval=tabdets["NO_NAV"];  
	 				curbid.val(navval);
	 				currentNavcalc(null);
	 				
				} 
	 			
	 			
	 		}
		}); 
	}else{
		showAlert(NONAV_CALCULATED);
	}
	return true;
}
 

/**************************** Child Name based Year to Teritary Education Validation***********************/

$("#selDlgInvNameOfChild").on("change",function(){
	getChildYrtoTerEduc($(this),$("#selDlgInvYrToRet"));
});

function getChildYrtoTerEduc(curElm,chgElm){
	if(!isEmpty(curElm.val())){ 
		var rowCount = chldpartTbl.rows().count();	 
		if(rowCount >0){ 
			$('#childParticularsTable tbody').find('tr').each(function(){
				var childname=$(this).find("td:eq(2)").find("input:eq(0)").val();
				if(childname == curElm.val()){
					chgElm.val($(this).find("td:eq(9)").find("input:eq(0)").val());
				}
			}); 
		}
	}
}

/***************************************Mandatory Validation*************************************************/
 
function validateNavDetails(){
	
	
	 
	if(!(validateFocusFlds('Investment_Dialog','txtFldDlgInvInstitution', IPINVST_INSNAME))) return;
	if(!(validateFocusFlds('Investment_Dialog','txtFldDlgInvDesc', IPINVST_FUNDCODE))) return;
	if(!(validateFocusFlds('Investment_Dialog','txtFldDlgInvDateInvst',IPINST_DATEINV))) return; 
	
	  return true; 
}
 
/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgInvInstitution,#txtFldDlgInvDesc,#txtFldDlgInvDateInvst").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});

/**************************** Payment Method Validation***********************/
$("#txtFldDlgInvSource").on("change",function(){
	invpaymentmtd($(this),$("#txtFldDlgAnlDivd"),$("#selDlgDivdPaymode"));
});



function invpaymentmtd(elmid,changeid,chgeid2){
	var invpaycash=elmid.val(); 
	if(invpaycash == 'Cash'){  
		$("#invAnlDivid").css("display","block");
		$("#invDividPaymode").css("display","block");
		changeid.prop("readonly",false);
		chgeid2.prop("disabled",false);
	} else{
		$("#invAnlDivid").css("display","none");
		$("#invDividPaymode").css("display","none");
		changeid.prop("readonly",true);
		changeid.val("");
		chgeid2.prop("disabled",true);
		chgeid2.val("");
	}
	
	return true;
}

/****************************Analysis By Portfolio validation***********************/
$("#txtFldDlgAnalsByPortfolio").on("change",function(){
 invportfolioChk($(this));
});

function invportfolioChk(elmid){
	if(elmid.val() == 'Y'){  
		$("#currentnavdiv").find("label[id=currentnavlabelchange]").text("Current Portfolio NAV");
	}else{
		$("#currentnavdiv").find("label[id=currentnavlabelchange]").text("Current NAV");
	}
}


/****************************Objective based Year to retirement validation***********************/
$("#selDlgInvObjInvst,#selDlgInvYrToRet").on("change",function(){
	yrtoretirementChk($("#selDlgInvYrToRet"));
});
  
function yrtoretirementChk(elmid){
	var yrtoretirement=elmid.val(); 
	var oriretyr=$("#retYrstoret").val();
	if(!isEmpty(yrtoretirement) && !isEmpty($("#selDlgInvObjInvst").val())){
	if($("#selDlgInvObjInvst").val() == "Retirement Planning"){
		if(oriretyr < yrtoretirement){  
			$("#alertRetyrMsg").removeClass("hidden"); 
		}else{
			$("#alertRetyrMsg").addClass("hidden"); 
		}
	}else{
		$("#alertRetyrMsg").addClass("hidden"); 
	}
	}else{
		$("#alertRetyrMsg").addClass("hidden"); 
	}
	
	return true;
}
