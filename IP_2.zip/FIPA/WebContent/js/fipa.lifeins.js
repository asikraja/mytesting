/**
 * 
//**************************************Input Life Insurance*********************************************
 */

 

function callDeletePolicy(lifeId,datatblvar,tblId){

	var aplnName = lifeId.closest("tr").find("td:eq(1)").find('input:eq(0)').val(),
	lifeIns_id = lifeId.closest("tr").find("td:eq(1)").find('input:eq(1)').val(),
	fna_id = lifeId.closest("tr").find("td:eq(1)").find('input:eq(2)').val(),
	app_id  = lifeId.closest("tr").find("td:eq(1)").find('input:eq(3)').val();
	refId  = lifeId.closest("tr").find("td:eq(1)").find('input:eq(4)').val();
	
	
	var $parentRow=lifeId.closest("tr"); 
	datatblvar.$('tr.selected').removeClass('selected');
     $parentRow.addClass('selected');   
     
	 
	
     
	  
	  //Other Reference 
		if(!isEmpty(refId)){  
			var message;
			 
			
			$("#IncAssRetPlgtbl tbody tr[rowref='"+refId+"']").each(function(){
				message=true;
				IncAssRetPlgtbl.row($(this)).remove().draw();
			});	
			 
			$("#cpfAccAddDedTable tbody tr[rowref='"+refId+"']").each(function(){
				message=true;
				cpfAccAddDedTable.row($(this)).remove().draw();
			});	 
			
			if(message){
				showAlert("The Existing Reference Record will also be deleted");
			}
			
			 
		}
		
		
	$('#deletemsglifeData').modal({
		  backdrop: 'static',
		  keyboard: false,
		  show:true
		});
	  $('#deletemsglifeData').on('shown.bs.modal', function() {  
		  $(this).find(".modal-title").text('FIPA Message');
		  $(this).find(".modal-footer").find("button:eq(0)").unbind();  
			  $(this).find(".modal-footer").find("button:eq(0)").click(function (){ 
				  				
				  if(aplnName == 'FIPA'){	
						if(!(isEmpty(lifeIns_id)) ){
							
							showLoader();
							
							var parameter = "DBCALLFOR=DELETE_FIPALIFEDATA&strlifeInsId="+lifeIns_id+"&strlifeFnaId="+fna_id;
						
							ajaxCall(parameter,servletName,function(Data){
								
								var retval = Data;	
									hideLoader();
								for ( var val in retval) {

									var tabdets = retval[val];


									if (tabdets["SESSION_EXPIRY"]) {
										window.location = BASE_URL +  SESSION_EXP_JSP;
										return;
									}

									if (tabdets["DB_ERROR"]) {
										window.location = BASE_URL +  DB_EXP_JSP;
										return;
									}
									for ( var tab in tabdets) {
										

										if (tabdets.hasOwnProperty(tab)) {
											
											var key = tab;
											var value = tabdets[tab];
											

											 
											if (key == "TARGET") {
											
												showAlert(value);
												datatblvar.row('.selected').remove().draw( false ); 
												$parentRow.removeClass('selected');  
												clearLifeInsuranceScreen();
												reorderSino(tblId);
											   return ;
											}	
											
											
											
										}
									}

								}
							});
						}
				  }
				
				  $('#deletemsglifeData').modal('hide'); 
			  });  
		});
	   
	

		  
	  
	  
}
//validations -------------
$("a.addlifeicon").on("click",function(){ 
	 calcTotalPlandetails();
	if($("#addnewlife").hasClass("blinking")){
		$("#addnewlife").removeClass("blinking");
	} 
	$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(4)").find("a").click();	 
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust().draw(false);	
	$("#addnewlife").addClass("blinking"); 
	$("#addnewlife").focus();
});


$("#lipPremiumsrc").on("change",function(){ 
	SyncLifeToCpfAddDed($(this).val());
	calcTotalPlandetails();
	 if(!$("#RDIncAsstbl .lifeIns").length > 0){ 
       	 if(!validationRetirementScreen())return;  
             	 if (!valilifeinsurance())return;   
             var $rowliferef=$("#sellipCoveragetype").attr("rowref"); 
           var chklength=$("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowliferef+"]").length;
         $('#sellipCoveragetype').multiselect('select','RP');
 			if(!(chklength > 0)){
       	 if(!($("#lipOwner").val() == "Joint")  && !($("#lipOwner").val() == "Parents")){
       		 applyToastrAlert("Life Insurance data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
       		 getincassrtRows(null,"Y"); 
       	 }
        } 
 			 
	 }
});

$("#lipSa").on("change",function(){ 
	SyncLifeToCpfAddDed($("#lipPremiumsrc").val());
	calcTotalPlandetails();
	SyncLifeToRetEdit();
});

$("#lipOwner").on("change",function(){ 
	SyncLifeToCpfAddDed($("#lipPremiumsrc").val());
	calcTotalPlandetails();
	SyncLifeToRetEdit();
});

$("#lipPlanname").on("change",function(){ 
	SyncLifeToRetEdit();
});
function SyncLifeToRetEdit(){
	 if(!$("#RDIncAsstbl .lifeIns").length > 0){ 
       	 if(!validationRetirementScreen())return;  
             	 if (!valilifeinsurance())return;   
             var $rowliferef=$("#sellipCoveragetype").attr("rowref"); 
           var chklength=$("#IncAssRetPlgtbl  tbody").find("tr[rowref="+$rowliferef+"]").length;
         $('#sellipCoveragetype').multiselect('select','RP');
 			if(!(chklength > 0)){
       	 if(!($("#lipOwner").val() == "Joint")  && !($("#lipOwner").val() == "Parents")){
       		 applyToastrAlert("Life Insurance data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
       		 getincassrtRows(null,"Y"); 
       	 }
        } else{
        	var owner=$("#lipOwner").val();
				if(owner == "Self" || owner == "Spouse"){
       	 var dte=new Date();  
 		var rowRefID=$("#lipPremiumsrc").attr("rowref");
 		var rowRefID1=$("#sellipCoveragetype").attr("rowref");
 			if(isValidObject(rowRefID)){
 				rowRefID=rowRefID;
 			}else if(isValidObject(rowRefID1)){
 				rowRefID=rowRefID1;
 			}else{
 				rowRefID="LIFE_"+$lastRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
 				 dte.getSeconds()+dte.getMilliseconds();
 			}

 			$("#IncAssRetPlgtbl tbody").find("tr[rowref="+rowRefID+"]").each(function(){ 
 				 applyToastrAlert("Life Insurance data will be reflected to Income and assets available for Retirement Section in Retirement Planning Screen !");
 				$(this).find("td:eq(3)").find('input:eq(0)').val($("#lipPlanname").val());//plan name
 				$(this).find("td:eq(5)").find('input:eq(0)').val($("#lipSa").val());//amount
 				$(this).find("td:eq(8)").find('select:eq(0)').val(owner.toUpperCase());//ownership
 					 
 	      
 			}); 
        }
        }
 			 
	 }
	 return true;
}
function SyncLifeToCpfAddDed(elmid){
	var $elmVal=elmid;//source of premium
	var ownership=$("#lipOwner").val(); 
	var sumassured=$("#lipSa").val();
	 if(!isEmpty($elmVal)){
		 var refids=$("#lipPremiumsrc").attr("rowref");
	$("#cpfAccAddDedTable tbody").find("tr[rowref="+refids+"]").each(function(){ 
			var ext=$(this).attr("rowref").substring(0,4);
			if(ext=="LIFE"){
				$(this).addClass('selected'); 
				cpfAccAddDedTable.row('.selected').remove().draw( false );
			 
		}
      
  } );

	 
		cpfAccAddDedTable.row($("#cpfAccAddDedTable  tbody")).remove().draw(); 
 
		
		

	var cell0 = '<span></span>'+
	'<input type="hidden" name="txtFldCADMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="cdPkid"><input type="hidden" name="txtFldCADRefId">';

	var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radadctSelect"/><label>&nbsp;</label></div>'; 
	 
	var cell2 ='<select name="txtFldCADApplicant" id="txtFldCADApplicant"  class="form-control editable"> </select>';

	var cell3 ='<select name="selCdApplicantType" id="selCdApplicantType"  class="form-control editable"> </select>';

	   
	var cell4 ='<select name="selCADType" id="selCADType" class="form-control editable"> </select>';//description 
	 
	var cell5 ='<select name="selCADTypesOfTrans" id="selCADTypesOfTrans"  class="form-control editable"> </select>';
	 
	 
	var cell6 = '<input type="hidden" name="txtCADCpfAcctype" id="txtCADCpfAcctype"  />'+
				      '<input type="text" name="selCADCpfAcctype" id="selCADCpfAcctype" onmouseover="fipaTooltip(this);"  class="form-control editable"/>';
	  
	var cell7 = '<input type="text" name="txtFldCADPerFrom" maxlength="10"  id="txtFldCADPerFrom" onmouseover="fipaTooltip(this);" class="form-control editable" maxlength="10"/>';
	  
	var cell8 = '<input type="text" name="txtFldCADPerTo" maxlength="10" id="txtFldCADPerTo" onmouseover="fipaTooltip(this);" class="form-control editable" maxlength="10"/>';
	  
	var cell9 = '<input type="text" name="txtFldCADAmt" id="txtFldCADAmt" onmouseover="fipaTooltip(this);" class="form-control editable"/>';
	 
	 
	var cell10 ='<select name="selCADPayTerm" id="selCADPayTerm"  class="form-control editable"> </select>';
	 
	 
	var cell11 ='<select name="selCADRetrAccAge" id="selCADRetrAccAge"  class="form-control editable"> </select>'+
	'<input type="hidden" name="txtFldCADCrtdBy"/><input type="hidden" name="txtFldCADCrtdDate"/>';
	 

	 var rowCount;
	 var $lastRow;	
	
	

			if(!isEmpty($elmVal)){
				
				if($elmVal == "CPFOA" || $elmVal == "CPFSA" || $elmVal == "CPFMA" || $elmVal == "CPFRA"){
					applyToastrAlert("Life Insurance data will be reflected to CPF Account - Additions & Deductions of funds into CPF A/C in Central Provident Fund Screen !");
				cpfAccAddDedTable.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,cell10,cell11] ).draw( false );
				 
				  rowCount = $('#cpfAccAddDedTable tbody tr').length;	
				  $lastRow = $("#cpfAccAddDedTable tbody tr:last");	
				  var cpfacc,ccid;
				 var sel1 = $("#txtFldDlgCADApplicant > option").clone();
				 var seltype = $("#selDlgCADApplicantType > option").clone();
				 var sel2 = $("#selDlgCADType > option").clone();
				 var sel3 = $("#selDlgCADTypesOfTrans > option").clone();
				 var sel4 = $("#selDlgCADPayTerm > option").clone();
				 var sel5 = $("#selDlgCADRetrAccAge > option").clone();
				 
				 if($elmVal == "CPFOA"){cpfacc="Ordinary";ccid="CPFACC000001";}
				 else if($elmVal == "CPFSA"){cpfacc="Special";ccid="CPFACC000002";}
				 else if($elmVal == "CPFMA"){cpfacc="Medisave";ccid="CPFACC000003";}
				 else if($elmVal == "CPFRA"){cpfacc="Retirement";ccid="CPFACC000004";}
				 else {cpfacc="";ccid="";}
				 
				 var dte=new Date();  
					var rowRefID=$("#sellipCoveragetype").attr("rowref");
					var rowRefID1=$("#lipPremiumsrc").attr("rowref");
					
						if(isValidObject(rowRefID)){
							rowRefID=rowRefID;
						}if(isValidObject(rowRefID1)){
							rowRefID=rowRefID1;
						}else{
							rowRefID="LIFE_"+$lastRow.index()+dte.getDate()+dte.getMonth()+dte.getYear()+dte.getMinutes()+
							 dte.getSeconds()+dte.getMilliseconds();
						}

						
				$lastRow.attr("rowref",rowRefID); 
				$lastRow.find("td:eq(0)").find('input:eq(2)').val(rowRefID);
				$("#sellipCoveragetype").attr("rowref",rowRefID);
				$("#lipPremiumsrc").attr("rowref",rowRefID);
				$("#lipRefId").val(rowRefID);
				
				
					
				 $lastRow.find("td:first").find('span').text(rowCount); 

				 $lastRow.find("td:eq(1)").find("input:first").click(function(){
				 	selectSingleRow(this);
				 })

				 $lastRow.find("td:eq(1)").find("input:first").attr('id',"radadct"+$lastRow.index())
				 .parent().find('label').attr('for',"radadct"+$lastRow.index());

				
				 
				
				 $lastRow.find("td:eq(2)").find('select:eq(0)').append(sel1);
				 if(ownership == "Self"){
					 $lastRow.find("td:eq(2)").find('option:eq(1)').prop("selected","selected");
				 }else  if(ownership == "Spouse"){
					 $lastRow.find("td:eq(2)").find('option:eq(2)').prop("selected","selected");
				 }else{
					 $lastRow.find("td:eq(2)").find('option:eq(0)').prop("selected","selected");
				 } 
				 $lastRow.find("td:eq(2)").find('select:eq(0)').on("change",function(){
					 changeOnCADType($(this));
					 reverseCpfSync($lastRow);
				});
				 
				  
				 
				 $lastRow.find("td:eq(3)").find('select:eq(0)').append(seltype);
				 $lastRow.find("td:eq(3)").find('select:eq(0)').val(ownership); 
				 $lastRow.find("td:eq(3)").find('select:eq(0)').on("change",function(){
						reverseCpfSync($lastRow);	
					});
				 
				 $lastRow.find("td:eq(4)").find('select:eq(0)').append(sel2);
				 $lastRow.find("td:eq(4)").find('select:eq(0)').val(""); 


				
				 $lastRow.find("td:eq(5)").find('select:eq(0)').append(sel3);
				 $lastRow.find("td:eq(5)").find('select:eq(0)').val("Addition"); 


				 
				 
				   
				 
				 $lastRow.find("td:eq(6)").find('input:eq(0)').val(ccid); 
				 $lastRow.find("td:eq(6)").find('input:eq(1)').val(cpfacc);
				 $lastRow.find("td:eq(6)").find('input:eq(1)').on("change",function(){
						reverseCpfSync($lastRow);	
					});
				  
				 $lastRow.find("td:eq(7)").find('input:eq(0)').val("");
				 $lastRow.find("td:eq(7)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
				 	 checkDateFormat($(this));  
				 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
				 }); 

				 $lastRow.find("td:eq(8)").find('input:eq(0)').val("");
				 $lastRow.find("td:eq(8)").find('input:eq(0)').datetimepicker(dateOptions).on("blur change",function(){
				 	 checkDateFormat($(this));  
				 	if(!dhtmlChkDateValidation($lastRow.find("td:eq(7)").find('input:eq(0)'),$lastRow.find("td:eq(8)").find('input:eq(0)'),"To Date should greater than the Period Date"));
				 });

			 
				 $lastRow.find("td:eq(9)").find('input:eq(0)').val(sumassured);
				 $lastRow.find("td:eq(9)").find('input:eq(0)').addClass("applyEvntUsd");
				 $lastRow.find("td:eq(9)").find('input:eq(0)').on("change",function(){
						reverseCpfSync($lastRow);	
					});

				 
				 $lastRow.find("td:eq(10)").find('select:eq(0)').append(sel4);
				 $lastRow.find("td:eq(10)").find('select:eq(0)').val(""); 


				 
				 $lastRow.find("td:eq(11)").find('select:eq(0)').append(sel5);
				 $lastRow.find("td:eq(11)").find('select:eq(0)').val(""); 
				 applyEventHandlers();
			}  
			}
	 }
	
};
function openBackToFundFlow(elmtofocus){
	 if($("#"+elmtofocus).hasClass("blinking")){
			$("#"+elmtofocus).removeClass("blinking");
		} 
		$("#sidebar-menu ul").find("li[id=analysis_li]").find("ul li:eq(1)").find("a").click();	 
		$("#"+elmtofocus).addClass("blinking"); 
		$("#"+elmtofocus).focus();
}
 

$("#liDisabilty_Dialog #txtFldDlgliDsbltyYrBegins").on("change", function(){ 
	disablityYrBegin($(this),$("#liDisabilty_Dialog #txtFldDlgliDsbltyYrCeases"));
});


function disablityYrBegin(yrbegin,yrceases){
	var beginCeases=yrceases.val();
	   
	if(!isEmpty(yrbegin.val())){
		if(yrbegin.val() < 0 ){
			showAlert("Year Begins should be 0 or greater than Year Ceases!",yrbegin);
			yrbegin.val("");
		}    
	} 
	
	if(!isEmpty(beginCeases)){
		if( yrbegin.val() > beginCeases){
			showAlert("Year Begins should be 0 or greater than Year Ceases!",yrbegin);
			yrbegin.val("");
		}    
	}   
}
 
$("#liDisabilty_Dialog #txtFldDlgliDsbltyYrCeases").on("change", function(){
	
	disablityYrCeases($(this),$("#liDisabilty_Dialog #txtFldDlgliDsbltyYrBegins"))
});

function disablityYrCeases(yrceases,yrbegin){
	var beginYr=yrbegin.val();
	if(!isEmpty(beginYr)){
		if(!isEmpty(yrceases.val())){ 
		if(yrceases.val() < beginYr){
			showAlert("Year Ceases should be greater than Year Begins !",yrceases);
			yrceases.val("");
		}

		}
	}   
}
function filldetsLifeInsuranceDlg(cont,contvalue,data,lifeIns_id){ 

	 
	$("input[name=lipId]").val(lifeIns_id);

 if(cont=="lipCreatedBy"){  
	 $("input[name=lipCreatedBy]").val(contvalue);
 }
 
 if(cont=="lipCreatedDate"){  

	 $("input[name=lipCreatedDate]").val(contvalue); 
 }
 
  if(cont=="nominationType"){   
		 if(contvalue == ''){ 
				$("#lifeInsdetstab #NomineesTblDiv").css("display","none");
		  }else{
			  $("#lifeInsdetstab #NomineesTblDiv").css("display","block");
		  } 
  }
  if(cont == 'retMultionret'){ 
	  if(contvalue == 'Y'){  
		  $("#retCashvalonret").attr("readonly",false);
	  }else{
		  $("#retCashvalonret").attr("readonly",true);
	  }
  }
	 
	 
   if(cont=="lipCoveragetype"){ 
       var arrLipCovType=contvalue.split(',');
         $('#sellipCoveragetype').multiselect('select',arrLipCovType);    
       for(var opt=0;opt<arrLipCovType.length;opt++){
           typeOfCoverage(arrLipCovType[opt],'block')
       }  
   }
   
   if(cont=="lipIsnurObject"){   
   
       var arrLipIsnurObject=contvalue.split(',');
        $('#sellipIsnurObject').multiselect('select',arrLipIsnurObject);        
        for(var opt=0;opt<arrLipIsnurObject.length;opt++){
       	 ObjOfInsurance(arrLipIsnurObject[opt],'block')
          } 
   } 
   
//   if(cont=="lipPremiumsrc"){ 
//	   SyncLifeToCpfAddDed(contvalue);
//   }
   
   if(cont == "lipRefId"){
	   if(!isEmpty(contvalue)){
		 $("#lipRefId").val(contvalue);
		 $("#sellipCoveragetype").attr("rowref",contvalue); 
		 $("#lipPremiumsrc").attr("rowref",contvalue);
	   }
   }
  
 if(cont == "lipCompany"){
	   
	   selectNullOrBlank($("#"+cont),contvalue); 
   }
   if(cont=="retTotalSa"){ 
	   $("#retTotalSa").val(contvalue); 
   }
   if(cont=="retTotalPrem"){ 
	   $("#retTotalPrem").val(contvalue);
   }
  
  
}
 


function fillFPMSDataDlg(lifeId,appId){
	
	var $rowIndex=$(lifeId).closest("tr").index(); 
	var $lastRow=$('#existPolicyLHIns tr:eq('+(Number($rowIndex)+1)+')') ; 
	
	showLoader();
	var parameter = "DBCALLFOR=GET_FPMS_LIFEDATA&strSrchlifeInsId="+lifeId+"&strSrchAppId="+appId;
	
	ajaxCall(parameter,servletName,function(Data){
		var retval = Data;


		hideLoader();

		for ( var val in retval) {

			var tabdets = retval[val];


			if (tabdets["SESSION_EXPIRY"]) {
				window.location = BASE_URL +  SESSION_EXP_JSP;
				return;
			}

			if (tabdets["DB_ERROR"]) {
				window.location = BASE_URL +  DB_EXP_JSP;
				return;
			}

			for ( var tab in tabdets) {


				if (tabdets.hasOwnProperty(tab)) {

					var key = tab;
					var value = tabdets[tab]; 

					if (key == "FPMS_POLICY_DETS"){
						
						$("#listofLifeIns_Dialog #lifeInsdetstab #lipOwner").val("Self");

						var jsnData = value; 	  
						for ( var cont in jsnData) {
							jsonDataPopulate(jsnData[cont], key);
							if (jsnData.hasOwnProperty(cont)) {			

								var contvalue = jsnData[cont];
								
								$("#listofLifeIns_Dialog #lifeInsdetstab #lipOwner").val("Self");
								
								for(var data in contvalue){

									var col = contvalue[data]; 
									
									switch(data){
										case "strFPMSPolOwner":
											$("#listofLifeIns_Dialog #lifeInsdetstab #lipAssured").val(col);											
											break;
											
										case "strFPMSPolPlanName":
											$("#listofLifeIns_Dialog #lifeInsdetstab #lipPlanname").val(col);
											break;
											
										case "strFPMSPolPolNo":
											$("#listofLifeIns_Dialog #lifeInsdetstab #lipPolicyno").val(col);
											break;
											
										case "strFPMSPolPrincipalId":
											$("#listofLifeIns_Dialog #lifeInsdetstab #lipCompany").val(col);
											break;
											
										case "strFPMSPolPremiumType":											
											break;	
											
										case "strFPMSPolPremium":											
											break;
											
										case "strFPMSPolSA":
											$("#listofLifeIns_Dialog #lifeInsdetstab #lipSa").val(col);
											break;
											
										case "strFPMSPolPaymentMode":
											var mode;
											if(col == "SEMI-ANNUAL" || col=="HALF-YEARLY"){
												mode="HALF YEARLY";
											}else{
												mode=col;
											}
											selectNullOrBlank($("#listofLifeIns_Dialog #lifeInsdetstab #lipPaymentfreq"),mode);   
//											$("#listofLifeIns_Dialog #lifeInsdetstab #lipPaymentfreq").val(col);
											break;
										case "strFPMSPolPaymentMeth":
											selectNullOrBlank($("#listofLifeIns_Dialog #lifeInsdetstab #lipPaymentmethod"),col);  
											break;
										case "strFPMSPolEffDate":
											$("#listofLifeIns_Dialog #lifeInsdetstab #lipIncepdate").val(col);
											break;
										case "strFPMSPolStatus":
											selectNullOrBlank($("#listofLifeIns_Dialog #lifeInsdetstab #policyStatus"),col);   
											break;
									}
								

								}

							}
						}




						
						
					}
					
					
					if(key == "FPMS_POLICYPLAN_DETS"){
//						jsonTableDataPopulate(value, tab, false); 
						$.each(value, function(contkey, contvalue) {
							getliPlndetRows(contvalue, tab);
						})
					}
				}
			}
		}

	});
	
}


function clearLifeInsuranceScreen(){
	
	$("input[name=lipId]").val("");
	var txtFldInputsAll =['lifeInsdetstab', 'li_DeathBenef_tab',
	                      'li_Disability_tab','li_CriticalIllness_tab',
	                      'li_Hospitalisation_tab','li_RetirementPlg_tab','li_EducationPlg_tab'];
	
	$.each( txtFldInputsAll, function( index, value ) {  
		 $("#listofLifeIns_Dialog #"+value).find("input[type=text]").val(""); 
		 $("#listofLifeIns_Dialog #"+value).find("input[type=hidden]").val(""); 
		 $("#listofLifeIns_Dialog #"+value).find("select").val(""); 
	});  
	
	if(isEmpty($("#nominationType").val())   || $("#nominationType").val() == "None"){
		
		$('#listofLifeIns_Dialog #NomineesTblDiv').css("display","none");
	}else{
		$('#listofLifeIns_Dialog #NomineesTblDiv').css("display","block");
	}
	
	$('#listofLifeIns_Dialog #liTypesOfCovBenefdiv').css("display","none");
	$('#listofLifeIns_Dialog #retCashvalonret').prop("readonly",true);
	$('#listofLifeIns_Dialog #LIDDCovergePanel').css("display","none"); 
	
 
	$('#listofLifeIns_Dialog').find('ul li:eq(3)').find("a").css('display','none');
	$('#listofLifeIns_Dialog').find('ul li:eq(4)').find("a").css('display','none');
	$('#listofLifeIns_Dialog').find('ul li:eq(5)').find("a").css('display','none');
	$('#listofLifeIns_Dialog').find('ul li:eq(6)').find("a").css('display','none');
	$('#listofLifeIns_Dialog').find('ul li:eq(7)').find("a").css('display','none');
	$('#listofLifeIns_Dialog').find('ul li:eq(8)').find("a").css('display','none'); 
	 
	resetMultiSel('sellipCoveragetype');
	resetMultiSel('sellipIsnurObject');
	resetMultiSel('selmulCriticalLevelofDD');   
	
	$("#sellipCoveragetype").removeAttr("rowref");
	$("#lipRefId").val("");
	$("#lipPremiumsrc").removeAttr("rowref");
	clrDatatables('liPlanDetailstbl');
	clrDatatables('liDeathBenefittbl');
	clrDatatables('liDisabilitytbl');
	clrDatatables('liCriticalIllnesstbl');
	clrDatatables('liHospitilisationtbl');
	clrDatatables('liEducationtbl');
	clrDatatables('liRetirementPlgtbl');
	clrDatatables('fnaLINomineesTbl');
	
	 
}
function openLifeScreen(){  
	var flag = true; 
	
	$("input[name=lipId]").val(""); 
	$("input[name=coverId]").val("");
	 
	  $('#lifeInsdetstab,#li_DeathBenef_tab,#li_Disability_tab,'
			  +'#li_CriticalIllness_tab,#li_Hospitalisation_tab'
			  +'#li_RetirementPlg_tab,#li_EducationPlg_tab')
			  .find("input[type='text'],select,input[type='hidden']").each(function() { 
		  var elmval=$(this).val(); 
		   if (!(elmval == null  ||  elmval == "")) {
			      flag = false; 
			      return;
		   }  
	  });

	  if (!flag) { 
		  	openModelforClearLifeDets();
	  }else{
		  $('#lifeInsNavTabsDets a[href="#lifeInsdetstab"]').click(); 
		  
		  
	  }
}


function openModelforClearLifeDets(){
	$('#clearmsglifeData').modal({
		  backdrop: 'static',
		  keyboard: false,
		  show:true
		});
	  $('#clearmsglifeData').on('shown.bs.modal', function() {  
		  $(this).find(".modal-title").text('FIPA Message');
		  $(this).find(".modal-footer").find("button:eq(0)").unbind();  
			  $(this).find(".modal-footer").find("button:eq(0)").click(function (){ 
				  				clearLifeInsuranceScreen();
				  			  $('#lifeInsNavTabsDets a[href="#lifeInsdetstab"]').click(); 
				        	  $('#clearmsglifeData').modal('hide'); 
			  });  
		});
	   
		
}
 
