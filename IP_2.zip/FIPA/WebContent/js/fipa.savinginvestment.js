
/**
 * Wealth Accumulation 
 */

/*Datatable Initialisation*/
var wealthAccmltTable = $('#wealthAccmltTable').DataTable( {
	destroy: true,
 	responsive: false,         
    ordering: false,
    searching: false,     
    scrollY:  "40vh",
    scrollX: true,
    scroller: false,
    scrollCollapse:false,
    paging:false, 
    filter:false,   
    columnDefs: [], 
    dom: '<<"top" ip>flt>',  
  columnDefs: [  { width: '20px', targets: [0,1]},
   	             {"className": "dt-head-center text-center",targets: [0,1,2,3,4,5,6],"orderable": false,"searchable": false}],		 
		 fnDrawCallback: function(oSettings) {
			 if (oSettings._iDisplayLength > oSettings.fnRecordsDisplay()) { 
				 
			    } 
    
		 }, 
}).draw();
	


  

/*Add Row Click */
$("#WAcARow").on("click",function(){
			wlthaccClearFlds();
			showFIPAModel('svinvst_Dialog','Wealth Accumulation Goals');   
			$('#svinvst_Dialog').on('shown.bs.modal', function () {
				$("#svinvst_Dialog").find(".modal-footer").find("button:eq(0)").text("Add");
				$("#svinvst_Dialog").find("textarea[id=txtFldDlgSAPurpose]").focus();//Aravindh
				$("#svinvst_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
						if(!validatewlthaccDetails())return;
					   	wlthaccRdlyflds(INS_MODE);  
					   	getwlthaccRows(null); 
						$('#svinvst_Dialog').modal('hide'); 
				  });  
			});
			
			
});



/*Populate Data */
function getwlthaccRows(dataset){ 
 
var cell0 = '<span></span>'+
'<input type="hidden" name="txtFldwlthaccMode" readonly="true" value="'+INS_MODE+'" class="fipaMode"/><input type="hidden" name="txtFldSAInvId">';
 
var cell1 = '<div class="checkbox checkbox-primary text-center"><input type="checkbox" name="radwlthaccSelect"/><label>&nbsp;</label></div>'; 
var cell2 = '<input type="text" name="txtFldSAPurpose" class="form-control editable" onmouseover="fipaTooltip(this);" maxlength="300"/>'; 
var cell3 = '<input type="text" name="txtFldSAWhen" class="form-control editable" onmouseover="fipaTooltip(this);" />';
var cell4 = '<input type="text" name="txtFldSAmount" class="form-control editable" onmouseover="fipaTooltip(this);"/>';
var cell5 = '<select name="selSAPriority" id="selSAPriority" class="form-control editable" onmouseover="fipaTooltip(this);"> </select>';
var cell6 = '<select name="selSARiskLvl" id="selSARiskLvl" class="form-control editable" onmouseover="fipaTooltip(this);"   > </select>'+
'<input type="hidden" name="txtFldSACrtdBy"/><input type="hidden" name="txtFldSACrtdDate"/>'; 

   

wealthAccmltTable.row.add( [cell0,cell1,cell2,cell3,cell4,cell5,cell6] ).draw( false );

var rowCount = $('#wealthAccmltTable tbody tr').length;	
var $lastRow = $("#wealthAccmltTable tbody tr:last");	

$lastRow.find("td:first").find('span').text(rowCount); 

$lastRow.find("td:eq(1)").find("input:first").click(function(){
	selectSingleRow(this);
})

$lastRow.find("td:eq(1)").find("input:first").attr('id',"radwlthacc"+$lastRow.index())
.parent().find('label').attr('for',"radwlthacc"+$lastRow.index());

$lastRow.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgSAPurpose").val()); 

$lastRow.find("td:eq(3)").find('input:eq(0)').val($("#txtFldDlgSAWhen").val());
$lastRow.find("td:eq(3)").find('input:eq(0)').addClass("applyEvntYrs");

$lastRow.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgSAmount").val());  
$lastRow.find("td:eq(4)").find('input:eq(0)').addClass("applyEvntUsd");


var sel1 =  $("#selDlgSAPriority > option").clone();
$lastRow.find("td:eq(5)").find('select:eq(0)').append(sel1);
$lastRow.find("td:eq(5)").find('select:eq(0)').val($("#selDlgSAPriority").val());
  
var sel2 =  $("#selDlgSARiskLvl > option").clone();
$lastRow.find("td:eq(6)").find('select:eq(0)').append(sel2);
$lastRow.find("td:eq(6)").find('select:eq(0)').val($("#selDlgSARiskLvl").val());
  
applyEventHandlers();


if(dataset != null){

	
			if($("#hTxtFldFnaReviewFlag").val() == "U"  || $("#hTxtFldFnaReviewFlag").val() == ""){ 
					$lastRow.find("td:eq(0)").find('input:eq(0)').val(col);
			}
			
	var infoDetsArr = new Array();
	
	for(var data in dataset){
		var col = dataset[data];
		
		switch(data){
		
			case "sainvId": 
				$lastRow.find("td:eq(0)").find('input:eq(1)').val(col); 
				break;
				
			case "sainvPurpose": 
				$lastRow.find("td:eq(2)").find('input:eq(0)').val(col); 
				
				break;
				
			case "sainvWhen": 
				$lastRow.find("td:eq(3)").find('input:eq(0)').val(col); 
				break;
			 
			case "sainvAmount": 
				$lastRow.find("td:eq(4)").find('input:eq(0)').val(col); 
				break;
			 
			case "saivnPriority": 
				selectNullvalChk($lastRow.find("td:eq(5)"),col);  
				break;
			 
			 
			case "savinvRisklvl": 
				selectNullvalChk($lastRow.find("td:eq(6)"),col);  
				break;
			 
			 
			case "sainvCreatedBy": 
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 
				break;
			 
			 
			case "sainvCreatedDate": 
				$lastRow.find("td:eq(6)").find('input:eq(0)').val(col); 
				break; 
				 
		}			 
		 
	}
	}

wlthaccClearFlds();
 
}


 
/*Edit Row Click */
$("#WAcERow").on("click",function(){
	
	$("#WAcVRow").click();
	
//	var isOneRowSelected=false;
//	$("#wealthAccmltTable tbody").find('input[name="radwlthaccSelect"]').each(function(){ 
//		if($(this).is(":checked")){ 
//			var $row = $(this).parents("tr"); 
//			var $mode = $(this).parents("tr").find("td:first").find('input:eq(0)').val(); 
//			
//			 
//			if($mode == INS_MODE){ 
//				$(this).parents("tr").find("td:first").find('input:eq(0)').val($mode); 
//				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
//					$(this).attr("disabled",false); 
//					$row.removeClass('selected');  
//					$(this).parent().css({border:'1px solid green'});
//					$row.css({border:'1px solid green'});
//					$row.find("td").css({border:'1px solid green'});
//				});  
//			}
//			
//			$(this).attr("checked",false);
//			isOneRowSelected=true;
//		}
//	});	    
//	if(!isOneRowSelected){
//		showAlert("No Rows Selected");
//	}
});


/*View Row Click */
$("#WAcVRow").on("click",function(){
	var isOneRowSelected=0;
	var $rowCount = $('#wealthAccmltTable tbody tr').length;	
	var $lastRow = $("#wealthAccmltTable tbody tr:last");	
	
	if($rowCount<1){
		showAlert("Insert rows before edit/view!");
		return;
	} 
	
	$("#wealthAccmltTable tbody tr").each(function(){
		var $row = $(this);   
		$row.removeClass('selected');  
		$(this).removeAttr("style"); 
		$row.find("td").removeAttr("style");
		
			
	});
	
	
	$("#wealthAccmltTable tbody").find('input[name="radwlthaccSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			isOneRowSelected++;
		}
	});
	
	
	if(isOneRowSelected > 1){ 
		showAlert("More than one rows selected.Select one row only");
		return;
	}
	
	$("#wealthAccmltTable tbody").find('input[name="radwlthaccSelect"]').each(function(){ //Checkbox selection
		var $curElm=$(this);
		if($curElm.is(":checked")){ 
			var $row = $curElm.parents("tr");                                    
			var $mode = $curElm.parents("tr").find("td:first").find('input:eq(0)').val(); 
			$curElm.prop("checked",false);
	     	 $curElm.parents("tr").removeClass('selected');
	     	 
			if(($mode == INS_MODE) || ($mode == UPD_MODE) ){
				 var $RowId=$row.index();
				 $curElm.parents("tr").find("td:first").find('input:eq(0)').val($mode); 
				 
				$(this).parents("tr").find("td").find("input.editable,select.editable").each(function(){
					$(this).attr("disabled",false); 
					$row.removeClass('selected');  
					$(this).parent().css({border:'1px solid green'});
					$row.css({border:'1px solid green'});
					$row.find("td").css({border:'1px solid green'});
				}); 
				
				 	wlthaccRdlyflds($mode);
					wlthaccfilldlgval($row); 
					showFIPAModel('svinvst_Dialog','Wealth Accumulation Goals');  
					$('#svinvst_Dialog').on('shown.bs.modal', function () {
						$("#svinvst_Dialog").find(".modal-footer").find("button:eq(0)").text("Edit");
						$("#svinvst_Dialog").find("textarea[id=txtFldDlgSAPurpose]").focus();//Aravindh
						$("#svinvst_Dialog").find(".modal-footer").find("button:eq(0)").on("click",function(){
							 if(!validatewlthaccDetails())return; 
					     		if(!isEmpty($RowId) && !($RowId==undefined)){  
					     			wlthaccfilldomval($RowId,$row); 
					     		}  
								$('#svinvst_Dialog').modal('hide'); 
								wlthaccClearFlds();
							
						});
					});
					 
			}  
			isOneRowSelected++;
		} 
	});
	
	 
	if(isOneRowSelected==0){
		showAlert("No Rows Selected");
		return;
	}

	
});


/*Delete Row Click */
$("#WAcDRow").on("click",function(){ 
	datatableDeleteRow('wealthAccmltTable',wealthAccmltTable); 
});

/*Clear Fields */
function wlthaccClearFlds(){
	$("#svinvst_Dialog").find("input[type=text]").val("");
	$("#svinvst_Dialog").find("textarea").val("");
	$("#svinvst_Dialog").find("select").val("");
}

/*Disabled/Readonly Fields */
function wlthaccRdlyflds(mode){ 
	 if(mode == QRY_MODE ){
			$("#svinvst_Dialog :input").prop("disabled", true); 
	 } else if((mode == INS_MODE) || (mode == UPD_MODE) ){
			$("#svinvst_Dialog :input").prop("disabled", false);
	 }
}

/*Validation */
function validatewlthaccDetails(){
	 
	if(!(validateFocusFlds('svinvst_Dialog','txtFldDlgSAPurpose',SAVEINV_PUR))) return; 
	if(!(validateFocusFlds('svinvst_Dialog','txtFldDlgSAWhen',SAVEINV_WHEN))) return;
	if(!(validateFocusFlds('svinvst_Dialog','txtFldDlgSAmount',SAVEINV_AMT))) return;
	 
	
	  return true; 
}




/*Mandatory Fields Tooltip*/ 
$("#txtFldDlgSAPurpose,#txtFldDlgSAWhen,#txtFldDlgSAmount").on("change blur",function(){
	if(!isEmpty($(this).val())){
	$(this).removeClass("mandatoryFillFlds");
	$(this).qtip('disable');
	$(this).qtip('destroy',true);
	}
});




/* Filling Model Fields*/
function wlthaccfilldlgval($lastRow){
	  
	  $('#svinvst_Dialog #txtFldDlgSAInvId').val($lastRow.find("td:eq(0)").find('input:eq(1)').val());
	  $('#svinvst_Dialog #txtFldDlgSAPurpose').val($lastRow.find("td:eq(2)").find('input:eq(0)').val());
	  $('#svinvst_Dialog #txtFldDlgSAWhen').val($lastRow.find("td:eq(3)").find('input:eq(0)').val());
	  $('#svinvst_Dialog #txtFldDlgSAmount').val($lastRow.find("td:eq(4)").find('input:eq(0)').val());
	  $('#svinvst_Dialog #selDlgSAPriority').val($lastRow.find("td:eq(5)").find('select:eq(0)').val());
	  $('#svinvst_Dialog #selDlgSARiskLvl').val($lastRow.find("td:eq(6)").find('select:eq(0)').val());
	  $('#svinvst_Dialog #txtFldSACrtdBy').val($lastRow.find("td:eq(6)").find('input:eq(1)').val());
	  $('#svinvst_Dialog #txtFldSACrtdDate').val($lastRow.find("td:eq(6)").find('input:eq(2)').val());
	 
}

/* Filling Table Fields*/
function wlthaccfilldomval($RowId,$row){
	
	$row.find("td:eq(2)").find('input:eq(0)').val($("#txtFldDlgSAPurpose").val()); 
	$row.find("td:eq(3)").find('select:eq(0)').val($("#txtFldDlgSAWhen").val());
	$row.find("td:eq(4)").find('input:eq(0)').val($("#txtFldDlgSAmount").val());  
	$row.find("td:eq(5)").find('input:eq(0)').val($("#selDlgSAPriority").val()); 
	$row.find("td:eq(6)").find('select:eq(0)').val($("#selDlgSARiskLvl").val());  
}

 
