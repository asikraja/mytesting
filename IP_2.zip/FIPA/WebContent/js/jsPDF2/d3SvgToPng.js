function getSVGString( svgNode ) {
	svgNode.setAttribute('xlink', 'http://www.w3.org/1999/xlink');
	var cssStyleText = getCSSStyles( svgNode );
	appendCSS( cssStyleText, svgNode );

	var serializer = new XMLSerializer();
	var svgString = serializer.serializeToString(svgNode);
	svgString = svgString.replace(/(\w+)?:?xlink=/g, 'xmlns:xlink='); // Fix root xlink without namespace
	svgString = svgString.replace(/NS\d+:href/g, 'xlink:href'); // Safari NS namespace fix

	return svgString;

	function getCSSStyles( parentElement ) {
		var selectorTextArr = [];

		// Add Parent element Id and Classes to the list
		selectorTextArr.push( '#'+parentElement.id );
		
		var cls=parentElement.classList;
		
		if(parentElement.classList && cls){
		for (var c = 0; c < parentElement.classList.length; c++)
				if ( !contains('.'+parentElement.classList[c], selectorTextArr) )
					selectorTextArr.push( '.'+parentElement.classList[c] );
		}
		// Add Children element Ids and Classes to the list
		var nodes = parentElement.getElementsByTagName("*");
		for (var i = 0; i < nodes.length; i++) {
			var id = nodes[i].id;
			if ( !contains('#'+id, selectorTextArr) )
				selectorTextArr.push( '#'+id );

			var classes = nodes[i].classList;
			if(classes && classes.length>0){
			for (var c = 0; c < classes.length; c++)
				if ( !contains('.'+classes[c], selectorTextArr) )
					selectorTextArr.push( '.'+classes[c] );
			}
		}

		// Extract CSS Rules
		var extractedCSSText = "";
		for (var i = 0; i < document.styleSheets.length; i++) {
			var s = document.styleSheets[i];
			
			try {
			    if(!s.cssRules) continue;
			} catch( e ) {
		    		if(e.name !== 'SecurityError') throw e; // for Firefox
		    		continue;
		    	}

			var cssRules = s.cssRules;
			for (var r = 0; r < cssRules.length; r++) {
				if ( contains( cssRules[r].selectorText, selectorTextArr ) )
					extractedCSSText += cssRules[r].cssText;
			}
		}
		

		return extractedCSSText;

		function contains(str,arr) {
			return arr.indexOf( str ) === -1 ? false : true;
		}

	}

	function appendCSS( cssText, element ) {
		var styleElement = document.createElement("style");
		styleElement.setAttribute("type","text/css"); 
		styleElement.innerHTML = cssText;
		var refNode = element.hasChildNodes() ? element.children[0] : null;
		element.insertBefore( styleElement, refNode );
	}
}


function svgString2Image( svgString, width, height, format, callback ) {
	var format = format ? format : 'png';

	var imgsrc = 'data:image/svg+xml;base64,'+ btoa( unescape( encodeURIComponent( svgString ) ) ); // Convert SVG string to data URL

	var canvas = document.createElement("canvas");
	var context = canvas.getContext("2d");

	canvas.width = width;
	canvas.height = height;

	var image = new Image();
	image.onload = function() {
		context.clearRect ( 0, 0, width, height );
		context.drawImage(image, 0, 0, width, height);

		canvas.toBlob( function(blob) {
			var filesize = Math.round( blob.length/1024 ) + ' KB';
			if ( callback ) callback( blob, filesize );
		});

		
	};

	image.src = imgsrc;
}

function tableToJson(table) {
	var data = [];

	// first row needs to be headers
	var headers = [];
	for (var i=0; i<table.rows[0].cells.length; i++) {
	    headers[i] = table.rows[0].cells[i].innerHTML.toLowerCase().replace(/ /gi,'');
	}

	// go through cells
	for (var i=1; i<table.rows.length; i++) {

	    var tableRow = table.rows[i];
	    var rowData = {};

	    for (var j=0; j<tableRow.cells.length; j++) {

	        rowData[ headers[j] ] = tableRow.cells[j].innerHTML;

	    }

	    data.push(rowData);
	}       

	return data; 
}


function addTableData(doc,position){
	var columns =[];
	var rows = [];
	
	$("#generateproExptbl thead tr:first th").each(function(){
		var hdrText=$(this).find("div").text();
		columns.push(hdrText);
	});
	
	$("#generateproExptbl tbody tr").each(function(){
		var rowdata=[];
		$(this).find("td").each(function(i){
			
			var cellData=$(this).text();
			
			if(i==0){
				var subtext=cellData.substring(cellData.indexOf("<"),cellData.length);
				
				rowdata.push(subtext);
				return;
			}
			
			rowdata.push(cellData);
			
			
		});
		
		rows.push(rowdata);
	});
	
	
//	doc.autoTable(columns,rows,{styles: {overflow: 'linebreak',columnWidth: 'wrap'},startY: 20,columnStyles: {note: {columnWidth: 'auto'}}});
	doc.autoTable(columns,rows,{
	     startY:(isEmpty(position)?20:position),
//         afterPageContent: footer,
         margin:{left:10,right:10}/*{ horizontal: 5 }*/,
         bodyStyles: { valign: 'top' },
         styles:{overflow:'linebreak',halign:'right',columnWidth: 'wrap'},
         headerStyles: {
             fillColor: [51, 122, 183],
             textColor: [255],
             halign: 'center',
             overflow: 'linebreak',
             columnWidth: 'wrap'
         },
         columnStyles: {text: {columnWidth:'wrap'}},
         //theme: 'striped'
         theme: 'grid'
	});
	
}

function addAmendTableData(doc,position){
	var columns =[];
	var rows = [];
	
	$("#generatetoamendincExp thead tr:first th").each(function(){
		var hdrText=$(this).find("div").text();
		columns.push(hdrText);
	});
	
	$("#generatetoamendincExp tbody tr").each(function(){
		var rowdata=[];
		$(this).find("td").each(function(i){
			
			var cellData=$(this).text();
			
			if(i==0){
				var subtext=cellData.substring(cellData.indexOf("<"),cellData.length);
				
				rowdata.push(subtext);
				return;
			}
			
			rowdata.push(cellData);
			
			
		});
		
		rows.push(rowdata);
	});
	
	
//	doc.autoTable(columns,rows,{styles: {overflow: 'linebreak',columnWidth: 'wrap'},startY: 20,columnStyles: {note: {columnWidth: 'auto'}}});
	doc.autoTable(columns,rows,{
	     startY:(isEmpty(position)?20:position),
//        afterPageContent: footer,
        margin:{left:10,right:10}/*{ horizontal: 5 }*/,
        bodyStyles: { valign: 'top' },
        styles:{overflow:'linebreak',halign:'right',columnWidth: 'wrap'},
        headerStyles: {
            fillColor: [51, 122, 183],
            textColor: [255],
            halign: 'center',
            overflow: 'linebreak',
            columnWidth: 'wrap'
        },
        columnStyles: {text: {columnWidth:'wrap'}},
        //theme: 'striped'
        theme: 'grid'
	});
	
}

function addGenTableData(doc,position){
	var columns =[];
	var rows = [];
	
	$("#generateproIncometbl thead tr:first th").each(function(){
		var hdrText=$(this).find("div").text();
		columns.push(hdrText);
	});
	
	$("#generateproIncometbl tbody tr").each(function(){
		var rowdata=[];
		$(this).find("td").each(function(i){
			
			var cellData=$(this).text();
			
			if(i==0){
				var subtext=cellData.substring(cellData.indexOf("<"),cellData.length);
				
				rowdata.push(subtext);
				return;
			}
			
			rowdata.push(cellData);
			
			
		});
		
		rows.push(rowdata);
	});
	
	
//	doc.autoTable(columns,rows,{styles: {overflow: 'linebreak',columnWidth: 'wrap'},startY: 20,columnStyles: {note: {columnWidth: 'auto'}}});
	doc.autoTable(columns,rows,{
	     startY:(isEmpty(position)?20:position),
//        afterPageContent: footer,
        margin:{left:10,right:10}/*{ horizontal: 5 }*/,
        bodyStyles: { valign: 'top' },
        styles:{overflow:'linebreak',halign:'right', columnWidth: 'wrap'},
        headerStyles: {
            fillColor: [51, 122, 183],
            textColor: [255],
            halign: 'center',
            overflow: 'linebreak',
            columnWidth: 'wrap'	
        },
        columnStyles: {text: {columnWidth:'wrap'}},
        //theme: 'striped'
        theme: 'grid'
	});
	
}

function addAutoTblRDEExp(doc,position){
	var columns =[];
	var rows = [];
	
	$("#RDExptbl thead tr:first th").each(function(i){
		
		if(i==1)return;
		
		var hdrText=$(this).find(">div").find('div').text();
		columns.push(hdrText);
	});
	
	$("#RDExptbl tbody tr").each(function(){
		
		var rowdata=[];
		$(this).find("td").each(function(i){
			
			if(i==1)return;
			
			var cellData=$(this).find("input:first").val();
			
			if(i==0){
				var subtext=$(this).find("span:first").text();
				
				rowdata.push(subtext);
				return;
			}
			
			if(i==3 || i==6){
				var subtext=$(this).find("select:first").val();
				
				rowdata.push(subtext);
				return;
			}
			
			rowdata.push(cellData);
			
			
		});
		
		rows.push(rowdata);
	});
	
	
//	doc.autoTable(columns,rows,{styles: {overflow: 'linebreak',columnWidth: 'wrap'},startY: 20,columnStyles: {note: {columnWidth: 'auto'}}});
	doc.autoTable(columns,rows,{
	     startY:(isEmpty(position)?20:position),
//        afterPageContent: footer,
        margin:{left:10,right:10}/*{ horizontal: 5 }*/,
        bodyStyles: { valign: 'top' },
        styles:{overflow:'linebreak',halign:'left', columnWidth: 'wrap'},
        headerStyles: {
            fillColor: [51, 122, 183],
            textColor: [255],
            halign: 'center',
            overflow: 'linebreak',
            columnWidth: 'wrap'	
        },
        columnStyles: {
        	0: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	3: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	4: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	6: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	7: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        },
        //theme: 'striped'
        theme: 'grid'
	});
	
}

function addAutoTblRDInc(doc,position){
	var columns =[];
	var rows = [];
	
	$("#RDInctbl thead tr:first th").each(function(i){
		
		if(i==1)return;
		
		var hdrText=$(this).find(">div").find('div').text();
		columns.push(hdrText);
	});
	
	$("#RDInctbl tbody tr").each(function(){
		
		var rowdata=[];
		$(this).find("td").each(function(i){
			
			if(i==1)return;
			
			var cellData=$(this).find("input:first").val();
			
			if(i==0){
				var subtext=$(this).find("span:first").text();
				
				rowdata.push(subtext);
				return;
			}
			
			if(i==4 || i==8){
				var subtext=$(this).find("select:first").val();
				
				rowdata.push(subtext);
				return;
			}
			
			rowdata.push(cellData);
			
			
		});
		
		rows.push(rowdata);
	});
	
	
//	doc.autoTable(columns,rows,{styles: {overflow: 'linebreak',columnWidth: 'wrap'},startY: 20,columnStyles: {note: {columnWidth: 'auto'}}});
	doc.autoTable(columns,rows,{
	     startY:(isEmpty(position)?20:position),
//        afterPageContent: footer,
        margin:{left:10,right:10}/*{ horizontal: 5 }*/,
        bodyStyles: { valign: 'top' },
        styles:{overflow:'linebreak',halign:'left', columnWidth: 'wrap'},
        headerStyles: {
            fillColor: [51, 122, 183],
            textColor: [255],
            halign: 'center',
            overflow: 'linebreak',
            columnWidth: 'wrap'	
        },
        columnStyles: {
        	0: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	4: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	5: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	6: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	8: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	9: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'}
        },
        //theme: 'striped'
        theme: 'grid'
	});
	
}

function addAutoTblRDIncAss(doc,position){
	var columns =[];
	var rows = [];
	
	$("#RDIncAsstbl thead tr:first th").each(function(i){
		
		if(i==1)return;
		
		var hdrText=$(this).find(">div").find('div').text();
		columns.push(hdrText);
	});
	
	$("#RDIncAsstbl tbody tr").each(function(){
		
		var rowdata=[];
		$(this).find("td").each(function(i){
			
			if(i==1)return;
			
			var cellData=$(this).find("input:first").val();
			
			if(i==0){
				var subtext=$(this).find("span:first").text();
				
				rowdata.push(subtext);
				return;
			}
			
			if(i==4 || i==8){
				var subtext=$(this).find("select:first").val();
				
				rowdata.push(subtext);
				return;
			}
			
			rowdata.push(cellData);
			
			
		});
		
		rows.push(rowdata);
	});
	
	
//	doc.autoTable(columns,rows,{styles: {overflow: 'linebreak',columnWidth: 'wrap'},startY: 20,columnStyles: {note: {columnWidth: 'auto'}}});
	doc.autoTable(columns,rows,{
	     startY:(isEmpty(position)?20:position),
//        afterPageContent: footer,
        margin:{left:10,right:10}/*{ horizontal: 5 }*/,
        bodyStyles: { valign: 'top' },
        styles:{overflow:'linebreak',halign:'left', columnWidth: 'wrap'},
        headerStyles: {
            fillColor: [51, 122, 183],
            textColor: [255],
            halign: 'center',
            overflow: 'linebreak',
            columnWidth: 'wrap'	
        },
        columnStyles: {
        	0: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	4: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	5: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	6: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	8: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'},
        	9: {columnWidth: 'wrap',halign:'right',overflow:'linebreak'}
        },
        //theme: 'striped'
        theme: 'grid'
	});
	
}


function ReplaceAt(input, search, replace, start, end) {
	return input.slice(0, start)
	+ input.slice(start, end).replace(search, replace)
  + input.slice(end);
}

function footer(doc,leftAlign){ 
    //doc.text(10,doc.internal.pageSize.height - 10, 'page ' + doc.page); //print number bottom right
	doc.text(doc.internal.pageSize.width-20,doc.internal.pageSize.height - 10, 'Page ' + doc.page);
	
	doc.text(190+leftAlign,doc.internal.pageSize.height - 10,"Avallis Financial Pte Ltd");
	doc.text(145+leftAlign,doc.internal.pageSize.height-5,"24, Raffles Place, #14-02  Clifford Centre,SINGAPORE,048621");
	
	var today=new Date();
	
	doc.text(10,doc.internal.pageSize.height - 10,"Report Printed on : -"+today.format("dd/mm/yyyy h:MM TT"));
	doc.text(10,doc.internal.pageSize.height-5,"Retirement Planning Cash Flow Analysis");
	
	doc.page ++;
};

function pdfheader(doc,LeftAlign){ 
	doc.text(LeftAlign,7,"Retirement Planning Cash Flow Analysis");
};


function savePdf(pdf){
	var dte=new Date(); 
    var fileName="Rpt"+"_"+dte.getDate()+(dte.getMonth()+1)+dte.getFullYear()+"_"+dte.getHours()+dte.getMinutes()+dte.getSeconds();
    
    pdf.save(''+fileName+'.pdf');
    
    hideLoader();	
    $("#rpCashFlwAnlys_Dialog .btn-group").show();
    $("#rpCashFlwAnlys_Dialog .pdf-hide").show();
}
