package com.fipa.service;

 
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
 



import com.fipa.db.AttachmentDB;
import com.fipa.db.ClientDB;  
import com.fipa.db.MasterDB;
import com.fipa.dbinterface.DBInterface;   
import com.fipa.dto.FnaAdvDeclare;
import com.fipa.dto.FnaApptypes; 
import com.fipa.dto.FnaAssetCashdets;
import com.fipa.dto.FnaAssetOtherdets; 
import com.fipa.dto.FnaContingencyDets; 
import com.fipa.dto.FnaCurassDets;
import com.fipa.dto.FnaExpenditureDets;
import com.fipa.dto.FnaFinLiability;
import com.fipa.dto.FnaInvsetmentSummary; 
import com.fipa.dto.FnaLifeinsuranceDets;  
import com.fipa.dto.FnaPersprio;
import com.fipa.dto.FnaRetireplanDets;
import com.fipa.dto.FnaRiskprefDets;
import com.fipa.dto.FnaSelfspouseDets;
import com.fipa.dto.FnaSrcofincome;
import com.fipa.dto.FnaSummaryAnalysis; 
import com.fipa.dbinterface.DBInterfaceImpl; 
import com.fipa.util.FipaConstant;
import com.fipa.util.FipaDateUtils;
import com.fipa.util.FipaUtils;





	
public class ClientService {
	
	public List getLoginMsgDets(){
		ClientDB clientDB = new ClientDB();
		return clientDB.getLoginMsgDets();
	}
	
		
	
	public List<FnaApptypes> getAllAnalysisTypes(){
		ClientDB clientDB = new ClientDB();
		return clientDB.getAllAnalysisTypes();
	}
	
	
	public ArrayList<String> saveClientDetails(Vector vectDeptDetails,Vector vectExpFdFlowDetails,Vector vectContPlnDetails,
				Vector vectHlthInsDetails,Vector vectPropOwnDetails,Vector vectVehOwnDetails,
				Vector vectLIPDetails,Vector vectIpInvstDetails,Vector vectOthpers,Vector vectSavingInvDetails,
				Vector vectRcmPrdDetails, Vector vectRcmPrdPlnDetails,
				Vector vectRcmPrdFundDetails,Vector vectSwtPlnDetails,
				Vector vectSwtFundDetails,Vector vectChildDetails, Vector vectFinGoalsDetails,
				Vector vectAnalysisType,Vector vectCpfMonthlyCtrb ,Vector vectCpfTopUpCtrb, Vector vectCpfDedtnCtrb,
				Vector vectAssetdetails,Vector vectOthArCrndetails,Vector vectReasonsdetails,
				Vector vectCPFBalanceDets,Vector vectCashOfBankDetails,Vector vectCpfAddtnDedtnCtrb,Vector vectEstPlan,
				 Vector vectInputInvest,Vector vectLifeInsCovPlan,Vector vectliMvRetDetails,Vector vectliChildDets,
				 Vector vectLiBenefits,Vector vectNomNamedetails,Vector vectliPlanAndProDetails,
				 Vector vectOthRetPlg,Vector vectIncRetPlg,Vector vectAttchDetails,
				HttpServletRequest request ){
	
			
		ClientDB clientDB = new ClientDB();
		AttachmentDB attDB = new AttachmentDB();
		HttpSession session  = request.getSession(false);
		
		 Map<String,Object> objMapping  = new HashMap();
		 objMapping = FipaUtils.getRequestMapping(request);
		 
		 Map<String,String> sessMap    = new HashMap<String,String>();
		 sessMap = (HashMap<String, String>)session.getAttribute(FipaConstant.LOGGED_USER_INFO);
		 String strCrtdUser = (String)sessMap.get(FipaConstant.LOGGED_USER_ID);
		 
		 String strClientId = "";
		 String strClientName = "";
		 String strClientNric = "";
		 
		 ArrayList<String> strArrDets=new ArrayList<String>();
		 String strLICId = FipaUtils.getParamValue(request, "lipId");
		 
		 
			
		 FnaSelfspouseDets selfspsDets = new FnaSelfspouseDets();
		 
		 if(objMapping.containsKey(FipaConstant.SLFSPS_DETS)){
			 
			 selfspsDets = (FnaSelfspouseDets)objMapping.get(FipaConstant.SLFSPS_DETS);
			 
			 String strSlfDOB        = FipaUtils.getParamValue(request, "dfSelfDob");
			 Date dateSlfDOB         = FipaDateUtils.convertStringToDate(strSlfDOB);
			
		     String strSpsDOB        = FipaUtils.getParamValue(request, "dfSpsDob");
			 Date dateSpsDOB         = FipaDateUtils.convertStringToDate(strSpsDOB);
			 
			 String strAdvId = FipaUtils.getParamValue(request,"advstfId");
			 String strAdvMgrId = FipaUtils.getParamValue(request, "mgrId");	

			 selfspsDets.setDfSelfDob(dateSlfDOB);
			 selfspsDets.setDfSpsDob(dateSpsDOB);
			  
			 selfspsDets.setAdvstfId(strAdvId);
				 
			 selfspsDets.setMgrId(strAdvMgrId);
			 selfspsDets.setFnaType("FULLFACT");	 
			 selfspsDets.setDfCreatedBy(strCrtdUser);
			 selfspsDets.setDfCreatedDate(new Date());
			 selfspsDets.setDfCreatedDatetime(new Date());
			 
			 strClientId  = clientDB.saveClientDetails(selfspsDets); 
			 strArrDets.add(strClientId);
			 strArrDets.add(selfspsDets.getDfSelfName());
			 strArrDets.add(selfspsDets.getDfSelfNric());
			 
		 }
		 
		 clientDB.saveChilddetails(vectChildDetails,strClientId);
		 
		 clientDB.saveFinGoalsdetails(vectFinGoalsDetails,strClientId);
		 
		  
		 
		 clientDB.saveAppTypesDetails(vectAnalysisType,strClientId);		 
		 
		 clientDB.saveDepdetails(vectDeptDetails,strClientId);
		 
//		 clientDB.saveExpFDFlwdetails(vectExpFdFlowDetails,strClientId);		
		 
		 if(objMapping.containsKey(FipaConstant.ADVDECLR_DETS)){
			 FnaAdvDeclare fnaAdvDclDets    = new FnaAdvDeclare();
			 fnaAdvDclDets = (FnaAdvDeclare)objMapping.get(FipaConstant.ADVDECLR_DETS);
			 
			 fnaAdvDclDets.setAdvDecCrtdBy(strCrtdUser);
			 fnaAdvDclDets.setAdvDecCrtdDate(new Date());
			 
			 clientDB.saveAdvDeclareDetails(fnaAdvDclDets,strClientId);			 
		 }		 
		 
		 clientDB.saveSAInvdetails(vectSavingInvDetails,strClientId);
		 
		 clientDB.saveCPFBalanDets(vectCPFBalanceDets,strClientId);
		 clientDB.saveCpfMtlyCtbDetails(vectCpfMonthlyCtrb,strClientId);
//		 clientDB.saveCpfTopupsDetails(vectCpfTopUpCtrb,strClientId);
//		 clientDB.saveCpfDedtDetails(vectCpfDedtnCtrb,strClientId);
		 
		 if(objMapping.containsKey(FipaConstant.EXP_DETS)){
			 
			 FnaExpenditureDets fnaExpDets    = new FnaExpenditureDets();
			 fnaExpDets = (FnaExpenditureDets)objMapping.get(FipaConstant.EXP_DETS);
			 
			 fnaExpDets.setExpdCreatedBy(strCrtdUser);
			 fnaExpDets.setExpdCreatedDate(new Date());
			 
			 clientDB.saveExpenditureDetails(fnaExpDets,strClientId);
		}
		 
		 
		 clientDB.saveAssetsDetails(vectAssetdetails,strClientId);
		 clientDB.saveOthArOfCnDetails(vectOthArCrndetails,strClientId);
		 clientDB.saveReasonsDetails(vectReasonsdetails,strClientId);
		 
		 
		 	if(objMapping.containsKey(FipaConstant.CONTG_DETS)){
			 
		 		FnaContingencyDets fnaContgDets   = new FnaContingencyDets();
		 		fnaContgDets = (FnaContingencyDets)objMapping.get(FipaConstant.CONTG_DETS);
		 		fnaContgDets.setContCrtdBy(strCrtdUser);
		 		fnaContgDets.setContCrtdDate(new Date());
				
		 		clientDB.saveContgDetails(fnaContgDets,strClientId);
					
				}

		 	 if(objMapping.containsKey(FipaConstant.PERS_DETS)){
				 
				 FnaPersprio fnaPersDets    = new FnaPersprio();
				 fnaPersDets = (FnaPersprio)objMapping.get(FipaConstant.PERS_DETS);
				 
				 fnaPersDets.setPpCreatedBy(strCrtdUser);
				 fnaPersDets.setPpCreatedDate(new Date());
				 
				 clientDB.savePersPrioDetails(fnaPersDets,strClientId);
			 }
//		 clientDB.saveContgPlndetails(vectContPlnDetails,strClientId);		
		 
		 
		if(objMapping.containsKey(FipaConstant.SRCOFINC_DETS)){
			 
			 FnaSrcofincome fnaSrcOfincDets    = new FnaSrcofincome();
			 fnaSrcOfincDets = (FnaSrcofincome)objMapping.get(FipaConstant.SRCOFINC_DETS);
			 
			 fnaSrcOfincDets.setIncsrcCreatedBy(strCrtdUser);
			 fnaSrcOfincDets.setIncsrcCreatedDate(new Date());			
			 clientDB.saveSrcOfIncDetails(fnaSrcOfincDets,strClientId);

		 }	
		
		 clientDB.saveHIdetails(vectHlthInsDetails,strClientId);
			
		  
		
		if(objMapping.containsKey(FipaConstant.FNLBTY_DETS)){
			
			FnaFinLiability fnaFinLbltyDets    = new FnaFinLiability();
			fnaFinLbltyDets = (FnaFinLiability)objMapping.get(FipaConstant.FNLBTY_DETS);
			
			fnaFinLbltyDets.setLiabCreatedBy(strCrtdUser);
			fnaFinLbltyDets.setLiabCreatedDate(new Date());
			
			clientDB.saveFinLbltyDetails(fnaFinLbltyDets,strClientId);			
		}

		clientDB.savePropOwndetails(vectPropOwnDetails,strClientId); 
		 
		
		if(objMapping.containsKey(FipaConstant.CURASS_DETS)){		
			
			FnaCurassDets fnaCurAssDets    = new FnaCurassDets();
			fnaCurAssDets = (FnaCurassDets)objMapping.get(FipaConstant.CURASS_DETS);
			
			fnaCurAssDets.setCaCreatedBy(strCrtdUser);
			fnaCurAssDets.setCaCreatedDate(new Date());
			
			clientDB.saveCurAssDetails(fnaCurAssDets,strClientId);
			
		}
		
		if(objMapping.containsKey(FipaConstant.RETPLN_DETS)){
			
			FnaRetireplanDets fnaRetirePlnDets    = new FnaRetireplanDets();
			fnaRetirePlnDets = (FnaRetireplanDets)objMapping.get(FipaConstant.RETPLN_DETS);
			
			fnaRetirePlnDets.setRetCreatedBy(strCrtdUser);
			fnaRetirePlnDets.setRetCreatedDate(new Date());
			
			clientDB.saveRetirePlnDetails(fnaRetirePlnDets,strClientId);
			
		}
			
		 clientDB.saveVehOwndetails(vectVehOwnDetails,strClientId);
		
		
		if(objMapping.containsKey(FipaConstant.INVST_DETS)){
			
			FnaInvsetmentSummary fnaInvstDets    = new FnaInvsetmentSummary();
			fnaInvstDets = (FnaInvsetmentSummary)objMapping.get(FipaConstant.INVST_DETS);
			
			fnaInvstDets.setInvCreatedBy(strCrtdUser);
			fnaInvstDets.setInvCreatedDate(new Date());
			
			clientDB.saveInvstDetails(fnaInvstDets,strClientId);			
		}
		
		if(objMapping.containsKey(FipaConstant.CSHASS_DETS)){
			
			FnaAssetCashdets fnaCashAssDets  = new FnaAssetCashdets();
			fnaCashAssDets = (FnaAssetCashdets)objMapping.get(FipaConstant.CSHASS_DETS);
			
			fnaCashAssDets.setCasstCreatedBy(strCrtdUser);
			fnaCashAssDets.setCasstCreatedDate(new Date());
			
			clientDB.saveCashAssDetails(fnaCashAssDets,strClientId);			
		}
		

//		 clientDB.saveLipInsurncedetails(vectLIPDetails,strClientId);
		 
		
		if(objMapping.containsKey(FipaConstant.OTHASS_DETS)){
			
			FnaAssetOtherdets fnaOthAssDets    = new FnaAssetOtherdets();
			fnaOthAssDets = (FnaAssetOtherdets)objMapping.get(FipaConstant.OTHASS_DETS);
			
			fnaOthAssDets.setOthasstCreatedBy(strCrtdUser);
			fnaOthAssDets.setOthasstCreatedDate(new Date());
			
			clientDB.saveOthAssDetails(fnaOthAssDets,strClientId);
			
		}
		

		 clientDB.saveIpInvstdetails(vectIpInvstDetails,strClientId);
		
		 
		 if(objMapping.containsKey(FipaConstant.RSKPREF_DETS)){
				
			 FnaRiskprefDets fnaRskPrefDets    = new FnaRiskprefDets();
			 fnaRskPrefDets = (FnaRiskprefDets)objMapping.get(FipaConstant.RSKPREF_DETS);
				
			 fnaRskPrefDets.setCrCreatedBy(strCrtdUser);
			 fnaRskPrefDets.setCrCreatedDate(new Date());
				
				clientDB.saveRskPrefDetails(fnaRskPrefDets,strClientId);
				
			}
		 
		 if(objMapping.containsKey(FipaConstant.SANAL_DETS)){
				
			 FnaSummaryAnalysis fnaSmAnalysisDets    = new FnaSummaryAnalysis();
			 fnaSmAnalysisDets = (FnaSummaryAnalysis)objMapping.get(FipaConstant.SANAL_DETS);
				
			 fnaSmAnalysisDets.setSaCreatedBy(strCrtdUser);
			 fnaSmAnalysisDets.setSaCreatedDate(new Date());
				
				clientDB.saveSAnalDetails(fnaSmAnalysisDets,strClientId);
				
			}
		
 
		 
		 
		 
		 
		 clientDB.saveOthPerDetails(vectOthpers,strClientId);
		 clientDB.saveEstPlanDetails(vectEstPlan,strClientId);
		  
		 
		 clientDB.saveRcmPrdDetails(vectRcmPrdDetails, strClientId);
		 
		 clientDB.saveRcmPrdPlndetails(vectRcmPrdPlnDetails,strClientId);
		 clientDB.saveRcmPrdFunddetails(vectRcmPrdFundDetails,strClientId);
		 
		 clientDB.saveSwtPlndetails(vectSwtPlnDetails,strClientId);
		 clientDB.saveSwtFunddetails(vectSwtFundDetails,strClientId);
		 clientDB.saveCashAtBankdetails(vectCashOfBankDetails,strClientId);
		 clientDB.saveCADdetails(vectCpfAddtnDedtnCtrb,strClientId); 
		  
		 clientDB.saveInvstdetails(vectInputInvest,strClientId);
		 clientDB.saveRdOthPaymenttails(vectOthRetPlg,strClientId);
		 clientDB.saveRdIncPaymenttails(vectIncRetPlg,strClientId);

		  
		 attDB.saveCustAttDetails(vectAttchDetails,strClientId);
		 
		 
		 
		 //Life Insurance Details 
		 if(objMapping.containsKey(FipaConstant.LIFEINSRCE_DETS)){
				
			 FnaLifeinsuranceDets fnaLifeInsurceDets    = new FnaLifeinsuranceDets();
			 fnaLifeInsurceDets = (FnaLifeinsuranceDets)objMapping.get(FipaConstant.LIFEINSRCE_DETS);
			 
			 
			 String lipIncepdate        = FipaUtils.getParamValue(request, "lipIncepdate");
			 Date dteLipIncepdate         = FipaDateUtils.convertStringToDate(lipIncepdate);
			 fnaLifeInsurceDets.setLipIncepdate(dteLipIncepdate);
			
		     String lipMaturityDate        = FipaUtils.getParamValue(request, "lipMaturityDate");
			 Date dteLipMaturityDate         = FipaDateUtils.convertStringToDate(lipMaturityDate);
			 fnaLifeInsurceDets.setLipMaturityDate(dteLipMaturityDate);
			   
			 String strLICRefId = FipaUtils.getParamValue(request, "lipRefId");
			 
			 
			 if(FipaUtils.nullOrBlank(strLICId)){ 
				 fnaLifeInsurceDets.setLipCreatedBy(strCrtdUser);
				 fnaLifeInsurceDets.setLipCreatedDate(new Date());
				 fnaLifeInsurceDets.setLipRefId(strLICRefId);
				 strLICId=clientDB.saveLifeInsrceDetails(fnaLifeInsurceDets,strClientId);
				 
				
			 }else{ 
				 fnaLifeInsurceDets.setLipRefId(strLICRefId);
				 fnaLifeInsurceDets.setLipModifiedBy(strCrtdUser);
				 fnaLifeInsurceDets.setLipModifiedDate(new Date());
				
				 fnaLifeInsurceDets.setFnaSelfspouseDets(selfspsDets);
				 clientDB.updLifeInsrceDetails(fnaLifeInsurceDets);
				 
			 }
				
			}
		 
		  
		 clientDB.saveLifeInsCoverageDetails(vectLifeInsCovPlan,strClientId,strLICId); 
		 clientDB.saveRetPlgdetails(vectliMvRetDetails,strClientId,strLICId);
		 clientDB.saveEduPlgdetails(vectliChildDets,strClientId,strLICId);
		 clientDB.saveBenefdetails(vectLiBenefits,strClientId,strLICId);
		 clientDB.saveNomineeNamedetails(vectNomNamedetails,strClientId,strLICId);
		 clientDB.savePlnProdetails(vectliPlanAndProDetails,strClientId,strLICId);
		 
		 
		 
		 
		return strArrDets;
		 
		 
		 
	}
		
		public String updateClientDetails(Vector vectDeptDetails,Vector vectExpFdFlowDetails,Vector vectContPlnDetails,
				Vector vectHlthInsDetails,Vector vectPropOwnDetails,Vector vectVehOwnDetails,
				Vector vectLIPDetails,Vector vectIpInvstDetails,Vector vectOthpers,Vector vectSavingInvDetails,
				Vector vectRcmPrdDetails,Vector vectRcmPrdPlnDetails,Vector vectRcmPrdFundDetails,
				Vector vectSwtPlnDetails,Vector vectSwtFundDetails,Vector vectChildDetails,
				Vector vectFinGoalsDetails,Vector vectAnalysisType,Vector vectCpfMonthlyCtrb, Vector vectCpfTopUpCtrb, Vector vectCpfDedtnCtrb,
				Vector vectAssetdetails,Vector vectOthArCrndetails,Vector vectReasonsdetails,
				Vector vectCPFBalanceDets,Vector vectCashOfBankDetails,Vector vectCpfAddtnDedtnCtrb,Vector vectEstPlan,
				 Vector vectInputInvest,Vector vectLifeInsCovPlan,Vector vectliMvRetDetails,Vector vectliChildDets,
				 Vector vectLiBenefits,Vector vectNomNamedetails,Vector vectliPlanAndProDetails,
				 Vector vectOthRetPlg,Vector vectIncRetPlg,Vector vectAttchDetails,
				 HttpServletRequest request ){
 
			
			ClientDB clientDB = new ClientDB();
			AttachmentDB attDB = new AttachmentDB();
			HttpSession session           = request.getSession(false);
			
			 Map<String,Object> objMapping  = new HashMap();
			 objMapping = FipaUtils.getRequestMapping(request);
			  
			 
			 Map<String,String> sessMap    = new HashMap<String,String>();
			 sessMap                       = (HashMap<String, String>)session.getAttribute(FipaConstant.LOGGED_USER_INFO);
			 String strCrtdUser = (String)sessMap.get(FipaConstant.LOGGED_USER_ID);
			  
			 String strClientId = request.getParameter("fnaId");
			 String strLICId = request.getParameter("lipId");
			 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
			 selFnaSelfSpouseDets.setFnaId(strClientId);
			  
			 
			 if(objMapping.containsKey(FipaConstant.SLFSPS_DETS)){
				 
				 
				 
				 FnaSelfspouseDets selfspsDets = (FnaSelfspouseDets)objMapping.get(FipaConstant.SLFSPS_DETS);
				 
				 strClientId = selfspsDets.getFnaId();
				 
				 String strSlfDOB        = FipaUtils.getParamValue(request, "dfSelfDob");
				 Date dateSlfDOB         = FipaDateUtils.convertStringToDate(strSlfDOB);
				
			     String strSpsDOB        = FipaUtils.getParamValue(request, "dfSpsDob");
				 Date dateSpsDOB         = FipaDateUtils.convertStringToDate(strSpsDOB);
				 
				 String strAdvId = FipaUtils.getParamValue(request,"advstfId");
				 String strAdvMgrId = FipaUtils.getParamValue(request, "mgrId");	

				 selfspsDets.setDfSelfDob(dateSlfDOB);
				 selfspsDets.setDfSpsDob(dateSpsDOB);
				  		 
				 selfspsDets.setAdvstfId(strAdvId);
					 
				 selfspsDets.setMgrId(strAdvMgrId);
					
				 selfspsDets.setFnaType("FULLFACT");
				 selfspsDets.setDfModifiedBy(strCrtdUser);
				 selfspsDets.setDfModifiedDate(new Date());				 
				 selfspsDets.setDfCreatedDatetime(new Date());
				 clientDB.updateClientDetails(selfspsDets);
				 
			 }
			 
			 clientDB.saveChilddetails(vectChildDetails,strClientId);
			 clientDB.saveFinGoalsdetails(vectFinGoalsDetails,strClientId);
			 
		 
			 clientDB.saveAppTypesDetails(vectAnalysisType,strClientId);
	 
			 clientDB.saveDepdetails(vectDeptDetails,strClientId);
			 
//			 clientDB.saveExpFDFlwdetails(vectExpFdFlowDetails,strClientId);
			 
			
			 if(objMapping.containsKey(FipaConstant.ADVDECLR_DETS)){
				 FnaAdvDeclare fnaAdvDclDets    = new FnaAdvDeclare();
				 fnaAdvDclDets = (FnaAdvDeclare)objMapping.get(FipaConstant.ADVDECLR_DETS);
				 
				 String strAdvDclId=fnaAdvDclDets.getAdvDecId();
				 
				 if(FipaUtils.nullOrBlank(strAdvDclId)){
					 
					 fnaAdvDclDets.setAdvDecCrtdBy(strCrtdUser);
					 fnaAdvDclDets.setAdvDecCrtdDate(new Date());
					 
					 clientDB.saveAdvDeclareDetails(fnaAdvDclDets,strClientId);
					 
				 }else{
					 
					 fnaAdvDclDets.setAdvDecModBy(strCrtdUser);
					 fnaAdvDclDets.setAdvDecModDate(new Date());
					 fnaAdvDclDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 
					 clientDB.updateAdvDclDetails(fnaAdvDclDets);
				 }
			 }
			 
			 clientDB.saveSAInvdetails(vectSavingInvDetails,strClientId);
			 clientDB.saveCPFBalanDets(vectCPFBalanceDets,strClientId);
			 clientDB.saveCpfMtlyCtbDetails(vectCpfMonthlyCtrb,strClientId);
//			 clientDB.saveCpfTopupsDetails(vectCpfTopUpCtrb,strClientId);
//			 clientDB.saveCpfDedtDetails(vectCpfDedtnCtrb,strClientId);
			 
			 
			 if(objMapping.containsKey(FipaConstant.EXP_DETS)){
				 
				 FnaExpenditureDets fnaExpDets    = new FnaExpenditureDets();
				 fnaExpDets = (FnaExpenditureDets)objMapping.get(FipaConstant.EXP_DETS);
				 String strExpId=fnaExpDets.getExpdId();
				 
				 if(FipaUtils.nullOrBlank(strExpId)){
					 
					 fnaExpDets.setExpdCreatedBy(strCrtdUser);
					 fnaExpDets.setExpdCreatedDate(new Date());
					 clientDB.saveExpenditureDetails(fnaExpDets,strClientId);
					 
				 }else{
					 
					 fnaExpDets.setExpdModifiedBy(strCrtdUser);
					 fnaExpDets.setExpdModifiedDate(new Date());
					 fnaExpDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 
					 clientDB.updateExpDetails(fnaExpDets);					 
				 }
				 
				
			}
			
			 

			 clientDB.saveAssetsDetails(vectAssetdetails,strClientId);
			 clientDB.saveOthArOfCnDetails(vectOthArCrndetails,strClientId);
			 clientDB.saveReasonsDetails(vectReasonsdetails,strClientId);
		 
			 
				if(objMapping.containsKey(FipaConstant.CONTG_DETS)){
					 
			 		FnaContingencyDets fnaContgDets   = new FnaContingencyDets();
			 		fnaContgDets = (FnaContingencyDets)objMapping.get(FipaConstant.CONTG_DETS);

					 String strContgId = fnaContgDets.getConId();
					 
					 if(FipaUtils.nullOrBlank(strContgId)){
						 
						 fnaContgDets.setContCrtdBy(strCrtdUser);
					 		fnaContgDets.setContCrtdDate(new Date());
							
					 		clientDB.saveContgDetails(fnaContgDets,strClientId);
					 		
					 }else{
						 fnaContgDets.setContModBy(strCrtdUser);
						 fnaContgDets.setContModDate(new Date());
						
						 fnaContgDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
						 clientDB.updContgDetails(fnaContgDets);
					 }
			 		
						
					}
				
				
			 
			  
			 
//			 clientDB.saveContgPlndetails(vectContPlnDetails,strClientId);
			 clientDB.saveHIdetails(vectHlthInsDetails,strClientId);		
			
//			 if(objMapping.containsKey(FipaConstant.PERS_DETS)){
//				 
//				 FnaPersprio fnaPersDets    = new FnaPersprio();
//				 fnaPersDets = (FnaPersprio)objMapping.get(FipaConstant.PERS_DETS);
//				 
//				 String strPersId = fnaPersDets.getTxtFldPersPrioId();
//				 
//				 if(FipaUtils.nullOrBlank(strPersId)){
//					 fnaPersDets.setTxtFldPPCrtdBy(strCrtdUser);
//					 fnaPersDets.setTxtFldPPCrtdDate(new Date());
//				
//					 clientDB.savePersPrioDetails(fnaPersDets,strClientId);
//				 }else{
//					 
//					 fnaPersDets.setTxtFldPPModBy(strCrtdUser);
//					 fnaPersDets.setTxtFldPPModDate(new Date());
//					
//					 fnaPersDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
//					 clientDB.updPersPrioDetails(fnaPersDets);
//				 }
//			
//			}

			if(objMapping.containsKey(FipaConstant.SRCOFINC_DETS)){
				 
				 FnaSrcofincome fnaSrcOfincDets    = new FnaSrcofincome();
				 fnaSrcOfincDets = (FnaSrcofincome)objMapping.get(FipaConstant.SRCOFINC_DETS);
				 
				 String strSrcId = fnaSrcOfincDets.getIncsrcId();
				 
				 if(FipaUtils.nullObj(strSrcId)){
					 fnaSrcOfincDets.setIncsrcCreatedBy(strCrtdUser);
					 fnaSrcOfincDets.setIncsrcCreatedDate(new Date());			
					 clientDB.saveSrcOfIncDetails(fnaSrcOfincDets,strClientId);
				 } else{
					 
					 fnaSrcOfincDets.setIncsrcModifiedBy(strCrtdUser);
					 fnaSrcOfincDets.setIncsrcModifiedDate(new Date());
					 
					 
					 fnaSrcOfincDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.updSrcOfIncDetails(fnaSrcOfincDets);
				 }
				
			}
		
//			if(objMapping.containsKey(FipaConstant.CPF_DETS)){
//				
//				FnaCpfDets fnCpfDets    = new FnaCpfDets();			
//				fnCpfDets = (FnaCpfDets)objMapping.get(FipaConstant.CPF_DETS);
//				
//				String strCpfId = fnCpfDets.getTxtFldCpfId();
//				
//				if(FipaUtils.nullOrBlank(strCpfId)){
//					fnCpfDets.setTxtFldCpfCrtdBy(strCrtdUser);
//					fnCpfDets.setTxtFldCpfCrtdDate(new Date());
//				
//					clientDB.saveCpfDetails(fnCpfDets,strClientId);
//					
//				}else{
//					
//					fnCpfDets.setTxtFldCpfModBy(strCrtdUser);
//					fnCpfDets.setTxtFldCpfModDate(new Date());
//					
//					
//					 fnCpfDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
//					clientDB.updCpfDetails(fnCpfDets);
//				}
//				
//			}
			
			if(objMapping.containsKey(FipaConstant.FNLBTY_DETS)){
				
				FnaFinLiability fnaFinLbltyDets    = new FnaFinLiability();
				fnaFinLbltyDets = (FnaFinLiability)objMapping.get(FipaConstant.FNLBTY_DETS);
				
				String strFinId = fnaFinLbltyDets.getLiabId();
				
				if(FipaUtils.nullOrBlank(strFinId)){
				
					fnaFinLbltyDets.setLiabCreatedBy(strCrtdUser);
					fnaFinLbltyDets.setLiabCreatedDate(new Date());
				
				 	clientDB.saveFinLbltyDetails(fnaFinLbltyDets,strClientId);
				}else{
					fnaFinLbltyDets.setLiabModifiedBy(strCrtdUser);
					fnaFinLbltyDets.setLiabModifiedDate(new Date());
					
					
					 fnaFinLbltyDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.updFinLbltyDetails(fnaFinLbltyDets);
				}
				
			}
			
			if(objMapping.containsKey(FipaConstant.CURASS_DETS)){		
				
				FnaCurassDets fnaCurAssDets    = new FnaCurassDets();
				fnaCurAssDets = (FnaCurassDets)objMapping.get(FipaConstant.CURASS_DETS);
				
				String strCurrAssId = fnaCurAssDets.getCaId();
				
				if(FipaUtils.nullOrBlank(strCurrAssId)){					
					fnaCurAssDets.setCaCreatedBy(strCrtdUser);
					fnaCurAssDets.setCaCreatedDate(new Date());
					
					clientDB.saveCurAssDetails(fnaCurAssDets,strClientId);					
				}else{
					fnaCurAssDets.setCaModifiedBy(strCrtdUser);
					fnaCurAssDets.setCaModifiedDate(new Date());
					 
					 fnaCurAssDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.updCurAssDetails(fnaCurAssDets);
				}
				
				
				
			}
			
			if(objMapping.containsKey(FipaConstant.RETPLN_DETS)){
				
				FnaRetireplanDets fnaRetirePlnDets    = new FnaRetireplanDets();
				fnaRetirePlnDets = (FnaRetireplanDets)objMapping.get(FipaConstant.RETPLN_DETS);
				
				String strRetId = fnaRetirePlnDets.getRetId();
				
				if(FipaUtils.nullOrBlank(strRetId)){
					fnaRetirePlnDets.setRetCreatedBy(strCrtdUser);
					fnaRetirePlnDets.setRetCreatedDate(new Date());
				
					clientDB.saveRetirePlnDetails(fnaRetirePlnDets,strClientId);
				}else{
					fnaRetirePlnDets.setRetModifiedBy(strCrtdUser);
					fnaRetirePlnDets.setRetModifiedDate(new Date());
					
					 fnaRetirePlnDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.updRetirePlnDetails(fnaRetirePlnDets);
				}
				
			}
			
			 clientDB.savePropOwndetails(vectPropOwnDetails,strClientId);
			 clientDB.saveVehOwndetails(vectVehOwnDetails,strClientId);
			
			
			if(objMapping.containsKey(FipaConstant.INVST_DETS)){
				
				FnaInvsetmentSummary fnaInvstDets    = new FnaInvsetmentSummary();
				fnaInvstDets = (FnaInvsetmentSummary)objMapping.get(FipaConstant.INVST_DETS);
				String strInvId = fnaInvstDets.getInvstId();
				
				if(FipaUtils.nullOrBlank(strInvId)){
					fnaInvstDets.setInvCreatedBy(strCrtdUser);
					fnaInvstDets.setInvCreatedDate(new Date());				
				
					clientDB.saveInvstDetails(fnaInvstDets,strClientId);
				}else{
					fnaInvstDets.setInvModifiedBy(strCrtdUser);
					fnaInvstDets.setInvModifiedDate(new Date());	
					
					 fnaInvstDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.updInvstDetails(fnaInvstDets);
				}
			}
			
			if(objMapping.containsKey(FipaConstant.CSHASS_DETS)){
				
				FnaAssetCashdets fnaCashAssDets  = new FnaAssetCashdets();
				fnaCashAssDets = (FnaAssetCashdets)objMapping.get(FipaConstant.CSHASS_DETS);
				String strCashId = fnaCashAssDets.getCasstId();
				
				if(FipaUtils.nullOrBlank(strCashId)){
				
					fnaCashAssDets.setCasstCreatedBy(strCrtdUser);
					fnaCashAssDets.setCasstCreatedDate(new Date());
				
					clientDB.saveCashAssDetails(fnaCashAssDets,strClientId);
				}else{
					fnaCashAssDets.setCasstModifiedBy(strCrtdUser);
					fnaCashAssDets.setCasstModifiedDate(new Date());
					
					 fnaCashAssDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.updCashAssDetails(fnaCashAssDets);
					
				}
			}
			
			if(objMapping.containsKey(FipaConstant.OTHASS_DETS)){
				
				FnaAssetOtherdets fnaOthAssDets    = new FnaAssetOtherdets();
				fnaOthAssDets = (FnaAssetOtherdets)objMapping.get(FipaConstant.OTHASS_DETS);
				String strOthAsstId= fnaOthAssDets.getOthId();
				
				if(FipaUtils.nullOrBlank(strOthAsstId)){
					fnaOthAssDets.setOthasstCreatedBy(strCrtdUser);
					fnaOthAssDets.setOthasstCreatedDate(new Date());
				
					clientDB.saveOthAssDetails(fnaOthAssDets,strClientId);
				}else{
					fnaOthAssDets.setOthasstModifiedBy(strCrtdUser);
					fnaOthAssDets.setOthasstModifiedDate(new Date());
					
					 fnaOthAssDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.updOthAssDetails(fnaOthAssDets);
				}
				
			}
			
//			 clientDB.saveLipInsurncedetails(vectLIPDetails,strClientId);
			 clientDB.saveIpInvstdetails(vectIpInvstDetails,strClientId);
			
			 
			 if(objMapping.containsKey(FipaConstant.RSKPREF_DETS)){
					
				 FnaRiskprefDets fnaRskPrefDets    = new FnaRiskprefDets();
				 fnaRskPrefDets = (FnaRiskprefDets)objMapping.get(FipaConstant.RSKPREF_DETS);
				 String strRiskId=fnaRskPrefDets.getRiskId();
					
				 if(FipaUtils.nullOrBlank(strRiskId)){
					 fnaRskPrefDets.setCrCreatedBy(strCrtdUser);
					 fnaRskPrefDets.setCrCreatedDate(new Date());
					
					 clientDB.saveRskPrefDetails(fnaRskPrefDets,strClientId);
				 }else{
					 fnaRskPrefDets.setCrModifiedBy(strCrtdUser);
					 fnaRskPrefDets.setCrModifiedDate(new Date());
					 
					 fnaRskPrefDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.updRskPrefDetails(fnaRskPrefDets);
					
				 }
					
			}
			 
			 if(objMapping.containsKey(FipaConstant.SANAL_DETS)){
					
				 FnaSummaryAnalysis fnaSmAnalysisDets    = new FnaSummaryAnalysis();
				 fnaSmAnalysisDets = (FnaSummaryAnalysis)objMapping.get(FipaConstant.SANAL_DETS);
				 String strAnalyseId = fnaSmAnalysisDets.getSaId();
					
				 if(FipaUtils.nullOrBlank(strAnalyseId)){
					 fnaSmAnalysisDets.setSaCreatedBy(strCrtdUser);
					 fnaSmAnalysisDets.setSaCreatedDate(new Date());
					
					 clientDB.saveSAnalDetails(fnaSmAnalysisDets,strClientId);
				 }else{
					 fnaSmAnalysisDets.setSaModifiedBy(strCrtdUser);
					 fnaSmAnalysisDets.setSaModifiedDate(new Date());
					
					 fnaSmAnalysisDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.updSumAnlysDetails(fnaSmAnalysisDets);
				 }
			}
			 
			 
			 
			 String strOthPerId = request.getParameter("txtFldOthPerId"); 
			 if(FipaUtils.nullOrBlank(strOthPerId)){ 
				 clientDB.saveOthPerDetails(vectOthpers,strClientId);
			 }else{ 
				 clientDB.updOthPerDetails(vectOthpers,strClientId); 
			 }
			 
			 
			 
			 String strEstPlanId = request.getParameter("txtFldEstPlanId"); 
			 if(FipaUtils.nullOrBlank(strEstPlanId)){ 
				 clientDB.saveEstPlanDetails(vectEstPlan,strClientId);
			 }else{ 
				 clientDB.updEstPlanDetails(vectEstPlan,strClientId);
			 }
			 
			 
			 clientDB.saveRcmPrdDetails(vectRcmPrdDetails, strClientId);
			 
			 clientDB.saveRcmPrdPlndetails(vectRcmPrdPlnDetails,strClientId);
			 clientDB.saveRcmPrdFunddetails(vectRcmPrdFundDetails,strClientId);
		
			 
			 clientDB.saveSwtPlndetails(vectSwtPlnDetails,strClientId);
			 clientDB.saveSwtFunddetails(vectSwtFundDetails,strClientId);
			 clientDB.saveCashAtBankdetails(vectCashOfBankDetails,strClientId);
			 clientDB.saveCADdetails(vectCpfAddtnDedtnCtrb,strClientId); 
//			 clientDB.saveLifeInsuranceDets(vectLifeInscDetails,strClientId);
			  clientDB.saveInvstdetails(vectInputInvest,strClientId);
			  clientDB.saveRdOthPaymenttails(vectOthRetPlg,strClientId);
				 clientDB.saveRdIncPaymenttails(vectIncRetPlg,strClientId);
				 
				 
				 attDB.saveCustAttDetails(vectAttchDetails,strClientId);
				 
			 
			 //Life Insurance Details 
			 if(objMapping.containsKey(FipaConstant.LIFEINSRCE_DETS)){
					
				 FnaLifeinsuranceDets fnaLifeInsurceDets    = new FnaLifeinsuranceDets();
				 fnaLifeInsurceDets = (FnaLifeinsuranceDets)objMapping.get(FipaConstant.LIFEINSRCE_DETS);
				 String strLisId = request.getParameter("lipId");  

				 Date incpdate = FipaUtils.nullOrBlank(request.getParameter("lipIncepdate")) ? new Date() :FipaDateUtils.convertStringToDate(request.getParameter("lipIncepdate")) ;
				 Date matdate = FipaUtils.nullOrBlank(request.getParameter("lipMaturityDate")) ? new Date() :FipaDateUtils.convertStringToDate(request.getParameter("lipMaturityDate")) ;
				 fnaLifeInsurceDets.setLipMaturityDate(incpdate);
				 fnaLifeInsurceDets.setLipIncepdate(matdate);
				 
				 
			  if(FipaUtils.nullOrBlank(strLisId)){
				 fnaLifeInsurceDets.setLipCreatedBy(strCrtdUser);
				 fnaLifeInsurceDets.setLipCreatedDate(new Date());
				  strLICId=clientDB.saveLifeInsrceDetails(fnaLifeInsurceDets,strClientId);
					
				 }else{
					 fnaLifeInsurceDets.setLipModifiedBy(strCrtdUser);
					 fnaLifeInsurceDets.setLipModifiedDate(new Date());
					
					 fnaLifeInsurceDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.updLifeInsrceDetails(fnaLifeInsurceDets);
					 
				 }
					
				}
			 
			 
			 //Life Insurance Coverage
//			 String strLisCovId = request.getParameter("coverId"); 
//			 if(FipaUtils.nullOrBlank(strLisCovId)){ 
//				 clientDB.saveLifeInsCoverageDetails(vectLifeInsCovPlan,strClientId,strLICId);
//			 }else{ 
				 clientDB.saveLifeInsCoverageDetails(vectLifeInsCovPlan,strClientId,strLICId);
//			 }
			
				 clientDB.saveLifeInsCoverageDetails(vectLifeInsCovPlan,strClientId,strLICId);   
				 clientDB.saveRetPlgdetails(vectliMvRetDetails,strClientId,strLICId);
				 clientDB.saveEduPlgdetails(vectliChildDets,strClientId,strLICId);
				 clientDB.saveBenefdetails(vectLiBenefits,strClientId,strLICId);
				 clientDB.saveNomineeNamedetails(vectNomNamedetails,strClientId,strLICId);
				 clientDB.savePlnProdetails(vectliPlanAndProDetails,strClientId,strLICId);
				  
			return strClientId;
		}


		public void deleteClientDetails(Vector vectDeptDetails,Vector vectExpFdFlowDetails,Vector vectContPlnDetails,
				Vector vectHlthInsDetails,Vector vectPropOwnDetails,Vector vectVehOwnDetails,
				Vector vectLIPDetails,Vector vectIpInvstDetails,Vector vectSavingInvDetails,
				Vector vectRcmPrdDetails,Vector vectRcmPrdPlnDetails,Vector vectRcmPrdFundDetails,
				Vector vectSwtPlnDetails,Vector vectSwtFundDetails, Vector vectOthpers,
				Vector vectChildDetails,Vector vectFinGoalsDetails
				,Vector vectCpfMonthlyCtrb, Vector vectCpfTopUpCtrb, Vector vectCpfDedtnCtrb,
				Vector vectAssetdetails,Vector vectOthArCrndetails,Vector vectReasonsdetails,
				Vector vectCashOfBankDetails,Vector vectCpfAddtnDedtnCtrb,Vector vectEstPlan, 
				Vector vectInputInvest,Vector vectLifeInsCovPlan,Vector vectliMvRetDetails,Vector vectliChildDets,
				Vector vectLiBenefits,Vector vectNomNamedetails,Vector vectliPlanAndProDetails,
				Vector vectOthRetPlg,Vector vectIncRetPlg,Vector vectAttchDetails,
				HttpServletRequest request ){
			
			
			// TODO Auto-generated method stub 
			ClientDB clientDB = new ClientDB(); 
			AttachmentDB attDB = new AttachmentDB();
			 HttpSession session           = request.getSession(false);
				
			 Map<String,Object> objMapping  = new HashMap();
			 objMapping = FipaUtils.getRequestMapping(request);
			  
			 
			 Map<String,String> sessMap    = new HashMap<String,String>();
			 sessMap                       = (HashMap<String, String>)session.getAttribute(FipaConstant.LOGGED_USER_INFO);
			 String strCrtdUser = (String)sessMap.get(FipaConstant.LOGGED_USER_ID);
			 
			 String strClientId = request.getParameter("fnaId");
			 String strLICId = request.getParameter("lipId");
			
			
			 
			  
			 
//			 if(objMapping.containsKey("APPTYPES_DETS")){
//				 FnaApptypes fnaApptypes   = new FnaApptypes();
//				 fnaApptypes = (FnaApptypes)objMapping.get("APPTYPES_DETS"); 
//				
//				 	String strApptypesId=fnaApptypes.getAppTypeid();
//				 	  
//				 
//				 if(FipaUtils.nullOrBlank(strApptypesId)){
//					  
//					 clientDB.delAppTypesDets(strApptypesId);  
//				 } 
//				
//			 }

			 
			 clientDB.delAppTypesDets(strClientId); 
			 
			  
			 clientDB.saveChilddetails(vectChildDetails,strClientId);
			 clientDB.saveFinGoalsdetails(vectFinGoalsDetails,strClientId);
				 
		 
			 clientDB.saveDepdetails(vectDeptDetails,strClientId); 
//			 clientDB.saveExpFDFlwdetails(vectExpFdFlowDetails,strClientId);
			 
			 
			
			 if(objMapping.containsKey(FipaConstant.ADVDECLR_DETS)){
				 FnaAdvDeclare fnaAdvDclDets    = new FnaAdvDeclare();
				 fnaAdvDclDets = (FnaAdvDeclare)objMapping.get(FipaConstant.ADVDECLR_DETS);
				 String strAdvDclId=fnaAdvDclDets.getAdvDecId();
				  
				 
				 if(!FipaUtils.nullOrBlank(strAdvDclId)){		
					 
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaAdvDclDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 
					 clientDB.deleteAdvDeclareDetails(fnaAdvDclDets);			 
				 }	
			 }
			 
			 
			 clientDB.saveSAInvdetails(vectSavingInvDetails,strClientId);
			 clientDB.delCpfMtlyCtbDetails(request,strClientId);
			 clientDB.delCpfBalcCtbDetails(request,strClientId);
//			 clientDB.saveCpfTopupsDetails(vectCpfTopUpCtrb,strClientId);
//			 clientDB.saveCpfDedtDetails(vectCpfDedtnCtrb,strClientId);
			 
			 
			 if(objMapping.containsKey(FipaConstant.EXP_DETS)){
				 
				 FnaExpenditureDets fnaExpDets    = new FnaExpenditureDets();
				 fnaExpDets = (FnaExpenditureDets)objMapping.get(FipaConstant.EXP_DETS);
				 String strExpId=fnaExpDets.getExpdId();
				  
				 
				 if(!FipaUtils.nullOrBlank(strExpId)){		
					 
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaExpDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 
					 clientDB.deleteExpenditureDetails(fnaExpDets);			 
				 }				
			}
			 
			 
			 
			 if(objMapping.containsKey(FipaConstant.CONTG_DETS)){
				 
			 		FnaContingencyDets fnaContgDets   = new FnaContingencyDets();
			 		fnaContgDets = (FnaContingencyDets)objMapping.get(FipaConstant.CONTG_DETS);

					 String strContgId = fnaContgDets.getConId();
					 
					 if(FipaUtils.nullOrBlank(strContgId)){
						 
//						 fnaContgDets.set(strCrtdUser);
//					 		fnaContgDets.setTxtFldContCrtdDate(new Date());
							
					 		clientDB.delContgDetails(fnaContgDets);
					 		
					 } 
			 		 
					}
			 
//			 if(objMapping.containsKey(FipaConstant.CONT_DETS)){
//				 
//				 FnaContingencyDets fnaContDets   = new FnaContingencyDets();
//				 fnaContDets = (FnaContingencyDets)objMapping.get(FipaConstant.CONT_DETS);
//				 
//				 String strContId = fnaContDets.getTxtFldContId(); 
//				 
//				 if(!FipaUtils.nullOrBlank(strContId)){		
//					 
//					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
//					 selFnaSelfSpouseDets.setFnaId(strClientId);
//					 
//					 fnaContDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
//					 
//					 clientDB.delContingencyDetails(fnaContDets);
//				 }
//				
//			}
//			 
//			 clientDB.saveContgPlndetails(vectContPlnDetails,strClientId);
			 clientDB.saveHIdetails(vectHlthInsDetails,strClientId);		
			
//			 if(objMapping.containsKey(FipaConstant.PERS_DETS)){
//				  
//				 
//				 FnaPersprio fnaPersDets    = new FnaPersprio();
//				 fnaPersDets = (FnaPersprio)objMapping.get(FipaConstant.PERS_DETS);
//				 
//				 String strPersId = fnaPersDets.getTxtFldPersPrioId(); 
//				 
//				 if(!FipaUtils.nullOrBlank(strPersId)){
//					 
//					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
//					 selFnaSelfSpouseDets.setFnaId(strClientId);
//					 
//					 fnaPersDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
//					 
//					 clientDB.delPersPrioDetails(fnaPersDets);
//				 }
//			
//			}

			if(objMapping.containsKey(FipaConstant.SRCOFINC_DETS)){
				 
				 FnaSrcofincome fnaSrcOfincDets    = new FnaSrcofincome();
				 fnaSrcOfincDets = (FnaSrcofincome)objMapping.get(FipaConstant.SRCOFINC_DETS);
				 
				 String strSrcId = fnaSrcOfincDets.getIncsrcId(); 
				 
				 if(!FipaUtils.nullObj(strSrcId)){
				
					
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaSrcOfincDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.delSrcOfIncDetails(fnaSrcOfincDets);
				 }
				
			}
		
//			if(objMapping.containsKey(FipaConstant.CPF_DETS)){
//				
//				FnaCpfDets fnCpfDets    = new FnaCpfDets();			
//				fnCpfDets = (FnaCpfDets)objMapping.get(FipaConstant.CPF_DETS);
//				
//				String strCpfId = fnCpfDets.getTxtFldCpfId();
////				System.out.println("---------------------------------------->strCpfId"+strCpfId);
//				
//				if(!FipaUtils.nullOrBlank(strCpfId)){
//					
//					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
//					 selFnaSelfSpouseDets.setFnaId(strClientId);
//					
//					 fnCpfDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
//					clientDB.delCpfDetails(fnCpfDets);
//				}
//				
//			}
			
			if(objMapping.containsKey(FipaConstant.FNLBTY_DETS)){
				
				FnaFinLiability fnaFinLbltyDets    = new FnaFinLiability();
				fnaFinLbltyDets = (FnaFinLiability)objMapping.get(FipaConstant.FNLBTY_DETS);
				
				String strFinId = fnaFinLbltyDets.getLiabId();
//				System.out.println("---------------------------------------->strFinId"+strFinId);
				
				if(!FipaUtils.nullOrBlank(strFinId)){
				
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaFinLbltyDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.delFinLbltyDetails(fnaFinLbltyDets);
				}
				
			}
			
			if(objMapping.containsKey(FipaConstant.CURASS_DETS)){		
				
				FnaCurassDets fnaCurAssDets    = new FnaCurassDets();
				fnaCurAssDets = (FnaCurassDets)objMapping.get(FipaConstant.CURASS_DETS);
				
				String strCurrAssId = fnaCurAssDets.getCaId();
//				System.out.println("---------------------------------------->strCurrAssId"+strCurrAssId);
				
				if(!FipaUtils.nullOrBlank(strCurrAssId)){					
				
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaCurAssDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.delCurAssDetails(fnaCurAssDets);
				}
				
				
				
			}
			
			 clientDB.saveRdOthPaymenttails(vectOthRetPlg,strClientId);
			 clientDB.saveRdIncPaymenttails(vectIncRetPlg,strClientId);
			 
			

			 clientDB.saveAssetsDetails(vectAssetdetails,strClientId);
			 clientDB.saveOthArOfCnDetails(vectOthArCrndetails,strClientId);
			 clientDB.saveReasonsDetails(vectReasonsdetails,strClientId);
			
			
			if(objMapping.containsKey(FipaConstant.RETPLN_DETS)){
				
				FnaRetireplanDets fnaRetirePlnDets    = new FnaRetireplanDets();
				fnaRetirePlnDets = (FnaRetireplanDets)objMapping.get(FipaConstant.RETPLN_DETS);
				
				String strRetId = fnaRetirePlnDets.getRetId();
//				System.out.println("---------------------------------------->strRetId"+strRetId);
				
				if(!FipaUtils.nullOrBlank(strRetId)){
					
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					
					 fnaRetirePlnDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.delRetirePlnDetails(fnaRetirePlnDets);
				}
				
			}
			
			 clientDB.savePropOwndetails(vectPropOwnDetails,strClientId);
			 clientDB.saveVehOwndetails(vectVehOwnDetails,strClientId);
			
			
			if(objMapping.containsKey(FipaConstant.INVST_DETS)){
				
				FnaInvsetmentSummary fnaInvstDets    = new FnaInvsetmentSummary();
				fnaInvstDets = (FnaInvsetmentSummary)objMapping.get(FipaConstant.INVST_DETS);
				String strInvId = fnaInvstDets.getInvstId();
//				System.out.println("---------------------------------------->strInvId"+strInvId);
				
				if(!FipaUtils.nullOrBlank(strInvId)){
					
					
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaInvstDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.delInvstDetails(fnaInvstDets);
				}
			}
			
			if(objMapping.containsKey(FipaConstant.CSHASS_DETS)){
				
				FnaAssetCashdets fnaCashAssDets  = new FnaAssetCashdets();
				fnaCashAssDets = (FnaAssetCashdets)objMapping.get(FipaConstant.CSHASS_DETS);
				String strCashId = fnaCashAssDets.getCasstId();
//				System.out.println("---------------------------------------->strCashId"+strCashId);
				
				if(!FipaUtils.nullOrBlank(strCashId)){
				
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					
				
					 fnaCashAssDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.delCashAssDetails(fnaCashAssDets);
					
				}
			}
			
			if(objMapping.containsKey(FipaConstant.OTHASS_DETS)){
				
				FnaAssetOtherdets fnaOthAssDets    = new FnaAssetOtherdets();
				fnaOthAssDets = (FnaAssetOtherdets)objMapping.get(FipaConstant.OTHASS_DETS);
				String strOthAsstId= fnaOthAssDets.getOthId();
//				System.out.println("---------------------------------------->strOthAsstId"+strOthAsstId);
				
				if(!FipaUtils.nullOrBlank(strOthAsstId)){
					
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaOthAssDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					clientDB.delOthAssDetails(fnaOthAssDets);
				}
				
			}
			
//			 clientDB.saveLipInsurncedetails(vectLIPDetails,strClientId);
			 clientDB.saveIpInvstdetails(vectIpInvstDetails,strClientId);
			
			 
			 if(objMapping.containsKey(FipaConstant.RSKPREF_DETS)){
					
				 FnaRiskprefDets fnaRskPrefDets    = new FnaRiskprefDets();
				 fnaRskPrefDets = (FnaRiskprefDets)objMapping.get(FipaConstant.RSKPREF_DETS);
				 String strRiskId=fnaRskPrefDets.getRiskId();
					
//				 System.out.println("---------------------------------------->strRiskId"+strRiskId);
				 
				 if(!FipaUtils.nullOrBlank(strRiskId)){
					 
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaRskPrefDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.delRskPrefDetails(fnaRskPrefDets);
					
				 }
					
			}
			 
			 if(objMapping.containsKey(FipaConstant.SANAL_DETS)){
					
				 FnaSummaryAnalysis fnaSmAnalysisDets    = new FnaSummaryAnalysis();
				 fnaSmAnalysisDets = (FnaSummaryAnalysis)objMapping.get(FipaConstant.SANAL_DETS);
				 String strAnalyseId = fnaSmAnalysisDets.getSaId();
//				 System.out.println("---------------------------------------->strAnalyseId"+strAnalyseId);
					
				 if(!FipaUtils.nullOrBlank(strAnalyseId)){
					 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
					 selFnaSelfSpouseDets.setFnaId(strClientId);
					 
					 fnaSmAnalysisDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
					 clientDB.delSumAnalysDetails(fnaSmAnalysisDets);
				 }
			}
			 
			 
	
			 
			 
			 clientDB.saveRcmPrdDetails(vectRcmPrdDetails, strClientId);
			 
			 clientDB.saveRcmPrdPlndetails(vectRcmPrdPlnDetails,strClientId);
			 clientDB.saveRcmPrdFunddetails(vectRcmPrdFundDetails,strClientId);
			
			 
			 
			 clientDB.saveSwtPlndetails(vectSwtPlnDetails,strClientId);
			 clientDB.saveSwtFunddetails(vectSwtFundDetails,strClientId);
			 clientDB.saveCashAtBankdetails(vectCashOfBankDetails,strClientId);
			 clientDB.saveCADdetails(vectCpfAddtnDedtnCtrb,strClientId); 
//			 clientDB.saveLifeInsuranceDets(vectLifeInscDetails,strClientId);
			 attDB.saveCustAttDetails(vectAttchDetails,strClientId);

			  clientDB.delOthPerDetails(vectOthpers,strClientId);
			 
			  clientDB.delEstPlnDetails(vectEstPlan,strClientId);
			  
			  clientDB.saveInvstdetails(vectInputInvest,strClientId);
			  
			  //Plan Product
			  clientDB.savePlnProdetails(vectliPlanAndProDetails,strClientId,strLICId);
			//Life Insurance Nominees Name 
			  clientDB.saveNomineeNamedetails(vectNomNamedetails,strClientId,strLICId);
			//Life Insurance Benefits 
			  clientDB.saveBenefdetails(vectLiBenefits,strClientId,strLICId);
			//Life Insurance Retirement Plg Details  
			  clientDB.saveRetPlgdetails(vectliMvRetDetails,strClientId,strLICId);
			//Life Insurance Education Plg Details  
			  clientDB.saveEduPlgdetails(vectliChildDets,strClientId,strLICId); 
			//Life Insurance Coverage Details 
			  clientDB.delLifeInsCoverageDetails(vectLifeInsCovPlan,strClientId,strLICId);
			  
			  
			//Life Insurance Details  
			  if(objMapping.containsKey(FipaConstant.LIFEINSRCE_DETS)){
					
				  FnaLifeinsuranceDets fnaLifeInsurceDets    = new FnaLifeinsuranceDets();
				  fnaLifeInsurceDets = (FnaLifeinsuranceDets)objMapping.get(FipaConstant.LIFEINSRCE_DETS);
					
				  strLICId = fnaLifeInsurceDets.getLipId(); 
					 
					 
					 if(!FipaUtils.nullOrBlank(strLICId)){
						 FnaSelfspouseDets  selFnaSelfSpouseDets = new FnaSelfspouseDets();
						 selFnaSelfSpouseDets.setFnaId(strClientId);
						 
						 fnaLifeInsurceDets.setFnaSelfspouseDets(selFnaSelfSpouseDets);
						 clientDB.delLifeInsurceDetails(fnaLifeInsurceDets);
					 }
			  	}
			  

			
			  
			  if(objMapping.containsKey(FipaConstant.SLFSPS_DETS)){ 
				 
			 
				 FnaSelfspouseDets selfspsDets = (FnaSelfspouseDets)objMapping.get(FipaConstant.SLFSPS_DETS);
				 
				 strClientId = selfspsDets.getFnaId(); 
				 
				 String strAdvId = FipaUtils.getParamValue(request,"advstfId");
				 String strAdvMgrId = FipaUtils.getParamValue(request, "mgrId");	
  
				 selfspsDets.setAdvstfId(strAdvId);
					 
				 selfspsDets.setMgrId(strAdvMgrId);
				  
				 
				 clientDB.deleteClientDetails(selfspsDets);
				 
			 }
			
			 
			 
					
		}
		
	
	 public List clientSearch(DBInterface dao,String ... strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clientSearch(dao, strBufQryParam);
	 }
	 
	 public List clientNRICSearch(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clientNRICSearch(dao, strBufQryParam);
	 }
		 
	 
	 public List clntLifeInsSearch(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clntLifeInsSearch(dao, strBufQryParam);
	 }
	 
	 public List clntLifeInsList(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clntLifeInsList(dao, strBufQryParam);
	 }
	 public List clntLifeCovSearch(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clntLifeCovSearch(dao, strBufQryParam);
	 }
	 public List clntLifePlanDetsSearch(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clntLifePlanDetsSearch(dao, strBufQryParam);
	 }
	 public List clntLifeBenfSearch(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clntLifeBenfSearch(dao, strBufQryParam);
	 }
	 public List clntLifeChldEduSearch(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clntLifeChldEduSearch(dao, strBufQryParam);
	 }
	 public List clntLifeMVSearch(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clntLifeMVSearch(dao, strBufQryParam);
	 }
	 public List clntLifeNomSearch(DBInterface dao,String strBufQryParam){
		 ClientDB db = new ClientDB();		 
		 return db.clntLifeNomSearch(dao, strBufQryParam);
	 }
	 public List openClientProfileList(DBInterfaceImpl dao,String params){
		 ClientDB db = new ClientDB();		 
		 return db.openClientProfileList(dao, params);
	 }
	
	 
	 public List openClientProfile(DBInterfaceImpl dao,String ... params){
		 ClientDB db = new ClientDB();		 
		 return db.openClientProfile(dao, params);
	 }
	 
	 public List openClntProfAppTypes(DBInterfaceImpl dao,String ... params){
			
		 ClientDB db = new ClientDB();		 
		 return db.openAppTypes(dao, params);
	 }
	 
	 public List openClntProfAnalyTypes(DBInterfaceImpl dao,String ... params){
			
		 ClientDB db = new ClientDB();		 
		 return db.openClntProfAnalyTypes(dao, params);
	 }
	 
	 public List openAdvDclProfile(DBInterfaceImpl dao,String ... params){
			
		 ClientDB db = new ClientDB();		 
		 return db.openAdvDeclare(dao, params);
	 }
	 
	 public List openExpProfile(DBInterfaceImpl dao,String ... params){
		
		 ClientDB db = new ClientDB();		 
		 return db.openExpenditure(dao, params);
	 }
	 
	 public List openClntContgProfile(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
		 ClientDB db = new ClientDB();		 
		 return db.openContg(dao, params);
	}
	 
//	 public List openContProfile(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//		 ClientDB db = new ClientDB();		 
//		 return db.openContingency(dao, params);
//	}
		public List openPerpProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openPerprio(dao, params);
		}
		public List openSrcIncProfile(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openSrcOfInc(dao, params);
		}
//		public List openCpfProfile(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//			ClientDB db = new ClientDB();		 
//			 return db.openCpf(dao, params);
//		}
		public List openFinlbProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openFinLblty(dao, params);
		}
		public List openCrtAssProfile(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openCurAss(dao, params);
		}
		public List openRetProfile(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openRetirepln(dao, params);
		}
		public List openInvProfile(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openInvst(dao, params);
		}
		public List openCasProfile(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openCshAss(dao, params);
		}
		public List openOthCAProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openOthAss(dao, params);
		}
		
		public List openRskPrefProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openRskPref(dao, params);
		}
		public List openSumAnlProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openSumAnl(dao, params);
		}
		
		public List openCdAhocProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openCdAdhoc(dao, params);
		}
		
		
		public List openLifeInsuranceProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openLifeInsuranceProfile(dao, params);
		}
		
		
		
//		public List openOthPerProfile(DBInterfaceImpl dao,String ... params) {
//			// TODO Auto-generated method stub
//			ClientDB db = new ClientDB();		 
//			 return db.openOthPer(dao, params);
//		}
//		
		
		

		public List openEstPlanProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openEstPlan(dao, params);
		}
		
		
		public List openLifeInsCoveProfile(DBInterfaceImpl dao,String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openLifeInsCoveProfile(dao, params);
		}
		
		 public List openClntProfChild(DBInterfaceImpl dao,String ... params){
			 ClientDB db = new ClientDB();		 
			 return db.openClntProfChild(dao, params);
		 }
		 
		 public List openClntProfFinGoals(DBInterfaceImpl dao,String ... params){
			 ClientDB db = new ClientDB();		 
			 return db.openClntProfFinGoals(dao, params);
		 }
		 
	 public List openClntProfDepnt(DBInterfaceImpl dao,String ... params){
		 ClientDB db = new ClientDB();		 
		 return db.openClntProfDepnt(dao, params);
	 }
	 public List openClntProfSAInvst(DBInterfaceImpl dao,String ... params){
		 ClientDB db = new ClientDB();		 
		 return db.openClntProfSAInvt(dao, params);
	 }
//	 public List openClntProfFDFlw(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//		 ClientDB db = new ClientDB();		 
//		 return db.openClntProfFDFlw(dao, params);
//		}
//		public List openClntProfCtgDep(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//			ClientDB db = new ClientDB();		 
//			 return db.openClntProfCtgDep(dao, params);
//		}
		
		public List openClntProfAssets(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfAssets(dao, params);
		}
		
		
		
		public List openClntProfRdIncomeAss(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfRdIncomeAss(dao, params);
		}
		
		public List openClntProfArOfConcern(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfArOfConcern(dao, params);
		}
		 

		public List openClntProfRecmReasn(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfRecmReasn(dao, params);
		}
		
//		 public List openClntProfFinGlsPrio(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//			ClientDB db = new ClientDB();		 
//			 return db.openClntProfFinGlsPrio(dao, params);
//		}
		 
		 public List openClntProfCPFBalance(DBInterfaceImpl dao, String ... params){
			 ClientDB db= new ClientDB();
			 return db.openClntProfCPFBalance(dao, params);
		 }
		public List openClntProfCpfMCtb(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfCpfMCtb(dao, params);
		}
//		public List openClntProfCpfTp(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//			ClientDB db = new ClientDB();		 
//			 return db.openClntProfCpfTp(dao, params);
//		}
		
		
//		public List openClntProfCpfDt(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//			ClientDB db = new ClientDB();		 
//			 return db.openClntProfCpfDt(dao, params);
//		}
//		
		public List openClntProfCAD(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfCAD(dao, params);
		}
		
		public List openClntProfHI(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfHI(dao, params);
		}
		public List openClntProfPrpOwn(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfPrpOwn(dao, params);
		}
		public List openClntProfVehOwn(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfVehOwn(dao, params);
		}
		
		public List openClntAttachments(DBInterfaceImpl dao, String... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntAttachments(dao, params);
		}
		
		
		
//		public List openClntProfLIP(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//			ClientDB db = new ClientDB();		 
//			 return db.openClntProfLIP(dao, params);
//		}
		
		public List openClntProfIPINV(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfIPINV(dao, params);
		}
		
		public List openClntProfRcmPrt(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfRcmPrd(dao, params);
		}
		
		public List openClntProfRcmPln(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfRPln(dao, params);
		}
		
		public List openClntProfRcmFd(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfRFd(dao, params);
		}
	 
	public List openClntProfSwtPln(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfSPln(dao, params);
	}
		
		
	 public List openClntProfSwtFd(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfSFd(dao, params);
		} 
		
	 
	 public List openClntProfCashAtBank(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfCashAtBank(dao, params);
	 } 
	 public List openRdOtherIncome(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openRdOtherIncome(dao, params);
	 } 
	 public List openInputInvestment(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openInputInvestment(dao, params);
	 }
	 
	 
//	 public List openClntProfLISDets(DBInterfaceImpl dao, String ... params) {
//			// TODO Auto-generated method stub
//			ClientDB db = new ClientDB();		 
//			 return db.openClntProfLISDets(dao, params);
//	 } 
	 
	 
	 public List openClntProfLIRetPlgDets(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfLIRetPlgDets(dao, params);
	 } 
	 public List openClntProfLIBenefitsDets(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfLIBenefitsDets(dao, params);
	 } 
	 public List openClntProfLINomNamesDets(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfLINomNamesDets(dao, params);
	 } 
	 
	 
	 
	 public List openClntProfLIEduPlgDets(DBInterfaceImpl dao, String ... params) {
			// TODO Auto-generated method stub
			ClientDB db = new ClientDB();		 
			 return db.openClntProfLIEduPlgDets(dao, params);
	 }  
	 
	
	
	public List rcmPrdtSearch(DBInterfaceImpl dao,String strCpfBufQryParam) {
		// TODO Auto-generated method stub
		  ClientDB db = new ClientDB();		 
		 return db.rcmPrdtSearch(dao,strCpfBufQryParam);
	}



	 
	public List searchQuotes(DBInterfaceImpl dao) {
		// TODO Auto-generated method stub
		MasterDB db = new MasterDB();		 
		 return db.searchQuotes(dao);
	}
	

	
}
